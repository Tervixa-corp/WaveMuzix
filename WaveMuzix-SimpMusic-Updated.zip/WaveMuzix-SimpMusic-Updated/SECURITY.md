# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security issue or credential-handling vulnerability in **WaveMuzix**, please report it privately via email before opening a public issue:

- **Email**: `wavemuzix@gmail.com` or `hritvikkrishnansajeev@gmail.com`

We will review and respond to all legitimate reports promptly.
