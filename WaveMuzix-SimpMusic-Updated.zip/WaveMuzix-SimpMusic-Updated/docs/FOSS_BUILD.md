# Building the FOSS (Free & Open Source Software) Version of WaveMuzix

## What is a FOSS Version?

A **FOSS (Free and Open Source Software)** version of an Android app is a build that contains **100% open-source code and libraries**, with zero proprietary binary blobs.

App stores such as **F-Droid** and **IzzyOnDroid** (as well as privacy-focused Android ROMs like **GrapheneOS**, **CalyxOS**, and **LineageOS** without GApps) strictly prohibit proprietary closed-source SDKs—most notably:
1. **Google Play Services Auth & Location** (`com.google.android.gms:play-services-auth`, `play-services-location`)
2. **Firebase SDKs** (`com.google.firebase:firebase-auth`, `firebase-firestore`, `firebase-bom`, and the `com.google.gms.google-services` Gradle plugin)

Just like [SimpMusic](https://github.com/maxrave-dev/SimpMusic) provides both a `full` flavor and a `foss` flavor, you can build a `foss` flavor of **WaveMuzix** where all music streaming, `FEmusic_home` scraping, word-by-word lyrics, local Room database analytics, offline downloads, and local JSON backup/restore work identically—while replacing Firebase Cloud Sync with a no-op stub.

---

## Step-by-Step Guide to Adding the `foss` & `full` Product Flavors

### 1. Configure Product Flavors in `app/build.gradle.kts`

In `app/build.gradle.kts`, only apply the `com.google.gms.google-services` plugin when building the `full` flavor, and define `full` and `foss` flavors under `android { ... }`:

```kotlin
flavorDimensions += "distribution"

productFlavors {
    create("full") {
        dimension = "distribution"
        buildConfigField("boolean", "IS_FOSS", "false")
    }
    create("foss") {
        dimension = "distribution"
        applicationIdSuffix = ".foss"
        versionNameSuffix = "-foss"
        buildConfigField("boolean", "IS_FOSS", "true")
    }
}
```

### 2. Scope Proprietary Dependencies to `fullImplementation`

In `app/build.gradle.kts`, change the Firebase and Play Services dependencies from `implementation(...)` to `fullImplementation(...)`:

```kotlin
dependencies {
    // Only included in the "full" build; excluded from the "foss" build:
    "fullImplementation"(platform(libs.firebase.bom))
    "fullImplementation"(libs.firebase.auth.ktx)
    "fullImplementation"(libs.firebase.firestore.ktx)
    "fullImplementation"("com.google.android.gms:play-services-auth:21.1.1")
    "fullImplementation"("com.google.android.gms:play-services-location:21.2.0")
}
```

### 3. Provide Source-Set Implementations (`src/full` vs `src/foss`)

Create two flavor source directories inside `app/src/`:
- `app/src/full/java/com/tervixa/wavemuzix/data/FirebaseSyncManager.kt`: Contains the existing Firebase Auth + Cloud Firestore sync implementation.
- `app/src/foss/java/com/tervixa/wavemuzix/data/FirebaseSyncManager.kt`: Contains a lightweight open-source stub with the exact same method signatures (`syncToFirebase`, `syncFromFirebase`, `incrementPlayCount`) that delegates to `DataBackupManager` (local JSON backup) without importing `com.google.firebase.*`.

### 4. Build the FOSS APK

Run Gradle to assemble the `foss` release or debug APK:

```bash
./gradlew assembleFossDebug
# or for release:
./gradlew assembleFossRelease
```

The resulting APK in `app/build/outputs/apk/foss/` will pass F-Droid's `fdroid scanner` with zero proprietary dependency warnings.
