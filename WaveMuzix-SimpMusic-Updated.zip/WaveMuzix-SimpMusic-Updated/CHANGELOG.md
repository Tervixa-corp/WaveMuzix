# Changelog

## [1.1.0] - 2026-10-19

### Added
- **Minimal & Semi-Modern Analytics Screen**: Complete redesign featuring a dynamic palette Hero Top Song header, Period Navigator, 2x2 borderless Quick Facts, 5-tile `FiveImagesComponent` mosaics for Top Artists & Top Albums, `MusicRatioChart` concentric arcs, 5-axis `FingerprintChart` pentagon radar, 24-hour `ListeningClockChart`, `DecadeChart`, Day/Week/Month timeline, and interactive Receiptify `ShareReceiptSheet`.
- **Apple Liquid Slider**: White active progress track with a low-blur, low-refraction oval liquid pill thumb in the Classic Player and Landscape Video Preview.
- **Landscape Video Gestures**: Added pinch-to-zoom (`1.0x – 3.5x`) with pan support and double-tap left/right (`-5s` / `+5s`) seek with visual badges.
- **Floating Volume Container**: Separated the volume control into its own floating Liquid Glass container above the Player Options Bottom Sheet.
- **YouTube Music `FEmusic_home` Scraper**: Direct `WEB_REMIX` home feed and continuation scraping for both logged-in (`Connect To Wave`) and non-logged-in users.

### Fixed
- **Album Loading (`MPREb_...` & `OLAK5uy_...`)**: Resolved false "No Internet Connection" errors when opening albums by querying `WEB_REMIX` `browse` first and assigning 1:1 square album covers to all album tracks.
- **16:9 Thumbnail Sidebars**: Cropped 16:9 colored pillarbox bars on audio song thumbnails so 1:1 boxes always display clean square covers.
- **Spotify & Discord WebView Logins**: Fixed Discord `/app` & `/channels/@me` token extraction and regional Spotify `/status` `sp_dc` cookie capture, plus added a manual Cookie/Token entry sheet.
- **DJ Transition, SponsorBlock & Skip Silence**: Removed volume fade dips in DJ Transition mode, restricted SponsorBlock strictly to video tracks with pre-trimming before playback start, and disabled tempo-warping beat silence skipping during song intros.
- **Lyrics Matching Accuracy**: Added exact `videoId` lookup and strict title/artist/duration tolerance checks so lyrics never play for the wrong song.
