<div align="center">

# 🌊 WaveMuzix

### **Next-Gen Immersive Music & Video Streaming Client for Android**

[![Platform](https://img.shields.io/badge/Platform-Android%208.0%2B%20(API%2026%2B)-3DDC84?style=for-the-badge&logo=android&logoColor=white)](https://developer.android.com)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.2-7F52FF?style=for-the-badge&logo=kotlin&logoColor=white)](https://kotlinlang.org)
[![Jetpack Compose](https://img.shields.io/badge/UI-Jetpack%20Compose%20%2B%20Liquid%20Glass-4285F4?style=for-the-badge&logo=jetpackcompose&logoColor=white)](https://developer.android.com/compose)
[![Media3](https://img.shields.io/badge/Audio%20Engine-AndroidX%20Media3%20ExoPlayer-FF2D55?style=for-the-badge)](https://developer.android.com/media/media3)
[![License](https://img.shields.io/badge/License-GPLv3-blue?style=for-the-badge)](LICENSE)

<p align="center">
  <b>WaveMuzix</b> blends high-resolution YouTube Music streaming, real-time word-by-word glowing karaoke lyrics, 3D refractive Liquid Glass optics, club-style DJ transitions, and deep listening analytics into one cohesive, zero-compromise Android music experience.
</p>

[Features](#-key-features) •
[Analytics & Receiptify](#-listening-analytics--receiptify) •
[Audio Engine](#-next-gen-audio-engine) •
[Architecture](#-architecture--tech-stack) •
[Build & FOSS Guide](#-building-from-source--foss-flavor) •
[Acknowledgements](#-acknowledgements--credits)

</div>

---

## ✨ Key Features

### 🎨 Dual Player Design & 3D Liquid Glass UI
- **3D Refractive Liquid Glass**: Real-time backdrop blur, lens refraction, vibrancy saturation, and specular 3D borders across floating navigation bars, mini-player, and modal sheets — with a one-tap toggle in Settings to switch between **Liquid Glass** and clean **Solid Matte Grey (`#1C1C1E`)**.
- **Classic & Material 3 Expressive Players**: Switch seamlessly between the **Classic Player** ( featuring an Apple Music white liquid pill slider and containerless transport icons) and the **Material 3 Expressive Player** (with morphing squircle controls and wavy progress bar).
- **Floating Volume & Deep-Frosted Option Sheets**: Detached, floating-in-air volume pill container above a deep-frosted, reduced-brightness options bottom sheet across Home, Search, Library, Queue, Playlists, and Analytics.
- **Interactive Landscape Video Mode**: Instant **Song / Video** mode switcher for tracks with official music videos, complete with pinch-to-zoom (`1.0x – 3.5x`), pan gestures, and double-tap left/right (`-5s` / `+5s`) seeking.

### 🎤 Immersive Word-by-Word Glowing Lyrics
- **Multi-Provider Word-Synced Engine**: Queries **SimpMusic Lyrics**, **BetterLyrics (TTML)**, **LRCLIB**, **Netease (`yrc`)**, **KuGou**, and **Alsong** with strict title, artist, and duration verification so lyrics never mismatch.
- **Word-by-Word Karaoke Glow**: Real-time word-by-word radial glow (`Shadow` illumination) in the inline title lyric strip, the tonal lyrics preview card, and the fullscreen Apple Music blur lyrics overlay.
- **Romanization & Offset Control**: Automatic phonetic romanization for non-Latin scripts and millisecond sync offset tuning.

### 📊 Listening Analytics & Receiptify
- **Minimal, Borderless Insights**: Dynamic palette-tinted analytics with a Hero `#1 Top Song` header, period step navigator (`7d`, `30d`, `90d`, `365d`, `All Time`), and period-over-period `%` deltas.
- **5-Tile Flush Mosaics**: Visual `2:1 + 2x2` artwork mosaics for your **Top Artists** and **Top Albums & Releases**.
- **Advanced Visual Charts**:
  - **Music Ratio Concentric Arcs** (Songs vs. Albums vs. Artists)
  - **5-Axis Listening Fingerprint Radar** (*Consistency*, *Discovery*, *Diversity*, *Concentration*, *Replay*)
  - **24-Hour Radial Listening Clock** (with busiest hour readout)
  - **Release Decade Proportional Bars** & **Day / Week / Month Timeline**
- **Shareable Listening Receipt**: Crinkled paper Receiptify generator with itemized play counts, durations, barcode, and one-tap sharing.

### 🔊 Next-Gen Audio Engine
- **Seamless Crossfade & Club DJ Transition**: Dual-ExoPlayer overlap engine with a dedicated **DJ Transition Mode** that blends outgoing and incoming tracks at full energy without volume fade dips, using midpoint EQ bass handoff.
- **Pre-Trimmed Video SponsorBlock**: Crowd-sourced [SponsorBlock](https://sponsor.ajay.app/) intro/outro/dialogue pre-trimming strictly restricted to music videos (never touching audio songs) so tracks never restart or dip in volume after starting.
- **Non-Tempo-Warping Skip Silence**: Trims non-music dead air at track boundaries without cutting musical pauses between drum beats.
- **Built-In 10-Band AudioFX Equalizer**: 10-band graphic EQ with 22 curated presets, Bass Boost, Loudness Normalization, Anti-Clip Peak Limiter, and Direct Volume Control (Hi-Res DVC).

### 🔗 Connect To Wave & Cloud Sync
- **YouTube Music (`FEmusic_home`)**: Scrape personalized YouTube Music shelves (*Quick picks*, *Listen again*, *Mixed for you*, *New releases*, *Charts*) both as a guest and when signed in via **Connect To Wave**.
- **Spotify (`sp_dc` & Session Scraper)**: Enrich tracks with true multi-singer credits, high-resolution 1:1 album artwork, and Canvas metadata.
- **Last.fm & Discord Rich Presence**: Real-time track scrobbling, Now Playing updates, and live Discord profile presence.
- **Firebase Cloud Backup & Sync**: Automatic per-account cloud backup of your settings, listening analytics, liked songs, playlists, most played tracks, and followed artists.

---

## 🏗️ Architecture & Tech Stack

| Layer | Technology |
| :--- | :--- |
| **UI Framework** | Jetpack Compose (Material 3), Haze Blur, Custom Backdrop Lens Shaders |
| **Media Playback** | AndroidX Media3 (`ExoPlayer`, `MediaSessionService`, Dual-Player Crossfade) |
| **Extraction & Networking** | YouTube Music `WEB_REMIX` InnerTube API, NewPipeExtractor, OkHttp3, Retrofit2 |
| **Persistence & Sync** | Room SQLite Database, SharedPreferences, Firebase Auth & Cloud Firestore |
| **Image Pipeline** | Glide Compose, AndroidX Palette Dynamic Color Extraction |

---

## 🛠️ Building from Source & FOSS Flavor

### Prerequisites
- **Android Studio** Ladybug (2024.2.1) or newer
- **JDK 17+** and **Android SDK 36**

### Standard Build (`full`)
1. Clone the repository:
   ```bash
   git clone https://github.com/Tervixa-Corp/WaveMuzix.git
   cd WaveMuzix
   ```
2. Place your `google-services.json` inside `app/` (already pre-configured for development builds).
3. Build and install the debug APK:
   ```bash
   ./gradlew assembleDebug
   ```

### FOSS Build (`foss` — Free and Open Source Software)
Want to distribute WaveMuzix on **F-Droid**, **IzzyOnDroid**, or run it on de-Googled Android ROMs (GrapheneOS, LineageOS, CalyxOS) without proprietary Google Play Services or Firebase binaries?
- Read the complete step-by-step guide in **[`docs/FOSS_BUILD.md`](docs/FOSS_BUILD.md)**.

---

## 📚 Repository Documentation

- **[`CONTRIBUTING.md`](CONTRIBUTING.md)** — Development setup, code style, and pull request workflow
- **[`docs/FOSS_BUILD.md`](docs/FOSS_BUILD.md)** — How to configure and build the 100% open-source `foss` flavor
- **[`CHANGELOG.md`](CHANGELOG.md)** — Release history and recent architectural upgrades
- **[`PRIVACY_POLICY.md`](PRIVACY_POLICY.md)** — How local storage, cookies, and optional cloud sync are handled
- **[`SECURITY.md`](SECURITY.md)** — Vulnerability reporting guidelines

---

## 🙏 Acknowledgements & Credits

WaveMuzix is developed and maintained by **Tervixa-Corp (Tervixa Forge)**.

Special thanks and gratitude to:
- **[@maxrave-dev](https://github.com/maxrave-dev)** and **[SimpMusic](https://github.com/maxrave-dev/SimpMusic)** — for providing open-source inspiration, lyrics API ecosystem support, and modern music client design ideas.
- **[@z-huang](https://github.com/z-huang)** and **[InnerTune](https://github.com/z-huang/InnerTune)** — for pioneering Material 3 YouTube Music client concepts and InnerTube research that inspired parts of this project.
- **[TeamNewPipe](https://github.com/TeamNewPipe/NewPipeExtractor)** — for the NewPipeExtractor streaming pipeline.
- **[SponsorBlock](https://sponsor.ajay.app/)** & **[LRCLIB](https://lrclib.net/)** — for community-powered segment skipping and synchronized lyrics.
