package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun WavySlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isPlaying: Boolean = true,
    colors: SliderColors = SliderDefaults.colors(),
    waveAmplitude: Dp = 6.dp,
    waveFrequency: Float = 0.045f,
    luminance: Float = 0.2f
) {
    val isDarkTheme = LocalIsDarkTheme.current
    val isBrightBackground = luminance > 0.5f

    var isDragging by remember { mutableStateOf(false) }

    // When the user slides/drags the slider OR when the song is paused,
    // settle amplitudeFactor to 0f so it displays the standard straight slider!
    val amplitudeFactor by animateFloatAsState(
        targetValue = if (isPlaying && !isDragging) 1f else 0f,
        animationSpec = tween(
            durationMillis = if (isDragging) 160 else 750,
            easing = FastOutSlowInEasing
        ),
        label = "amplitudeFactor"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * kotlin.math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val activeTrackColor = if (colors.activeTrackColor == SliderDefaults.colors().activeTrackColor) {
        if (isBrightBackground) Color.Black else Color.White
    } else {
        colors.activeTrackColor
    }

    val inactiveTrackColor = if (colors.inactiveTrackColor == SliderDefaults.colors().inactiveTrackColor) {
        activeTrackColor.copy(alpha = 0.24f)
    } else {
        colors.inactiveTrackColor
    }

    val thumbColor = if (colors.thumbColor == SliderDefaults.colors().thumbColor) {
        activeTrackColor
    } else {
        colors.thumbColor
    }

    BoxWithConstraints(
        modifier = modifier
            .height(36.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    isDragging = true
                    try {
                        onValueChange((down.position.x / size.width).coerceIn(0f, 1f))
                        horizontalDrag(down.id) { change ->
                            onValueChange((change.position.x / size.width).coerceIn(0f, 1f))
                            if (change.positionChange() != Offset.Zero) change.consume()
                        }
                    } finally {
                        isDragging = false
                    }
                }
            }
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()
        val centerY = height / 2f
        val activeWidth = width * value.coerceIn(0f, 1f)

        Canvas(modifier = Modifier.fillMaxSize()) {
            val amplitude = waveAmplitude.toPx() * amplitudeFactor
            val trackStrokePx = 5.dp.toPx()

            // Draw Inactive Track (Straight Line)
            if (activeWidth < width) {
                drawLine(
                    color = inactiveTrackColor,
                    start = Offset(activeWidth, centerY),
                    end = Offset(width, centerY),
                    strokeWidth = trackStrokePx,
                    cap = StrokeCap.Round
                )
            }

            // Draw Active Track (Straight when paused or dragging; Wavy when playing & not dragging)
            if (activeWidth > 1f) {
                if (amplitude <= 0.15f) {
                    drawLine(
                        color = activeTrackColor,
                        start = Offset(0f, centerY),
                        end = Offset(activeWidth, centerY),
                        strokeWidth = trackStrokePx,
                        cap = StrokeCap.Round
                    )
                } else {
                    val path = Path().apply {
                        moveTo(0f, centerY)
                        val step = 2f
                        var x = 0f
                        while (x < activeWidth) {
                            val taperStart = (x / 20f).coerceIn(0f, 1f)
                            val taperEnd = ((activeWidth - x) / 20f).coerceIn(0f, 1f)
                            val y = centerY + sin(x * waveFrequency + phase) * amplitude * taperStart * taperEnd
                            lineTo(x, y)
                            x += step
                        }
                        lineTo(activeWidth, centerY)
                    }
                    drawPath(
                        path = path,
                        color = activeTrackColor,
                        style = Stroke(width = trackStrokePx, cap = StrokeCap.Round)
                    )
                }
            }

            // Draw Thumb
            drawCircle(
                color = thumbColor,
                radius = if (isDragging) 11.5.dp.toPx() else 10.5.dp.toPx(),
                center = Offset(activeWidth, centerY)
            )
        }
    }
}
