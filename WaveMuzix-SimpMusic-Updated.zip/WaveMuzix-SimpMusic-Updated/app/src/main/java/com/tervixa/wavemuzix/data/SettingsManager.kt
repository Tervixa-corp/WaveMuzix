package com.tervixa.wavemuzix.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("wave_settings", Context.MODE_PRIVATE)

    // --- Core WaveMuzix + SimpMusic Appearance & UI Settings ---
    var isLiquidGlass: Boolean
        get() = prefs.getBoolean("liquid_glass", true)
        set(value) { prefs.edit().putBoolean("liquid_glass", value).commit() }

    var translucentBottomBar: Boolean
        get() = prefs.getBoolean("translucent_bottom_bar", false)
        set(value) { prefs.edit().putBoolean("translucent_bottom_bar", value).commit() }

    var blurPlayerBackground: Boolean
        get() = prefs.getBoolean("blur_player_background", true)
        set(value) { prefs.edit().putBoolean("blur_player_background", value).commit() }

    var playerType: String
        get() = prefs.getString("player_type", "Classic") ?: "Classic"
        set(value) { prefs.edit().putString("player_type", value).commit() }

    var themeMode: String
        get() = prefs.getString("theme_mode", "Dark") ?: "Dark"
        set(value) { prefs.edit().putString("theme_mode", value).commit() }

    var themeColorSource: String
        get() = prefs.getString("theme_color_source", "Custom") ?: "Custom"
        set(value) { prefs.edit().putString("theme_color_source", value).commit() }

    var accentColor: Int
        get() = prefs.getInt("accent_color", 0xFFFF2D55.toInt())
        set(value) { prefs.edit().putInt("accent_color", value).commit() }

    var isAmbientBackgroundEnabled: Boolean
        get() = prefs.getBoolean("is_ambient_background_enabled", true)
        set(value) { prefs.edit().putBoolean("is_ambient_background_enabled", value).commit() }

    var isKeepScreenOn: Boolean
        get() = prefs.getBoolean("keep_screen_on", false)
        set(value) { prefs.edit().putBoolean("keep_screen_on", value).commit() }

    // --- Account & Content Settings ---
    var contentCountry: String
        get() = prefs.getString("content_country", "IN") ?: "IN"
        set(value) { prefs.edit().putString("content_country", value).commit() }

    var preferredAudioLanguage: String
        get() = prefs.getString("preferred_audio_language", "Original Audio") ?: "Original Audio"
        set(value) { prefs.edit().putString("preferred_audio_language", value).commit() }

    var selectedLanguages: Set<String>
        get() {
            val set = prefs.getStringSet("selected_languages", null)
            return if (set.isNullOrEmpty()) setOf("hindi", "english") else set
        }
        set(value) { prefs.edit().putStringSet("selected_languages", value).commit() }

    var selectedArtists: Set<String>
        get() = prefs.getStringSet("selected_artists", emptySet()) ?: emptySet()
        set(value) { prefs.edit().putStringSet("selected_artists", value).commit() }

    var phoneNumber: String
        get() = prefs.getString("user_phone_number", "") ?: ""
        set(value) { prefs.edit().putString("user_phone_number", value).commit() }

    var isPreferHighQuality: Boolean
        get() = prefs.getBoolean("prefer_high_quality", false)
        set(value) { prefs.edit().putBoolean("prefer_high_quality", value).commit() }

    var streamingQuality: String
        get() = prefs.getString("streaming_quality", "High (OPUS 160kbps)") ?: "High (OPUS 160kbps)"
        set(value) { prefs.edit().putString("streaming_quality", value).commit() }

    var downloadQuality: String
        get() = prefs.getString("download_quality", "Standard (OPUS 160kbps)") ?: "Standard (OPUS 160kbps)"
        set(value) { prefs.edit().putString("download_quality", value).commit() }

    var downloadThreads: Int
        get() = prefs.getInt("download_threads", 4)
        set(value) { prefs.edit().putInt("download_threads", value).commit() }

    var autoDownloadLikedSongs: Boolean
        get() = prefs.getBoolean("auto_download_liked_songs", false)
        set(value) { prefs.edit().putBoolean("auto_download_liked_songs", value).commit() }

    var smartDownloadsEnabled: Boolean
        get() = prefs.getBoolean("smart_downloads_enabled", false)
        set(value) { prefs.edit().putBoolean("smart_downloads_enabled", value).commit() }

    var smartDownloadsCount: Int
        get() = prefs.getInt("smart_downloads_count", 50)
        set(value) { prefs.edit().putInt("smart_downloads_count", value).commit() }

    var explicitContentEnabled: Boolean
        get() = prefs.getBoolean("explicit_content_enabled", true)
        set(value) { prefs.edit().putBoolean("explicit_content_enabled", value).commit() }

    var sendBackToGoogle: Boolean
        get() = prefs.getBoolean("send_back_to_google", false)
        set(value) { prefs.edit().putBoolean("send_back_to_google", value).commit() }

    var usingProxy: Boolean
        get() = prefs.getBoolean("using_proxy", false)
        set(value) { prefs.edit().putBoolean("using_proxy", value).commit() }

    var proxyType: String
        get() = prefs.getString("proxy_type", "HTTP") ?: "HTTP"
        set(value) { prefs.edit().putString("proxy_type", value).commit() }

    var proxyHost: String
        get() = prefs.getString("proxy_host", "127.0.0.1") ?: "127.0.0.1"
        set(value) { prefs.edit().putString("proxy_host", value).commit() }

    var proxyPort: Int
        get() = prefs.getInt("proxy_port", 8080)
        set(value) { prefs.edit().putInt("proxy_port", value).commit() }

    // --- Connect To Wave (YouTube Music, Spotify, Last.fm, Discord) ---
    var isYouTubeMusicConnected: Boolean
        get() = prefs.getBoolean("connect_ytm_enabled", false)
        set(value) { prefs.edit().putBoolean("connect_ytm_enabled", value).commit() }

    var ytmAccountName: String
        get() = prefs.getString("connect_ytm_account_name", "") ?: ""
        set(value) { prefs.edit().putString("connect_ytm_account_name", value).commit() }

    var isSpotifyConnected: Boolean
        get() = prefs.getBoolean("connect_spotify_enabled", false)
        set(value) { prefs.edit().putBoolean("connect_spotify_enabled", value).commit() }

    var spotifySpDcCookie: String
        get() = prefs.getString("connect_spotify_sp_dc", "") ?: ""
        set(value) { prefs.edit().putString("connect_spotify_sp_dc", value).commit() }

    var spotifyClientToken: String
        get() = prefs.getString("connect_spotify_client_token", "") ?: ""
        set(value) { prefs.edit().putString("connect_spotify_client_token", value).commit() }

    var isSpotifyMetadataEnabled: Boolean
        get() = prefs.getBoolean("spotify_metadata_enabled", true)
        set(value) { prefs.edit().putBoolean("spotify_metadata_enabled", value).commit() }

    var isSpotifyCanvasEnabled: Boolean
        get() = prefs.getBoolean("spotify_canvas_enabled", false)
        set(value) { prefs.edit().putBoolean("spotify_canvas_enabled", value).commit() }

    var isLastFmConnected: Boolean
        get() = prefs.getBoolean("connect_lastfm_enabled", false)
        set(value) { prefs.edit().putBoolean("connect_lastfm_enabled", value).commit() }

    var lastFmUsername: String
        get() = prefs.getString("connect_lastfm_username", "") ?: ""
        set(value) { prefs.edit().putString("connect_lastfm_username", value).commit() }

    var lastFmSessionKey: String
        get() = prefs.getString("connect_lastfm_session_key", "") ?: ""
        set(value) { prefs.edit().putString("connect_lastfm_session_key", value).commit() }

    var isDiscordConnected: Boolean
        get() = prefs.getBoolean("connect_discord_enabled", false)
        set(value) { prefs.edit().putBoolean("connect_discord_enabled", value).commit() }

    var discordToken: String
        get() = prefs.getString("connect_discord_token", "") ?: ""
        set(value) { prefs.edit().putString("connect_discord_token", value).commit() }

    // --- Next-Gen Audio Engine & Built-In Equalizer Settings ---
    var isNormalizeVolume: Boolean
        get() = prefs.getBoolean("normalize_volume", true)
        set(value) { prefs.edit().putBoolean("normalize_volume", value).commit() }

    var isPeakLimiterEnabled: Boolean
        get() = prefs.getBoolean("peak_limiter_enabled", false)
        set(value) { prefs.edit().putBoolean("peak_limiter_enabled", value).commit() }

    var isGaplessRenderingEnabled: Boolean
        get() = prefs.getBoolean("gapless_rendering_enabled", false)
        set(value) { prefs.edit().putBoolean("gapless_rendering_enabled", value).commit() }

    // 3D Surround Virtualizer removed from UI and kept off
    var surroundMode: String
        get() = "None"
        set(_) { prefs.edit().putString("surround_mode", "None").commit() }

    var isDirectVolumeControlEnabled: Boolean
        get() = prefs.getBoolean("direct_volume_control_enabled", false)
        set(value) { prefs.edit().putBoolean("direct_volume_control_enabled", value).commit() }

    var isSkipSilenceEnabled: Boolean
        get() = prefs.getBoolean("skip_silence_enabled", false)
        set(value) { prefs.edit().putBoolean("skip_silence_enabled", value).commit() }

    var equalizerType: String
        get() = prefs.getString("equalizer_type", "Built-in Equalizer") ?: "Built-in Equalizer"
        set(value) { prefs.edit().putString("equalizer_type", value).commit() }

    var isBuiltInEqEnabled: Boolean
        get() = prefs.getBoolean("builtin_eq_enabled", true)
        set(value) { prefs.edit().putBoolean("builtin_eq_enabled", value).commit() }

    var builtInEqPreset: String
        get() = prefs.getString("builtin_eq_preset", "Flat") ?: "Flat"
        set(value) { prefs.edit().putString("builtin_eq_preset", value).commit() }

    var builtInEqBandsCsv: String
        get() = prefs.getString("builtin_eq_bands_csv", "0,0,0,0,0,0,0,0,0,0") ?: "0,0,0,0,0,0,0,0,0,0"
        set(value) { prefs.edit().putString("builtin_eq_bands_csv", value).commit() }

    var builtInBassBoostStrength: Int
        get() = prefs.getInt("builtin_bass_boost_strength", 0)
        set(value) { prefs.edit().putInt("builtin_bass_boost_strength", value).commit() }

    var builtInVirtualizerStrength: Int
        get() = prefs.getInt("builtin_virtualizer_strength", 0)
        set(value) { prefs.edit().putInt("builtin_virtualizer_strength", value).commit() }

    var builtInPreampDb: Float
        get() = prefs.getFloat("builtin_preamp_db", 0f)
        set(value) { prefs.edit().putFloat("builtin_preamp_db", value).commit() }

    // --- Playback & SimpMusic Crossfade Settings ---
    var isSavePlaybackState: Boolean
        get() = prefs.getBoolean("save_playback_state", true)
        set(value) { prefs.edit().putBoolean("save_playback_state", value).commit() }

    var isSaveLastPlayed: Boolean
        get() = prefs.getBoolean("save_last_played", true)
        set(value) { prefs.edit().putBoolean("save_last_played", value).commit() }

    var lastPlayedPositionMs: Long
        get() = prefs.getLong("last_played_position_ms", 0L)
        set(value) { prefs.edit().putLong("last_played_position_ms", value).apply() }

    // Player Audio Visualizer removed per user request (Queue spectrum uses Compose animation)
    var isVisualizerEnabled: Boolean
        get() = false
        set(_) { prefs.edit().putBoolean("visualizer_enabled", false).commit() }

    var isKeepServiceAlive: Boolean
        get() = prefs.getBoolean("keep_service_alive", true)
        set(value) { prefs.edit().putBoolean("keep_service_alive", value).commit() }

    var isCrossfadeEnabled: Boolean
        get() = prefs.getBoolean("crossfade_enabled", false)
        set(value) { prefs.edit().putBoolean("crossfade_enabled", value).commit() }

    var crossfadeDurationSeconds: Int
        get() = prefs.getInt("crossfade_duration_seconds", 5)
        set(value) { prefs.edit().putInt("crossfade_duration_seconds", value).commit() }

    var crossfadeDjMode: Boolean
        get() = prefs.getBoolean("crossfade_dj_mode", false)
        set(value) {
            val editor = prefs.edit().putBoolean("crossfade_dj_mode", value)
            if (value) {
                editor.putBoolean("skip_silence_enabled", true)
            }
            editor.commit()
        }

    var crossfadeSkipAlbum: Boolean
        get() = prefs.getBoolean("crossfade_skip_album", true)
        set(value) { prefs.edit().putBoolean("crossfade_skip_album", value).commit() }

    var crossfadeThresholdDb: Float
        get() = prefs.getFloat("crossfade_threshold_db", -10f)
        set(value) { prefs.edit().putFloat("crossfade_threshold_db", value).commit() }

    // --- Extreme Control (The Cockpit) & SponsorBlock ---
    var isSponsorBlockEnabled: Boolean
        get() = prefs.getBoolean("sponsor_block_enabled", true)
        set(value) { prefs.edit().putBoolean("sponsor_block_enabled", value).commit() }

    var skipSponsorMentions: Boolean
        get() = prefs.getBoolean("skip_sponsor_mentions", true)
        set(value) { prefs.edit().putBoolean("skip_sponsor_mentions", value).commit() }

    var skipIntroOutro: Boolean
        get() = prefs.getBoolean("skip_intro_outro", true)
        set(value) { prefs.edit().putBoolean("skip_intro_outro", value).commit() }

    var skipNonMusicSkits: Boolean
        get() = prefs.getBoolean("skip_non_music_skits", true)
        set(value) { prefs.edit().putBoolean("skip_non_music_skits", value).commit() }

    var networkBufferSizeMs: Long
        get() = prefs.getLong("network_buffer_size_ms", 0L)
        set(value) { prefs.edit().putLong("network_buffer_size_ms", value).commit() }

    var isDataSaverEnabled: Boolean
        get() = prefs.getBoolean("is_data_saver_enabled", false)
        set(value) { prefs.edit().putBoolean("is_data_saver_enabled", value).commit() }

    var isPlayVideoIfAvailable: Boolean
        get() = prefs.getBoolean("is_play_video_if_available", true)
        set(value) { prefs.edit().putBoolean("is_play_video_if_available", value).commit() }

    var preferredVideoQuality: String
        get() = prefs.getString("preferred_video_quality", "auto(recommended)") ?: "auto(recommended)"
        set(value) { prefs.edit().putString("preferred_video_quality", value).commit() }

    var radioAudioOnly: Boolean
        get() = prefs.getBoolean("radio_audio_only", false)
        set(value) { prefs.edit().putBoolean("radio_audio_only", value).commit() }

    // --- Lyrics & Romanization Settings ---
    var lyricsProvider: String
        get() = prefs.getString("lyrics_provider", "BetterLyrics") ?: "BetterLyrics"
        set(value) { prefs.edit().putString("lyrics_provider", value).commit() }

    var lyricsStyle: String
        get() = prefs.getString("lyrics_style", "Apple Music (Blur)") ?: "Apple Music (Blur)"
        set(value) { prefs.edit().putString("lyrics_style", value).commit() }

    var lyricsRomanization: Boolean
        get() = prefs.getBoolean("lyrics_romanization", true)
        set(value) { prefs.edit().putBoolean("lyrics_romanization", value).commit() }

    var lyricsOffsetMs: Int
        get() = prefs.getInt("lyrics_offset_ms", 0)
        set(value) { prefs.edit().putInt("lyrics_offset_ms", value).commit() }

    var translationLanguage: String
        get() = prefs.getString("translation_language", "en") ?: "en"
        set(value) { prefs.edit().putString("translation_language", value).commit() }

    // --- Storage, History, Backup & Misc ---
    // Local Listening History Tracking is permanently ON by default and hidden from Settings UI
    var localTrackingEnabled: Boolean
        get() = true
        set(_) { prefs.edit().putBoolean("local_tracking_enabled", true).commit() }

    var limitPlayerCacheMb: Int
        get() = prefs.getInt("limit_player_cache_mb", 512)
        set(value) { prefs.edit().putInt("limit_player_cache_mb", value).commit() }

    var autoBackupEnabled: Boolean
        get() = prefs.getBoolean("auto_backup_enabled", true)
        set(value) { prefs.edit().putBoolean("auto_backup_enabled", value).commit() }

    var autoBackupFrequency: String
        get() = prefs.getString("auto_backup_frequency", "Daily") ?: "Daily"
        set(value) { prefs.edit().putString("auto_backup_frequency", value).commit() }

    var autoCheckUpdate: Boolean
        get() = prefs.getBoolean("auto_check_update", true)
        set(value) { prefs.edit().putBoolean("auto_check_update", value).commit() }

    var lastPlayedSongId: String?
        get() = prefs.getString("last_played_song_id", null)
        set(value) { prefs.edit().putString("last_played_song_id", value).commit() }

    var isOnboardingComplete: Boolean
        get() = prefs.getBoolean("onboarding_complete", false)
        set(value) { prefs.edit().putBoolean("onboarding_complete", value).commit() }

    var userLocation: String?
        get() = prefs.getString("user_location", null)
        set(value) { prefs.edit().putString("user_location", value).commit() }

    var lastIgnoredVersion: Int
        get() = prefs.getInt("last_ignored_version", 0)
        set(value) { prefs.edit().putInt("last_ignored_version", value).commit() }

    var shouldShowLoginPrompt: Boolean
        get() = prefs.getBoolean("should_show_login_prompt", true)
        set(value) { prefs.edit().putBoolean("should_show_login_prompt", value).commit() }

    var userVolume: Float
        get() = prefs.getFloat("user_volume", 1.0f)
        set(value) { prefs.edit().putFloat("user_volume", value).commit() }

    var hasSeenPlayerTutorial: Boolean
        get() = prefs.getBoolean("has_seen_player_tutorial", false)
        set(value) { prefs.edit().putBoolean("has_seen_player_tutorial", value).commit() }

    var hasSeenLibraryTutorial: Boolean
        get() = prefs.getBoolean("has_seen_library_tutorial", false)
        set(value) { prefs.edit().putBoolean("has_seen_library_tutorial", value).commit() }

    var hasSeenSettingsTutorial: Boolean
        get() = prefs.getBoolean("has_seen_settings_tutorial", false)
        set(value) { prefs.edit().putBoolean("has_seen_settings_tutorial", value).commit() }

    var homeFeedCache: String?
        get() = prefs.getString("home_feed_cache", null)
        set(value) { prefs.edit().putString("home_feed_cache", value).apply() }

    // --- SimpMusic Search History Persistence ---
    var searchHistory: List<String>
        get() {
            val raw = prefs.getString("search_history_json", null) ?: return emptyList()
            return try {
                val arr = JSONArray(raw)
                val list = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    val item = arr.optString(i).trim()
                    if (item.isNotEmpty()) list.add(item)
                }
                list
            } catch (_: Exception) {
                emptyList()
            }
        }
        set(value) {
            val arr = JSONArray()
            value.distinct().take(25).forEach { arr.put(it) }
            prefs.edit().putString("search_history_json", arr.toString()).apply()
        }

    fun addSearchHistory(query: String) {
        val clean = query.trim()
        if (clean.isEmpty()) return
        val updated = mutableListOf(clean)
        updated.addAll(searchHistory.filterNot { it.equals(clean, ignoreCase = true) })
        searchHistory = updated.take(25)
    }

    fun removeSearchHistory(query: String) {
        searchHistory = searchHistory.filterNot { it.equals(query, ignoreCase = true) }
    }

    fun clearSearchHistory() {
        searchHistory = emptyList()
    }
}
