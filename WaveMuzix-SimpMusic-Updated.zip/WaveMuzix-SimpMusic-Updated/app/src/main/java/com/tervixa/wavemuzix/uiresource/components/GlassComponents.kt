package com.tervixa.wavemuzix.uiresource.components

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.SettingsManager
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeProgressive
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.HazeBlurStyle
import dev.chrisbanes.haze.blur.HazeColorEffect
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class WaveBottomSheetPortalState {
    val entries = mutableStateListOf<Pair<Any, @Composable () -> Unit>>()

    fun setSheet(key: Any, content: @Composable () -> Unit) {
        val index = entries.indexOfFirst { it.first == key }
        if (index >= 0) {
            entries[index] = key to content
        } else {
            entries.add(key to content)
        }
    }

    fun removeSheet(key: Any) {
        entries.removeAll { it.first == key }
    }
}

val LocalBackdrop = staticCompositionLocalOf<LayerBackdrop?> { null }
val LocalBottomSheetPortal = staticCompositionLocalOf<WaveBottomSheetPortalState?> { null }

@Composable
fun WaveBottomSheetPortalHost(
    portalState: WaveBottomSheetPortalState,
    defaultBackdrop: LayerBackdrop?,
    modifier: Modifier = Modifier,
) {
    if (portalState.entries.isEmpty()) return
    CompositionLocalProvider(
        LocalBackdrop provides defaultBackdrop,
        LocalHazeState provides null,
    ) {
        Box(modifier = modifier.fillMaxSize()) {
            portalState.entries.forEach { (_, sheetContent) ->
                sheetContent()
            }
        }
    }
}

@Composable
fun WaveGlassBottomSheet(
    onDismissRequest: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val portal = LocalBottomSheetPortal.current
    val sheetKey = remember { Any() }
    val currentOnDismiss by rememberUpdatedState(onDismissRequest)
    val currentContent by rememberUpdatedState(content)

    val sheetUi: @Composable () -> Unit = {
        BackHandler(onBack = currentOnDismiss)
        var dragOffsetY by remember { mutableFloatStateOf(0f) }
        val openOffset = remember { androidx.compose.animation.core.Animatable(500f) }
        LaunchedEffect(Unit) {
            openOffset.animateTo(
                targetValue = 0f,
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = 0.68f, // light bouncy feel on reach full sliding top!
                    stiffness = 380f,
                )
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = currentOnDismiss,
                ),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        translationY = openOffset.value + dragOffsetY.coerceAtLeast(0f)
                    }
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = {
                                if (dragOffsetY > 140f) {
                                    currentOnDismiss()
                                } else {
                                    dragOffsetY = 0f
                                }
                            },
                            onDragCancel = { dragOffsetY = 0f },
                            onVerticalDrag = { change, dragAmount ->
                                val next = dragOffsetY + dragAmount
                                if (next >= 0f) {
                                    change.consume()
                                    dragOffsetY = next
                                }
                            },
                        )
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    ),
                content = currentContent,
            )
        }
    }

    if (portal != null) {
        SideEffect {
            portal.setSheet(sheetKey, sheetUi)
        }
        DisposableEffect(portal, sheetKey) {
            onDispose {
                portal.removeSheet(sheetKey)
            }
        }
    } else {
        sheetUi()
    }
}
val LocalHazeState = staticCompositionLocalOf<HazeState?> { null }
val LocalPreferHaze = staticCompositionLocalOf { false }
val LocalIsDarkTheme = staticCompositionLocalOf { true }

/**
 * Exact solid grey color used in the Queue screen background (`Color(0xFF1C1C1E)`).
 * Used for all buttons, search buttons, back buttons, and options bottom sheets when
 * "Enable Liquid Glass" is turned OFF in Settings.
 */
val QueueSolidGrey = Color(0xFF1C1C1E)

@Composable
fun rememberIsLiquidGlassEnabled(requested: Boolean = true): Boolean {
    if (!requested) return false
    val performance = LocalPerformanceConfig.current
    if (!performance.isLiquidGlassEnabled) return false
    val context = LocalContext.current
    val settingsManager = remember(context) { SettingsManager(context) }
    return settingsManager.isLiquidGlass
}

fun smoothScrimBrush(
    from: Color,
    to: Color,
    startFraction: Float = 0f,
    endFraction: Float = 1f,
    steps: Int = 24,
): Brush {
    val stops = Array(steps + 1) { i ->
        val t = i.toFloat() / steps
        val position = startFraction + (endFraction - startFraction) * t
        val eased = t * t * (3f - 2f * t)
        position to lerpColor(from, to, eased)
    }
    return Brush.verticalGradient(colorStops = stops)
}

fun smoothScrimBrush(
    color: Color,
    steps: Int = 24,
): Brush = smoothScrimBrush(from = color.copy(alpha = 0f), to = color, steps = steps)

fun artworkScrimBrush(backgroundColor: Color): Brush = smoothScrimBrush(backgroundColor)

fun barBlurStyle(
    tint: Color,
    tintAlpha: Float = 0.55f,
    blurRadius: Dp = 28.dp,
): HazeBlurStyle =
    HazeBlurStyle {
        this.blurEnabled(true)
        this.blurRadius(blurRadius)
        this.backgroundColor(tint)
        this.noiseFactor(0f)
        this.colorEffects(listOf(HazeColorEffect.tint(tint.copy(alpha = tintAlpha))))
        this.fallbackColorEffect(HazeColorEffect.tint(tint.copy(alpha = 0.94f)))
    }

@Composable
fun ultraThinBarStyle(
    tint: Color = MaterialTheme.colorScheme.background,
    tintAlpha: Float = 0.55f,
    blurRadius: Dp = 28.dp,
): HazeBlurStyle = barBlurStyle(tint = tint, tintAlpha = tintAlpha, blurRadius = blurRadius)

data class ImmersivePaletteColors(
    val backgroundColor: Color,
    val accentColor: Color,
    val sectionCardColor: Color,
    val topBarTintColor: Color = backgroundColor,
)

fun Palette?.toImmersiveBackground(isDarkTheme: Boolean = true): Color {
    val p = this ?: return if (isDarkTheme) Color(0xFF0E0E12) else Color(0xFFF6F6FA)
    val rgb = p.getDominantColor(0).takeIf { it != 0 }
        ?: p.getMutedColor(0).takeIf { it != 0 }
        ?: p.getVibrantColor(0).takeIf { it != 0 }
        ?: return if (isDarkTheme) Color(0xFF0E0E12) else Color(0xFFF6F6FA)
    val base = Color(rgb)
    val luminance = 0.299f * base.red + 0.587f * base.green + 0.114f * base.blue
    return if (isDarkTheme) {
        val darkenFactor = (0.35f + 0.45f * luminance).coerceIn(0.35f, 0.82f)
        lerpColor(base, Color.Black, darkenFactor)
    } else {
        val lightenFactor = (0.82f - 0.15f * luminance).coerceIn(0.68f, 0.88f)
        lerpColor(base, Color.White, lightenFactor)
    }
}

fun Palette?.getVibrantOrMutedFromPalette(fallback: Color): Color {
    val p = this ?: return fallback
    val defaultColor = 0
    var chosen = p.getVibrantColor(defaultColor)
    if (chosen == defaultColor) chosen = p.getLightVibrantColor(defaultColor)
    if (chosen == defaultColor) chosen = p.getDarkVibrantColor(defaultColor)
    if (chosen == defaultColor) chosen = p.getMutedColor(defaultColor)
    if (chosen == defaultColor) chosen = p.getDominantColor(defaultColor)
    return if (chosen != defaultColor) Color(chosen) else fallback
}

@Composable
fun rememberImmersivePaletteColors(
    imageUrl: String?,
    fallbackBackground: Color = MaterialTheme.colorScheme.background,
    fallbackAccent: Color = MaterialTheme.colorScheme.primary,
): ImmersivePaletteColors {
    val context = LocalContext.current
    val isDark = LocalIsDarkTheme.current
    var heldBgArgb by rememberSaveable(imageUrl, isDark) { mutableStateOf<Int?>(null) }
    var heldAccentArgb by rememberSaveable(imageUrl, isDark) { mutableStateOf<Int?>(null) }
    var heldSectionArgb by rememberSaveable(imageUrl, isDark) { mutableStateOf<Int?>(null) }

    LaunchedEffect(imageUrl, isDark) {
        if (imageUrl.isNullOrBlank()) return@LaunchedEffect
        Glide.with(context.applicationContext)
            .asBitmap()
            .load(imageUrl)
            .into(object : CustomTarget<Bitmap>(256, 256) {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    Palette.from(resource).generate { palette ->
                        val bg = palette.toImmersiveBackground(isDarkTheme = isDark)
                        val rawAccent = palette.getVibrantOrMutedFromPalette(fallbackAccent)
                        val accentLum = 0.299f * rawAccent.red + 0.587f * rawAccent.green + 0.114f * rawAccent.blue
                        val bgLum = 0.299f * bg.red + 0.587f * bg.green + 0.114f * bg.blue
                        val contrast = (max(accentLum, bgLum) + 0.05f) / (min(accentLum, bgLum) + 0.05f)
                        val adjustedAccent = if (contrast >= 2.6f) {
                            rawAccent
                        } else if (isDark) {
                            lerpColor(rawAccent, Color.White, 0.55f)
                        } else {
                            lerpColor(rawAccent, Color.Black, 0.45f)
                        }
                        val section = if (isDark) {
                            Color(
                                red = (rawAccent.red * 0.45f).coerceIn(0f, 1f),
                                green = (rawAccent.green * 0.45f).coerceIn(0f, 1f),
                                blue = (rawAccent.blue * 0.45f).coerceIn(0f, 1f),
                                alpha = 1f,
                            )
                        } else {
                            lerpColor(rawAccent, Color.White, 0.78f)
                        }
                        heldBgArgb = bg.toArgb()
                        heldAccentArgb = adjustedAccent.toArgb()
                        heldSectionArgb = section.toArgb()
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }

    val animatedBg by animateColorAsState(
        targetValue = heldBgArgb?.let { Color(it) } ?: fallbackBackground,
        animationSpec = tween(500),
        label = "immersiveBgColor",
    )
    val animatedAccent by animateColorAsState(
        targetValue = heldAccentArgb?.let { Color(it) } ?: fallbackAccent,
        animationSpec = tween(500),
        label = "immersiveAccentColor",
    )
    val animatedSection by animateColorAsState(
        targetValue = heldSectionArgb?.let { Color(it) } ?: MaterialTheme.colorScheme.surfaceContainer,
        animationSpec = tween(500),
        label = "immersiveSectionColor",
    )

    return ImmersivePaletteColors(
        backgroundColor = animatedBg,
        accentColor = animatedAccent,
        sectionCardColor = animatedSection,
        topBarTintColor = animatedBg,
    )
}

@Composable
fun rememberContinuousScrollOffsetPx(listState: LazyListState): State<Float> {
    val itemHeights = remember(listState) { mutableMapOf<Int, Int>() }
    return remember(listState) {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            layoutInfo.visibleItemsInfo.forEach { info ->
                itemHeights[info.index] = info.size
            }
            val firstIdx = listState.firstVisibleItemIndex
            var totalPx = listState.firstVisibleItemScrollOffset
            for (i in 0 until firstIdx) {
                totalPx += itemHeights[i] ?: 220
            }
            totalPx.toFloat()
        }
    }
}

@Composable
fun LazyListState.isScrollingUp(): State<Boolean> {
    var previousIndex by remember(this) { mutableIntStateOf(firstVisibleItemIndex) }
    var previousScrollOffset by remember(this) { mutableIntStateOf(firstVisibleItemScrollOffset) }
    return remember(this) {
        derivedStateOf {
            if (firstVisibleItemIndex > 0) {
                if (previousIndex != firstVisibleItemIndex) {
                    previousIndex > firstVisibleItemIndex
                } else {
                    previousScrollOffset >= firstVisibleItemScrollOffset
                }.also {
                    previousIndex = firstVisibleItemIndex
                    previousScrollOffset = firstVisibleItemScrollOffset
                }
            } else {
                true
            }
        }
    }
}

private fun easedColorStops(
    colors: List<Color>,
    stepsPerSegment: Int = 24,
): Array<Pair<Float, Color>> {
    val segments = colors.size - 1
    val total = segments * stepsPerSegment
    return Array(total + 1) { i ->
        val segment = minOf(i / stepsPerSegment, segments - 1)
        val t = (i - segment * stepsPerSegment) / stepsPerSegment.toFloat()
        i / total.toFloat() to lerpColor(colors[segment], colors[segment + 1], t * t * (3f - 2f * t))
    }
}

fun Modifier.angledGradientBackground(
    colors: List<Color>,
    degrees: Float,
): Modifier =
    if (colors.size < 2) {
        this
    } else {
        this.drawBehind {
            val (x, y) = size
            val gamma = atan2(y, x)
            if (gamma == 0f || gamma == (PI / 2).toFloat()) return@drawBehind
            val degreesNormalised = (degrees % 360).let { if (it < 0) it + 360 else it }
            val alpha = (degreesNormalised * PI / 180).toFloat()
            val gradientLength = when (alpha) {
                in 0f..gamma, in (2 * PI - gamma).toFloat()..(2 * PI).toFloat() -> x / cos(alpha)
                in gamma..(PI - gamma).toFloat() -> y / sin(alpha)
                in (PI - gamma).toFloat()..(PI + gamma).toFloat() -> x / -cos(alpha)
                in (PI + gamma).toFloat()..(2 * PI - gamma).toFloat() -> y / -sin(alpha)
                else -> hypot(x, y)
            }
            val centerOffsetX = cos(alpha) * gradientLength / 2f
            val centerOffsetY = sin(alpha) * gradientLength / 2f
            drawRect(
                brush = Brush.linearGradient(
                    colorStops = easedColorStops(colors),
                    start = Offset(center.x - centerOffsetX, center.y - centerOffsetY),
                    end = Offset(center.x + centerOffsetX, center.y + centerOffsetY),
                ),
                size = size,
            )
        }
    }

fun Color.rgbFactor(factor: Float): Color =
    Color(
        red = (red * factor).coerceIn(0f, 1f),
        green = (green * factor).coerceIn(0f, 1f),
        blue = (blue * factor).coerceIn(0f, 1f),
        alpha = alpha,
    )

val AmbientGlowHeight = 380.dp

/**
 * Top-right / top ambient color glow.
 * Only rendered when `showTopRightGlow == true` (enabled strictly on the Home screen and disabled
 * on all other screens per user preference).
 */
@Composable
fun AmbientThemeGlow(
    modifier: Modifier = Modifier,
    tint: Color? = MaterialTheme.colorScheme.primary,
    scrollState: LazyListState? = null,
    showTopRightGlow: Boolean = false,
) {
    if (!showTopRightGlow) return
    val backgroundColor = MaterialTheme.colorScheme.background
    val isLightTheme = backgroundColor.luminance() > 0.5f
    val glow by animateColorAsState(
        targetValue = when {
            tint == null -> backgroundColor
            isLightTheme -> lerpColor(tint, Color.White, 0.82f)
            else -> tint.rgbFactor(0.45f)
        },
        animationSpec = tween(500),
        label = "ambientGlow",
    )
    val scrollOffsetPx = scrollState?.let { rememberContinuousScrollOffsetPx(it) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(AmbientGlowHeight)
            .then(
                if (scrollOffsetPx != null) {
                    Modifier.graphicsLayer {
                        translationY = (-scrollOffsetPx.value).coerceAtLeast(-size.height)
                    }
                } else {
                    Modifier
                },
            )
            .angledGradientBackground(listOf(glow, backgroundColor), 25f),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.6f)
                .align(Alignment.BottomCenter)
                .background(artworkScrimBrush(backgroundColor)),
        )
    }
}

@Composable
fun Modifier.liquidGlass(
    shape: Shape,
    layer: GraphicsLayer,
    luminance: Float,
    isDark: Boolean = LocalIsDarkTheme.current,
    minScrim: Float = 0.16f,
    maxScrim: Float = 0.54f,
    blurScale: Float = 1.35f,
    interaction: GlassInteraction? = null,
    pressedScale: Float = 1.06f,
    accentColor: Color = Color.Transparent,
    showBorder: Boolean = true,
): Modifier {
    val enabled = rememberIsLiquidGlassEnabled(true)

    if (enabled) {
        return this.stableLiquidGlass(
            layer = layer,
            luminance = luminance,
            shape = shape,
            interaction = interaction,
            pressedScale = pressedScale,
            minScrim = minScrim,
            maxScrim = maxScrim,
            blurScale = blurScale,
            accentColor = accentColor,
            showBorder = showBorder,
        )
    }

    return this
        .clip(shape)
        .background(QueueSolidGrey, shape)
        .then(
            if (showBorder) {
                Modifier.border(1.dp, Color.White.copy(alpha = 0.12f), shape)
            } else Modifier
        )
}

/**
 * Applies SimpMusic 3D Liquid Glass blur, contrast/saturation/brightness, lens refraction,
 * and sculpted 3D specular border outline to Option Sheets, Artist Selection, Video Details,
 * and floating containers.
 *
 * - Controlled globally by the "Enable Liquid Glass" setting (`rememberIsLiquidGlassEnabled`):
 *   when disabled, replaces the glass background with the exact Queue screen solid grey (`Color(0xFF1C1C1E)`).
 * - When `deepFrostedSheet == true` (Options Bottom Sheet, Artist Selection Sheet, Video Details Sheet),
 *   applies significantly higher blur (`blurScale = 2.65f`, `extraBlurDp = 28.dp`, `blurRadius = 56.dp`)
 *   and reduced brightness (`brightnessOffset = -0.22f`, deep dark surface `Color(0xFF07070B)`).
 */
@Composable
fun Modifier.glassContainer(
    shape: Shape,
    isLiquidGlass: Boolean = true,
    borderWidth: Dp = 1.15.dp,
    backgroundColor: Color = Color.Transparent,
    baseAlpha: Float = 0.72f,
    blurScale: Float = 1.35f,
    deepFrostedSheet: Boolean = false,
    interaction: GlassInteraction? = null,
    showBorder: Boolean = true,
    interactive: Boolean = false,
): Modifier {
    val enabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val isDarkTheme = LocalIsDarkTheme.current
    val backdrop = LocalBackdrop.current

    if (!enabled) {
        return this
            .clip(shape)
            .background(QueueSolidGrey, shape)
            .then(
                if (showBorder) {
                    Modifier.border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.12f),
                        shape = shape,
                    )
                } else Modifier,
            )
    }

    // Clear glass for options sheet, video details, volume container, etc.:
    // NO tint and NO darkness (minScrim = 0f, maxScrim = 0f, brightnessOffset = 0f),
    // only basic refraction and a medium blur!
    val effectiveBlurScale = if (deepFrostedSheet) 1.25f else blurScale.coerceAtMost(1.35f)
    val extraBlur = if (deepFrostedSheet) 3.dp else 0.dp
    val brightnessAdj = 0f
    val minScrimVal = if (deepFrostedSheet) 0f else 0f
    val maxScrimVal = if (deepFrostedSheet) 0f else 0f
    val effectiveAccent = if (deepFrostedSheet) Color.Transparent else backgroundColor

    if (backdrop != null) {
        val layer = rememberGraphicsLayer()
        val sampledLuminance by rememberGlassLuminance(layer, enabled = true)
        val activeInteraction = if (interactive) (interaction ?: rememberGlassInteraction()) else interaction
        return this.drawInteractiveGlass(
            isDark = isDarkTheme,
            backdrop = backdrop,
            layer = layer,
            luminance = { sampledLuminance },
            shape = shape,
            interaction = activeInteraction,
            pressedScale = if (interactive) 1.06f else 1.0f,
            blurScale = effectiveBlurScale,
            extraBlurDp = extraBlur,
            brightnessOffset = brightnessAdj,
            minScrim = minScrimVal,
            maxScrim = maxScrimVal,
            accentColor = effectiveAccent,
            outlineAlpha = if (deepFrostedSheet) 0.34f else 0.36f,
            showBorder = showBorder,
            borderWidth = borderWidth,
        )
    }

    val rimTint = if (isDarkTheme) Color.White else Color.Black

    return this
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.08f),
                    Color.White.copy(alpha = 0.04f),
                ),
            ),
            shape = shape,
        )
        .then(
            if (showBorder) {
                Modifier.border(
                    width = borderWidth,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            rimTint.copy(alpha = 0.42f),
                            rimTint.copy(alpha = 0.14f),
                            rimTint.copy(alpha = 0.08f),
                            rimTint.copy(alpha = 0.28f),
                        ),
                        start = Offset.Zero,
                        end = Offset(900f, 900f),
                    ),
                    shape = shape,
                )
            } else Modifier,
        )
}

@Composable
fun Modifier.hazeGlass(
    shape: Shape,
    hazeState: HazeState? = null,
    isLiquidGlass: Boolean = true,
    blurRadius: Dp = 28.dp,
    tint: Color = Color.Transparent,
    luminance: Float = 0.2f,
    showBorder: Boolean = true,
): Modifier {
    val enabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val backdrop = LocalBackdrop.current

    if (!enabled) {
        return this
            .clip(shape)
            .background(QueueSolidGrey, shape)
            .then(
                if (showBorder) {
                    Modifier.border(1.dp, Color.White.copy(alpha = 0.12f), shape)
                } else Modifier,
            )
    }

    if (backdrop != null) {
        val layer = rememberGraphicsLayer()
        val sampledLuminance by rememberGlassLuminance(layer, enabled = true)
        return this.stableLiquidGlass(
            layer = layer,
            luminance = sampledLuminance,
            shape = shape,
            interaction = null,
            accentColor = tint,
            minScrim = 0f,
            maxScrim = 0f,
            blurScale = 1.25f,
            showBorder = showBorder,
            borderWidth = 1.15.dp,
        )
    }

    return this
        .clip(shape)
        .background(Color.White.copy(alpha = 0.06f), shape)
        .then(
            if (showBorder) {
                Modifier.border(1.15.dp, Color.White.copy(alpha = 0.26f), shape)
            } else Modifier,
        )
}

@Composable
fun LiquidGlassContainer(
    modifier: Modifier = Modifier,
    backdrop: LayerBackdrop? = LocalBackdrop.current,
    isLiquidGlass: Boolean = true,
    shape: Shape = CircleShape,
    interactive: Boolean = true,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit,
) {
    val enabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val isDark = LocalIsDarkTheme.current
    val interaction = rememberGlassInteraction()
    val rimColor = if (isDark) Color.White else Color.Black

    val surfaceModifier = if (!enabled) {
        modifier
            .clip(shape)
            .background(QueueSolidGrey, shape)
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
    } else if (backdrop != null) {
        val layer = rememberGraphicsLayer()
        val luminance by rememberGlassLuminance(layer, enabled = true)
        modifier.drawInteractiveGlass(
            isDark = isDark,
            backdrop = backdrop,
            layer = layer,
            luminance = { luminance },
            shape = shape,
            interaction = if (interactive) interaction else null,
            outlineAlpha = 0.38f,
            borderWidth = 1.15.dp,
        )
    } else {
        modifier.glassContainer(
            shape = shape,
            isLiquidGlass = true,
            interaction = if (interactive) interaction else null,
            interactive = interactive,
            borderWidth = 1.15.dp,
        )
    }

    Box(
        modifier = surfaceModifier,
        contentAlignment = contentAlignment,
        content = content,
    )
}

@Composable
fun HazeHeader(
    modifier: Modifier = Modifier,
    backgroundColor: Color = MaterialTheme.colorScheme.background,
    state: HazeState = remember { HazeState() },
    blurRadius: Dp = 32.dp,
    blurHeight: Dp = 200.dp,
    gradientHeight: Dp = 220.dp,
    headerImage: @Composable BoxScope.() -> Unit,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val maskBrush = remember { smoothScrimBrush(Color.Black, steps = 24) }
    val tintScrimBrush = remember(backgroundColor) { artworkScrimBrush(backgroundColor) }

    CompositionLocalProvider(
        LocalHazeState provides state,
        LocalPreferHaze provides true,
    ) {
        Box(modifier = modifier) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .hazeSource(state = state),
            ) {
                headerImage()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            val maskStart = (size.height - blurHeight.toPx()).coerceAtLeast(0f)
                            drawRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black),
                                    startY = maskStart,
                                    endY = size.height,
                                ),
                                blendMode = BlendMode.DstIn,
                            )
                        }
                        .blur(blurRadius),
                ) {
                    headerImage()
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(blurHeight)
                    .align(Alignment.BottomCenter)
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            brush = maskBrush,
                            blendMode = BlendMode.DstIn,
                        )
                    }
                    .hazeBlur(
                        input = HazeInput.Sources(state),
                        style = HazeBlurStyle {
                            this.blurEnabled(true)
                            this.blurRadius(blurRadius)
                            this.backgroundColor(backgroundColor)
                            this.noiseFactor(0f)
                            this.colorEffects(listOf(HazeColorEffect.tint(backgroundColor.copy(alpha = 0.08f))))
                            this.progressive(
                                HazeProgressive.verticalGradient(
                                    startIntensity = 0f,
                                    endIntensity = 1f,
                                ),
                            )
                        },
                    ),
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.72f)
                    .align(Alignment.BottomCenter)
                    .background(tintScrimBrush),
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .align(Alignment.BottomCenter)
                    .background(backgroundColor),
            )

            content()
        }
    }
}

object WaveHazeHeader {
    @Composable
    fun VerticalGradient(
        modifier: Modifier = Modifier,
        backgroundColor: Color = MaterialTheme.colorScheme.background,
        state: HazeState = remember { HazeState() },
        blurRadius: Dp = 32.dp,
        blurHeight: Dp = 200.dp,
        gradientHeight: Dp = 220.dp,
        headerImage: @Composable BoxScope.() -> Unit,
        content: @Composable BoxScope.() -> Unit = {},
    ) {
        HazeHeader(
            modifier = modifier,
            backgroundColor = backgroundColor,
            state = state,
            blurRadius = blurRadius,
            blurHeight = blurHeight,
            gradientHeight = gradientHeight,
            headerImage = headerImage,
            content = content,
        )
    }
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLiquidGlass: Boolean = true,
    contentDescription: String? = null,
    iconSize: Dp = 24.dp,
    tint: Color = Color.White,
    containerSize: Dp = 48.dp,
    backgroundColor: Color = Color.Transparent,
    shape: Shape = CircleShape,
) {
    val enabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val interaction = rememberGlassInteraction()
    Box(
        modifier = modifier
            .size(containerSize)
            .then(
                if (enabled) {
                    Modifier.glassContainer(
                        shape = shape,
                        isLiquidGlass = true,
                        backgroundColor = backgroundColor,
                        interaction = interaction,
                        interactive = true,
                        borderWidth = 1.15.dp,
                    )
                } else {
                    Modifier
                        .clip(shape)
                        .background(QueueSolidGrey, shape)
                        .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
                },
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(iconSize),
        )
    }
}