package com.tervixa.wavemuzix.data

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.annotation.OptIn
import androidx.compose.runtime.*
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.upstream.DefaultAllocator
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.PlayerMessage
import kotlin.math.abs
import kotlin.math.hypot
import androidx.media3.common.MediaMetadata
import android.net.Uri
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.sanitized
import com.tervixa.wavemuzix.repository.StreamingResult
import com.tervixa.wavemuzix.repository.YtDescriptionRepository
import com.tervixa.wavemuzix.repository.VideoDetails
import com.tervixa.wavemuzix.repository.AudioStreamRepository
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.palette.graphics.Palette
import androidx.core.graphics.ColorUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import androidx.media3.datasource.okhttp.OkHttpDataSource
import com.tervixa.wavemuzix.data.SponsorSegment
import androidx.core.content.ContextCompat
import com.tervixa.wavemuzix.data.database.FavoriteSongEntity
import com.tervixa.wavemuzix.data.database.DownloadedSongEntity
import com.tervixa.wavemuzix.data.database.LyricsCacheEntity
import com.tervixa.wavemuzix.data.database.SponsorBlockCacheEntity
import com.tervixa.wavemuzix.data.database.PaletteCacheEntity
import com.tervixa.wavemuzix.data.database.PlaybackStateEntity
import com.tervixa.wavemuzix.data.DataBackupManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.session.CacheBitmapLoader
import com.tervixa.wavemuzix.data.database.AppDatabase
import kotlinx.coroutines.flow.first

import com.tervixa.wavemuzix.data.FirebaseSyncManager
import com.tervixa.wavemuzix.utils.NetworkUtils

@OptIn(UnstableApi::class)
object MusicPlayer {
    private var activePlayer: ExoPlayer? = null
    private var inactivePlayer: ExoPlayer? = null
    private var videoPlayer: ExoPlayer? = null
    private var settingsManager: SettingsManager? = null
    private var appContext: Context? = null
    private var pendingRestorePosition: Long = 0L
    private var pendingRestoreVideoId: String? = null
    @Volatile private var hasPlayedFirstSongInSession: Boolean = false
    @Volatile private var prebufferedCrossfadeVideoId: String? = null
    @Volatile private var isPrebufferingCrossfade: Boolean = false
    private var lastPositionSaveTimeMs: Long = 0L
    private var cachingStreamJob: Job? = null

    private fun getInstantResumeCacheFile(context: Context, videoId: String): java.io.File {
        val dir = java.io.File(context.applicationContext.cacheDir, "wave_instant_resume")
        if (!dir.exists()) dir.mkdirs()
        return java.io.File(dir, "$videoId.audio")
    }

    var unifiedRepository: UnifiedMusicRepository? = null
    var cookies: String? = null

    var isPlaying by mutableStateOf(false)
    var isLoading by mutableStateOf(false)
    var isPlaybackError by mutableStateOf(false)
    var playbackErrorMessage by mutableStateOf<String?>(null)
    var isVideoAvailable by mutableStateOf(false)
    var isVideoModeEnabled by mutableStateOf(false)
    var isPlayerViewVisible by mutableStateOf(false)
    var isVideoActuallyPlaying by mutableStateOf(false)
    var activeScreenAccentTint by mutableStateOf<Color?>(null)
    var currentVideoQuality by mutableStateOf<String?>(null)
    var currentServer by mutableStateOf<String>("Unknown")

    fun createMediaMetadata(song: Song): MediaMetadata {
        val allSingers = song.displayArtists
        return MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(allSingers)
            .setAlbumArtist(allSingers)
            .setDisplayTitle(song.title)
            .setSubtitle(allSingers)
            .setAlbumTitle(allSingers)
            .setArtworkUri(if (song.thumbnailUrl.isBlank()) null else Uri.parse(song.thumbnailUrl))
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
            .build()
    }

    private var _currentSong by mutableStateOf<Song?>(null)
    var currentSong: Song?
        get() = _currentSong
        set(value) {
            val oldId = _currentSong?.videoId
            _currentSong = value
            if (value != null) {
                val newId = value.videoId
                // Sync State Clearing: Prevent UI flickering/stale data during transitions
                val cleanName = value.displayArtists.replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "").trim()
                sanitizedArtistName = cleanName
                
                // CRITICAL: Compute high-res URL immediately to prevent blurry thumbnail flash
                highResThumbnailUrl = getHighResThumbnailUrl(value.thumbnailUrl)
                
                currentSongDurationText = value.durationText
                duration = parseDurationToMs(value.durationText)
                
                // Only reset/restore metadata if the song actually changed
                if (oldId != newId) {
                    videoDetails = null
                    isDetailsLoading = true
                    
                    // Instant restoration from cache to eliminate UI flickering
                    accentColors = accentColorsCache[newId] ?: emptyList()
                    artistAvatarUrl = artistAvatarCache[cleanName]
                    artistAvatarSource = artistAvatarSourceCache[cleanName]

                    // Lyrics Restoration: Immediate recovery from cache to prevent "Searching..." flicker
                    val cachedLyrics = lyricsRepository.getCachedLyrics(newId)
                    if (cachedLyrics != null) {
                        lyricsText = cachedLyrics
                        lyricsProvider = lyricsRepository.getCachedProvider(newId)
                        isLyricsLoading = false
                    } else {
                        lyricsText = null
                        lyricsProvider = null
                        isLyricsLoading = true
                    }
                }
            } else {
                sanitizedArtistName = ""
                artistAvatarUrl = null
                artistAvatarSource = null
                videoDetails = null
                highResThumbnailUrl = null
                lyricsText = null
                lyricsProvider = null
                isLyricsLoading = false
            }
            
            // Automatically update MediaSession metadata when currentSong changes
            mainScope.launch {
                activePlayer?.let { player ->
                    val song = value ?: return@launch
                    val metadata = createMediaMetadata(song)

                    val currentItem = player.currentMediaItem
                    if (currentItem != null && currentItem.mediaId == song.videoId) {
                        if (currentItem.mediaMetadata.title != metadata.title) {
                            player.replaceMediaItem(
                                player.currentMediaItemIndex,
                                currentItem.buildUpon().setMediaMetadata(metadata).build()
                            )
                        }
                    }
                }
            }
        }

    private val defaultAmbientColors = listOf(
        Color(0xFF6200EE), // Deep Purple
        Color(0xFF03DAC6), // Teal
        Color(0xFFBB86FC), // Light Purple
        Color(0xFF3700B3), // Dark Purple
        Color(0xFF018786)  // Dark Teal
    )

    private var _accentColors by mutableStateOf<List<Color>>(defaultAmbientColors)
    var accentColors: List<Color>
        get() = _accentColors
        set(value) {
            _accentColors = value.ifEmpty { defaultAmbientColors }
        }
    var videoDetails by mutableStateOf<VideoDetails?>(null)
    var artistAvatarUrl by mutableStateOf<String?>(null)
    var artistAvatarSource by mutableStateOf<String?>(null)
    var sanitizedArtistName by mutableStateOf<String>("")
    var isDetailsLoading by mutableStateOf(false)
    var highResThumbnailUrl by mutableStateOf<String?>(null)
    var currentSongDurationText by mutableStateOf<String?>(null)
    var isFavorite by mutableStateOf(false)
    var isDownloaded by mutableStateOf(false)
    private var hasIncrementedPlayCount = false

    /**
     * Tunes ExoPlayer's internal SilenceSkippingAudioProcessor so that:
     * - minimumSilenceDurationUs = 1_250_000L (1.25s continuous dead air required before cutting,
     *   instead of ExoPlayer's 150ms default which cuts pauses between drum beats!)
     * - paddingSilenceUs = 180_000L (natural musical breathing room around transitions)
     * - silenceThresholdLevel = 256 (only true digital silence is skipped, preserving quiet intros)
     */
    private fun tuneSilenceProcessorObject(proc: Any) {
        var procCls: Class<*>? = proc.javaClass
        while (procCls != null && procCls != Any::class.java) {
            for (pf in procCls.declaredFields) {
                try {
                    pf.isAccessible = true
                    when (pf.name) {
                        // CRITICAL: In Media3 SilenceSkippingAudioProcessor, maxSilenceToKeepDurationUs MUST be >= minimumSilenceDurationUs
                        // and buffer sizes depend on minimumSilenceDurationUs. Setting silenceRetentionRatio = 0.0f and
                        // minVolumeToKeepPercentageWhenMuting = 0 cuts silent sections instantaneously without buffer assertions!
                        "silenceRetentionRatio" -> if (pf.type == Float::class.javaPrimitiveType) pf.setFloat(proc, 0.0f)
                        "minVolumeToKeepPercentageWhenMuting" -> if (pf.type == Int::class.javaPrimitiveType) pf.setInt(proc, 0)
                        "silenceThresholdLevel" -> if (pf.type == Short::class.javaPrimitiveType) pf.setShort(proc, 1024.toShort())
                    }
                } catch (_: Throwable) {}
            }
            procCls = procCls.superclass
        }
    }

    private fun scanAndTuneSilenceProcessors(rootObj: Any?, depth: Int = 0, visited: MutableSet<Int> = mutableSetOf()) {
        if (rootObj == null || depth > 4) return
        val id = System.identityHashCode(rootObj)
        if (!visited.add(id)) return
        val clsName = rootObj.javaClass.simpleName
        if (clsName.contains("SilenceSkippingAudioProcessor", ignoreCase = true)) {
            tuneSilenceProcessorObject(rootObj)
            return
        }
        var cls: Class<*>? = rootObj.javaClass
        while (cls != null && cls != Any::class.java) {
            for (f in cls.declaredFields) {
                try {
                    f.isAccessible = true
                    val v = f.get(rootObj) ?: continue
                    val vClass = v.javaClass
                    if (vClass.simpleName.contains("SilenceSkippingAudioProcessor", ignoreCase = true)) {
                        tuneSilenceProcessorObject(v)
                    } else if (v is Array<*>) {
                        for (elem in v) {
                            if (elem != null && elem.javaClass.simpleName.contains("SilenceSkippingAudioProcessor", ignoreCase = true)) {
                                tuneSilenceProcessorObject(elem)
                            }
                        }
                    } else if (f.name.contains("audioSink", ignoreCase = true) ||
                        f.name.contains("audioProcessor", ignoreCase = true) ||
                        f.name.contains("processorChain", ignoreCase = true) ||
                        vClass.simpleName.contains("AudioSink", ignoreCase = true) ||
                        vClass.simpleName.contains("ProcessorChain", ignoreCase = true)
                    ) {
                        scanAndTuneSilenceProcessors(v, depth + 1, visited)
                    }
                } catch (_: Throwable) {}
            }
            cls = cls.superclass
        }
    }

    private fun configureSmartSilenceProcessor(player: ExoPlayer) {
        try {
            for (i in 0 until player.rendererCount) {
                val renderer = player.getRenderer(i)
                if (renderer.trackType == C.TRACK_TYPE_AUDIO) {
                    scanAndTuneSilenceProcessors(renderer)
                }
            }
        } catch (t: Throwable) {
            Log.d("MusicPlayer", "SmartSilenceProcessor tuning fallback: ${t.message}")
        }
    }

    var skipSilenceEnabled: Boolean = false
        set(value) {
            field = value
            activePlayer?.skipSilenceEnabled = value
            inactivePlayer?.skipSilenceEnabled = value
        }

    fun toggleFavorite(context: Context, song: Song? = currentSong, isCurrent: Boolean = true) {
        if (song == null) return

        // Capture the target state immediately on the Main thread for instant UI response
        val targetIsFavorite = if (isCurrent) !isFavorite else true 
        // Note: If isCurrent is false, we assume we are favoring a specific song from a list
        
        if (isCurrent) {
            isFavorite = targetIsFavorite
        }

        // Update Favorite status in background
        ioScope.launch {
            val dao = database?.songDao() ?: return@launch
            try {
                // We use targetIsFavorite to determine the action, 
                // avoiding an extra database query (dao.isFavorite) for speed.
                if (!targetIsFavorite) {
                    dao.deleteFavorite(FavoriteSongEntity(
                        videoId = song.videoId,
                        title = song.title,
                        artist = song.artist,
                        thumbnailUrl = song.thumbnailUrl,
                        artistId = song.artistId
                    ))
                    LastFmManager.setTrackLoved(context, song, false)
                    FirebaseSyncManager.removeFavorite(song.videoId)
                } else {
                    val fav = FavoriteSongEntity(
                        videoId = song.videoId,
                        title = song.title,
                        artist = song.artist,
                        thumbnailUrl = song.thumbnailUrl,
                        artistId = song.artistId
                    )
                    dao.insertFavorite(fav)
                    if (SettingsManager(context).autoDownloadLikedSongs) {
                        enqueueAutoDownloadForSong(context, song)
                    }
                    LastFmManager.setTrackLoved(context, song, true)
                    FirebaseSyncManager.pushFavorite(context, fav)
                }

                DataBackupManager.backupAll(context)
            } catch (e: Exception) {
                // Revert UI state only if we were tracking the current song
                if (isCurrent) {
                    withContext(Dispatchers.Main) {
                        isFavorite = !targetIsFavorite
                    }
                }
                Log.e("MusicPlayer", "Failed to toggle favorite", e)
            }
        }
    }

    fun release() {
        savePlaybackState()
        currentPlaybackRequestId++
        fetchJob?.cancel()
        skipJob?.cancel()
        prefetchJob?.cancel()
        crossfadeJob?.cancel()
        fadeJob?.cancel()
        isCrossfadeTriggered = false
        isCrossfadeInFlight = false
        isPrebufferingCrossfade = false
        prebufferedCrossfadeVideoId = null
        inactivePlayer?.stop()
        inactivePlayer?.clearMediaItems()
        isPrefetching = false
        progressJob?.cancel()
        volumeFadeJob?.cancel()
        sleepTimerJob?.cancel()
        refreshQueueJob?.cancel()

        activePlayer?.release()
        activePlayer = null
        inactivePlayer?.release()
        inactivePlayer = null
        videoPlayer?.release()
        videoPlayer = null

        releaseVisualizer()
        loudnessEnhancer?.release()
        loudnessEnhancer = null

        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = null

        clearState()
    }

    fun clearState() {
        currentSong = null
        isPlaying = false
        isLoading = false
        isPlaybackError = false
        playbackErrorMessage = null
        isCrossfadeTriggered = false
        videoDetails = null
        artistAvatarUrl = null
        artistAvatarSource = null
        sanitizedArtistName = ""
        highResThumbnailUrl = null
        currentSongDurationText = null
        accentColors = emptyList() // Resets to defaults
        lyricsText = null
        lyricsProvider = null
        isFavorite = false
        isDownloaded = false
        currentVolumeAmplitude = 0f
        currentBassAmplitude = 0f
        currentTrebleAmplitude = 0f
        videoDetailsCache.clear()
        accentColorsCache.clear()
        artistAvatarCache.clear()
        artistAvatarSourceCache.clear()
        sponsorSegmentsCache.clear()

        // Persistent State Reset: Only clear if we are resetting the app state entirely, 
        // not during a standard release/save cycle.
    }

    var lyricsText by mutableStateOf<String?>(null)
    var lyricsProvider by mutableStateOf<String?>(null)
    var isLyricsLoading by mutableStateOf(false)

    val lyricsRepository = com.tervixa.wavemuzix.repository.LyricsRepository()

    val queue = mutableStateListOf<Song>()
    var currentIndex by mutableIntStateOf(-1)
    private var shuffledIndices = mutableListOf<Int>()

    var currentPosition by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)

    private var consecutiveErrors = 0
    private const val MAX_CONSECUTIVE_ERRORS = 3

    private var _shuffleEnabled by mutableStateOf(false)
    var shuffleEnabled: Boolean
        get() = _shuffleEnabled
        set(value) {
            _shuffleEnabled = value
            if (value && queue.isNotEmpty()) {
                generateShuffledIndices()
            }
        }

    private var _repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var repeatMode: Int
        get() = _repeatMode
        set(value) {
            _repeatMode = value
            // Only pass REPEAT_MODE_ONE to ExoPlayer.
            // REPEAT_MODE_ALL is handled manually via our queue and prefetching.
            val exoMode = if (value == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            activePlayer?.repeatMode = exoMode
            inactivePlayer?.repeatMode = exoMode
        }

    var currentVolumeAmplitude by mutableFloatStateOf(0f)
    var currentBassAmplitude by mutableFloatStateOf(0f)
    var currentTrebleAmplitude by mutableFloatStateOf(0f)
    var playbackSpeed by mutableFloatStateOf(1f)

    private var dynamicsProcessing: android.media.audiofx.DynamicsProcessing? = null
    private var virtualizer: android.media.audiofx.Virtualizer? = null
    private var reverb: android.media.audiofx.PresetReverb? = null
    private var currentAudioSessionId = C.AUDIO_SESSION_ID_UNSET

    private fun generateShuffledIndices() {
        shuffledIndices = queue.indices.toMutableList()
        shuffledIndices.shuffle()
        // Move current index to front of shuffled list to avoid jumping
        val currentInShuffled = shuffledIndices.indexOf(currentIndex)
        if (currentInShuffled != -1) {
            shuffledIndices.removeAt(currentInShuffled)
            shuffledIndices.add(0, currentIndex)
        }
    }

    var sleepTimerMillis by mutableLongStateOf(0L)
    var stopAfterCurrentSong by mutableStateOf(false)
    private var sleepTimerJob: Job? = null

    private val sponsorSegments = mutableStateListOf<SponsorSegment>()

    var onErrorCallback: ((PlaybackException) -> Unit)? = null
    var onReadyCallback: (() -> Unit)? = null
    var onPlayerChanged: ((ExoPlayer) -> Unit)? = null

    private var progressJob: Job? = null
    private var visualizer: Visualizer? = null
    private var fetchJob: Job? = null
    private var skipJob: Job? = null
    private var prefetchJob: Job? = null
    @Volatile private var currentPlaybackRequestId: Long = 0L
    private var lastManualIndexChangeTime = 0L
    private var lastSkipTime = 0L
    private var isSkipping = false
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var database: com.tervixa.wavemuzix.data.database.AppDatabase? = null
    private var refreshQueueJob: Job? = null

    private val videoDetailsCache = java.util.concurrent.ConcurrentHashMap<String, VideoDetails>()
    private val accentColorsCache = java.util.concurrent.ConcurrentHashMap<String, List<Color>>()
    private val artistAvatarCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val artistAvatarSourceCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val sponsorSegmentsCache = java.util.concurrent.ConcurrentHashMap<String, List<Pair<Long, Long>>>()

    private var prefetchedVideoId: String? = null
    var scheduledVideoId: String? = null
    var scheduledIndex: Int = -1
    var isPrefetching: Boolean by mutableStateOf(false)
    private var currentVisualizerSessionId: Int = C.AUDIO_SESSION_ID_UNSET
    private var loudnessEnhancer: android.media.audiofx.LoudnessEnhancer? = null
    private var lastSponsorSeekTarget = -1L
    private var cleanPositionAtSkipTrigger = 0L
    private var skipTriggerTime = 0L
    private var lastSponsorSeekAttemptTime = 0L
    private var mergedSponsorSegments: List<Pair<Long, Long>> = emptyList()
    private var isFadingForSkip = false
    private var isCrossfadeTriggered = false
    @Volatile private var isCrossfadeInFlight = false
    private var crossfadeJob: Job? = null
    private var fadeJob: Job? = null
    private var volumeFadeJob: Job? = null
    private val streamUserAgents = java.util.concurrent.ConcurrentHashMap<String, String>()
    private var baseVolume = 1.0f
    private var videoSyncStartTime = 0L
    private var currentLoudness: Double? = null

    var wasPausedBeforeSkip = false
    private var _userVolume = mutableFloatStateOf(1.0f)
    var userVolume: Float
        get() = _userVolume.floatValue
        set(value) {
            _userVolume.floatValue = value
            updatePlayerVolume()
            settingsManager?.userVolume = value
        }


    private fun updatePlayerVolume() {
        val vol = userVolume * baseVolume
        activePlayer?.volume = vol
    }

    private fun calculateBaseVolume(loudness: Double?): Float {
        return 1.0f
    }

    @OptIn(UnstableApi::class)
    private val httpDataSourceFactory = OkHttpDataSource.Factory(RetrofitClient.getOkHttpClient())
        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36")
        .setDefaultRequestProperties(mapOf(
            "Origin" to "https://music.youtube.com",
            "Referer" to "https://music.youtube.com/",
            "Accept" to "*/*"
        ))

    @OptIn(UnstableApi::class)
    private val resolvingHttpDataSourceFactory by lazy {
        androidx.media3.datasource.ResolvingDataSource.Factory(httpDataSourceFactory) { dataSpec ->
            val urlStr = dataSpec.uri.toString()
            val ua = streamUserAgents[urlStr]
            val extraHeaders = mutableMapOf(
                "Origin" to "https://music.youtube.com",
                "Referer" to "https://music.youtube.com/",
                "Accept" to "*/*"
            )
            if (!ua.isNullOrBlank()) {
                extraHeaders["User-Agent"] = ua
            }
            if (!cookies.isNullOrEmpty()) {
                extraHeaders["Cookie"] = cookies!!
            }
            dataSpec.withAdditionalHeaders(extraHeaders)
        }
    }

    @OptIn(UnstableApi::class)
    private val dataSourceFactory by lazy {
        androidx.media3.datasource.DefaultDataSource.Factory(
            appContext!!,
            resolvingHttpDataSourceFactory
        )
    }

    private val ytDescriptionRepository by lazy {
        YtDescriptionRepository()
    }

    fun getHighResThumbnailUrl(url: String?): String? {
        if (url == null) return null

        return when {
            url.contains("i.scdn.co") -> {
                // Spotify high-res images usually use /image/ URL segments. 
                // Ensure we don't truncate them.
                url
            }
            url.contains("e-cdns-images.dzcdn.net") -> {
                // Deezer high-res: Replace size with 1000x1000 if not already XL
                if (url.contains("1000x1000")) url else url.replace(Regex("/\\d+x\\d+/"), "/1000x1000/")
            }
            url.contains("googleusercontent.com") || url.contains("ggpht.com") -> {
                if (url.contains("=")) {
                    url.substringBeforeLast("=") + "=s1080"
                } else {
                    "$url=s1080"
                }
            }
            url.contains("i.ytimg.com") || url.contains("img.youtube.com") -> {
                url.replace("img.youtube.com", "i.ytimg.com")
                    .replace(Regex("(default|mqdefault|sddefault|maxresdefault)\\.jpg"), "hqdefault.jpg")
            }
            else -> url
        }
    }

    private fun fetchMetadata(context: Context, song: Song) {
        val targetVideoId = song.videoId
        val highResUrl = getHighResThumbnailUrl(song.thumbnailUrl)

        // 1. Fetch True Singers (YouTube Music WEB_REMIX + Spotify Catalog) & Artist HD Metadata
        ioScope.launch {
            try {
                unifiedRepository?.let { repo ->
                    val spDc = settingsManager?.spotifySpDcCookie
                    val enriched = repo.resolveTrueSingersForSong(song, cookies, spDc)
                    if (enriched.artists.isNotEmpty() && enriched.displayArtists != song.displayArtists) {
                        withContext(Dispatchers.Main) {
                            if (currentSong?.videoId == targetVideoId) {
                                _currentSong = enriched
                                sanitizedArtistName = enriched.displayArtists
                            }
                            val qIdx = queue.indexOfFirst { it.videoId == targetVideoId }
                            if (qIdx != -1) {
                                queue[qIdx] = enriched
                            }
                        }
                    }
                }
                // Fetch Artist HD Metadata (MusicBrainz/CAA -> Deezer -> YouTube Fallback)
                val currentName = sanitizedArtistName
                val cachedAvatar = artistAvatarCache[currentName]
                
                if (cachedAvatar != null) {
                    if (currentSong?.videoId == targetVideoId) {
                        artistAvatarUrl = cachedAvatar
                    }
                } else {
                    unifiedRepository?.let { repo ->
                        val hdResult = repo.getArtistHDMetadata(artistName = currentName, albumName = currentSong?.title, cookies = cookies)
                        if (hdResult != null) {
                            artistAvatarCache[currentName] = hdResult.artist.thumbnailUrl
                            if (currentSong?.videoId == targetVideoId) {
                                withContext(Dispatchers.Main) {
                                    val hdUrl = getHighResThumbnailUrl(hdResult.artist.thumbnailUrl)
                                    artistAvatarUrl = hdUrl
                                    artistAvatarSource = hdResult.source
                                }
                            }
                        }
                    }
                }

                // Fetch Video Details
                val details = ytDescriptionRepository.fetchVideoDetails(targetVideoId, cookies)
                if (details != null) {
                    videoDetailsCache[targetVideoId] = details
                    if (currentSong?.videoId == targetVideoId) {
                        withContext(Dispatchers.Main) {
                            videoDetails = details
                            // Fallback to channel avatar ONLY if Spotify/HD metadata failed
                            if (artistAvatarUrl == null && details.channelThumbnailUrl.isNotEmpty()) {
                                val hdAvatarUrl = getHighResThumbnailUrl(details.channelThumbnailUrl)
                                artistAvatarUrl = hdAvatarUrl
                                artistAvatarSource = "YouTube"
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Failed to fetch video/artist details", e)
            } finally {
                if (currentSong?.videoId == targetVideoId) {
                    isDetailsLoading = false
                }
            }
        }

        // 2. Update Favorite and Downloaded status
        ioScope.launch {
            val fav = database?.songDao()?.isFavorite(targetVideoId) ?: false
            val down = database?.songDao()?.getDownloadByVideoId(targetVideoId) != null
            withContext(Dispatchers.Main) {
                if (currentSong?.videoId == targetVideoId) {
                    isFavorite = fav
                    isDownloaded = down
                }
            }
        }

        // 3. Extract Palette Colors and Pre-load High-res Image
        mainScope.launch {
            // Check Database Cache for Palette first
            ioScope.launch {
                val dbPalette = database?.songDao()?.getPaletteByVideoId(targetVideoId)
                if (dbPalette != null) {
                    val colors = listOf(
                        Color(dbPalette.vibrant),
                        Color(dbPalette.lightVibrant),
                        Color(dbPalette.darkVibrant),
                        Color(dbPalette.muted)
                    )
                    withContext(Dispatchers.Main) {
                        if (currentSong?.videoId == targetVideoId) {
                            accentColorsCache[targetVideoId] = colors
                            accentColors = colors
                        }
                    }
                }
            }

            Glide.with(context.applicationContext)
                .asBitmap()
                .load(highResUrl)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        if (currentSong?.videoId == targetVideoId) {
                            highResThumbnailUrl = highResUrl

                            activePlayer?.let { player ->
                                val currentItem = player.currentMediaItem
                                if (currentItem != null && currentItem.mediaId == targetVideoId) {
                                    val updatedMetadata = currentItem.mediaMetadata.buildUpon()
                                        .setArtworkUri(Uri.parse(highResUrl))
                                        .build()

                                    player.replaceMediaItem(
                                        player.currentMediaItemIndex,
                                        currentItem.buildUpon().setMediaMetadata(updatedMetadata).build()
                                    )
                                }
                            }

                            val cachedColors = accentColorsCache[targetVideoId]
                            if (cachedColors != null) {
                                accentColors = cachedColors
                            } else {
                                Palette.from(resource).generate { palette ->
                                    if (currentSong?.videoId == targetVideoId) {
                                        palette?.let { p ->
                                            val colors = mutableListOf<Color>()
                                            
                                            val vibrant = p.getVibrantColor(p.getDominantColor(0))
                                            val lightVibrant = p.getLightVibrantColor(p.getLightMutedColor(0))
                                            val darkVibrant = p.getDarkVibrantColor(p.getDarkMutedColor(0))
                                            val muted = p.getMutedColor(0)
                                            
                                            if (vibrant != 0) colors.add(Color(vibrant))
                                            if (lightVibrant != 0) colors.add(Color(lightVibrant))
                                            if (darkVibrant != 0) colors.add(Color(darkVibrant))
                                            if (muted != 0) colors.add(Color(muted))

                                            var filteredColors = colors.filter { ColorUtils.calculateLuminance(it.toArgb()) > 0.02 }

                                            if (filteredColors.size < 4 && filteredColors.isNotEmpty()) {
                                                val baseColor = filteredColors.first().toArgb()
                                                val hsl = FloatArray(3)
                                                ColorUtils.colorToHSL(baseColor, hsl)
                                                val generated = mutableListOf<Color>()
                                                generated.addAll(filteredColors)
                                                while (generated.size < 4) {
                                                    hsl[0] = (hsl[0] + 60f) % 360f
                                                    generated.add(Color(ColorUtils.HSLToColor(hsl)))
                                                }
                                                filteredColors = generated
                                            }
                                            
                                            if (filteredColors.isNotEmpty()) {
                                                accentColorsCache[targetVideoId] = filteredColors
                                                accentColors = filteredColors
                                                
                                                // Save to DB
                                                ioScope.launch {
                                                    database?.songDao()?.insertPalette(PaletteCacheEntity(
                                                        videoId = targetVideoId,
                                                        vibrant = if (filteredColors.size > 0) filteredColors[0].toArgb() else 0,
                                                        lightVibrant = if (filteredColors.size > 1) filteredColors[1].toArgb() else 0,
                                                        darkVibrant = if (filteredColors.size > 2) filteredColors[2].toArgb() else 0,
                                                        muted = if (filteredColors.size > 3) filteredColors[3].toArgb() else 0
                                                    ))
                                                }
                                            } else {
                                                accentColors = defaultAmbientColors
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    override fun onLoadCleared(placeholder: Drawable?) {}
                })
        }
    }

    private fun prefetchMetadata(context: Context, song: Song) {
        val targetVideoId = song.videoId
        val cleanArtistName = song.artist.replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "").trim()

        // Check if we need to fetch anything
        val needsDetails = !videoDetailsCache.containsKey(targetVideoId)
        val needsColors = !accentColorsCache.containsKey(targetVideoId)
        val needsArtist = !artistAvatarCache.containsKey(cleanArtistName)

        if (!needsDetails && !needsColors && !needsArtist) return

        ioScope.launch {
            // 1. Prefetch Artist HD Metadata
            if (needsArtist) {
                try {
                    unifiedRepository?.let { repo ->
                        val hdResult = repo.getArtistHDMetadata(artistName = cleanArtistName, albumName = song.title, cookies = cookies)
                        if (hdResult != null) {
                            artistAvatarCache[cleanArtistName] = hdResult.artist.thumbnailUrl
                            artistAvatarSourceCache[cleanArtistName] = hdResult.source
                        }
                    }
                } catch (e: Exception) {}
            }

            // 2. Prefetch Video Details
            if (needsDetails) {
                try {
                    val details = ytDescriptionRepository.fetchVideoDetails(targetVideoId, cookies)
                    if (details != null) {
                        videoDetailsCache[targetVideoId] = details
                        // Fallback for artist avatar if HD metadata wasn't found
                        if (!artistAvatarCache.containsKey(cleanArtistName) && details.channelThumbnailUrl.isNotEmpty()) {
                            artistAvatarCache[cleanArtistName] = details.channelThumbnailUrl
                            artistAvatarSourceCache[cleanArtistName] = "YouTube"
                        }
                    }
                } catch (e: Exception) {}
            }

            // 3. Prefetch Palette/Accent Colors
            if (needsColors) {
                val highResUrl = getHighResThumbnailUrl(song.thumbnailUrl)
                withContext(Dispatchers.Main) {
                    Glide.with(context.applicationContext)
                        .asBitmap()
                        .load(highResUrl)
                        .into(object : CustomTarget<Bitmap>() {
                            override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                                Palette.from(resource).generate { palette ->
                                    palette?.let { p ->
                                        val colors = mutableListOf<Color>()
                                        val dominant = p.getVibrantColor(p.getDominantColor(0))
                                        val light = p.getLightVibrantColor(p.getLightMutedColor(0))
                                        val dark = p.getDarkVibrantColor(p.getDarkMutedColor(0))
                                        val muted = p.getMutedColor(0)
                                        
                                        if (dominant != 0) colors.add(Color(dominant))
                                        if (light != 0) colors.add(Color(light))
                                        if (dark != 0) colors.add(Color(dark))
                                        if (muted != 0) colors.add(Color(muted))
                                        
                                        var finalColors = colors.filter { ColorUtils.calculateLuminance(it.toArgb()) > 0.02 }.distinct()
                                        
                                        if (finalColors.size < 4 && finalColors.isNotEmpty()) {
                                            val baseColor = finalColors.first().toArgb()
                                            val hsl = FloatArray(3)
                                            ColorUtils.colorToHSL(baseColor, hsl)
                                            val generated = finalColors.toMutableList()
                                            while (generated.size < 4) {
                                                hsl[0] = (hsl[0] + 60f) % 360f
                                                generated.add(Color(ColorUtils.HSLToColor(hsl)))
                                            }
                                            finalColors = generated
                                        }

                                        accentColorsCache[targetVideoId] = finalColors.ifEmpty { defaultAmbientColors }
                                    }
                                }
                            }
                            override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    fun getInstance(context: Context): ExoPlayer {
        val player = activePlayer
        if (player != null) return player

        synchronized(this) {
            if (activePlayer != null) return activePlayer!!

            if (appContext == null) appContext = context.applicationContext
            if (settingsManager == null) {
                settingsManager = SettingsManager(context.applicationContext)
            }
            if (database == null) {
                database = com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context.applicationContext)
                // Ensure offline metadata is synced from JSON backups
                mainScope.launch {
                    DownloadManager.syncWithStorage(context.applicationContext)
                    restorePlaybackState(context.applicationContext)
                }
            }
            if (wifiLock == null) {
                val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
                wifiLock = wifiManager?.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WaveMuzix:WifiLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            
            val active = createPlayer(context.applicationContext)
            activePlayer = active
            restorePlaybackState(context.applicationContext)
            
            // LAZY INITIALIZATION: The inactive and video players are heavy. 
            // We defer them to the Main thread to keep startup snappy.
            // ExoPlayer MUST be created on a thread with a Looper (typically Main).
            mainScope.launch(Dispatchers.Main) {
                if (inactivePlayer == null) {
                    inactivePlayer = createPlayer(context.applicationContext)
                }
                if (videoPlayer == null) {
                    videoPlayer = createVideoPlayer(context.applicationContext)
                }
                
                // Warm up the service in the background if it's not already started.
                // This prepares the MediaSession and Notification early.
                ensureServiceStarted(context.applicationContext)
            }

            // Properly restore user volume via setter to ensure players are updated
            userVolume = settingsManager?.userVolume ?: 1.0f
            
            return active
        }
    }

    fun getVideoPlayer(context: Context): ExoPlayer {
        return videoPlayer ?: synchronized(this) {
            videoPlayer ?: createVideoPlayer(context.applicationContext).also { videoPlayer = it }
        }
    }

    fun getInactivePlayer(context: Context): ExoPlayer {
        return inactivePlayer ?: synchronized(this) {
            inactivePlayer ?: createPlayer(context.applicationContext).also { 
                inactivePlayer = it 
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun createVideoPlayer(context: Context): ExoPlayer {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                12000, // Min buffer to start/resume
                50000, // Max buffer
                1000,  // Fast buffer for immediate video playback start
                2000   // After rebuffer
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val videoRenderersFactory = DefaultRenderersFactory(context.applicationContext)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)

        return ExoPlayer.Builder(context.applicationContext, videoRenderersFactory)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(context.applicationContext)
                    .setDataSourceFactory(dataSourceFactory)
            )
            .setHandleAudioBecomingNoisy(false)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build().apply {
                volume = 0f
                repeatMode = Player.REPEAT_MODE_OFF
                playWhenReady = true
                addListener(object : Player.Listener {
                    override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                        if (videoSize.height > 0) {
                            currentVideoQuality = "${videoSize.height}p"
                        }
                    }

                    override fun onRenderedFirstFrame() {
                        isVideoActuallyPlaying = true
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY && playWhenReady) {
                            isVideoActuallyPlaying = true
                        } else if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED) {
                            currentVideoQuality = null
                            isVideoActuallyPlaying = false
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        Log.e("MusicPlayer", "Video Player Error: ${error.message}", error)
                        isVideoActuallyPlaying = false
                    }
                })
            }
    }

    private fun ensureServiceStarted(context: Context) {
        try {
            val intent = Intent(context.applicationContext, PlaybackService::class.java)
            context.applicationContext.startService(intent)
        } catch (e: Exception) {
            Log.e("MusicPlayer", "CRITICAL: Failed to start PlaybackService: ${e.message}")
        }
    }

    private val failedClientsForCurrentSong = mutableListOf<String>()

    @OptIn(UnstableApi::class)
    private fun createPlayer(context: Context): ExoPlayer {
        val settings = SettingsManager(context)

        val audioAttributesBuilder = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)

        val audioAttributes = audioAttributesBuilder.build()

        val loadControlBuilder = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, 16 * 1024))

        // Optimized buffer settings: High stability with snappy start.
        // We give the player a larger cushion (30s-50s) to prevent tempo jitter 
        // while keeping the start-threshold low (1.5s) for instant response.
        val userConfigBuffer = settings.networkBufferSizeMs
        val minBuffer = if (userConfigBuffer > 0) userConfigBuffer.toInt() else if (settings.isDataSaverEnabled) 20000 else 30000
        val maxBuffer = if (userConfigBuffer > 0) (userConfigBuffer + 20000).toInt() else if (settings.isDataSaverEnabled) 40000 else 60000
        
        loadControlBuilder.setBufferDurationsMs(
            minBuffer,
            maxBuffer,
            if (settings.isDataSaverEnabled) 2500 else 1500,
            if (settings.isDataSaverEnabled) 4000 else 2500
        ).setPrioritizeTimeOverSizeThresholds(true)

        val loadControl = loadControlBuilder.build()

        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableAudioTrackPlaybackParams(true) // Enable hardware params for smoother tempo control

        return ExoPlayer.Builder(context.applicationContext, renderersFactory)
            .setAudioAttributes(audioAttributes, false)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(context.applicationContext)
                    .setDataSourceFactory(dataSourceFactory)
            )
            .build().apply {
                // Use EXACT seeking for absolute precision as requested
                setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
                playWhenReady = false
                configureSmartSilenceProcessor(this)
                skipSilenceEnabled = settings.isSkipSilenceEnabled
                playbackParameters = androidx.media3.common.PlaybackParameters(1.0f)
                this.repeatMode = if (this@MusicPlayer.repeatMode == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF

                addListener(object : Player.Listener {
                    override fun onRepeatModeChanged(repeatMode: Int) {
                        // Prevent ExoPlayer from using REPEAT_MODE_ALL internally as it loops our small pruned queue.
                        // We handle "Repeat All" manually via queue logic.
                        if (repeatMode == Player.REPEAT_MODE_ALL) {
                            this@apply.repeatMode = Player.REPEAT_MODE_OFF
                            this@MusicPlayer.repeatMode = Player.REPEAT_MODE_ALL
                        }
                    }

                    override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
                        playbackSpeed = playbackParameters.speed
                    }

                    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                        if (this@apply == activePlayer) {
                            // Sync intended playback state immediately for UI responsiveness
                            this@MusicPlayer.isPlaying = playWhenReady

                            if (playWhenReady) {
                                try {
                                    if (wifiLock?.isHeld == false) wifiLock?.acquire()
                                } catch (e: Exception) {
                                    Log.e("MusicPlayer", "Failed to acquire WifiLock", e)
                                }
                                startProgressUpdate(context)
                                if (isVideoAvailable && isPlayerViewVisible) {
                                    videoPlayer?.play()
                                }
                            } else {
                                try {
                                    if (wifiLock?.isHeld == true) wifiLock?.release()
                                } catch (e: Exception) {
                                    Log.e("MusicPlayer", "Failed to release WifiLock", e)
                                }
                                stopProgressUpdate()
                                videoPlayer?.pause()
                                savePlaybackState()
                            }
                        }
                    }

                    override fun onIsPlayingChanged(playing: Boolean) {
                        if (this@apply == activePlayer) {
                            // Secondary sync to ensure consistency when actual playback state changes
                            this@MusicPlayer.isPlaying = playWhenReady
                        }
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        // CRITICAL: Only the active player updates the global currentIndex to prevent sync wars
                        if (this@apply != activePlayer) return

                        val transitionRequestId = currentPlaybackRequestId
                        val mediaId = mediaItem?.mediaId ?: this@apply.currentMediaItem?.mediaId

                        // Ignore empty/clear transitions or stale transitions while a manual skip fetch is in flight
                        if (mediaId == null) return
                        if (targetSongId != null && mediaId != targetSongId && (this@MusicPlayer.isLoading || reason != Player.MEDIA_ITEM_TRANSITION_REASON_AUTO)) {
                            Log.d("MusicPlayer", "Ignoring stale onMediaItemTransition for $mediaId (target is $targetSongId)")
                            return
                        }

                        // Prune played items from the player's internal queue to keep it lean
                        if (this@apply.currentMediaItemIndex > 0) {
                            val count = this@apply.currentMediaItemIndex
                            try {
                                this@apply.removeMediaItems(0, count)
                            } catch (e: Exception) {
                                Log.e("MusicPlayer", "Pruning failed", e)
                            }
                        }

                        // We must update state on the main thread for Compose visibility
                        mainScope.launch {
                            if (transitionRequestId != currentPlaybackRequestId) return@launch
                            if (targetSongId != null && mediaId != targetSongId && (this@MusicPlayer.isLoading || reason != Player.MEDIA_ITEM_TRANSITION_REASON_AUTO)) {
                                return@launch
                            }
                            // Nudge Media3 to refresh the notification for automatic transitions
                            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                                try {
                                    activePlayer?.playlistMetadata = activePlayer?.playlistMetadata ?: MediaMetadata.EMPTY
                                } catch (e: Exception) {}
                            }

                            if (mediaId != null) {
                                // Sync currentServer from the MediaItem tag
                                (mediaItem?.localConfiguration?.tag as? StreamingResult)?.let { result ->
                                    currentServer = result.clientName
                                }

                                // Find the song in the queue to sync details correctly.
                                val nextExpectedIndex = getNextIndex()
                                val index = when {
                                    // 1. Check if it's the song we scheduled via prefetch
                                    scheduledIndex != -1 && queue.getOrNull(scheduledIndex)?.videoId == mediaId -> scheduledIndex
                                    // 2. Check if it's the song we expected to play next anyway
                                    nextExpectedIndex != -1 && queue.getOrNull(nextExpectedIndex)?.videoId == mediaId -> nextExpectedIndex
                                    // 3. Check if it's the current song (e.g. repeat one or manual restart)
                                    currentSong?.videoId == mediaId -> currentIndex
                                    // 4. Search for the mediaId, prioritizing indices "after" the current one in playback order
                                    else -> {
                                        if (shuffleEnabled) {
                                            val currentPos = shuffledIndices.indexOf(currentIndex)
                                            val searchIndices = if (currentPos != -1) shuffledIndices.drop(currentPos + 1) else shuffledIndices
                                            val found = searchIndices.firstOrNull { queue.getOrNull(it)?.videoId == mediaId }
                                            found ?: queue.indexOfFirst { it.videoId == mediaId }
                                        } else {
                                            val firstAfter = (currentIndex + 1 until queue.size).firstOrNull { queue[it].videoId == mediaId }
                                            firstAfter ?: queue.indexOfFirst { it.videoId == mediaId }
                                        }
                                    }
                                }

                                if (index != -1) {
                                    val song = queue[index]
                                    val songChanged = index != currentIndex || currentSong?.videoId != mediaId

                                    if (songChanged) {
                                        currentIndex = index
                                        currentSong = song
                                        targetSongId = song.videoId
                                        scheduledVideoId = null
                                        scheduledIndex = -1
                                        
                                        // Skip clearing lyrics if they are already for this song
                                        // (Fixes flicker on gapless/repeat-one transitions)
                                        if (lyricsRepository.getLastSongId() != mediaId) {
                                            clearLyrics()
                                        }
                                        
                                        hasIncrementedPlayCount = false

                                        // Reset state for new song
                                        lastSponsorSeekTarget = -1L
                                        lastSponsorSeekAttemptTime = 0L
                                        cleanPositionAtSkipTrigger = 0L
                                        skipTriggerTime = 0L

                                        if (isStrictVideoPlaybackForSong(mediaId)) {
                                            fetchSponsorSegments(mediaId)
                                        } else {
                                            sponsorSegments.clear()
                                            mergedSponsorSegments = emptyList()
                                        }
                                        fetchMetadata(context, song)
                                        startLyricsFetch(song)
                                        refreshQueueIfLow()
                                        releaseVisualizer()
                                        savePlaybackState()
                                    }
                                }
                            }

                            // SYNC VIDEO PLAYER FOR AUTOMATIC/GAPLESS TRANSITIONS
                            val currentResult = this@apply.currentMediaItem?.localConfiguration?.tag as? StreamingResult
                            
                            // SYNC VOLUME NORMALIZATION & EFFECTS
                            val loudness = currentResult?.loudnessDb
                            baseVolume = calculateBaseVolume(loudness)
                            this@apply.volume = baseVolume * userVolume
                            applyAudioEffects(this@apply, loudness)

                            val currentTrackObj = currentSong
                            val hasVideo = !currentResult?.videoUrl.isNullOrBlank() && (currentResult?.isAudioOnly == false || currentTrackObj?.isVideo == true)
                            isVideoAvailable = hasVideo
                            if (!hasVideo) {
                                isVideoModeEnabled = false
                            } else if (currentTrackObj?.isVideo == true) {
                                isVideoModeEnabled = true
                            }
                            val shouldPlayVideoNow = hasVideo && isVideoModeEnabled
                            if (shouldPlayVideoNow) {
                                val vPlayer = getVideoPlayer(context)
                                val videoMediaItem = MediaItem.Builder()
                                    .setMediaId(mediaId ?: "")
                                    .setUri(Uri.parse(currentResult!!.videoUrl))
                                    .setMimeType(currentResult.videoMimeType ?: "video/mp4")
                                    .build()
                                vPlayer.stop()
                                vPlayer.clearMediaItems()
                                vPlayer.setMediaItem(videoMediaItem)
                                vPlayer.prepare()
                                videoSyncStartTime = System.currentTimeMillis()
                                vPlayer.seekTo(this@apply.currentPosition)
                                vPlayer.playWhenReady = isPlayerViewVisible && this@apply.playWhenReady
                            } else {
                                isVideoActuallyPlaying = false
                                videoPlayer?.pause()
                            }

                            scheduleBackgroundTriggers(context, this@apply)

                            // Proactively prefetch metadata for the next song in queue
                            val nextIdx = getNextIndex()
                            if (nextIdx != -1) {
                                prefetchMetadata(context, queue[nextIdx])
                            }

                            if (settingsManager?.isCrossfadeEnabled == false) {
                                prefetchNextSong(context)
                            } else if (settingsManager?.isCrossfadeEnabled == true && this@apply.mediaItemCount <= 1) {
                                // If crossfade is on but prefetch hasn't added the next item yet,
                                // we should try to prefetch if we are close to the end.
                                // Actually, startCrossfade handles its own item.
                            }

                            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && !stopAfterCurrentSong) {
                                this@apply.playWhenReady = true
                                this@apply.play()
                                this@MusicPlayer.isPlaying = true
                            }
                        }
                    }

                    override fun onPlaybackStateChanged(state: Int) {
                        if (this@apply != activePlayer) return

                        this@MusicPlayer.isPlaying = this@apply.playWhenReady

                        if (state == Player.STATE_READY) {
                            applyAudioEffects(this@apply)

                            // Reset skip state and restore volume quickly (100ms fade)
                            if (isFadingForSkip) {
                                isFadingForSkip = false
                                animateVolume(this@apply, baseVolume * userVolume, 100)
                                cleanPositionAtSkipTrigger = 0L
                                skipTriggerTime = 0L
                                lastSponsorSeekAttemptTime = 0L
                                // Restore high-accuracy seeking for normal playback
                                this@apply.setSeekParameters(SeekParameters.EXACT)
                            }

                            consecutiveErrors = 0
                            this@MusicPlayer.isLoading = false
                            setupVisualizer() // Ensure visualizer starts as soon as player is ready
                            scheduleBackgroundTriggers(context, this@apply)
                            savePlaybackState()

                            // Proactively prefetch metadata for the next song
                            val nextIdx = getNextIndex()
                            if (nextIdx != -1) {
                                prefetchMetadata(context, queue[nextIdx])
                            }

                            skipSilenceEnabled = settingsManager?.isSkipSilenceEnabled ?: false
                            playbackParameters = androidx.media3.common.PlaybackParameters(1.0f)
                            onReadyCallback?.invoke()

                            if (settingsManager?.isCrossfadeEnabled == false) {
                                prefetchNextSong(context)
                            }
                        } else if (state == Player.STATE_BUFFERING) {
                            // Suppress loader flicker during SponsorBlock skips.
                            // We check if a skip was recently triggered to distinguish between
                            // normal buffering (network) and skip-induced buffering (seeking).
                            val isSkippingSponsor = lastSponsorSeekTarget != -1L &&
                                (System.currentTimeMillis() - lastSponsorSeekAttemptTime < 3000)

                            if (!isSkippingSponsor) {
                                this@MusicPlayer.isLoading = true
                            }
                            startProgressUpdate(context)
                        } else if (state == Player.STATE_ENDED) {
                            if (stopAfterCurrentSong) {
                                stopAfterCurrentSong = false
                                pause()
                            } else {
                                // ANTI-BOUNCE GUARD: If the player reached ENDED while we are still loading 
                                // a new song (due to manual skip/clear), DO NOT trigger auto-advance.
                                if (this@MusicPlayer.isLoading || isCrossfadeInFlight || isCrossfadeTriggered) {
                                    Log.d("MusicPlayer", "onPlaybackStateChanged: STATE_ENDED ignored during track fetch or crossfade.")
                                    return
                                }

                                // Logic: If we reached ENDED, the internal player queue is exhausted.
                                // We must force advance to the next song in our logical queue.
                                lastSkipTime = 0L
                                skipJob?.cancel()
                                skipJob = mainScope.launch {
                                    playNextInQueue(context, isAuto = true)
                                }
                                refreshQueueIfLow()
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        if (this@apply == activePlayer) {
                            val errorCodeName = error.errorCodeName
                            val errorCause = error.cause?.message ?: "Unknown cause"
                            Log.e("MusicPlayer", "Playback Error: $errorCodeName (Code: ${error.errorCode}) - $errorCause", error)

                            // Check internet connectivity
                            val context = appContext ?: return
                            val isConnected = NetworkUtils.isNetworkAvailable(context)

                            if (!isConnected) {
                                Log.e("MusicPlayer", "DIAGNOSTIC: Network unavailable. Connectivity check failed.")
                                this@apply.pause()
                                this@MusicPlayer.isPlaying = false
                                this@MusicPlayer.isLoading = false
                                isPlaybackError = true
                                playbackErrorMessage = "No Internet Connection"
                                onErrorCallback?.invoke(error)
                                return
                            }

                            // Distinguish between Network issues (timeouts/403s) and Extraction/Parsing blocks
                            val isNetworkError = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                                               error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                                               error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
                                               error.errorCode == PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED

                            val isParsingError = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                                               error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED

                            if (isNetworkError && errorCause.contains("403")) {
                                Log.w("MusicPlayer", "DIAGNOSTIC: Potential Extraction Block or Link Expiry (HTTP 403).")
                            } else if (isNetworkError) {
                                Log.w("MusicPlayer", "DIAGNOSTIC: Network timeout or connection reset.")
                            } else if (isParsingError) {
                                Log.e("MusicPlayer", "DIAGNOSTIC: Media3 failed to parse the stream. Possible extraction corruption.")
                            }

                            if ((isNetworkError || isParsingError) && consecutiveErrors < 1) {
                                Log.w("MusicPlayer", "Attempting automated recovery/URL refresh for current song.")
                                consecutiveErrors++
                                mainScope.launch {
                                    val song = currentSong ?: return@launch
                                    val lastResult = (this@apply.currentMediaItem?.localConfiguration?.tag as? StreamingResult)
                                    if (lastResult != null && lastResult.clientName.isNotEmpty()) {
                                        failedClientsForCurrentSong.add(lastResult.clientName)
                                    }

                                    val targetBitrate = null
                                    val priority = if (settingsManager?.isDataSaverEnabled == true) "Data Saver" else "Force OPUS 160kbps"
                                    val preferredQuality = settingsManager?.preferredVideoQuality ?: "auto"
                                    
                                    // Fallback Logic: URL refresh for current song using YouTube.

                                    val result = unifiedRepository?.getStreamingUrl(
                                        videoId = song.videoId,
                                        cookies = cookies,
                                        failedClients = failedClientsForCurrentSong,
                                        targetBitrate = targetBitrate,
                                        priority = priority,
                                        preferredVideoQuality = preferredQuality
                                    )
                                    if (result != null) {
                                        // Ensure the recovery attempt is still for the song currently displayed
                                        if (song.videoId == currentSong?.videoId) {
                                            playStream(context, result, song, cookies, isAutoPlay = true)
                                        }
                                    } else {
                                        Log.e("MusicPlayer", "Failed to refresh URL on error. Skipping in 10s...")
                                        delay(10000)
                                        playNextInQueue(context, isAuto = true)
                                    }
                                }
                                return
                            }

                            this@apply.pause()
                            consecutiveErrors++
                            this@MusicPlayer.isPlaying = false
                            this@MusicPlayer.isLoading = false

                            if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
                                Log.e("MusicPlayer", "Max consecutive errors reached: $consecutiveErrors")
                                consecutiveErrors = 0
                                onErrorCallback?.invoke(error)
                            } else {
                                skipJob?.cancel()
                                skipJob = mainScope.launch {
                                    val errorSongId = currentSong?.videoId
                                    Log.w("MusicPlayer", "Auto-skipping to next song in 10s... (Count: $consecutiveErrors)")
                                    delay(10000)
                                    // ONLY skip if the user hasn't already changed the song manually
                                    if (isActive && currentSong?.videoId == errorSongId) {
                                        playNextInQueue(context, isAuto = true)
                                    }
                                }
                                onErrorCallback?.invoke(error)
                            }
                        }
                    }
                })
            }
    }

    private fun applyAudioEffects(player: ExoPlayer, trackLoudness: Double? = null) {
        currentLoudness = trackLoudness
        try {
            val audioSessionId = player.audioSessionId
            if (audioSessionId == C.AUDIO_SESSION_ID_UNSET) return

            val settings = settingsManager ?: return

            if (currentAudioSessionId != audioSessionId) {
                releaseAudioEffects()
                currentAudioSessionId = audioSessionId
            }
            appContext?.let { ctx ->
                AudioFxManager.attachToSession(ctx, audioSessionId)
            }

            // Loudness Enhancer disabled as per user request for "No manual boosting"
            loudnessEnhancer?.enabled = false

            // 2. Anti-Peak Limiter (Dynamic Processor)
            if (settings.isPeakLimiterEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                if (dynamicsProcessing == null) {
                    // Limiter config: 1 channel (mono/stereo both handled by framework), enabled=true,
                    // ratio=10 (heavy), threshold=-0.1dB (just below ceiling),
                    // attack=0.1ms (instant), release=100ms
                    val limiter = android.media.audiofx.DynamicsProcessing.Config.Builder(0, 1, true, 1, false, 0, false, 0, true).build().getLimiterByChannelIndex(0).apply {
                        isEnabled = true
                        ratio = 10f
                        threshold = -0.1f
                        attackTime = 0.1f
                        releaseTime = 100f
                    }

                    val config = android.media.audiofx.DynamicsProcessing.Config.Builder(
                        android.media.audiofx.DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        1, // channel count
                        true, 1, // preEq
                        false, 0, // mbc
                        false, 0, // postEq
                        true // limiter
                    ).setLimiterByChannelIndex(0, limiter).build()

                    dynamicsProcessing = android.media.audiofx.DynamicsProcessing(0, audioSessionId, config).apply {
                        enabled = true
                    }
                } else {
                    dynamicsProcessing?.enabled = true
                }
            } else {
                dynamicsProcessing?.enabled = false
            }

            // 3. Virtual 3D Surround & Custom Reverb (Removed as requested)
            if (false && settings.surroundMode != "None") {
                if (virtualizer == null) {
                    virtualizer = android.media.audiofx.Virtualizer(0, audioSessionId).apply {
                        setStrength(1000.toShort())
                        enabled = true
                    }
                } else {
                    virtualizer?.enabled = true
                }

                if (reverb == null) {
                    reverb = android.media.audiofx.PresetReverb(0, audioSessionId).apply {
                        preset = when (settings.surroundMode) {
                            "Empty Stadium" -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL
                            "Cyberpunk Club" -> android.media.audiofx.PresetReverb.PRESET_LARGEROOM
                            "Small Studio" -> android.media.audiofx.PresetReverb.PRESET_SMALLROOM
                            else -> android.media.audiofx.PresetReverb.PRESET_NONE
                        }
                        enabled = true
                    }
                } else {
                    reverb?.enabled = true
                    reverb?.preset = when (settings.surroundMode) {
                        "Empty Stadium" -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL
                        "Cyberpunk Club" -> android.media.audiofx.PresetReverb.PRESET_LARGEROOM
                        "Small Studio" -> android.media.audiofx.PresetReverb.PRESET_SMALLROOM
                        else -> android.media.audiofx.PresetReverb.PRESET_NONE
                    }
                }
            } else {
                virtualizer?.enabled = false
                reverb?.enabled = false
            }

        } catch (e: Exception) {
            Log.e("MusicPlayer", "Failed to apply audio effects", e)
        }
    }

    private fun releaseAudioEffects() {
        try {
            loudnessEnhancer?.release()
            dynamicsProcessing?.release()
            virtualizer?.release()
            reverb?.release()
        } catch (e: Exception) {
            Log.e("MusicPlayer", "Error releasing effects", e)
        } finally {
            loudnessEnhancer = null
            dynamicsProcessing = null
            virtualizer = null
            reverb = null
            currentAudioSessionId = C.AUDIO_SESSION_ID_UNSET
        }
    }

    fun getAudioSessionId(): Int {
        return activePlayer?.audioSessionId ?: C.AUDIO_SESSION_ID_UNSET
    }

    fun openEqualizer(context: Context) {
        AudioFxManager.openEqualizer(context, getAudioSessionId())
    }

    private fun animateVolume(player: ExoPlayer, targetVolume: Float, durationMs: Long, onEnd: (() -> Unit)? = null) {
        if (durationMs <= 50) {
            player.volume = targetVolume
            onEnd?.invoke()
            return
        }
        volumeFadeJob?.cancel()
        volumeFadeJob = mainScope.launch {
            val startTime = System.currentTimeMillis()
            val startVol = player.volume
            val endVol = targetVolume

            while (isActive) {
                val now = System.currentTimeMillis()
                val elapsed = now - startTime
                if (elapsed >= durationMs) break

                val progress = elapsed.toFloat() / durationMs
                player.volume = (startVol + (endVol - startVol) * progress).coerceIn(0f, 1f)

                // Use a slightly larger delay to be more background-friendly,
                // but the time-based calculation ensures we finish on time even if throttled.
                delay(40)
            }
            if (isActive) {
                player.volume = targetVolume
                onEnd?.invoke()
            }
        }
    }

    private fun startProgressUpdate(context: Context) {
        progressJob?.cancel()
        progressJob = mainScope.launch {
            while (isActive) {
                val currentP = activePlayer
                if (currentP == null) {
                    delay(500)
                    continue
                }

                // Robust Visualizer check: Ensure it's running if player is active and screen is visible
                if (currentP.playWhenReady && currentP.playbackState == Player.STATE_READY) {
                    if (settingsManager?.isVisualizerEnabled == true && isPlayerViewVisible) {
                        setupVisualizer()
                    } else if (visualizer != null) {
                        releaseVisualizer()
                    }
                }

                // Sync video player for instant YT Music style Song | Video playback
                videoPlayer?.let { vPlayer ->
                    if (isVideoAvailable && isVideoModeEnabled && isPlayerViewVisible && vPlayer.playbackState != Player.STATE_IDLE) {
                        val audioPos = currentP.currentPosition
                        if (currentP.playWhenReady) {
                            if (!vPlayer.playWhenReady) {
                                vPlayer.seekTo(audioPos)
                                vPlayer.playWhenReady = true
                            }
                            if (vPlayer.playbackState == Player.STATE_READY || vPlayer.isPlaying) {
                                isVideoActuallyPlaying = true
                            }
                            val diff = abs(vPlayer.currentPosition - audioPos)
                            if (diff > 750L && vPlayer.playbackState == Player.STATE_READY) {
                                vPlayer.seekTo(audioPos)
                            }
                        } else {
                            vPlayer.playWhenReady = false
                        }
                    } else {
                        isVideoActuallyPlaying = false
                        if (vPlayer.playWhenReady) vPlayer.playWhenReady = false
                    }
                }

                // FIX: Update UI position only if we are actually supposed to be playing or if we are actively seeking/buffering.
                if (!currentP.playWhenReady && currentP.playbackState == Player.STATE_READY) {
                    // Update duration/position once and then wait
                    duration = (currentP.duration.takeIf { it != C.TIME_UNSET } ?: 0L).coerceAtLeast(0L)
                    currentPosition = currentP.currentPosition.coerceAtLeast(0L)
                    delay(100)
                    continue
                }

                // Calculate "Clean" UI Position and Duration (Trimming skipped segments)
                val rawPosition = currentP.currentPosition
                val rawDuration = currentP.duration

                // Instant Non-Music Skip Silence:
                // SilenceSkippingAudioProcessor is tuned with minimumSilenceDurationUs = 650_000L (0.65s),
                // silenceRetentionRatio = 0.0f, and maxSilenceToKeepDurationUs = 25_000L so beat pauses
                // (< 0.65s) are untouched while silent intros/outros/interludes (>= 0.65s) are cut instantly!
                val userWantsSkipSilence = settingsManager?.isSkipSilenceEnabled == true
                if (currentP.skipSilenceEnabled != userWantsSkipSilence) {
                    configureSmartSilenceProcessor(currentP)
                    currentP.skipSilenceEnabled = userWantsSkipSilence
                }

                // SponsorBlock MUST ONLY act on video songs, never on audio songs!
                val isPlayingVideoSong = isVideoAvailable && isVideoModeEnabled
                val activeSegments = if (settingsManager?.isSponsorBlockEnabled == true && isPlayingVideoSong) {
                    mergedSponsorSegments
                } else {
                    emptyList()
                }

                // 1. Proactive SponsorBlock Skip Check (Video songs only, strictly after 3500ms so a song NEVER restarts at 0.5s!)
                if (settingsManager?.isSponsorBlockEnabled == true && isPlayingVideoSong && activeSegments.isNotEmpty() && rawPosition >= 3500L) {
                    val currentMs = rawPosition

                    // Ignore any intro segment (it.first <= 2500L) after playback has already started
                    val inside = activeSegments.find {
                        it.first > 2500L && currentMs >= it.first - 100 && currentMs < it.second - 10
                    }

                    if (inside != null) {
                        val skipToMs = inside.second
                        val now = System.currentTimeMillis()

                        // Loop Protection: Only trigger if we haven't skipped this segment yet OR 1s has passed (retry)
                        if (lastSponsorSeekTarget != skipToMs || (now - lastSponsorSeekAttemptTime > 1000)) {
                            lastSponsorSeekTarget = skipToMs
                            lastSponsorSeekAttemptTime = now
                            cleanPositionAtSkipTrigger = currentPosition
                            skipTriggerTime = now
                            isFadingForSkip = false
                            currentP.setSeekParameters(SeekParameters.EXACT)
                            currentP.seekTo(skipToMs)
                            currentP.volume = baseVolume * userVolume
                            Log.d("MusicPlayer", "SponsorBlock (Video Only): Jumped to $skipToMs")

                            delay(20)
                            continue
                        }
                    } else {
                        // Reset the target tracking once we are clearly past the segment
                        if (lastSponsorSeekTarget != -1L && !isFadingForSkip) {
                            if (rawPosition > lastSponsorSeekTarget - 500) {
                                lastSponsorSeekTarget = -1L
                            }
                        }
                    }
                }

                // 2. Continuous Wave Movement & Interpolation during seeks
                val isBuffering = currentP.playbackState == Player.STATE_BUFFERING
                val isNearSkip = isFadingForSkip // Use the fade flag to drive UI interpolation accurately

                // 3. Track Most Played at 50%
                if (!hasIncrementedPlayCount && duration > 0 && currentPosition >= duration / 2) {
                    hasIncrementedPlayCount = true
                    val song = currentSong
                    if (song != null) {
                        LastFmManager.scrobbleTrack(context, song)
                        ioScope.launch {
                            database?.songDao()?.incrementPlayCount(
                                song.videoId, song.title, song.artist, song.thumbnailUrl, song.artistId
                            )
                            if (settingsManager?.smartDownloadsEnabled == true) {
                                triggerSmartDownloads(context)
                            }
                            // Call specialized increment for instant Firebase Console feedback
                            // Pass the actual duration to track total minutes played
                            FirebaseSyncManager.incrementPlayCount(
                                context,
                                song.videoId,
                                song.title,
                                song.artist,
                                song.thumbnailUrl,
                                song.artistId,
                                rawDuration // passing the Uploads duration in ms
                            )
                        }
                    }
                }

                if ((isBuffering || isNearSkip) && currentP.playWhenReady) {
                    currentVolumeAmplitude = 0.15f + (Math.random().toFloat() * 0.25f)
                    if (isNearSkip) {
                        val elapsed = System.currentTimeMillis() - skipTriggerTime
                        // Smoothly advance UI while player buffers the jump.
                        // Cap interpolation at 5 seconds to prevent runaway drift if network fails.
                        currentPosition = cleanPositionAtSkipTrigger + elapsed.coerceAtMost(5000)
                        delay(50)
                        continue
                    }
                }

                // 3. Map Raw Position to Clean Position (Trimming)
                var totalSkippedBefore = 0L
                for (seg in activeSegments) {
                    if (rawPosition >= seg.second) {
                        totalSkippedBefore += (seg.second - seg.first)
                    } else if (rawPosition >= seg.first) {
                        // Freeze UI at segment start ONLY if we are actively skipping it.
                        totalSkippedBefore += (rawPosition - seg.first)
                    }
                }

                // 4. SimpMusic Crossfade Pre-Buffer & DJ Transition Trigger
                val crossfadeDurationMs = 1500L // Fixed 1.5s crossfade per user request
                if (settingsManager?.isCrossfadeEnabled == true &&
                    currentP.playbackState == Player.STATE_READY &&
                    !isCrossfadeTriggered &&
                    !isCrossfadeInFlight &&
                    !isPrebufferingCrossfade &&
                    rawDuration > (crossfadeDurationMs + 4000L) &&
                    rawPosition >= 3000L &&
                    repeatMode != Player.REPEAT_MODE_ONE
                ) {
                    prebufferCrossfadeNextSong(context)
                }

                if (settingsManager?.isCrossfadeEnabled == true &&
                    !isCrossfadeTriggered &&
                    rawDuration > (crossfadeDurationMs + 3000L) &&
                    rawPosition >= (rawDuration - crossfadeDurationMs) &&
                    repeatMode != Player.REPEAT_MODE_ONE
                ) {
                    Log.d("MusicPlayer", "SimpMusic Crossfade triggered at ${rawPosition}ms / ${rawDuration}ms (duration=${crossfadeDurationMs}ms, djMode=${settingsManager?.crossfadeDjMode})")
                    isCrossfadeTriggered = true
                    startCrossfade(context)
                }

                // Continuously persist exact playback timestamp every 2s so app exit/reopen resumes at exact millisecond
                val nowSave = System.currentTimeMillis()
                if (currentP.isPlaying && rawPosition > 0L && (nowSave - lastPositionSaveTimeMs >= 2000L)) {
                    lastPositionSaveTimeMs = nowSave
                    settingsManager?.lastPlayedPositionMs = rawPosition
                    savePlaybackState()
                }

                // Use a small 500ms safety buffer to ensure duration updates don't cause
                // negative clean positions or erratic slider jumps at start/end.
                if (rawDuration > 0) {
                    currentPosition = (rawPosition - totalSkippedBefore).coerceIn(0, rawDuration)
                    val totalSkippedMs = activeSegments.sumOf { it.second - it.first }
                    duration = (rawDuration - totalSkippedMs).coerceAtLeast(0)
                } else {
                    currentPosition = if (rawPosition != C.TIME_UNSET) rawPosition else 0L
                    duration = (rawDuration.takeIf { it != C.TIME_UNSET } ?: 0L).coerceAtLeast(0L)
                }

                delay(100)
            }
        }
    }

    private fun prebufferCrossfadeNextSong(context: Context) {
        if (isCrossfadeInFlight || isLoading) return
        val nextIndex = getNextIndex()
        if (nextIndex == -1) return
        val nextSong = queue.getOrNull(nextIndex) ?: return
        if (prebufferedCrossfadeVideoId == nextSong.videoId || isPrebufferingCrossfade) return

        isPrebufferingCrossfade = true
        ioScope.launch {
            try {
                val segments = if (isStrictVideoPlaybackForSong(nextSong.videoId)) {
                    fetchSponsorSegmentsSuspend(nextSong.videoId)
                } else emptyList()
                val initialTrimMs = segments.firstOrNull { it.first <= 2500L }?.second ?: 0L

                val priority = if (settingsManager?.isDataSaverEnabled == true) "Data Saver" else "Force OPUS 160kbps"
                val preferredQuality = settingsManager?.preferredVideoQuality ?: "auto"
                val result = unifiedRepository?.getStreamingUrl(
                    videoId = nextSong.videoId,
                    cookies = cookies,
                    failedClients = emptyList(),
                    targetBitrate = null,
                    priority = priority,
                    preferredVideoQuality = preferredQuality
                ) ?: return@launch

                streamUserAgents[result.url] = result.userAgent
                result.videoUrl?.let { streamUserAgents[it] = result.userAgent }
                prefetchMetadata(context, nextSong)

                withContext(Dispatchers.Main) {
                    if (isCrossfadeInFlight || isLoading) return@withContext
                    val nextP = getInactivePlayer(context)
                    val metadata = createMediaMetadata(nextSong)
                    val mediaItem = MediaItem.Builder()
                        .setUri(result.url)
                        .setMediaId(nextSong.videoId)
                        .setMediaMetadata(metadata)
                        .setMimeType(result.mimeType)
                        .setTag(result)
                        .build()

                    val wantSkipSilence = settingsManager?.isSkipSilenceEnabled == true
                    nextP.stop()
                    nextP.clearMediaItems()
                    configureSmartSilenceProcessor(nextP)
                    nextP.skipSilenceEnabled = wantSkipSilence
                    nextP.volume = 0f
                    nextP.playWhenReady = false
                    if (initialTrimMs > 0L) {
                        nextP.setMediaItem(mediaItem, initialTrimMs)
                    } else {
                        nextP.setMediaItem(mediaItem, true)
                    }
                    nextP.prepare()
                    prebufferedCrossfadeVideoId = nextSong.videoId
                    Log.d("MusicPlayer", "SimpMusic Crossfade pre-buffered and ready: ${nextSong.title} (trim=${initialTrimMs}ms)")
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Failed to prebuffer crossfade song", e)
            } finally {
                isPrebufferingCrossfade = false
            }
        }
    }

    private fun startCrossfade(context: Context) {
        val nextIndex = getNextIndex()
        if (nextIndex == -1) {
            isCrossfadeTriggered = false
            return
        }
        if (isCrossfadeInFlight) return
        isCrossfadeInFlight = true

        val nextSong = queue[nextIndex]
        val currentP = activePlayer
        val nextP = getInactivePlayer(context)

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WaveMuzix:Crossfade")

        crossfadeJob?.cancel()
        crossfadeJob = ioScope.launch {
            try {
                wakeLock?.acquire(30000L)
                Log.d("MusicPlayer", "SimpMusic Crossfade Starting: ${nextSong.title}")

                val prebufferedItem = withContext(Dispatchers.Main) {
                    nextP.currentMediaItem?.takeIf {
                        it.mediaId == nextSong.videoId && nextP.playbackState != Player.STATE_IDLE
                    }
                }
                val prebufferedResult = prebufferedItem?.localConfiguration?.tag as? StreamingResult

                val result = prebufferedResult ?: run {
                    val priority = if (settingsManager?.isDataSaverEnabled == true) "Data Saver" else "Force OPUS 160kbps"
                    val preferredQuality = settingsManager?.preferredVideoQuality ?: "auto"
                    unifiedRepository?.getStreamingUrl(
                        videoId = nextSong.videoId,
                        cookies = cookies,
                        failedClients = emptyList(),
                        targetBitrate = null,
                        priority = priority,
                        preferredVideoQuality = preferredQuality
                    )
                }

                if (result != null) {
                    streamUserAgents[result.url] = result.userAgent
                    result.videoUrl?.let { streamUserAgents[it] = result.userAgent }
                    val segments = sponsorSegmentsCache[nextSong.videoId].orEmpty()
                    val initialTrimMs = segments.firstOrNull { it.first <= 2500L }?.second ?: 0L

                    withContext(Dispatchers.Main) {
                        val metadata = createMediaMetadata(nextSong)
                        val isDjTransition = settingsManager?.crossfadeDjMode == true
                        configureSmartSilenceProcessor(nextP)
                        nextP.skipSilenceEnabled = (settingsManager?.isSkipSilenceEnabled == true) || isDjTransition
                        nextP.volume = if (isDjTransition) (calculateBaseVolume(result.loudnessDb) * userVolume).coerceIn(0f, 1f) else 0f

                        if (prebufferedItem == null) {
                            val taggedMediaItem = MediaItem.Builder()
                                .setUri(result.url)
                                .setMediaId(nextSong.videoId)
                                .setMediaMetadata(metadata)
                                .setMimeType(result.mimeType)
                                .setTag(result)
                                .build()
                            nextP.stop()
                            nextP.clearMediaItems()
                            if (initialTrimMs > 0L) {
                                nextP.setMediaItem(taggedMediaItem, initialTrimMs)
                            } else {
                                nextP.setMediaItem(taggedMediaItem, true)
                            }
                            nextP.prepare()
                        }

                        currentServer = result.clientName
                        releaseVisualizer()
                        inactivePlayer = currentP
                        activePlayer = nextP
                        prebufferedCrossfadeVideoId = null

                        val oldIndex = currentIndex
                        currentIndex = nextIndex
                        currentSong = nextSong
                        targetSongId = nextSong.videoId
                        scheduledVideoId = null
                        isCrossfadeTriggered = false
                        hasIncrementedPlayCount = false

                        val hasNextVideo = !result.videoUrl.isNullOrBlank() && (!result.isAudioOnly || nextSong.isVideo)
                        isVideoAvailable = hasNextVideo
                        if (!hasNextVideo) {
                            isVideoModeEnabled = false
                        } else if (nextSong.isVideo) {
                            isVideoModeEnabled = true
                        }
                        if (hasNextVideo && isVideoModeEnabled) {
                            val vPlayer = getVideoPlayer(context)
                            val videoMediaItem = MediaItem.Builder()
                                .setMediaId(nextSong.videoId)
                                .setUri(Uri.parse(result.videoUrl))
                                .setMimeType(result.videoMimeType ?: "video/mp4")
                                .setMediaMetadata(metadata)
                                .build()
                            vPlayer.stop()
                            vPlayer.clearMediaItems()
                            vPlayer.setMediaItem(videoMediaItem)
                            vPlayer.prepare()
                            videoSyncStartTime = System.currentTimeMillis()
                            vPlayer.playWhenReady = isPlayerViewVisible
                            isVideoActuallyPlaying = false
                        } else {
                            isVideoActuallyPlaying = false
                            videoPlayer?.pause()
                        }

                        Log.d("MusicPlayer", "SimpMusic Crossfade Transition: $oldIndex -> $currentIndex (${nextSong.title})")
                        onPlayerChanged?.invoke(nextP)

                        nextP.playWhenReady = true
                        nextP.play()

                        applyAudioEffects(nextP, result.loudnessDb)
                        LastFmManager.updateNowPlaying(context, nextSong, parseDurationToMs(nextSong.durationText))

                        this@MusicPlayer.isPlaying = true
                        this@MusicPlayer.isLoading = false
                        startProgressUpdate(context)

                        if (hasNextVideo && isVideoModeEnabled && settingsManager?.isSponsorBlockEnabled == true) {
                            applySponsorSegments(nextSong.videoId, segments.filter { it.first > 2500L })
                        } else {
                            sponsorSegments.clear()
                            mergedSponsorSegments = emptyList()
                        }
                        fetchMetadata(context, nextSong)
                        startLyricsFetch(nextSong)
                        refreshQueueIfLow()

                        val oldBaseVol = baseVolume
                        val nextBaseVol = calculateBaseVolume(result.loudnessDb)
                        baseVolume = nextBaseVol
                        fadeBetween(currentP, nextP, oldBaseVol, nextBaseVol)
                    }
                } else {
                    Log.e("MusicPlayer", "Crossfade failed: Could not get URL, falling back to playNextInQueue")
                    isCrossfadeTriggered = false
                    isCrossfadeInFlight = false
                    withContext(Dispatchers.Main) {
                        playNextInQueue(context, isAuto = true)
                    }
                }
            } catch (e: CancellationException) {
                isCrossfadeInFlight = false
                throw e
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Crossfade fetch failed", e)
                isCrossfadeTriggered = false
                isCrossfadeInFlight = false
            } finally {
                if (wakeLock?.isHeld == true) wakeLock.release()
            }
        }
    }

    private fun fadeBetween(outPlayer: ExoPlayer?, inPlayer: ExoPlayer, outBaseVol: Float, inBaseVol: Float) {
        val fadeDuration = 1500L // Fixed 1.5s blend window per user request
        val isDjMode = settingsManager?.crossfadeDjMode == true

        fadeJob?.cancel()
        fadeJob = mainScope.launch {
            try {
                val steps = 75
                val interval = (fadeDuration / steps).coerceAtLeast(16L)

                for (i in 0..steps) {
                    val p = i.toFloat() / steps
                    val (outCurve, inCurve) = if (isDjMode) {
                        // DJ Transition: both tracks blend at full energy with smooth mid-transition bass handoff
                        val bassFactor = if (p in 0.20f..0.65f) 0.52f else 1.0f
                        AudioFxManager.applyCurrentStateToHardware(djBassCutFactor = bassFactor)
                        1.0f to 1.0f
                    } else {
                        // SimpMusic Equal-Power Cosine/Sine Crossfade
                        val eqOut = kotlin.math.cos(p * Math.PI / 2.0).toFloat()
                        val eqIn = kotlin.math.sin(p * Math.PI / 2.0).toFloat()
                        eqOut to eqIn
                    }

                    outPlayer?.volume = (outCurve * outBaseVol * userVolume).coerceIn(0f, 1f)
                    inPlayer.volume = (inCurve * inBaseVol * userVolume).coerceIn(0f, 1f)
                    delay(interval)
                }
            } finally {
                AudioFxManager.applyCurrentStateToHardware(djBassCutFactor = 1.0f)
                outPlayer?.stop()
                outPlayer?.clearMediaItems()
                outPlayer?.volume = outBaseVol * userVolume
                inPlayer.volume = inBaseVol * userVolume
                isCrossfadeInFlight = false
            }
        }
    }

    private fun stopProgressUpdate() {
        progressJob?.cancel()
        // DO NOT release visualizer here as it may cause crash if toggled rapidly.
        // It is managed by setupVisualizer's check and releaseVisualizer() call on song change.
    }

    private fun setupVisualizer() {
        // Audio visualizer removed as requested
        releaseVisualizer()
        if (true) return
        val context = appContext ?: return
        if (settingsManager?.isVisualizerEnabled == false) {
            releaseVisualizer()
            return
        }

        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.w("MusicPlayer", "Visualizer skip: RECORD_AUDIO permission not granted")
            return
        }

        val player = activePlayer ?: return
        val audioSessionId = player.audioSessionId
        if (audioSessionId <= 0) return 

        if (visualizer != null && currentVisualizerSessionId == audioSessionId) {
            try {
                if (visualizer?.enabled == false) visualizer?.enabled = true
                return 
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Visualizer health check failed, recreating", e)
            }
        }

        releaseVisualizer()
        try {
            currentVisualizerSessionId = audioSessionId
            visualizer = Visualizer(audioSessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    private val mainHandler = Handler(Looper.getMainLooper())
                    private var lastUpdateTime = 0L
                    private val THROTTLE_MS = 11L // ~90 FPS

                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        if (isLoading || !this@MusicPlayer.isPlaying) {
                            resetAmplitudes()
                            return
                        }
                        if (lastSponsorSeekTarget != -1L) return

                        val now = System.currentTimeMillis()
                        if (now - lastUpdateTime < THROTTLE_MS) return
                        lastUpdateTime = now

                        waveform?.let {
                            var sum = 0f
                            for (b in it) {
                                sum += abs(b.toInt() - 128).toFloat()
                            }
                            val amplitude = (sum / it.size) / 64f
                            mainHandler.post { currentVolumeAmplitude = amplitude }
                        }
                    }

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        if (isLoading || fft == null || !this@MusicPlayer.isPlaying) {
                            resetAmplitudes()
                            return
                        }

                        val now = System.currentTimeMillis()
                        if (now - lastUpdateTime < THROTTLE_MS) return
                        // Note: we don't update lastUpdateTime here to allow both listeners to fire 
                        // within the same "frame" if they arrive close together.
                        
                        var bassSum = 0f
                        var trebleSum = 0f
                        val bassRange = (fft.size * 0.1).toInt().coerceAtLeast(2)
                        for (i in 2 until bassRange step 2) {
                            bassSum += hypot(fft[i].toFloat(), fft[i+1].toFloat())
                        }
                        val trebleStart = (fft.size * 0.7).toInt()
                        for (i in trebleStart until fft.size - 1 step 2) {
                            trebleSum += hypot(fft[i].toFloat(), fft[i+1].toFloat())
                        }
                        
                        val bassAmp = (bassSum / (bassRange / 2)) / 50f
                        val trebleAmp = (trebleSum / ((fft.size - trebleStart) / 2)) / 30f
                        
                        mainHandler.post {
                            currentBassAmplitude = bassAmp.coerceIn(0f, 2f)
                            currentTrebleAmplitude = trebleAmp.coerceIn(0f, 2f)
                        }
                    }

                    private fun resetAmplitudes() {
                        if (currentVolumeAmplitude > 0 || currentBassAmplitude > 0 || currentTrebleAmplitude > 0) {
                            mainHandler.post {
                                currentVolumeAmplitude = 0f
                                currentBassAmplitude = 0f
                                currentTrebleAmplitude = 0f
                            }
                        }
                    }
                }, Visualizer.getMaxCaptureRate(), true, true)
                enabled = true
            }
            Log.d("MusicPlayer", "Visualizer attached to session: $audioSessionId at max rate")
        } catch (e: Exception) {
            Log.e("MusicPlayer", "Visualizer setup failed", e)
            currentVisualizerSessionId = C.AUDIO_SESSION_ID_UNSET
            visualizer = null
        }
    }

    fun releaseVisualizer() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (e: Exception) {}
        visualizer = null
        currentVisualizerSessionId = C.AUDIO_SESSION_ID_UNSET
        
        // Immediate reset of amplitudes to prevent "frozen" UI state
        currentVolumeAmplitude = 0f
        currentBassAmplitude = 0f
        currentTrebleAmplitude = 0f
    }

    fun persistExactPlaybackPosition() {
        val player = activePlayer ?: return
        val pos = player.currentPosition.coerceAtLeast(0L)
        val songId = currentSong?.videoId ?: return
        settingsManager?.lastPlayedSongId = songId
        settingsManager?.lastPlayedPositionMs = pos
        savePlaybackState(overridePositionMs = pos)
    }

    private fun savePlaybackState(overridePositionMs: Long? = null) {
        if (settingsManager?.isSavePlaybackState == false) return
        
        val player = activePlayer ?: return
        val currentSongId = currentSong?.videoId ?: return
        val queueList = queue.toList()
        val index = currentIndex
        val position = (overridePositionMs ?: player.currentPosition).coerceAtLeast(0L)
        settingsManager?.lastPlayedSongId = currentSongId
        settingsManager?.lastPlayedPositionMs = position
        
        // Capture current metadata state
        val currentArtistDetails = mapOf(
            "avatarUrl" to artistAvatarUrl,
            "source" to artistAvatarSource,
            "name" to sanitizedArtistName
        )
        val currentVideoDetails = videoDetails
        
        // Collect neighbor data for offline readiness (Previous + Next 4)
        val neighbors = mutableListOf<Song>()
        if (index > 0) neighbors.add(queueList[index - 1])
        
        // Add next 4 songs to neighbors for persistence
        for (i in 1..4) {
            val nextIdx = if (shuffleEnabled) {
                val currentPos = shuffledIndices.indexOf(index)
                if (currentPos != -1 && currentPos + i < shuffledIndices.size) {
                    shuffledIndices[currentPos + i]
                } else -1
            } else {
                if (index + i < queueList.size) index + i else -1
            }
            
            if (nextIdx != -1) {
                neighbors.add(queueList[nextIdx])
            }
        }

        ioScope.launch {
            try {
                val gson = Gson()
                val queueJson = gson.toJson(queueList)
                val artistJson = gson.toJson(currentArtistDetails)
                val videoJson = currentVideoDetails?.let { gson.toJson(it) }
                val neighborsJson = gson.toJson(neighbors)
                
                database?.songDao()?.insertPlaybackState(
                    PlaybackStateEntity(
                        queueJson = queueJson,
                        currentIndex = index,
                        currentPosition = position,
                        videoId = currentSongId,
                        artistDetailsJson = artistJson,
                        videoDetailsJson = videoJson,
                        neighborDataJson = neighborsJson
                    )
                )
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Failed to save playback state", e)
            }
        }
    }

    fun restorePlaybackState(context: Context) {
        if (settingsManager == null) {
            settingsManager = SettingsManager(context.applicationContext)
        }
        if (database == null) {
            database = com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context.applicationContext)
        }
        if (settingsManager?.isSavePlaybackState != true) return

        ioScope.launch {
            try {
                val state = database?.songDao()?.getPlaybackState() ?: return@launch
                val gson = Gson()
                val songListType = object : TypeToken<List<Song?>>() {}.type
                val rawQueue: List<Song?>? = gson.fromJson(state.queueJson, songListType)
                val restoredQueue: List<Song> = rawQueue?.mapNotNull { it?.sanitized() } ?: emptyList()
                
                if (restoredQueue.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        queue.clear()
                        queue.addAll(restoredQueue)
                        currentIndex = state.currentIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
                        val song = queue.getOrNull(currentIndex)
                        
                        if (song != null && song.videoId == state.videoId) {
                            val exactSavedPos = maxOf(state.currentPosition, settingsManager?.lastPlayedPositionMs ?: 0L)
                            // Restore basic state
                            currentSong = song
                            currentPosition = exactSavedPos
                            pendingRestorePosition = exactSavedPos
                            pendingRestoreVideoId = state.videoId
                            duration = parseDurationToMs(song.durationText)
                            
                            // Restore detailed metadata immediately for offline UI support
                            try {
                                state.artistDetailsJson?.takeIf { it.isNotBlank() && it != "null" }?.let { json ->
                                    val details: Map<String, String?>? = gson.fromJson(json, object : TypeToken<Map<String, String?>>() {}.type)
                                    if (details != null) {
                                        artistAvatarUrl = details["avatarUrl"]
                                        artistAvatarSource = details["source"]
                                        val safeName = (details["name"] ?: song.artist).ifBlank { "Unknown" }
                                        sanitizedArtistName = safeName
                                        
                                        // Populate caches to prevent re-fetching (ConcurrentHashMap requires non-null key & value)
                                        artistAvatarUrl?.let { artistAvatarCache[safeName] = it }
                                        artistAvatarSource?.let { artistAvatarSourceCache[safeName] = it }
                                    }
                                }
                                
                                state.videoDetailsJson?.takeIf { it.isNotBlank() && it != "null" }?.let { json ->
                                    val details: VideoDetails? = gson.fromJson(json, VideoDetails::class.java)
                                    if (details != null && song.videoId.isNotEmpty()) {
                                        videoDetails = details
                                        videoDetailsCache[song.videoId] = details
                                    }
                                }
                            } catch (e: Exception) {
                                Log.e("MusicPlayer", "Metadata restoration failed", e)
                            }
                            
                            // Load neighbors into cache
                            state.neighborDataJson?.takeIf { it.isNotBlank() && it != "null" }?.let { json ->
                                try {
                                    val neighbors: List<Song?>? = gson.fromJson(json, songListType)
                                    neighbors?.mapNotNull { it?.sanitized() }?.forEach { n ->
                                        // Prefetching will handle logic if already in cache
                                        prefetchMetadata(context, n)
                                    }
                                } catch (e: Exception) {}
                            }

                            // Still fetch fresh metadata in background if online
                            fetchMetadata(context, song)
                            startLyricsFetch(song)
                            // Pre-warm cached audio stream at exact saved millisecond so pressing Play is instantaneous!
                            warmUpRestoredSongCache(context, song, exactSavedPos)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Failed to restore playback state", e)
            }
        }
    }

    @OptIn(UnstableApi::class)
    fun playStream(
        context: Context,
        result: StreamingResult,
        song: Song,
        cookies: String? = null,
        playlist: List<Song> = emptyList(),
        isAutoPlay: Boolean = false,
        startRadio: Boolean = true
    ) {
        // TARGET LOCK GUARD: Only proceed if this song is still the user's latest target.
        if (song.videoId != targetSongId) {
            Log.d("MusicPlayer", "playStream: Discarding stale fetch for ${song.title}")
            return
        }

        // COMMIT STATE: Now that we are sure this is the song to play, update the global state.
        currentSong = song
        currentIndex = if (playlist.isNotEmpty()) {
            playlist.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        } else if (currentIndex in queue.indices && queue[currentIndex].videoId == song.videoId) {
            currentIndex
        } else {
            queue.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        }
        
        duration = parseDurationToMs(song.durationText)
        highResThumbnailUrl = getHighResThumbnailUrl(song.thumbnailUrl)
        currentSongDurationText = song.durationText
        
        val player = getInstance(context)
        player.stop()
        player.clearMediaItems()
        
        releaseVisualizer() 

        // Ensure repository is synced if this call came from a screen with its own repository instance
        if (this.unifiedRepository == null && context is com.tervixa.wavemuzix.MainActivity) {
            // This is a fallback; primary initialization happens in MainActivity.onCreate
        }

        releaseVisualizer()
        volumeFadeJob?.cancel()
        isFadingForSkip = false
        if (settingsManager == null) settingsManager = SettingsManager(context)
        this.cookies = cookies
        if (playlist.isNotEmpty() && !isAutoPlay) {
            queue.clear()
            queue.addAll(playlist)
            currentIndex = playlist.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        } else if (isAutoPlay) {
            // Stability: If already at this song in the queue, don't search and jump
            val isAlreadyAtCorrectIndex = currentIndex in queue.indices && queue[currentIndex].videoId == song.videoId
            if (!isAlreadyAtCorrectIndex) {
                val index = queue.indexOfFirst { it.videoId == song.videoId }
                if (index != -1) {
                    currentIndex = index
                } else {
                    // Don't add if we are just autoplaying/retrying a fetch
                }
            }
        } else {
            // Solo song from search - create a new queue and trigger radio curation
            queue.clear()
            queue.add(song)
            currentIndex = 0
        }

        currentServer = result.clientName
        currentSong = song
        prefetchedVideoId = null
        scheduledVideoId = null
        scheduledIndex = -1
        hasIncrementedPlayCount = false
        val isTrackVideo = !result.videoUrl.isNullOrBlank() && (!result.isAudioOnly || song.isVideo)
        isVideoAvailable = isTrackVideo
        if (!isTrackVideo) {
            isVideoModeEnabled = false
        } else if (song.isVideo) {
            isVideoModeEnabled = true
        }
        val shouldPlayVideo = isVideoAvailable && isVideoModeEnabled

        // Register per-stream User-Agent and set default headers BEFORE preparing either audio or video player!
        streamUserAgents[result.url] = result.userAgent
        result.videoUrl?.let { streamUserAgents[it] = result.userAgent }
        httpDataSourceFactory.setUserAgent(result.userAgent)
        crossfadeJob?.cancel()
        fadeJob?.cancel()
        isCrossfadeTriggered = false
        isCrossfadeInFlight = false
        isPrebufferingCrossfade = false
        prebufferedCrossfadeVideoId = null
        inactivePlayer?.stop()
        inactivePlayer?.clearMediaItems()
        val preHeaders = mutableMapOf(
            "Origin" to "https://music.youtube.com",
            "Referer" to "https://music.youtube.com/",
            "Accept" to "*/*"
        )
        if (!cookies.isNullOrEmpty()) preHeaders["Cookie"] = cookies
        httpDataSourceFactory.setDefaultRequestProperties(preHeaders)

        // FORCE RESET: Ensure the start position is strictly 0 unless the specific restored song is being played.
        val startPosition = if (song.videoId == pendingRestoreVideoId) pendingRestorePosition else 0L
        pendingRestorePosition = 0L 
        pendingRestoreVideoId = null

        if (!isAutoPlay) {
            failedClientsForCurrentSong.clear()
        }

        if (queue.size <= 1 && startRadio) {
            refreshQueueIfLow(force = true)
        }
        // This helps maintain foreground service status.
        val metadata = createMediaMetadata(song)

        val mediaItemBuilder = MediaItem.Builder()
            .setUri(result.url)
            .setMediaId(song.videoId)
            .setMediaMetadata(metadata)
            .setTag(result)

        if (!result.mimeType.isNullOrEmpty()) mediaItemBuilder.setMimeType(result.mimeType)

        val mediaItem = mediaItemBuilder.build()

        // Pre-trim SponsorBlock intro BEFORE setMediaItem & prepare (strictly for video songs only!)
        val preTrimmedSegments = if (shouldPlayVideo && settingsManager?.isSponsorBlockEnabled == true) {
            sponsorSegmentsCache[song.videoId].orEmpty()
        } else {
            sponsorSegments.clear()
            mergedSponsorSegments = emptyList()
            emptyList()
        }
        val preTrimIntroMs = if (startPosition == 0L) {
            preTrimmedSegments.firstOrNull { it.first <= 2500L }?.second ?: 0L
        } else 0L
        val effectiveStartMs = if (startPosition > 0L) startPosition else preTrimIntroMs

        player.stop()
        player.clearMediaItems()
        if (effectiveStartMs > 0L) {
            player.setMediaItem(mediaItem, effectiveStartMs)
        } else {
            player.setMediaItem(mediaItem, true)
        }

        baseVolume = calculateBaseVolume(result.loudnessDb)
        player.volume = (baseVolume * userVolume).coerceIn(0f, 1f)

        applyAudioEffects(player, result.loudnessDb)

        // Ensure PlaybackService is running BEFORE we start playback
        ensureServiceStarted(context)
        cacheCurrentSongForInstantResume(context, song, result.url, result.userAgent)

        configureSmartSilenceProcessor(player)
        player.skipSilenceEnabled = settingsManager?.isSkipSilenceEnabled == true

        if (preTrimmedSegments.isNotEmpty()) {
            // Only schedule segments after 2500ms so playback NEVER restarts 0.5s after starting!
            applySponsorSegments(song.videoId, preTrimmedSegments.filter { it.first > 2500L })
        }

        if (shouldPlayVideo) {
            updateVideoPlaybackState()
        } else {
            isVideoActuallyPlaying = false
            videoPlayer?.pause()
        }

        hasPlayedFirstSongInSession = true
        player.volume = (baseVolume * userVolume).coerceIn(0f, 1f)
        val shouldAutoPlay = !wasPausedBeforeSkip
        player.playWhenReady = shouldAutoPlay
        player.prepare()
        if (shouldAutoPlay) {
            player.play()
            isPlaying = true
        } else {
            player.pause()
            isPlaying = false
        }
        wasPausedBeforeSkip = false
        LastFmManager.updateNowPlaying(context, song, duration)
        isLoading = false
        startProgressUpdate(context)
        refreshQueueIfLow(force = true)
        prefetchUpcomingQueueAndCrossfade(context)

        if (settingsManager?.isSaveLastPlayed == true) {
            settingsManager?.lastPlayedSongId = song.videoId
        }
        consecutiveErrors = 0
    }

    fun playNext(song: Song) {
        if (currentIndex != -1 && currentIndex < queue.size) {
            val insertIndex = currentIndex + 1
            queue.add(insertIndex, song)
            if (shuffleEnabled) {
                // Update shuffledIndices to include the new song right after the current one
                val currentInShuffled = shuffledIndices.indexOf(currentIndex)
                if (currentInShuffled != -1) {
                    val newShuffledIndices = shuffledIndices.toMutableList()
                    // Shift all indices >= insertIndex in the current mapping
                    for (i in newShuffledIndices.indices) {
                        if (newShuffledIndices[i] >= insertIndex) {
                            newShuffledIndices[i]++
                        }
                    }
                    // Insert the new index at the position after currentInShuffled
                    newShuffledIndices.add(currentInShuffled + 1, insertIndex)
                    shuffledIndices.clear()
                    shuffledIndices.addAll(newShuffledIndices)
                } else {
                    generateShuffledIndices()
                }
            }

            // Update ExoPlayer's internal queue to include the new song next
            activePlayer?.let { player ->
                val currentIdx = player.currentMediaItemIndex
                if (currentIdx < player.mediaItemCount - 1) {
                    player.removeMediaItems(currentIdx + 1, player.mediaItemCount)
                }
                appContext?.let { prefetchNextSong(it) }
            }
            savePlaybackState()
        } else {
            queue.add(song)
            if (currentIndex == -1) currentIndex = 0
            if (shuffleEnabled) generateShuffledIndices()

            activePlayer?.let { player ->
                if (player.mediaItemCount <= 1) {
                    appContext?.let { prefetchNextSong(it) }
                }
            }
            savePlaybackState()
        }
    }

    fun moveItem(fromIndex: Int, toIndex: Int) {
        if (fromIndex !in queue.indices || toIndex !in queue.indices) return
        val song = queue.removeAt(fromIndex)
        queue.add(toIndex, song)

        // Update currentIndex to follow the song
        if (currentIndex == fromIndex) {
            currentIndex = toIndex
        } else if (fromIndex < currentIndex && toIndex >= currentIndex) {
            currentIndex--
        } else if (fromIndex > currentIndex && toIndex <= currentIndex) {
            currentIndex++
        }

        // Re-generate shuffled indices if needed to maintain consistency
        if (shuffleEnabled) {
            generateShuffledIndices()
        }
        savePlaybackState()
    }

    fun removeFromQueue(index: Int) {
        if (index !in queue.indices) return
        queue.removeAt(index)
        if (index < currentIndex) {
            currentIndex--
        } else if (index == currentIndex) {
            if (currentIndex >= queue.size) {
                currentIndex = queue.size - 1
            }
            // If the queue is now empty, reset
            if (queue.isEmpty()) {
                clearState()
            }
        }

        if (shuffleEnabled) {
            generateShuffledIndices()
        }
        savePlaybackState()
    }

    fun addToQueue(song: Song) {
        queue.add(song)
        if (currentIndex == -1) currentIndex = 0
        if (shuffleEnabled) {
            shuffledIndices.add(queue.size - 1)
        }
        savePlaybackState()
    }

    fun playNextInQueue(context: Context, isAuto: Boolean = false) {
        if (queue.isEmpty()) return

        val now = System.currentTimeMillis()
        // Only throttle automatic end-of-track transitions; NEVER drop manual user taps so
        // tapping Next 3-4+ times rapidly advances cleanly through every single song!
        if (isAuto && now - lastSkipTime < 500L) {
            return
        }
        lastSkipTime = now

        // Cancel all in-flight jobs immediately so skipped tracks never finish loading
        skipJob?.cancel()
        fetchJob?.cancel()
        prefetchJob?.cancel()
        isPrefetching = false
        isSkipping = true
        if (hasPlayedFirstSongInSession && !isPlaying && !isLoading) {
            wasPausedBeforeSkip = true
        }

        if (pendingRestoreVideoId != null) {
            ioScope.launch {
                database?.songDao()?.deletePlaybackState()
            }
        }
        pendingRestorePosition = 0L
        pendingRestoreVideoId = null

        if (repeatMode == Player.REPEAT_MODE_ONE && !isAuto) {
            val nextIndex = if (currentIndex + 1 < queue.size) currentIndex + 1 else 0
            playAtIndex(context, nextIndex)
            isSkipping = false
            return
        }

        if (shuffleEnabled) {
            if (shuffledIndices.isEmpty() || !shuffledIndices.contains(currentIndex)) generateShuffledIndices()

            val nextShuffledPos = shuffledIndices.indexOf(currentIndex) + 1
            if (nextShuffledPos < shuffledIndices.size) {
                playAtIndex(context, shuffledIndices[nextShuffledPos])
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL) {
                generateShuffledIndices()
                val nextPos = if (shuffledIndices.size > 1) 1 else 0
                playAtIndex(context, shuffledIndices[nextPos])
            }
        } else {
            if (currentIndex + 1 < queue.size) {
                playAtIndex(context, currentIndex + 1)
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL) {
                playAtIndex(context, 0)
            }
        }
        isSkipping = false
    }

    fun playAtIndex(context: Context, index: Int) {
        if (index in queue.indices) {
            val song = queue[index]

            val isSameSong = currentSong?.videoId == song.videoId
            val isActive = isPlaying || isLoading ||
                           activePlayer?.playbackState == Player.STATE_READY ||
                           activePlayer?.playbackState == Player.STATE_BUFFERING

            if (isSameSong && isActive && index == currentIndex) {
                Log.d("MusicPlayer", "playAtIndex: Song already active at index $index.")
                return
            }

            // Always cancel in-flight fetch, skip, and prefetch jobs BEFORE touching player state
            fetchJob?.cancel()
            skipJob?.cancel()
            prefetchJob?.cancel()
            isPrefetching = false
            volumeFadeJob?.cancel()
            isFadingForSkip = false

            val now = System.currentTimeMillis()
            val isRapidSkip = (now - lastManualIndexChangeTime) < 400L
            lastManualIndexChangeTime = now

            if (pendingRestoreVideoId != null && song.videoId != pendingRestoreVideoId) {
                pendingRestorePosition = 0L
                pendingRestoreVideoId = null
                ioScope.launch {
                    database?.songDao()?.deletePlaybackState()
                }
                queue.clear()
                queue.add(song)
                currentIndex = 0
                fetchAndPlay(context, song, debounceMs = if (isRapidSkip) 160L else 0L)
                refreshQueueIfLow()
                return
            }

            if (hasPlayedFirstSongInSession && !isPlaying && !isLoading) {
                wasPausedBeforeSkip = true
            }
            val oldIndex = currentIndex
            currentIndex = index
            targetSongId = song.videoId
            val requestId = ++currentPlaybackRequestId

            // Only seek inside ExoPlayer's prefetched queue on a single deliberate tap/swipe,
            // never during rapid multi-skipping (where seeking intermediate prefetched tracks
            // causes ExoPlayer to fire stale transitions and bounce backward).
            if (!isRapidSkip) {
                activePlayer?.let { player ->
                    for (i in 0 until player.mediaItemCount) {
                        if (player.getMediaItemAt(i).mediaId == song.videoId) {
                            Log.d("MusicPlayer", "playAtIndex: Found index $index in internal player queue at position $i. Seeking.")
                            player.seekToDefaultPosition(i)
                            player.play()
                            currentSong = song
                            currentPosition = 0L
                            duration = parseDurationToMs(song.durationText)
                            highResThumbnailUrl = getHighResThumbnailUrl(song.thumbnailUrl)
                            currentSongDurationText = song.durationText
                            fetchMetadata(context, song)
                            startLyricsFetch(song)
                            return
                        }
                    }
                }
            }

            releaseVisualizer()
            Log.d("MusicPlayer", "Play At Index: $oldIndex -> $currentIndex (${song.title}), rapidSkip=$isRapidSkip")

            fetchAndPlay(
                context = context,
                song = song,
                debounceMs = if (isRapidSkip) 160L else 50L,
                requestId = requestId
            )
            refreshQueueIfLow()
        }
    }

    var isRefreshingQueue by mutableStateOf(false)

    fun requestMoreQueueSongs(context: Context) {
        if (appContext == null) appContext = context.applicationContext
        isAutoCurationEnabled = true
        refreshQueueIfLow(force = true)
    }

    private fun refreshQueueIfLow(force: Boolean = false) {
        val song = currentSong ?: return
        val context = appContext ?: return

        // Allow endless queue expansion when forced (from QueueScreen scroll) or when auto-curation is enabled
        if (!force && !isAutoCurationEnabled) return

        // Trigger refresh if forced or when we are nearing the end of the current block.
        if (!force && currentIndex < queue.size - 15) return
        if (isRefreshingQueue && !force) return

        refreshQueueJob?.cancel()
        refreshQueueJob = ioScope.launch {
            withContext(Dispatchers.Main) { isRefreshingQueue = true }
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WaveMuzix:AI_Queue")
            try {
                wakeLock?.acquire(30000L)
                // SimpMusic endless queue strategy: use the tail song of the queue when expanding an existing
                // queue so every subsequent fetch brings fresh, non-duplicate tracks indefinitely!
                val seedSong = if (queue.size > 2 && force) (queue.lastOrNull() ?: song) else song
                Log.d("MusicPlayer", "AI Curation: Refreshing personalized queue for seed: ${seedSong.title}")

                // 1. YouTube AI Radio (The "Real" Curation)
                val radioId = "RD${seedSong.videoId}"
                val radioPlaylist = unifiedRepository?.fetchPlaylist(radioId, cookies, emptySet())
                val radioSuggestions = radioPlaylist?.songs ?: emptyList()

                // 2. Related Songs (Up Next) from both seedSong and currentSong
                val (relatedSuggestions, _) = unifiedRepository?.fetchNextSongs(seedSong.videoId, null, cookies, filterAudioOnly = false) ?: Pair(null, null)

                // Combine sources, prioritizing the AI Radio
                // We trust YouTube's algorithm here - it already handles vibe, language, and context perfectly.
                var suggestions = (radioSuggestions + (relatedSuggestions ?: emptyList()))
                    .distinctBy { it.videoId }
                    .filter { suggestion ->
                        // Basic sanity check: Don't add obviously non-music content
                        val lowerTitle = suggestion.title.lowercase()
                        !lowerTitle.contains("tutorial") && 
                        !lowerTitle.contains("how to") && 
                        !lowerTitle.contains("review") &&
                        !lowerTitle.contains("unboxing")
                    }

                // VALIDATION LOGGING (Native YT Music Curation)
                Log.d("AICurationValidation", "Seed Song: ${song.title} (${song.artist})")
                Log.d("AICurationValidation", "Source: Native YouTube Music AI (RD Playlist + Related)")

                suggestions = suggestions.shuffled()

                if (suggestions.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        val existingIds = queue.map { it.videoId }.toSet()
                        val existingTitles = queue.map { it.title.lowercase().trim() }.toSet()
                        val artistCounts = mutableMapOf<String, Int>()
                        
                        val newSongs = suggestions
                            .filter { it.videoId != song.videoId && !existingIds.contains(it.videoId) }
                            .filter { suggestion ->
                                // Near-duplicate / Remix Filter: Avoid multiple versions of the same song
                                val lowerTitle = suggestion.title.lowercase()
                                val isRemixOrLive = lowerTitle.contains("remix") || 
                                                  lowerTitle.contains("live") || 
                                                  lowerTitle.contains("performance") || 
                                                  lowerTitle.contains("cover") ||
                                                  lowerTitle.contains("mashup")
                                
                                // Only allow remix/live if the original title isn't already there 
                                // OR if the current song itself is a remix/live (respecting user's current vibe)
                                val currentIsSpecial = song.title.lowercase().let { it.contains("remix") || it.contains("live") }
                                
                                if (!currentIsSpecial && isRemixOrLive) return@filter false
                                
                                // Title Similarity check (Basic)
                                val cleanTitle = suggestion.title.lowercase()
                                    .replace(Regex("\\(.*?\\)"), "")
                                    .replace(Regex("\\[.*?\\]"), "")
                                    .trim()
                                
                                if (existingTitles.any { it.contains(cleanTitle) || cleanTitle.contains(it) }) return@filter false

                                true
                            }
                            .filter { 
                                // Strict Diversity Filter: Max 2 songs per artist to avoid artist-looping
                                val count = artistCounts.getOrDefault(it.artist, 0)
                                if (count < 2) {
                                    artistCounts[it.artist] = count + 1
                                    true
                                } else false
                            }
                            .take(50)

                        if (newSongs.isNotEmpty()) {
                            val oldSize = queue.size
                            queue.addAll(newSongs)
                            if (shuffleEnabled) {
                                // Stability: Append new indices to the end of shuffle and shuffle only those
                                // to prevent already played songs from repeating immediately.
                                val newIndices = (oldSize until queue.size).toMutableList()
                                newIndices.shuffle()
                                shuffledIndices.addAll(newIndices)
                            }
                            Log.d("MusicPlayer", "AI Queue expanded with ${newSongs.size} personalized songs. Total queue: ${queue.size}")
                            
                            // VALIDATION LOGGING
                            Log.d("AICurationValidation", "Curation Complete. Accepted ${newSongs.size} songs from native AI.")
                            newSongs.take(3).forEach { s ->
                                Log.d("AICurationValidation", " -> Sample Suggestion: ${s.title} by ${s.artist}")
                            }
                            prefetchNextSong(context)

                            if (activePlayer?.playbackState == Player.STATE_ENDED) {
                                playNextInQueue(context)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "AI Queue refresh failed", e)
            } finally {
                withContext(Dispatchers.Main) { isRefreshingQueue = false }
                if (wakeLock?.isHeld == true) try { wakeLock.release() } catch (e: Exception) {}
            }
        }
    }

    private fun extractVibeKeywords(title: String, metadata: String? = null): String {
        val keywords = mutableListOf<String>()
        val combined = (title + " " + (metadata ?: "")).lowercase()
        
        // Precise Vibe Detection (Moods, Genres, and Context)
        val vibeMap = mapOf(
            "lofi chill" to listOf("lofi", "lo-fi", "chill", "study", "relax"),
            "slowed reverb" to listOf("slowed", "reverb", "aesthetic"),
            "trap hiphop" to listOf("trap", "hip hop", "rap", "drill", "beat"),
            "sad emotional" to listOf("sad", "emotional", "heartbreak", "broken", "pain", "crying"),
            "party dance edm" to listOf("party", "dance", "edm", "club", "remix", "house", "techno"),
            "romantic love" to listOf("romantic", "love", "couple", "sweet", "valentine", "heart"),
            "sleep relax ambient" to listOf("sleep", "relax", "calm", "ambient", "lullaby", "meditation", "soothing"),
            "workout gym energetic" to listOf("workout", "gym", "energetic", "motivation", "power", "beast"),
            "acoustic guitar" to listOf("acoustic", "unplugged", "guitar", "piano version"),
            "rock metal" to listOf("rock", "metal", "heavy", "punk", "alternative"),
            "pop hits" to listOf("pop", "chart", "hits"),
            "classical piano" to listOf("classical", "piano", "violin", "orchestral", "composition"),
            "bass boosted" to listOf("bass", "subwoofer", "loud"),
            "devotional spiritual" to listOf("devotional", "bhajan", "spiritual", "mantra", "god", "prayer", "worship"),
            "jazz soul" to listOf("jazz", "soul", "blues", "r&b", "funk")
        )

        for ((vibe, triggerWords) in vibeMap) {
            if (triggerWords.any { combined.contains(it) }) {
                keywords.add(vibe)
            }
        }
        
        return if (keywords.isEmpty()) "similar music vibe" else keywords.distinct().joinToString(" ")
    }

    var isAutoCurationEnabled by mutableStateOf(true)

    fun playSong(context: Context, song: Song, playlist: List<Song> = emptyList(), cookies: String? = null, isFromFixedList: Boolean = false) {
        if (cookies != null) this.cookies = cookies
        isPlaybackError = false
        playbackErrorMessage = null
        isAutoCurationEnabled = !isFromFixedList

        // Check if the user is playing a different song than the one that was restored
        if (pendingRestoreVideoId != null && song.videoId != pendingRestoreVideoId) {
            pendingRestorePosition = 0L
            pendingRestoreVideoId = null
            ioScope.launch {
                database?.songDao()?.deletePlaybackState()
            }
        }

        // Handle Queue before fetching to ensure UI updates immediately
        if (playlist.isNotEmpty()) {
            queue.clear()
            queue.addAll(playlist)
            currentIndex = queue.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        } else {
            // Check if we are already playing this song to avoid unnecessary queue reset
            if (currentSong?.videoId != song.videoId) {
                // Starting a new "solo" play (e.g. from search) should clear the queue
                // to allow the AI-driven radio to populate a fresh personalized session.
                queue.clear()
                queue.add(song)
                currentIndex = 0
            }
        }

        fetchAndPlay(context, song)
    }

    private var targetSongId: String? = null

    private fun fetchAndPlay(
        context: Context,
        song: Song,
        debounceMs: Long = 0L,
        requestId: Long = ++currentPlaybackRequestId
    ) {
        fetchJob?.cancel()
        skipJob?.cancel()
        prefetchJob?.cancel()
        isPrefetching = false

        targetSongId = song.videoId

        val player = getInstance(context)
        // Stop the player immediately so the user knows the previous song is gone
        player.stop()
        player.clearMediaItems()
        videoPlayer?.stop()
        videoPlayer?.clearMediaItems()

        isLoading = true
        currentPosition = 0L
        // Commit UI state immediately for instant responsiveness on every skip tap
        currentSong = song
        duration = parseDurationToMs(song.durationText)
        highResThumbnailUrl = getHighResThumbnailUrl(song.thumbnailUrl)
        currentSongDurationText = song.durationText

        scheduledVideoId = null
        scheduledIndex = -1

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WaveMuzix:FetchNext")

        fetchJob = ioScope.launch {
            try {
                // If user is tapping Next/Prev rapidly, coalesce intermediate taps before hitting network
                if (debounceMs > 0L) {
                    delay(debounceMs)
                }
                if (!isActive || requestId != currentPlaybackRequestId || targetSongId != song.videoId) {
                    return@launch
                }

                withContext(Dispatchers.Main) {
                    if (requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                        fetchMetadata(context, song)
                        startLyricsFetch(song)
                    }
                }

                failedClientsForCurrentSong.clear()
                wakeLock?.acquire(30000L)
                if (wifiLock?.isHeld == false) wifiLock?.acquire()

                // 0. Check for instant-resume cached audio file when resuming last played song after app reopen
                val resumeCacheFile = getInstantResumeCacheFile(context, song.videoId)
                if (song.videoId == pendingRestoreVideoId && resumeCacheFile.exists() && resumeCacheFile.length() > 32_000L) {
                    withContext(Dispatchers.Main) {
                        if (requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                            playOffline(context, resumeCacheFile.absolutePath, song, "audio/webm")
                            isLoading = false
                        }
                    }
                    refreshQueueIfLow()
                    return@launch
                }

                // 1. Check for offline version first
                val downloadedSong = database?.songDao()?.getDownloadByVideoId(song.videoId)
                if (downloadedSong != null) {
                    val file = java.io.File(downloadedSong.filePath)
                    if (file.exists()) {
                        if (!isActive || requestId != currentPlaybackRequestId || targetSongId != song.videoId) return@launch
                        Log.d("MusicPlayer", "Found offline version for ${song.title} at ${downloadedSong.filePath}, playing locally.")
                        withContext(Dispatchers.Main) {
                            if (requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                                playOffline(context, downloadedSong.filePath, song, downloadedSong.mimeType)
                                isLoading = false
                            }
                        }
                        refreshQueueIfLow()
                        return@launch
                    } else {
                        Log.w("MusicPlayer", "Download record exists but file not found at ${downloadedSong.filePath}")
                    }
                }

                // 2. Fallback to network if not offline
                if (!NetworkUtils.isNetworkAvailable(context)) {
                    Log.e("MusicPlayer", "Network unavailable, cannot fetch streaming URL.")
                    withContext(Dispatchers.Main) {
                        if (requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                            isLoading = false
                            isPlaybackError = true
                            playbackErrorMessage = "No Internet Connection"
                            onErrorCallback?.invoke(
                                PlaybackException(
                                    "No Internet Connection",
                                    null,
                                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                                )
                            )
                        }
                    }
                    return@launch
                }

                Log.d("MusicPlayer", "Fetching streaming URL for: ${song.title} (requestId=$requestId)")
                val targetBitrate = null

                val priority = if (settingsManager?.isDataSaverEnabled == true) {
                    "Data Saver"
                } else {
                    "Force OPUS 160kbps"
                }
                val preferredQuality = settingsManager?.preferredVideoQuality ?: "auto"
                val result = unifiedRepository?.getStreamingUrl(
                    videoId = song.videoId,
                    cookies = cookies,
                    failedClients = emptyList(),
                    targetBitrate = targetBitrate,
                    priority = priority,
                    preferredVideoQuality = preferredQuality
                )

                // Abort immediately if the user skipped to another song while getStreamingUrl was running
                if (!isActive || requestId != currentPlaybackRequestId || targetSongId != song.videoId) {
                    Log.d("MusicPlayer", "Discarding completed extraction for skipped song: ${song.title}")
                    return@launch
                }

                val isVideoCandidate = (result?.videoUrl != null && !result.isAudioOnly) && (settingsManager?.isPlayVideoIfAvailable == true)
                if (isVideoCandidate && settingsManager?.isSponsorBlockEnabled == true) {
                    fetchSponsorSegmentsSuspend(song.videoId)
                } else {
                    sponsorSegments.clear()
                    mergedSponsorSegments = emptyList()
                }
                refreshQueueIfLow()

                withContext(Dispatchers.Main) {
                    if (!isActive || requestId != currentPlaybackRequestId || targetSongId != song.videoId) {
                        return@withContext
                    }
                    if (result != null) {
                        playStream(
                            context = context,
                            result = result,
                            song = song,
                            cookies = cookies,
                            isAutoPlay = true
                        )
                    } else {
                        Log.e("MusicPlayer", "Failed to get streaming URL for ${song.title}")

                        if (failedClientsForCurrentSong.isEmpty()) {
                            Log.w("MusicPlayer", "Initial extraction failed. Retrying with full client rotation.")
                            val secondAttempt = withContext(Dispatchers.IO) {
                                unifiedRepository?.getStreamingUrl(
                                    videoId = song.videoId,
                                    cookies = cookies,
                                    failedClients = listOf("ANDROID_MUSIC")
                                )
                            }
                            if (!isActive || requestId != currentPlaybackRequestId || targetSongId != song.videoId) {
                                return@withContext
                            }
                            if (secondAttempt != null) {
                                playStream(context, secondAttempt, song, cookies, isAutoPlay = true)
                                return@withContext
                            }
                        }

                        isLoading = false
                        consecutiveErrors++
                        if (consecutiveErrors < MAX_CONSECUTIVE_ERRORS) {
                            skipJob?.cancel()
                            skipJob = mainScope.launch {
                                Log.w("MusicPlayer", "Auto-skipping due to extraction failure in 10s... (Count: $consecutiveErrors)")
                                delay(10000)
                                if (isActive && requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                                    playNextInQueue(context, isAuto = true)
                                }
                            }
                        } else {
                            Log.e("MusicPlayer", "Max consecutive extraction errors reached. Stopping.")
                            isLoading = false
                            isPlaying = false
                            consecutiveErrors = 0
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    if (requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                        isLoading = false
                        Log.e("MusicPlayer", "Fetch error: ${e.message}")
                        consecutiveErrors++
                        if (consecutiveErrors < MAX_CONSECUTIVE_ERRORS) {
                            skipJob?.cancel()
                            skipJob = mainScope.launch {
                                delay(10000)
                                if (isActive && requestId == currentPlaybackRequestId && targetSongId == song.videoId) {
                                    playNextInQueue(context, isAuto = true)
                                }
                            }
                        }
                    }
                }
            } finally {
                if (wakeLock?.isHeld == true) {
                    try { wakeLock.release() } catch (e: Exception) {}
                }
                if (wifiLock?.isHeld == true) {
                    try { wifiLock?.release() } catch (e: Exception) {}
                }
            }
        }
    }

    private fun prefetchNextSong(context: Context) {
        if (settingsManager?.isCrossfadeEnabled == true) return
        if (isPrefetching || isLoading) return
        val player = activePlayer ?: return
        if (player.mediaItemCount == 0) return

        val anchorRequestId = currentPlaybackRequestId
        val anchorSongId = currentSong?.videoId ?: return

        // Count how many items are ahead of the current one in the timeline
        val currentIdx = player.currentMediaItemIndex
        val itemsAhead = player.mediaItemCount - 1 - currentIdx

        if (itemsAhead >= 4) return

        val lastItemIndex = player.mediaItemCount - 1
        val lastMediaId = if (lastItemIndex >= 0) player.getMediaItemAt(lastItemIndex).mediaId else null

        val baseIndex = if (lastMediaId != null) {
            if (shuffleEnabled) {
                val currentPos = shuffledIndices.indexOf(currentIndex)
                val searchIndices = if (currentPos != -1) shuffledIndices.drop(currentPos) else shuffledIndices
                val found = searchIndices.firstOrNull { queue.getOrNull(it)?.videoId == lastMediaId }
                found ?: queue.indexOfFirst { it.videoId == lastMediaId }
            } else {
                val searchStart = currentIndex.coerceAtLeast(0)
                val firstAfter = (searchStart until queue.size).firstOrNull { queue[it].videoId == lastMediaId }
                firstAfter ?: queue.indexOfFirst { it.videoId == lastMediaId }
            }
        } else {
            currentIndex
        }

        val nextIndex = getNextIndex(baseIndex)
        if (nextIndex == -1 || (nextIndex == baseIndex && repeatMode != Player.REPEAT_MODE_ALL)) return

        val nextSong = queue.getOrNull(nextIndex) ?: return

        for (i in 0 until player.mediaItemCount) {
            if (player.getMediaItemAt(i).mediaId == nextSong.videoId) return
        }

        isPrefetching = true
        scheduledIndex = nextIndex
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WaveMuzix:Prefetch")

        prefetchJob?.cancel()
        prefetchJob = ioScope.launch {
            try {
                wakeLock?.acquire(60000L)
                Log.d("MusicPlayer", "Background Prefetching: ${nextSong.title} (Items Ahead: $itemsAhead)")
                val targetBitrate = null

                val priority = if (settingsManager?.isDataSaverEnabled == true) {
                    "Data Saver"
                } else {
                    "Force OPUS 160kbps"
                }
                val preferredQuality = settingsManager?.preferredVideoQuality ?: "auto"
                val result = unifiedRepository?.getStreamingUrl(
                    videoId = nextSong.videoId,
                    cookies = cookies,
                    failedClients = emptyList(),
                    targetBitrate = targetBitrate,
                    priority = priority,
                    preferredVideoQuality = preferredQuality
                )
                if (!isActive || anchorRequestId != currentPlaybackRequestId || currentSong?.videoId != anchorSongId) {
                    return@launch
                }
                if (result != null) {
                    streamUserAgents[result.url] = result.userAgent
                    result.videoUrl?.let { streamUserAgents[it] = result.userAgent }
                    withContext(Dispatchers.Main) {
                        // CRITICAL GUARD: Verify the user has not skipped or started loading another song
                        // while prefetch was running in the background!
                        if (!isActive ||
                            anchorRequestId != currentPlaybackRequestId ||
                            currentSong?.videoId != anchorSongId ||
                            isLoading ||
                            player.mediaItemCount == 0
                        ) {
                            return@withContext
                        }
                        val freshItemsAhead = player.mediaItemCount - 1 - player.currentMediaItemIndex
                        if (freshItemsAhead < 4) {
                            val metadata = createMediaMetadata(nextSong)

                            val mediaItem = MediaItem.Builder()
                                .setUri(result.url)
                                .setMediaId(nextSong.videoId)
                                .setMediaMetadata(metadata)
                                .setMimeType(result.mimeType)
                                .setTag(result)
                                .build()

                            player.addMediaItem(mediaItem)
                            prefetchedVideoId = nextSong.videoId

                            prefetchMetadata(context, nextSong)
                            fetchSponsorSegments(nextSong.videoId, isPrefetch = true)

                            val finalFreshItemsAhead = player.mediaItemCount - 1 - player.currentMediaItemIndex
                            if (finalFreshItemsAhead < 4) {
                                isPrefetching = false
                                prefetchNextSong(context)
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Prefetch failed", e)
            } finally {
                isPrefetching = false
                if (wakeLock?.isHeld == true) {
                    try { wakeLock.release() } catch (_: Exception) {}
                }
            }
        }
    }

    fun clearLyrics() {
        lyricsText = null
        lyricsProvider = null
        isLyricsLoading = false
    }

    private fun startLyricsFetch(song: Song) {
        val targetVid = song.videoId
        if (lyricsRepository.getLastSongId() != targetVid) {
            clearLyrics()
        }
        ioScope.launch {
            if (currentSong?.videoId == targetVid) {
                val cached = lyricsRepository.getCachedLyrics(targetVid)
                if (cached != null) {
                    withContext(Dispatchers.Main) {
                        if (currentSong?.videoId == targetVid) {
                            lyricsText = cached
                            lyricsProvider = lyricsRepository.getCachedProvider(targetVid)
                            isLyricsLoading = false
                        }
                    }
                    return@launch
                }

                withContext(Dispatchers.Main) {
                    if (currentSong?.videoId == targetVid) {
                        isLyricsLoading = true
                    }
                }
                val provider = settingsManager?.lyricsProvider ?: "Auto"
                val durSec = (parseDurationToMs(song.durationText) / 1000L).toInt().takeIf { it > 0 }
                    ?: (duration / 1000L).toInt().takeIf { it > 0 }
                val result = lyricsRepository.fetchLyrics(
                    song = song,
                    preferredProvider = provider,
                    dao = database?.songDao(),
                    targetDurationSeconds = durSec,
                )
                withContext(Dispatchers.Main) {
                    if (currentSong?.videoId == targetVid) {
                        lyricsText = result?.lyrics
                        lyricsProvider = result?.provider
                        isLyricsLoading = false
                    }
                }
            }
        }
    }

    fun playPreviousInQueue(context: Context) {
        if (queue.isEmpty()) return

        val now = System.currentTimeMillis()
        val isRapidPrev = (now - lastSkipTime) < 600L
        lastSkipTime = now

        // Cancel all in-flight jobs immediately
        skipJob?.cancel()
        fetchJob?.cancel()
        prefetchJob?.cancel()
        isPrefetching = false
        isSkipping = true

        val player = activePlayer
        val currentPos = player?.currentPosition ?: 0L

        // Only restart current song if more than 3s in AND not double-tapping Previous rapidly
        if (!isRapidPrev && !isLoading && player?.currentMediaItem?.mediaId == currentSong?.videoId && currentPos > 3000) {
            player?.seekTo(0)
            Log.d("MusicPlayer", "playPrevious: Restarting current song (pos: $currentPos)")
            isSkipping = false
            return
        }

        // Logic check: if index is out of bounds due to queue change, reset to 0
        if (currentIndex < 0 || currentIndex >= queue.size) {
            currentIndex = 0
        }

        if (shuffleEnabled) {
            if (shuffledIndices.isEmpty() || !shuffledIndices.contains(currentIndex)) generateShuffledIndices()
            val currentInShuffled = shuffledIndices.indexOf(currentIndex)
            if (currentInShuffled > 0) {
                playAtIndex(context, shuffledIndices[currentInShuffled - 1])
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL && shuffledIndices.isNotEmpty()) {
                playAtIndex(context, shuffledIndices.last())
            } else {
                player?.seekTo(0)
            }
        } else {
            if (currentIndex > 0) {
                playAtIndex(context, currentIndex - 1)
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL && queue.isNotEmpty()) {
                playAtIndex(context, queue.size - 1)
            } else {
                player?.seekTo(0)
            }
        }
    }

    fun seekTo(cleanPosition: Long) {
        val player = activePlayer ?: return
        volumeFadeJob?.cancel()
        isFadingForSkip = false
        player.volume = baseVolume * userVolume
        // Reset skip state to allow the mapping logic to take full control of this seek
        lastSponsorSeekTarget = -1L
        lastSponsorSeekAttemptTime = 0L
        cleanPositionAtSkipTrigger = 0L
        skipTriggerTime = 0L

        val isPlayingVideoSong = isVideoAvailable && (settingsManager?.isPlayVideoIfAvailable == true)
        val activeSegments = if (settingsManager?.isSponsorBlockEnabled == true && isPlayingVideoSong) mergedSponsorSegments else emptyList()
        var rawPosition = cleanPosition

        // Translate Clean UI position back to Raw Player position.
        for (seg in activeSegments) {
            if (rawPosition >= seg.first - 500) {
                rawPosition += (seg.second - seg.first)
            } else {
                break
            }
        }

        Log.d("MusicPlayer", "SeekTo Mapping: Clean $cleanPosition -> Raw $rawPosition")
        player.seekTo(rawPosition)
        savePlaybackState()

        // Reset video sync on seek to prevent stuttering/mismatch during the jump
        if (isVideoAvailable) {
            videoSyncStartTime = System.currentTimeMillis() + 1500 // Slightly shorter delay for manual seeks
            videoPlayer?.playWhenReady = false
            videoPlayer?.seekTo(rawPosition)
        }
    }

    fun togglePlayPause(context: Context) {
        val player = getInstance(context)
        // Use MusicPlayer.isPlaying to track intent, as player.isPlaying is false during buffering/fetching.
        // This allows the user to pause the playback intent before the streaming URL even arrives.
        if (this.isPlaying) {
            player.pause()
            videoPlayer?.pause()
            stopProgressUpdate()
        } else {
            if (player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_ENDED || player.mediaItemCount == 0) {
                // If the player is idle or ended, we might want to reload the current song or next song.
                // However, for simplicity, if currentSong exists, just prepare and play.
                val song = currentSong
                if (song != null && player.mediaItemCount == 0) {
                    fetchAndPlay(context, song)
                    return
                }
                player.prepare()
            }
            player.play()
            if (isVideoAvailable && isPlayerViewVisible) {
                videoPlayer?.play()
            }
            startProgressUpdate(context)

            // Ensure PlaybackService is running to maintain background continuity
            ensureServiceStarted(context)
        }
    }

    fun stopPlayback() {
        currentPlaybackRequestId++
        targetSongId = null
        fetchJob?.cancel()
        skipJob?.cancel()
        prefetchJob?.cancel()
        isPrefetching = false
        activePlayer?.stop()
        activePlayer?.clearMediaItems()
        inactivePlayer?.stop()
        inactivePlayer?.clearMediaItems()
        videoPlayer?.stop()
        videoPlayer?.clearMediaItems()
        
        // Reset In-Memory Queue and indices
        queue.clear()
        shuffledIndices.clear()
        currentIndex = -1
        currentPosition = 0
        duration = 0

        clearState()
        stopProgressUpdate()
    }

    fun playOffline(
        context: Context,
        filePath: String,
        song: Song,
        mimeType: String? = null,
        playlist: List<Song> = emptyList(),
        isFromFixedList: Boolean = false
    ) {
        targetSongId = song.videoId

        // COMMIT STATE: Only now do we update the global currentSong for the UI
        currentSong = song
        currentIndex = if (playlist.isNotEmpty()) {
            playlist.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        } else {
            queue.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(currentIndex)
        }

        releaseVisualizer()
        currentServer = "OFFLINE"
        isAutoCurationEnabled = !isFromFixedList
        duration = parseDurationToMs(song.durationText)
        highResThumbnailUrl = getHighResThumbnailUrl(song.thumbnailUrl)
        currentSongDurationText = song.durationText
        
        Log.d("MusicPlayer", "playOffline: Committing playback for ${song.title}")

        // Ensure file actually exists before trying to play
        val file = java.io.File(filePath)
        if (!file.exists()) {
            Log.e("MusicPlayer", "playOffline FAILED: File does not exist at $filePath")
            // Fallback to streaming if file is missing
            fetchAndPlay(context, song)
            return
        }

        // Handle Queue
        if (playlist.isNotEmpty()) {
            queue.clear()
            queue.addAll(playlist)
            currentIndex = playlist.indexOfFirst { it.videoId == song.videoId }.coerceAtLeast(0)
        } else {
            if (queue.none { it.videoId == song.videoId }) {
                if (currentIndex != -1 && currentIndex < queue.size) {
                    queue.add(currentIndex + 1, song)
                    currentIndex++
                } else {
                    queue.add(song)
                    currentIndex = queue.size - 1
                }
            } else {
                currentIndex = queue.indexOfFirst { it.videoId == song.videoId }
            }
        }

        val player = getInstance(context)

        val metadata = createMediaMetadata(song)

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.fromFile(file))
            .setMediaId(song.videoId)
            .setMimeType(mimeType ?: "audio/mpeg") // Use stored mimeType or fallback to mp3
            .setMediaMetadata(metadata)
            .build()

        val startPosition = if (song.videoId == pendingRestoreVideoId) pendingRestorePosition else 0L
        pendingRestorePosition = 0L
        pendingRestoreVideoId = null
        
        if (startPosition > 0) {
            player.setMediaItem(mediaItem, startPosition)
        } else {
            player.setMediaItem(mediaItem, true)
        }

        // Reset volume for offline playback to avoid carrying over normalization from previous streams
        baseVolume = 1.0f
        player.volume = (baseVolume * userVolume).coerceIn(0f, 1f)

        // Track most played removed from here - now at 50% in progress update

        refreshQueueIfLow()

        player.prepare()
        player.play()

        isLoading = false
        isPlaying = true
        consecutiveErrors = 0 // Reset errors on successful load
        startProgressUpdate(context)

        ensureServiceStarted(context)
    }

    fun startSleepTimer(minutes: Int) {
        stopAfterCurrentSong = false
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            sleepTimerMillis = 0L
            return
        }

        val durationMs = minutes * 60 * 1000L
        sleepTimerMillis = System.currentTimeMillis() + durationMs

        sleepTimerJob = mainScope.launch {
            delay(durationMs)
            activePlayer?.pause()
            sleepTimerMillis = 0L
        }
    }

    fun toggleStopAfterCurrentSong(enabled: Boolean) {
        if (enabled) {
            cancelSleepTimer()
        }
        stopAfterCurrentSong = enabled
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerMillis = 0L
        stopAfterCurrentSong = false
    }

    fun updateDvcState() {
        mainScope.launch {
            val settings = settingsManager ?: return@launch
            
            // Audio Focus behavior: 
            // When DVC is ON, handleAudioFocus is false -> ExoPlayer won't pause/duck on notifications
            val handleAudioFocus = !settings.isDirectVolumeControlEnabled
            
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build()

            activePlayer?.setAudioAttributes(audioAttributes, handleAudioFocus)
            inactivePlayer?.setAudioAttributes(audioAttributes, handleAudioFocus)
            
            Log.d("MusicPlayer", "DVC State updated: ${settings.isDirectVolumeControlEnabled}, handleAudioFocus: $handleAudioFocus")
        }
    }

    fun updateAudioEffects() {
        activePlayer?.let { player ->
            val result = player.currentMediaItem?.localConfiguration?.tag as? StreamingResult
            applyAudioEffects(player, result?.loudnessDb)
        }
    }

    fun updateVisualizerState() {
        if (settingsManager?.isVisualizerEnabled == true && isPlayerViewVisible) {
            setupVisualizer()
        } else {
            releaseVisualizer()
        }
    }

    fun toggleVisualizer(enabled: Boolean) {
        updateVisualizerState()
    }

    fun updateSponsorBlockSettings() {
        mainScope.launch {
            if (settingsManager?.isSponsorBlockEnabled == false) {
                sponsorSegments.clear()
                mergedSponsorSegments = emptyList()
                lastSponsorSeekTarget = -1L
                isFadingForSkip = false
                activePlayer?.volume = baseVolume * userVolume
                sponsorSegmentsCache.clear() // Clear cache when disabled
                Log.d("MusicPlayer", "SponsorBlock disabled instantly.")
            } else {
                refreshSponsorSegments()
            }
        }
    }

    fun updateCrossfadeState(context: Context) {
        activePlayer?.let { scheduleBackgroundTriggers(context, it, force = true) }
    }

    private val resolvedMvCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()

    fun updateVideoPlaybackState() {
        mainScope.launch {
            val ctx = appContext
            if (ctx != null && settingsManager == null) {
                settingsManager = SettingsManager(ctx)
            }
            val currentResult = activePlayer?.currentMediaItem?.localConfiguration?.tag as? StreamingResult
            val song = currentSong
            isVideoAvailable = !currentResult?.videoUrl.isNullOrBlank() && (currentResult?.isAudioOnly == false || song?.isVideo == true)
            if (!isVideoAvailable) isVideoModeEnabled = false
            val shouldPlayVideo = isVideoAvailable && isVideoModeEnabled && isPlayerViewVisible
            if (!shouldPlayVideo) {
                videoPlayer?.pause()
                isVideoActuallyPlaying = false
            } else if (ctx != null && song != null) {
                val vPlayer = getVideoPlayer(ctx)
                val cachedMv = resolvedMvCache[song.videoId]
                val initialVideoUrl = cachedMv?.first ?: currentResult?.videoUrl
                val initialVideoMime = cachedMv?.second ?: currentResult?.videoMimeType ?: "video/mp4"

                if (!initialVideoUrl.isNullOrBlank()) {
                    val currentVidId = vPlayer.currentMediaItem?.mediaId
                    val currentVidUri = vPlayer.currentMediaItem?.localConfiguration?.uri?.toString()
                    if (vPlayer.mediaItemCount == 0 || currentVidId != song.videoId || currentVidUri != initialVideoUrl) {
                        val videoMediaItem = MediaItem.Builder()
                            .setMediaId(song.videoId)
                            .setUri(initialVideoUrl)
                            .setMimeType(initialVideoMime)
                            .setMediaMetadata(createMediaMetadata(song))
                            .build()
                        vPlayer.stop()
                        vPlayer.clearMediaItems()
                        vPlayer.setMediaItem(videoMediaItem)
                        vPlayer.prepare()
                    }
                    val audioPos = activePlayer?.currentPosition ?: 0L
                    if (abs(vPlayer.currentPosition - audioPos) > 600L) {
                        vPlayer.seekTo(audioPos)
                    }
                    videoSyncStartTime = System.currentTimeMillis()
                    vPlayer.playWhenReady = activePlayer?.playWhenReady == true
                    if (vPlayer.playbackState == Player.STATE_READY) {
                        isVideoActuallyPlaying = true
                    }
                }

                // If the current stream is an Art Track (- Topic) and we haven't resolved its official MV yet,
                // look up the official Music Video in the background so switching to Video plays the real MV!
                if ((currentResult?.isAudioOnly == true || initialVideoUrl.isNullOrBlank()) && !resolvedMvCache.containsKey(song.videoId)) {
                    val targetVidId = song.videoId
                    ioScope.launch {
                        val mvPair = unifiedRepository?.resolveOfficialMusicVideoStream(
                            title = song.title,
                            artist = song.artist,
                            currentVideoId = targetVidId,
                            cookies = cookies,
                            preferredVideoQuality = settingsManager?.preferredVideoQuality ?: "auto",
                        )
                        if (mvPair != null) {
                            resolvedMvCache[targetVidId] = mvPair
                            withContext(Dispatchers.Main) {
                                if (currentSong?.videoId == targetVidId && isVideoModeEnabled && isPlayerViewVisible) {
                                    val vp = getVideoPlayer(ctx)
                                    val mvItem = MediaItem.Builder()
                                        .setMediaId(targetVidId)
                                        .setUri(mvPair.first)
                                        .setMimeType(mvPair.second)
                                        .setMediaMetadata(createMediaMetadata(song))
                                        .build()
                                    val pos = activePlayer?.currentPosition ?: 0L
                                    vp.stop()
                                    vp.clearMediaItems()
                                    vp.setMediaItem(mvItem, pos)
                                    vp.prepare()
                                    vp.playWhenReady = activePlayer?.playWhenReady == true
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    fun setVideoPlaybackEnabled(context: Context, enabled: Boolean) {
        if (appContext == null) appContext = context.applicationContext
        if (settingsManager == null) settingsManager = SettingsManager(context.applicationContext)
        isVideoModeEnabled = enabled
        settingsManager?.isPlayVideoIfAvailable = enabled
        updateVideoPlaybackState()
    }

    fun refreshSponsorSegments() {
        currentSong?.videoId?.let { 
            sponsorSegmentsCache.remove(it)
            fetchSponsorSegments(it) 
        }
    }

    private fun isStrictVideoPlaybackForSong(videoId: String): Boolean {
        if (settingsManager?.isSponsorBlockEnabled != true) return false
        if (settingsManager?.isPlayVideoIfAvailable != true) return false
        val songObj = queue.find { it.videoId == videoId } ?: currentSong?.takeIf { it.videoId == videoId }
        return (songObj?.isVideo == true) || (currentSong?.videoId == videoId && isVideoAvailable)
    }

    private fun fetchSponsorSegments(videoId: String, isPrefetch: Boolean = false) {
        if (!isStrictVideoPlaybackForSong(videoId)) {
            if (!isPrefetch && currentSong?.videoId == videoId) {
                sponsorSegments.clear()
                mergedSponsorSegments = emptyList()
            }
            return
        }

        // 1. Check in-memory cache
        sponsorSegmentsCache[videoId]?.let { cached ->
            if (!isPrefetch) {
                applySponsorSegments(videoId, cached)
            }
            return
        }

        // 2. Check Database cache
        ioScope.launch {
            val dbEntry = database?.songDao()?.getSponsorSegmentsByVideoId(videoId)
            if (dbEntry != null) {
                try {
                    val type = object : TypeToken<List<Pair<Long, Long>>>() {}.type
                    val segments: List<Pair<Long, Long>> = Gson().fromJson(dbEntry.segmentsJson, type)
                    sponsorSegmentsCache[videoId] = segments
                    if (!isPrefetch && currentSong?.videoId == videoId) {
                        withContext(Dispatchers.Main) {
                            applySponsorSegments(videoId, segments)
                        }
                    }
                    return@launch
                } catch (e: Exception) {
                    Log.e("MusicPlayer", "Failed to parse cached sponsor segments", e)
                }
            }

            // 3. Fetch from network if not in DB
            try {
                val categoryList = mutableListOf<String>()
                if (settingsManager?.skipSponsorMentions == true) categoryList.add("sponsor")
                if (settingsManager?.skipIntroOutro == true) {
                    categoryList.add("intro")
                    categoryList.add("outro")
                }
                if (settingsManager?.skipNonMusicSkits == true) {
                    categoryList.add("selfpromo")
                    categoryList.add("interaction")
                    categoryList.add("preview")
                    categoryList.add("music_offtopic")
                    categoryList.add("filler")
                }

                if (categoryList.isEmpty()) return@launch
                val categories = categoryList.joinToString(prefix = "[", postfix = "]", separator = ",") { "\"$it\"" }

                val response = RetrofitClient.sponsorBlockInstance.getSkipSegments(videoId, categories)

                if (response.isSuccessful) {
                    val segments = response.body() ?: emptyList()
                    val songDuration = (queue.find { it.videoId == videoId } ?: currentSong?.takeIf { it.videoId == videoId })
                        ?.let { parseDurationToMs(it.durationText) } ?: 0L
                        
                    val merged = mergeSponsorSegments(segments, songDuration)
                    sponsorSegmentsCache[videoId] = merged

                    // Persist to Database
                    database?.songDao()?.insertSponsorSegments(SponsorBlockCacheEntity(
                        videoId = videoId,
                        segmentsJson = Gson().toJson(merged)
                    ))

                    if (!isPrefetch && currentSong?.videoId == videoId) {
                        withContext(Dispatchers.Main) {
                            sponsorSegments.clear()
                            sponsorSegments.addAll(segments)
                            applySponsorSegments(videoId, merged)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "SponsorBlock network error", e)
            }
        }
    }

    private fun applySponsorSegments(videoId: String, merged: List<Pair<Long, Long>>) {
        mainScope.launch {
            if (currentSong?.videoId != videoId || !isStrictVideoPlaybackForSong(videoId)) {
                mergedSponsorSegments = emptyList()
                return@launch
            }
            val postIntroSegments = merged.filter { it.first > 2500L }
            mergedSponsorSegments = postIntroSegments
            lastSponsorSeekTarget = -1L
            activePlayer?.let { player ->
                scheduleSponsorMessages(player, postIntroSegments)
            }
            Log.d("MusicPlayer", "SponsorBlock (Video Only): Applied pre-trimmed segments for $videoId")
        }
    }

    private fun scheduleSponsorMessages(player: ExoPlayer, mergedSegments: List<Pair<Long, Long>>) {
        mergedSegments.forEach { (startMs, endMs) ->
            val triggerPosition = (startMs - 120).coerceAtLeast(0)
            player.createMessage(object : PlayerMessage.Target {
                override fun handleMessage(messageType: Int, payload: Any?) {
                    val vid = currentSong?.videoId ?: return
                    if (!isStrictVideoPlaybackForSong(vid)) return

                    if (lastSponsorSeekTarget != endMs) {
                        lastSponsorSeekTarget = endMs
                        cleanPositionAtSkipTrigger = currentPosition
                        skipTriggerTime = System.currentTimeMillis()
                        isFadingForSkip = false
                        player.setSeekParameters(SeekParameters.EXACT)
                        player.seekTo(endMs)
                        player.volume = (baseVolume * userVolume).coerceIn(0f, 1f)
                        Log.d("MusicPlayer", "SponsorBlock (Video Only): Bypassed segment to $endMs")
                    }
                }
            })
            .setLooper(Looper.getMainLooper())
            .setPosition(triggerPosition)
            .setDeleteAfterDelivery(true)
            .send()
        }
    }

    private fun getNextIndex(fromIndex: Int = currentIndex): Int {
        if (queue.isEmpty()) return -1
        return if (shuffleEnabled) {
            if (shuffledIndices.isEmpty() || !shuffledIndices.contains(fromIndex)) generateShuffledIndices()
            val currentInShuffled = shuffledIndices.indexOf(fromIndex)
            if (currentInShuffled != -1 && currentInShuffled + 1 < shuffledIndices.size) {
                shuffledIndices[currentInShuffled + 1]
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL && shuffledIndices.isNotEmpty()) {
                // Return index 0 of the shuffled list
                shuffledIndices[0]
            } else {
                -1
            }
        } else {
            if (fromIndex + 1 < queue.size) {
                fromIndex + 1
            } else if (this.repeatMode == Player.REPEAT_MODE_ALL) {
                0
            } else {
                -1
            }
        }
    }

    private fun mergeSponsorSegments(segments: List<SponsorSegment>, totalDurationMs: Long): List<Pair<Long, Long>> {
        if (segments.isEmpty()) return emptyList()

        // Filter: Only skip segments that occur within the first or last 10 seconds of the track.
        // This targets dialogues (intros/outros) and edge sponsor mentions while preserving music sections.
        val filtered = segments.filter { seg ->
            val startMs = (seg.segment[0] * 1000).toLong()
            val endMs = (seg.segment[1] * 1000).toLong()

            val isAtBeginning = startMs < 10000
            val isAtEnd = totalDurationMs > 10000 && endMs > (totalDurationMs - 10000)

            isAtBeginning || isAtEnd
        }

        if (filtered.isEmpty()) return emptyList()

        val sorted = filtered.map {
            (it.segment[0] * 1000).toLong().coerceAtLeast(0) to
            (it.segment[1] * 1000).toLong()
        }.sortedBy { it.first }

        val merged = mutableListOf<Pair<Long, Long>>()
        var currentStart = sorted[0].first
        var currentEnd = sorted[0].second

        for (i in 1 until sorted.size) {
            val next = sorted[i]
            if (next.first <= currentEnd) {
                currentEnd = maxOf(currentEnd, next.second)
            } else {
                merged.add(currentStart to currentEnd)
                currentStart = next.first
                currentEnd = next.second
            }
        }
        merged.add(currentStart to currentEnd)
        return merged
    }

    private fun parseDurationToMs(duration: String?): Long {
        if (duration == null) return 0L
        return try {
            val parts = duration.split(":").map { it.toLongOrNull() ?: 0L }
            when (parts.size) {
                1 -> parts[0] * 1000
                2 -> (parts[0] * 60 + parts[1]) * 1000
                3 -> (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000
                else -> 0L
            }
        } catch (e: Exception) {
            0L
        }
    }

    private fun scheduleBackgroundTriggers(context: Context, player: ExoPlayer, force: Boolean = false) {
        val songId = currentSong?.videoId ?: return
        if (!force && scheduledVideoId == songId) return

        scheduledVideoId = songId

        mainScope.launch {
            // Wait for duration to be known (especially important for gapless transitions)
            var attempts = 0
            while (player.duration <= 1000 && attempts < 50) {
                delay(100)
                attempts++
            }

            val duration = player.duration
            if (duration <= 1000) {
                Log.w("MusicPlayer", "Could not schedule triggers: Duration unknown for $songId")
                scheduledVideoId = null // Allow retry
                return@launch
            }

            Log.d("MusicPlayer", "Scheduling triggers for $songId (Duration: $duration)")

            // Gapless Pre-fetch Trigger (30s before end)
            if (settingsManager?.isCrossfadeEnabled == false && duration > 40000) {
                player.createMessage(object : PlayerMessage.Target {
                    override fun handleMessage(messageType: Int, payload: Any?) {
                        Log.d("MusicPlayer", "Trigger: Prefetch Next Song")
                        prefetchNextSong(context)
                    }
                })
                .setLooper(Looper.getMainLooper())
                .setPosition(duration - 30000)
                .setDeleteAfterDelivery(true)
                .send()
            }

            // SimpMusic Crossfade Trigger based on crossfadeDurationSeconds
            val crossfadeDuration = 1500L // Fixed 1.5s crossfade per user request

            if (settingsManager?.isCrossfadeEnabled == true && duration > (crossfadeDuration + 3000L) && repeatMode != Player.REPEAT_MODE_ONE) {
                player.createMessage(object : PlayerMessage.Target {
                    override fun handleMessage(messageType: Int, payload: Any?) {
                        if (!isCrossfadeTriggered) {
                            Log.d("MusicPlayer", "Trigger: Start SimpMusic Crossfade (${crossfadeDuration}ms)")
                            isCrossfadeTriggered = true
                            startCrossfade(context)
                        }
                    }
                })
                .setLooper(Looper.getMainLooper())
                .setPosition(duration - crossfadeDuration)
                .setDeleteAfterDelivery(true)
                .send()
            }
        }
    }


    private fun cacheCurrentSongForInstantResume(context: Context, song: Song, streamUrl: String, userAgent: String) {
        cachingStreamJob?.cancel()
        cachingStreamJob = ioScope.launch {
            try {
                val targetFile = getInstantResumeCacheFile(context, song.videoId)
                if (targetFile.exists() && targetFile.length() > 64_000L) return@launch
                val tempFile = java.io.File(targetFile.parentFile, "${song.videoId}.tmp")
                val reqBuilder = okhttp3.Request.Builder()
                    .url(streamUrl)
                    .header("User-Agent", userAgent)
                    .header("Origin", "https://music.youtube.com")
                    .header("Referer", "https://music.youtube.com/")
                if (!cookies.isNullOrEmpty()) {
                    reqBuilder.header("Cookie", cookies!!)
                }
                RetrofitClient.getOkHttpClient().newCall(reqBuilder.build()).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val body = resp.body ?: return@use
                    body.byteStream().use { input ->
                        java.io.FileOutputStream(tempFile).use { output ->
                            val buf = ByteArray(32 * 1024)
                            while (isActive) {
                                val read = input.read(buf)
                                if (read == -1) break
                                output.write(buf, 0, read)
                            }
                            output.flush()
                        }
                    }
                    if (tempFile.length() > 32_000L) {
                        tempFile.renameTo(targetFile)
                        targetFile.parentFile?.listFiles()
                            ?.filter { it.name.endsWith(".audio") && it.name != targetFile.name }
                            ?.sortedByDescending { it.lastModified() }
                            ?.drop(2)
                            ?.forEach { try { it.delete() } catch (_: Exception) {} }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun warmUpRestoredSongCache(context: Context, song: Song, savedPositionMs: Long) {
        ioScope.launch {
            try {
                val downloaded = database?.songDao()?.getDownloadByVideoId(song.videoId)
                val cachedResumeFile = getInstantResumeCacheFile(context, song.videoId)
                val player = getInstance(context)
                val metadata = createMediaMetadata(song)
                val localFile = when {
                    downloaded != null && java.io.File(downloaded.filePath).exists() -> java.io.File(downloaded.filePath)
                    cachedResumeFile.exists() && cachedResumeFile.length() > 32_000L -> cachedResumeFile
                    else -> null
                }
                if (localFile != null) {
                    withContext(Dispatchers.Main) {
                        if (currentSong?.videoId == song.videoId && !isPlaying) {
                            val item = MediaItem.Builder()
                                .setUri(Uri.fromFile(localFile))
                                .setMediaId(song.videoId)
                                .setMimeType(downloaded?.mimeType ?: "audio/webm")
                                .setMediaMetadata(metadata)
                                .build()
                            player.playWhenReady = false
                            player.setMediaItem(item, savedPositionMs.coerceAtLeast(0L))
                            player.prepare()
                        }
                    }
                    return@launch
                }

                val priority = if (settingsManager?.isDataSaverEnabled == true) "Data Saver" else "Force OPUS 160kbps"
                val result = unifiedRepository?.getStreamingUrl(
                    videoId = song.videoId,
                    cookies = cookies,
                    failedClients = emptyList(),
                    targetBitrate = null,
                    priority = priority,
                    preferredVideoQuality = settingsManager?.preferredVideoQuality ?: "auto"
                ) ?: return@launch

                withContext(Dispatchers.Main) {
                    if (currentSong?.videoId == song.videoId && !isPlaying) {
                        val item = MediaItem.Builder()
                            .setUri(result.url)
                            .setMediaId(song.videoId)
                            .setMimeType(result.mimeType)
                            .setMediaMetadata(metadata)
                            .setTag(result)
                            .build()
                        player.playWhenReady = false
                        player.setMediaItem(item, savedPositionMs.coerceAtLeast(0L))
                        player.prepare()
                    }
                }
            } catch (e: Exception) {
                Log.w("MusicPlayer", "warmUpRestoredSongCache failed: ${e.message}")
            }
        }
    }

    private suspend fun fetchSponsorSegmentsSuspend(videoId: String): List<Pair<Long, Long>> {
        if (!isStrictVideoPlaybackForSong(videoId)) return emptyList()
        sponsorSegmentsCache[videoId]?.let { return it }

        val dbEntry = database?.songDao()?.getSponsorSegmentsByVideoId(videoId)
        if (dbEntry != null) {
            try {
                val type = object : TypeToken<List<Pair<Long, Long>>>() {}.type
                val segments: List<Pair<Long, Long>> = Gson().fromJson(dbEntry.segmentsJson, type)
                sponsorSegmentsCache[videoId] = segments
                return segments
            } catch (_: Exception) {}
        }

        return try {
            val categoryList = mutableListOf<String>()
            if (settingsManager?.skipSponsorMentions == true) categoryList.add("sponsor")
            if (settingsManager?.skipIntroOutro == true) {
                categoryList.add("intro")
                categoryList.add("outro")
            }
            if (settingsManager?.skipNonMusicSkits == true) {
                categoryList.add("selfpromo")
                categoryList.add("interaction")
                categoryList.add("preview")
                categoryList.add("music_offtopic")
                categoryList.add("filler")
            }
            if (categoryList.isEmpty()) return emptyList()
            val categories = categoryList.joinToString(prefix = "[", postfix = "]", separator = ",") { "\"$it\"" }
            val response = withTimeoutOrNull(2800L) {
                RetrofitClient.sponsorBlockInstance.getSkipSegments(videoId, categories)
            }
            if (response?.isSuccessful == true) {
                val raw = response.body() ?: emptyList()
                val songDuration = (queue.find { it.videoId == videoId } ?: currentSong?.takeIf { it.videoId == videoId })
                    ?.let { parseDurationToMs(it.durationText) } ?: 0L
                val merged = mergeSponsorSegments(raw, songDuration)
                sponsorSegmentsCache[videoId] = merged
                database?.songDao()?.insertSponsorSegments(
                    SponsorBlockCacheEntity(videoId = videoId, segmentsJson = Gson().toJson(merged))
                )
                merged
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Prefetches upcoming songs in the queue, computes their SponsorBlock and skip-silence trims,
     * and arranges crossfade pre-buffering so every upcoming track plays instantaneously.
     */
    private fun prefetchUpcomingQueueAndCrossfade(context: Context) {
        if (settingsManager?.isCrossfadeEnabled != true) {
            prefetchNextSong(context)
        }
        ioScope.launch {
            try {
                val startIdx = currentIndex.coerceAtLeast(0)
                val upcoming = (1..4).mapNotNull { offset ->
                    queue.getOrNull(startIdx + offset)
                }
                upcoming.forEach { nextTrack ->
                    fetchSponsorSegmentsSuspend(nextTrack.videoId)
                    prefetchMetadata(context, nextTrack)
                }
            } catch (e: Exception) {
                Log.w("MusicPlayer", "Upcoming queue trim prefetch warning: ${e.message}")
            }
        }
    }

    fun enqueueAutoDownloadForSong(context: Context, song: Song) {
        ioScope.launch {
            try {
                val db = AppDatabase.getDatabase(context.applicationContext)
                val existing = db.songDao().getDownloadByVideoId(song.videoId)
                if (existing != null && java.io.File(existing.filePath).exists()) return@launch

                val cookieStr = cookies ?: CookieManager(context.applicationContext).getCookies()
                val repo = unifiedRepository ?: UnifiedMusicRepository(
                    com.tervixa.wavemuzix.repository.YouTubeRepository(),
                    AudioStreamRepository(com.tervixa.wavemuzix.repository.YouTubeRepository())
                )
                val result = repo.getStreamingUrl(song.videoId, cookieStr) ?: return@launch

                DownloadManager.updateProgress(song.videoId, song.title, 0)
                val request = androidx.work.OneTimeWorkRequestBuilder<DownloadWorker>()
                    .addTag("download_${song.videoId}")
                    .setInputData(
                        androidx.work.workDataOf(
                            "url" to result.url,
                            "videoId" to song.videoId,
                            "title" to song.title,
                            "artist" to song.artist,
                            "thumbnailUrl" to song.thumbnailUrl,
                            "artistId" to song.artistId,
                            "userAgent" to result.userAgent,
                            "cookies" to cookieStr
                        )
                    )
                    .build()
                androidx.work.WorkManager.getInstance(context.applicationContext).enqueue(request)
                Log.d("MusicPlayer", "Auto-download enqueued for: ${song.title}")
            } catch (e: Exception) {
                Log.e("MusicPlayer", "Failed to auto-download ${song.title}", e)
            }
        }
    }

    fun triggerAutoDownloadLikedSongs(context: Context) {
        ioScope.launch {
            try {
                val db = AppDatabase.getDatabase(context.applicationContext)
                val liked = db.songDao().getAllFavorites().first()
                val downloadedIds = db.songDao().getAllDownloads().first()
                    .filter { java.io.File(it.filePath).exists() }
                    .map { it.videoId }
                    .toSet()

                liked.filter { it.videoId !in downloadedIds }.forEach { fav ->
                    enqueueAutoDownloadForSong(
                        context = context,
                        song = Song(
                            id = fav.videoId,
                            videoId = fav.videoId,
                            title = fav.title,
                            artist = fav.artist,
                            thumbnailUrl = fav.thumbnailUrl,
                            artistId = fav.artistId
                        )
                    )
                    delay(250)
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "triggerAutoDownloadLikedSongs failed", e)
            }
        }
    }

    fun triggerSmartDownloads(context: Context) {
        ioScope.launch {
            try {
                val db = AppDatabase.getDatabase(context.applicationContext)
                val mostPlayed = db.songDao().getMostPlayedSongs().first()
                val liked = db.songDao().getAllFavorites().first()
                val downloadedIds = db.songDao().getAllDownloads().first()
                    .filter { java.io.File(it.filePath).exists() }
                    .map { it.videoId }
                    .toSet()

                val candidates = mutableListOf<Song>()
                mostPlayed.take(15).forEach { mp ->
                    if (mp.videoId !in downloadedIds) {
                        candidates.add(
                            Song(
                                id = mp.videoId,
                                videoId = mp.videoId,
                                title = mp.title,
                                artist = mp.artist,
                                thumbnailUrl = mp.thumbnailUrl,
                                artistId = mp.artistId
                            )
                        )
                    }
                }
                liked.take(10).forEach { fav ->
                    if (fav.videoId !in downloadedIds && candidates.none { it.videoId == fav.videoId }) {
                        candidates.add(
                            Song(
                                id = fav.videoId,
                                videoId = fav.videoId,
                                title = fav.title,
                                artist = fav.artist,
                                thumbnailUrl = fav.thumbnailUrl,
                                artistId = fav.artistId
                            )
                        )
                    }
                }

                candidates.take(20).forEach { song ->
                    enqueueAutoDownloadForSong(context, song)
                    delay(250)
                }
            } catch (e: Exception) {
                Log.e("MusicPlayer", "triggerSmartDownloads failed", e)
            }
        }
    }
}
