package com.tervixa.wavemuzix.data

import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.roundToInt

/**
 * SimpMusic Built-In AudioFX Equalizer & DSP Engine:
 * - Provides 10-band graphic EQ mapped dynamically to hardware `android.media.audiofx.Equalizer` bands
 * - Includes all 22 SimpMusic EQ presets (`Flat`, `Bass booster`, `Acoustic`, `Pop`, `Rock`, `Vocal booster`, etc.)
 * - Includes hardware `BassBoost`, `Virtualizer` (3D Spatializer), and `LoudnessEnhancer` (Preamp)
 * - Never fails with "Open System Equalizer failed" because the built-in equalizer sheet opens directly in-app!
 */
object AudioFxManager {
    val FREQUENCY_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    val PRESETS: Map<String, List<Float>> = linkedMapOf(
        "Flat" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Bass booster" to listOf(5.5f, 5.0f, 4.0f, 2.5f, 1.0f, 0f, 0f, 0f, 0f, 0f),
        "Bass reducer" to listOf(-5.5f, -5.0f, -4.0f, -2.5f, -1.0f, 0f, 0f, 0f, 0f, 0f),
        "Acoustic" to listOf(5.0f, 4.5f, 3.5f, 1.0f, 2.0f, 2.0f, 3.5f, 4.0f, 3.5f, 2.0f),
        "Classical" to listOf(4.5f, 3.8f, 3.0f, 2.5f, -1.5f, -1.5f, 0f, 2.2f, 3.5f, 4.0f),
        "Dance" to listOf(4.0f, 6.5f, 5.0f, 0f, 2.0f, 3.5f, 5.0f, 4.5f, 3.5f, 0f),
        "Deep" to listOf(5.0f, 4.0f, 2.0f, 1.0f, 3.0f, 2.5f, 1.5f, -2.0f, -3.5f, -4.5f),
        "Electronic" to listOf(4.5f, 4.0f, 1.5f, 0f, -2.0f, 2.0f, 1.0f, 1.5f, 4.0f, 5.0f),
        "Hip-Hop" to listOf(5.0f, 4.5f, 1.5f, 3.0f, -1.5f, -1.0f, 1.5f, -0.5f, 2.0f, 3.0f),
        "Jazz" to listOf(4.0f, 3.0f, 1.5f, 2.0f, -1.5f, -1.5f, 0f, 1.5f, 3.0f, 4.0f),
        "Latin" to listOf(4.5f, 3.0f, 0f, 0f, -1.5f, -1.5f, -1.5f, 0f, 3.0f, 4.5f),
        "Loudness" to listOf(6.0f, 4.5f, 0f, 0f, -2.0f, 0f, -1.0f, -5.0f, 5.0f, 1.0f),
        "Lounge" to listOf(-3.0f, -1.5f, -0.5f, 1.5f, 4.0f, 2.5f, 0f, -1.5f, 2.0f, 1.0f),
        "Piano" to listOf(3.0f, 2.0f, 0f, 2.5f, 3.0f, 1.5f, 3.5f, 4.5f, 3.0f, 3.5f),
        "Pop" to listOf(-1.5f, -1.0f, 0f, 2.0f, 4.5f, 4.5f, 2.0f, 0f, -1.0f, -1.5f),
        "R&B" to listOf(3.0f, 7.0f, 6.0f, 1.5f, -2.0f, -1.5f, 2.5f, 3.0f, 3.0f, 4.0f),
        "Rock" to listOf(5.0f, 4.0f, 3.0f, 1.5f, -0.5f, -1.0f, 0.5f, 2.5f, 3.5f, 4.5f),
        "Small speakers" to listOf(5.5f, 4.5f, 3.5f, 2.5f, 1.0f, 0f, -1.5f, -2.5f, -3.5f, -4.5f),
        "Spoken word" to listOf(-3.5f, -0.5f, 0f, 0.5f, 3.5f, 5.0f, 5.0f, 4.5f, 2.5f, 0f),
        "Treble booster" to listOf(0f, 0f, 0f, 0f, 0f, 1.0f, 2.5f, 4.0f, 5.0f, 6.0f),
        "Treble reducer" to listOf(0f, 0f, 0f, 0f, 0f, -1.0f, -2.5f, -4.0f, -5.0f, -6.0f),
        "Vocal booster" to listOf(-1.5f, -3.0f, -3.0f, 1.5f, 4.0f, 4.0f, 3.0f, 1.5f, 0f, -1.5f),
    )

    var showEqualizerSheet by mutableStateOf(false)
    var isEnabled by mutableStateOf(true)
    var currentPreset by mutableStateOf("Flat")
    val bandGainsDb = mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)
    var bassBoostStrength by mutableIntStateOf(0) // 0..1000
    var virtualizerStrength by mutableIntStateOf(0) // 0..1000
    var preampDb by mutableFloatStateOf(0f) // -8f..+8f

    private var hardwareEq: Equalizer? = null
    private var hardwareBassBoost: BassBoost? = null
    private var hardwareVirtualizer: Virtualizer? = null
    private var hardwarePreamp: LoudnessEnhancer? = null
    private var attachedSessionId: Int = -1
    private var isInitializedFromPrefs = false

    fun ensureLoaded(context: Context) {
        if (isInitializedFromPrefs) return
        val settings = SettingsManager(context.applicationContext)
        isEnabled = settings.isBuiltInEqEnabled
        currentPreset = settings.builtInEqPreset
        bassBoostStrength = settings.builtInBassBoostStrength.coerceIn(0, 1000)
        virtualizerStrength = settings.builtInVirtualizerStrength.coerceIn(0, 1000)
        preampDb = settings.builtInPreampDb.coerceIn(-8f, 8f)

        val parsed = settings.builtInEqBandsCsv
            .split(",")
            .mapNotNull { it.trim().toFloatOrNull() }
        if (parsed.size == 10) {
            for (i in 0 until 10) {
                bandGainsDb[i] = parsed[i].coerceIn(-12f, 12f)
            }
        } else {
            val presetBands = PRESETS[currentPreset] ?: PRESETS["Flat"]!!
            for (i in 0 until 10) {
                bandGainsDb[i] = presetBands[i]
            }
        }
        isInitializedFromPrefs = true
    }

    fun attachToSession(context: Context, audioSessionId: Int) {
        ensureLoaded(context)
        if (audioSessionId <= 0) return

        try {
            if (attachedSessionId != audioSessionId || hardwareEq == null) {
                releaseHardwareEffects()
                attachedSessionId = audioSessionId
                hardwareEq = runCatching { Equalizer(0, audioSessionId) }.getOrNull()
                hardwareBassBoost = runCatching { BassBoost(0, audioSessionId) }.getOrNull()
                hardwareVirtualizer = runCatching { Virtualizer(0, audioSessionId) }.getOrNull()
                hardwarePreamp = runCatching { LoudnessEnhancer(audioSessionId) }.getOrNull()
            }
            applyCurrentStateToHardware()
        } catch (e: Exception) {
            Log.w("AudioFxManager", "Failed to attach Built-in AudioFX to session $audioSessionId: ${e.message}")
        }
    }

    fun applyCurrentStateToHardware(djBassCutFactor: Float = 1.0f) {
        try {
            hardwareEq?.let { eq ->
                eq.enabled = isEnabled
                val numBands = eq.numberOfBands.toInt()
                val range = eq.bandLevelRange
                val minLevel = range.getOrNull(0)?.toInt() ?: -1500
                val maxLevel = range.getOrNull(1)?.toInt() ?: 1500

                for (b in 0 until numBands) {
                    // Map hardware band index (0..numBands-1) to our 10-band curve (0..9)
                    val mappedIdx = ((b.toFloat() / (numBands - 1).coerceAtLeast(1)) * 9f).roundToInt().coerceIn(0, 9)
                    var gainDb = if (isEnabled) bandGainsDb[mappedIdx] else 0f
                    // Support DJ Transition Bass Swap on bands 0..2 (31Hz..125Hz)
                    if (mappedIdx <= 2 && djBassCutFactor < 0.99f) {
                        gainDb -= (1f - djBassCutFactor) * 9f
                    }
                    val millibels = (gainDb * 100f).roundToInt().coerceIn(minLevel, maxLevel).toShort()
                    eq.setBandLevel(b.toShort(), millibels)
                }
            }

            hardwareBassBoost?.let { bb ->
                bb.enabled = isEnabled && bassBoostStrength > 0
                if (bb.strengthSupported) {
                    val effectiveBass = (bassBoostStrength * djBassCutFactor).roundToInt().coerceIn(0, 1000).toShort()
                    bb.setStrength(effectiveBass)
                }
            }

            hardwareVirtualizer?.let { virt ->
                virt.enabled = isEnabled && virtualizerStrength > 0
                if (virt.strengthSupported) {
                    virt.setStrength(virtualizerStrength.coerceIn(0, 1000).toShort())
                }
            }

            hardwarePreamp?.let { enhancer ->
                enhancer.enabled = isEnabled && kotlin.math.abs(preampDb) > 0.1f
                if (enhancer.enabled) {
                    enhancer.setTargetGain((preampDb * 100f).roundToInt())
                }
            }
        } catch (e: Exception) {
            Log.w("AudioFxManager", "Error applying AudioFX parameters: ${e.message}")
        }
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        isEnabled = enabled
        SettingsManager(context.applicationContext).isBuiltInEqEnabled = enabled
        applyCurrentStateToHardware()
    }

    fun selectPreset(context: Context, presetName: String) {
        currentPreset = presetName
        val bands = PRESETS[presetName]
        if (bands != null && bands.size == 10) {
            for (i in 0 until 10) {
                bandGainsDb[i] = bands[i]
            }
        }
        persistBandsAndPreset(context)
        applyCurrentStateToHardware()
    }

    fun setBandGain(context: Context, index: Int, gainDb: Float) {
        if (index !in 0..9) return
        bandGainsDb[index] = gainDb.coerceIn(-12f, 12f)
        currentPreset = "Custom"
        persistBandsAndPreset(context)
        applyCurrentStateToHardware()
    }

    fun setBassBoost(context: Context, strength: Int) {
        bassBoostStrength = strength.coerceIn(0, 1000)
        SettingsManager(context.applicationContext).builtInBassBoostStrength = bassBoostStrength
        applyCurrentStateToHardware()
    }

    fun setVirtualizer(context: Context, strength: Int) {
        virtualizerStrength = strength.coerceIn(0, 1000)
        SettingsManager(context.applicationContext).builtInVirtualizerStrength = virtualizerStrength
        applyCurrentStateToHardware()
    }

    fun setPreamp(context: Context, db: Float) {
        preampDb = db.coerceIn(-8f, 8f)
        SettingsManager(context.applicationContext).builtInPreampDb = preampDb
        applyCurrentStateToHardware()
    }

    fun resetToFlat(context: Context) {
        selectPreset(context, "Flat")
        setBassBoost(context, 0)
        setVirtualizer(context, 0)
        setPreamp(context, 0f)
    }

    private fun persistBandsAndPreset(context: Context) {
        val settings = SettingsManager(context.applicationContext)
        settings.builtInEqPreset = currentPreset
        settings.builtInEqBandsCsv = bandGainsDb.joinToString(",") { "%.1f".format(it) }
    }

    /**
     * Opens the Built-In Equalizer sheet by default, or attempts the system equalizer intent if
     * explicitly configured and falls back cleanly to the Built-In Equalizer if no system equalizer exists.
     */
    fun openEqualizer(context: Context, audioSessionId: Int) {
        ensureLoaded(context)
        if (audioSessionId > 0) {
            attachToSession(context, audioSessionId)
        }
        val settings = SettingsManager(context.applicationContext)
        if (settings.equalizerType.equals("System Equalizer", ignoreCase = true)) {
            try {
                val intent = Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
                    putExtra(AudioEffect.EXTRA_AUDIO_SESSION, if (audioSessionId > 0) audioSessionId else 0)
                    putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
                    putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                }
                if (intent.resolveActivity(context.packageManager) != null && context is android.app.Activity) {
                    context.startActivityForResult(intent, 0)
                    return
                }
            } catch (_: Exception) {
            }
        }
        // Always open the Built-In Equalizer Sheet!
        showEqualizerSheet = true
    }

    fun releaseHardwareEffects() {
        try { hardwareEq?.release() } catch (_: Exception) {}
        try { hardwareBassBoost?.release() } catch (_: Exception) {}
        try { hardwareVirtualizer?.release() } catch (_: Exception) {}
        try { hardwarePreamp?.release() } catch (_: Exception) {}
        hardwareEq = null
        hardwareBassBoost = null
        hardwareVirtualizer = null
        hardwarePreamp = null
        attachedSessionId = -1
    }
}
