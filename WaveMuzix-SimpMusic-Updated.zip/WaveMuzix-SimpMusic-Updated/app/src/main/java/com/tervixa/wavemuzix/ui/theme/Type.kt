package com.tervixa.wavemuzix.ui.theme

import android.content.Context
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.R

/**
 * Bundled Inter modern minimal sans-serif font family (Regular, Medium, SemiBold, Bold).
 * Provides crisp, zero-latency rendering without cursive or decorative strokes, and
 * has proportionally balanced font sizes, line heights, and optical letter spacing.
 */
val WaveModernFontFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

val LocalForceDarkText = staticCompositionLocalOf { false }
val LocalPoppinsFontFamily = staticCompositionLocalOf<FontFamily> { WaveModernFontFamily }

@Composable
fun rememberPoppinsFontFamily(@Suppress("UNUSED_PARAMETER") context: Context = LocalContext.current): FontFamily {
    return WaveModernFontFamily
}

/**
 * Clean, minimal, high-legibility typography scale tuned specifically for Inter's tall x-height.
 * Every tier has matched fontSize, lineHeight, and letterSpacing so titles, artist subtitles,
 * filter chips, and lyrics never clip or crowd.
 */
@Composable
fun buildSimpTypography(
    fontFamily: FontFamily = LocalPoppinsFontFamily.current,
    colorScheme: ColorScheme = MaterialTheme.colorScheme,
    forceDark: Boolean = LocalForceDarkText.current,
): Typography {
    val titleColor = if (forceDark) Color.White else colorScheme.onBackground
    val bodyColor = if (forceDark) Color(0xFFA8A8A8) else colorScheme.onSurfaceVariant
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val textDirection = if (rtl) TextDirection.Content else TextDirection.Unspecified
    val textAlign = if (rtl) TextAlign.Right else TextAlign.Unspecified
    val defaultLineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.None,
    )

    return Typography(
        displayLarge = TextStyle(
            fontSize = 19.sp,
            lineHeight = 25.sp,
            letterSpacing = (-0.25).sp,
            fontWeight = FontWeight.Normal,
            fontFamily = fontFamily,
            color = bodyColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        displayMedium = TextStyle(
            fontSize = 24.sp,
            lineHeight = 30.sp,
            letterSpacing = (-0.4).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        displaySmall = TextStyle(
            fontSize = 21.sp,
            lineHeight = 27.sp,
            letterSpacing = (-0.35).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        headlineLarge = TextStyle(
            fontSize = 22.sp,
            lineHeight = 28.sp,
            letterSpacing = (-0.35).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        headlineMedium = TextStyle(
            fontSize = 19.sp,
            lineHeight = 24.sp,
            letterSpacing = (-0.3).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        headlineSmall = TextStyle(
            fontSize = 17.sp,
            lineHeight = 22.sp,
            letterSpacing = (-0.25).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        titleLarge = TextStyle(
            fontSize = 22.sp,
            lineHeight = 28.sp,
            letterSpacing = (-0.35).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        titleMedium = TextStyle(
            fontSize = 16.sp,
            lineHeight = 21.sp,
            letterSpacing = (-0.15).sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        titleSmall = TextStyle(
            fontSize = 13.5.sp,
            lineHeight = 18.sp,
            letterSpacing = (-0.1).sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        bodyLarge = TextStyle(
            fontSize = 16.sp,
            lineHeight = 22.sp,
            letterSpacing = (-0.1).sp,
            fontWeight = FontWeight.Normal,
            fontFamily = fontFamily,
            color = bodyColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        bodyMedium = TextStyle(
            fontSize = 13.sp,
            lineHeight = 18.sp,
            letterSpacing = 0.sp,
            fontWeight = FontWeight.Normal,
            fontFamily = fontFamily,
            color = bodyColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        bodySmall = TextStyle(
            fontSize = 11.5.sp,
            lineHeight = 15.sp,
            letterSpacing = 0.05.sp,
            fontWeight = FontWeight.Normal,
            fontFamily = fontFamily,
            color = bodyColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        labelLarge = TextStyle(
            fontSize = 14.sp,
            lineHeight = 19.sp,
            letterSpacing = (-0.1).sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        labelMedium = TextStyle(
            fontSize = 14.5.sp,
            lineHeight = 19.sp,
            letterSpacing = (-0.1).sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = fontFamily,
            color = titleColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
        labelSmall = TextStyle(
            fontSize = 12.5.sp,
            lineHeight = 16.sp,
            letterSpacing = 0.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = fontFamily,
            color = bodyColor,
            textDirection = textDirection,
            textAlign = textAlign,
            lineHeightStyle = defaultLineHeightStyle,
        ),
    )
}

@Composable
fun simpTypo(
    forceDark: Boolean = LocalForceDarkText.current,
): Typography = buildSimpTypography(forceDark = forceDark)

val Typography = Typography()
