package com.tervixa.wavemuzix.repository

import android.util.Log
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.SongArtist
import com.tervixa.wavemuzix.model.isRecordLabelOrChannelName
import com.tervixa.wavemuzix.model.parseArtists
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.YoutubeService
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.Serializable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

// --- MODELS ---

data class StreamingResult(
    val url: String,
    val mimeType: String,
    val bitrate: Int,
    val contentLength: Long,
    val audioQuality: String?,
    val expiresInSeconds: Int?,
    val isAudioOnly: Boolean,
    val userAgent: String,
    val loudnessDb: Double?,
    val videoUrl: String?,
    val videoMimeType: String?,
    val clientName: String,
) : Serializable

data class ArtistDetail(
    val name: String,
    val description: String,
    val thumbnailUrl: String,
    val songs: List<Song>,
    val items: List<Map<String, Any>> = emptyList(),
    val browseId: String,
    val songsBrowseId: String? = null,
    val songsParams: String? = null,
    val subscriberCountText: String? = null,
    val listenerCountText: String? = null,
    val radioId: String? = null,
    val shuffleId: String? = null,
) : Serializable

data class PlaylistDetail(
    val title: String,
    val description: String,
    val thumbnailUrl: String,
    val songs: List<Song>,
    val browseId: String,
    val type: String? = "playlist",
    val continuation: String? = null,
) : Serializable

data class HomeShelf(
    val title: String,
    val items: List<Any>,
    val type: String = "shelf",
) : Serializable

data class HomeResponse(
    val userName: String? = null,
    val userAvatarUrl: String? = null,
    val quickPicks: List<Song> = emptyList(),
    val trending: List<Song> = emptyList(),
    val albums: List<Map<String, String>> = emptyList(),
    val shelves: List<HomeShelf> = emptyList(),
    val continuation: String? = null,
) : Serializable

/**
 * SimpMusic-style rich search suggestion item shown while typing:
 * Can represent an Artist, Song, Video, Album, or Playlist with its thumbnail, subtitle, and action payload.
 */
data class SearchSuggestionItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val thumbnailUrl: String,
    val type: String, // "artist", "song", "video", "album", "playlist"
    val song: Song? = null,
    val artist: ArtistDetail? = null,
    val playlist: PlaylistDetail? = null,
) : Serializable

data class SearchSuggestionsResponse(
    val queries: List<String> = emptyList(),
    val recommendedItems: List<SearchSuggestionItem> = emptyList(),
) : Serializable

// --- REPOSITORY IMPLEMENTATION ---

class YouTubeRepository {
    private val ytService: YoutubeService by lazy {
        NewPipe.getService(0) as YoutubeService
    }

    companion object {
        // High-speed multi-threaded connection pool shared across all YouTube Music & stream calls
        private val fastHttpClient: OkHttpClient by lazy {
            val dispatcher = Dispatcher(Executors.newFixedThreadPool(24)).apply {
                maxRequests = 96
                maxRequestsPerHost = 32
            }
            OkHttpClient.Builder()
                .dispatcher(dispatcher)
                .connectionPool(ConnectionPool(24, 5, TimeUnit.MINUTES))
                .connectTimeout(7, TimeUnit.SECONDS)
                .readTimeout(8, TimeUnit.SECONDS)
                .build()
        }

        private val fastDispatcher = Dispatchers.IO.limitedParallelism(24)
        private val singerCache = ConcurrentHashMap<String, List<SongArtist>>()
        private val suggestionCache = ConcurrentHashMap<String, SearchSuggestionsResponse>()
        private val searchCache = ConcurrentHashMap<String, Triple<List<Song>, List<PlaylistDetail>, List<ArtistDetail>>>()

        private const val WEB_REMIX_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private fun getHighResThumbnail(
        thumbnails: List<org.schabi.newpipe.extractor.Image>?,
        fallbackVideoId: String? = null,
    ): String {
        val originalUrl = thumbnails?.maxByOrNull { it.width }?.url
            ?: thumbnails?.lastOrNull()?.url
            ?: thumbnails?.firstOrNull()?.url
            ?: ""

        if (originalUrl.isBlank()) {
            val cleanVid = fallbackVideoId?.trim().orEmpty()
            return if (cleanVid.length == 11) "https://i.ytimg.com/vi/$cleanVid/hqdefault.jpg" else ""
        }

        val normalized = when {
            originalUrl.startsWith("//") -> "https:$originalUrl"
            originalUrl.startsWith("http://") -> "https://${originalUrl.removePrefix("http://")}"
            else -> originalUrl
        }

        return when {
            normalized.contains("googleusercontent.com") || normalized.contains("ggpht.com") -> {
                if (normalized.contains("=")) {
                    normalized.substringBeforeLast("=") + "=w544-h544-l90-rj"
                } else {
                    "$normalized=w544-h544-l90-rj"
                }
            }
            normalized.contains("ytimg.com") -> {
                if (normalized.contains("/vi/")) {
                    val videoId = normalized.substringAfter("/vi/").substringBefore("/").substringBefore("?")
                    "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
                } else normalized
            }
            else -> normalized
        }
    }

    private fun upgradeInnerTubeThumbnail(rawUrl: String?, fallbackVideoId: String? = null): String {
        val raw = rawUrl?.trim().orEmpty()
        if (raw.isEmpty()) {
            val vid = fallbackVideoId?.trim().orEmpty()
            return if (vid.length == 11) "https://i.ytimg.com/vi/$vid/hqdefault.jpg" else ""
        }
        val httpsUrl = when {
            raw.startsWith("//") -> "https:$raw"
            raw.startsWith("http://") -> "https://${raw.removePrefix("http://")}"
            else -> raw
        }
        return when {
            httpsUrl.contains("googleusercontent.com") || httpsUrl.contains("ggpht.com") -> {
                if (httpsUrl.contains("=w")) {
                    val wMatch = Regex("=w(\\d+)-h(\\d+)").find(httpsUrl)
                    val w = wMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    val h = wMatch?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
                    if (w > 0 && h > 0 && w.toFloat() / h.toFloat() >= 1.35f) {
                        httpsUrl.substringBeforeLast("=") + "=w544-h306-l90-rj"
                    } else {
                        httpsUrl.substringBeforeLast("=") + "=w544-h544-l90-rj"
                    }
                } else {
                    "$httpsUrl=w544-h544-l90-rj"
                }
            }
            httpsUrl.contains("ytimg.com/vi/") -> {
                val vid = httpsUrl.substringAfter("/vi/").substringBefore("/").substringBefore("?")
                "https://i.ytimg.com/vi/$vid/hqdefault.jpg"
            }
            else -> httpsUrl
        }
    }

    private fun extractChannelId(uploaderUrl: String?): String? {
        if (uploaderUrl.isNullOrBlank()) return null
        return when {
            uploaderUrl.contains("/channel/") -> uploaderUrl.substringAfter("/channel/").substringBefore("/").substringBefore("?")
            uploaderUrl.contains("/browse/") -> uploaderUrl.substringAfter("/browse/").substringBefore("/").substringBefore("?")
            uploaderUrl.contains("/c/") -> uploaderUrl.substringAfter("/c/").substringBefore("/").substringBefore("?")
            uploaderUrl.contains("/@") -> uploaderUrl.substringAfter("/@").substringBefore("/").substringBefore("?")
            else -> null
        }?.takeIf { it.isNotBlank() }
    }

    private fun formatDurationSeconds(seconds: Long): String? {
        if (seconds <= 0L) return null
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hrs > 0) {
            "%d:%02d:%02d".format(hrs, mins, secs)
        } else {
            "%d:%02d".format(mins, secs)
        }
    }

    private fun isAudioSong(title: String, artist: String): Boolean {
        val lowerTitle = title.lowercase()
        val lowerArtist = artist.lowercase()

        if (lowerArtist.contains("topic") || lowerArtist.endsWith("- topic")) return true

        val nonSongKeywords = listOf(
            "teaser", "trailer", "behind the scenes", "making of", "interview", "podcast"
        )
        return nonSongKeywords.none { lowerTitle.contains(it) }
    }

    private fun cleanSongTitle(title: String): String {
        if (title.isBlank()) return ""
        var cleaned = title.trim()

        val noisePatterns = listOf(
            Regex("\\(\\s*official\\s*(music\\s*)?(video|audio|lyric\\s*video|visualizer|mv)\\s*\\)", RegexOption.IGNORE_CASE),
            Regex("\\[\\s*official\\s*(music\\s*)?(video|audio|lyric\\s*video|visualizer|mv)\\s*\\]", RegexOption.IGNORE_CASE),
            Regex("\\(\\s*(full\\s*video|video\\s*song|4k\\s*video|hd\\s*video)\\s*\\)", RegexOption.IGNORE_CASE),
            Regex("\\[\\s*(full\\s*video|video\\s*song|4k\\s*video|hd\\s*video|4k)\\s*\\]", RegexOption.IGNORE_CASE)
        )
        for (pattern in noisePatterns) {
            cleaned = cleaned.replace(pattern, "")
        }
        cleaned = cleaned.replace(Regex("\\s{2,}"), " ").trim()
        return if (cleaned.isNotEmpty()) cleaned else title.trim()
    }

    private fun cleanArtistName(rawArtist: String?): String {
        if (rawArtist.isNullOrBlank()) return "Unknown Artist"
        return rawArtist
            .replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")
            .trim()
            .ifEmpty { "Unknown Artist" }
    }

    private fun buildSongFromStreamItem(item: StreamInfoItem, isVideoItem: Boolean = false): Song {
        val videoId = item.url.substringAfter("v=").substringBefore("&")
        val rawTitle = cleanSongTitle(item.name ?: "")
        val cleanedUploader = cleanArtistName(item.uploaderName)
        val channelId = extractChannelId(item.uploaderUrl)
        val cachedSingers = singerCache[videoId]

        val baseSong = Song(
            id = item.url,
            videoId = videoId,
            title = rawTitle,
            artist = cleanedUploader,
            thumbnailUrl = getHighResThumbnail(item.thumbnails, videoId),
            artistId = channelId,
            durationText = formatDurationSeconds(item.duration),
            artists = cachedSingers.orEmpty(),
            isVideo = isVideoItem,
        )
        val parsedArtists = if (!cachedSingers.isNullOrEmpty()) {
            cachedSingers
        } else {
            baseSong.parseArtists(cleanedUploader, channelId)
        }
        val displayArtistStr = if (parsedArtists.isNotEmpty()) {
            parsedArtists.joinToString(", ") { it.name }
        } else {
            cleanedUploader
        }
        val primaryArtistId = parsedArtists.firstOrNull()?.id ?: channelId
        return baseSong.copy(
            artist = displayArtistStr,
            artistId = primaryArtistId,
            artists = parsedArtists,
        )
    }

    // --- INNER-TUBE WEB_REMIX CLIENT FOR FAST SIMPMUSIC SEARCH & MULTI-SINGER EXTRACTION ---

    private fun buildWebRemixContextJson(hl: String = "en", gl: String = "IN"): JSONObject {
        return JSONObject().apply {
            put(
                "client",
                JSONObject().apply {
                    put("clientName", "WEB_REMIX")
                    put("clientVersion", "1.20241118.01.00")
                    put("hl", hl)
                    put("gl", gl)
                }
            )
        }
    }

    private fun postWebRemix(endpoint: String, payload: JSONObject, cookies: String? = null): JSONObject? {
        return try {
            val reqBuilder = Request.Builder()
                .url("https://music.youtube.com/youtubei/v1/$endpoint?prettyPrint=false")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .header("User-Agent", WEB_REMIX_USER_AGENT)
                .header("Origin", "https://music.youtube.com")
                .header("Referer", "https://music.youtube.com/")
                .header("X-YouTube-Client-Name", "67")
                .header("X-YouTube-Client-Version", "1.20241118.01.00")
            if (!cookies.isNullOrBlank()) {
                reqBuilder.header("Cookie", cookies)
            }
            fastHttpClient.newCall(reqBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isBlank()) return null
                JSONObject(bodyStr)
            }
        } catch (e: Exception) {
            Log.w("YouTubeRepo", "WEB_REMIX call to $endpoint failed: ${e.message}")
            null
        }
    }

    private fun extractThumbnailFromRenderer(renderer: JSONObject, fallbackVideoId: String? = null): String {
        val thumbs = renderer.optJSONObject("thumbnail")
            ?.optJSONObject("musicThumbnailRenderer")
            ?.optJSONObject("thumbnail")
            ?.optJSONArray("thumbnails")
            ?: renderer.optJSONObject("thumbnailRenderer")
                ?.optJSONObject("musicThumbnailRenderer")
                ?.optJSONObject("thumbnail")
                ?.optJSONArray("thumbnails")
            ?: renderer.optJSONObject("thumbnail")
                ?.optJSONArray("thumbnails")

        val rawUrl = if (thumbs != null && thumbs.length() > 0) {
            thumbs.optJSONObject(thumbs.length() - 1)?.optString("url")
        } else null

        return upgradeInnerTubeThumbnail(rawUrl, fallbackVideoId)
    }

    /**
     * Parses a `musicResponsiveListItemRenderer` from YouTube Music `WEB_REMIX` into a
     * [SearchSuggestionItem] (Song, Video, Artist, Album, or Playlist) with ALL singers/artists.
     */
    private fun parseResponsiveListItem(
        itemRenderer: JSONObject,
        shelfTitleHint: String = "",
    ): SearchSuggestionItem? {
        val flexColumns = itemRenderer.optJSONArray("flexColumns") ?: return null
        if (flexColumns.length() == 0) return null

        val titleRuns = flexColumns.optJSONObject(0)
            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")
            ?.optJSONArray("runs")
        val rawTitle = buildString {
            if (titleRuns != null) {
                for (i in 0 until titleRuns.length()) {
                    append(titleRuns.optJSONObject(i)?.optString("text").orEmpty())
                }
            }
        }.trim()
        if (rawTitle.isEmpty()) return null

        // Determine navigation target: watchEndpoint (Song/Video) or browseEndpoint (Artist/Album/Playlist)
        val navEndpoint = itemRenderer.optJSONObject("navigationEndpoint")
            ?: titleRuns?.optJSONObject(0)?.optJSONObject("navigationEndpoint")
        val watchEndpoint = navEndpoint?.optJSONObject("watchEndpoint")
            ?: itemRenderer.optJSONObject("overlay")
                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")
                ?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")

        val browseEndpoint = navEndpoint?.optJSONObject("browseEndpoint")
        val videoId = watchEndpoint?.optString("videoId")?.takeIf { it.isNotBlank() }
            ?: itemRenderer.optJSONObject("playlistItemData")?.optString("videoId")?.takeIf { it.isNotBlank() }
        val browseId = browseEndpoint?.optString("browseId")?.takeIf { it.isNotBlank() }
        val pageType = browseEndpoint
            ?.optJSONObject("browseEndpointContextSupportedConfigs")
            ?.optJSONObject("browseEndpointContextMusicConfig")
            ?.optString("pageType")
            .orEmpty()
        val musicVideoType = watchEndpoint
            ?.optJSONObject("watchEndpointMusicSupportedConfigs")
            ?.optJSONObject("watchEndpointMusicConfig")
            ?.optString("musicVideoType")
            .orEmpty()

        // Inspect secondary flexColumns (index 1 and 2) to extract type label, singers/artists, and duration
        val subtitleRuns = mutableListOf<JSONObject>()
        for (colIdx in 1 until flexColumns.length()) {
            val runs = flexColumns.optJSONObject(colIdx)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
            if (runs != null) {
                for (rIdx in 0 until runs.length()) {
                    runs.optJSONObject(rIdx)?.let { subtitleRuns.add(it) }
                }
                if (colIdx < flexColumns.length() - 1) {
                    subtitleRuns.add(JSONObject().put("text", " • "))
                }
            }
        }

        val fixedColumns = itemRenderer.optJSONArray("fixedColumns")
        var durationText: String? = null
        if (fixedColumns != null && fixedColumns.length() > 0) {
            val fixedRuns = fixedColumns.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFixedColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
            val fixedText = fixedRuns?.optJSONObject(0)?.optString("text")?.trim()
            if (!fixedText.isNullOrBlank() && Regex("^\\d+:\\d{2}(:\\d{2})?$").matches(fixedText)) {
                durationText = fixedText
            }
        }

        // Group subtitle runs by " • " separator
        val segments = mutableListOf<MutableList<JSONObject>>()
        var currentSegment = mutableListOf<JSONObject>()
        for (run in subtitleRuns) {
            val txt = run.optString("text")
            if (txt.trim() == "•") {
                if (currentSegment.isNotEmpty()) {
                    segments.add(currentSegment)
                    currentSegment = mutableListOf()
                }
            } else {
                currentSegment.add(run)
            }
        }
        if (currentSegment.isNotEmpty()) {
            segments.add(currentSegment)
        }

        val firstSegText = segments.firstOrNull()?.joinToString("") { it.optString("text") }?.trim().orEmpty()
        val firstSegLower = firstSegText.lowercase()
        val shelfLower = shelfTitleHint.lowercase()

        val itemType = when {
            pageType.contains("ARTIST") || firstSegLower == "artist" || shelfLower.contains("artist") -> "artist"
            pageType.contains("ALBUM") || firstSegLower in listOf("album", "single", "ep") || shelfLower.contains("album") -> "album"
            pageType.contains("PLAYLIST") || firstSegLower.contains("playlist") || shelfLower.contains("playlist") -> "playlist"
            musicVideoType.contains("OMV") || musicVideoType.contains("UGC") || firstSegLower == "video" || shelfLower.contains("video") -> "video"
            !videoId.isNullOrBlank() -> "song"
            !browseId.isNullOrBlank() && (browseId.startsWith("UC") || browseId.startsWith("FMSP")) -> "artist"
            !browseId.isNullOrBlank() && browseId.startsWith("MPREb") -> "album"
            !browseId.isNullOrBlank() -> "playlist"
            else -> return null
        }

        val thumbUrl = extractThumbnailFromRenderer(itemRenderer, videoId)

        if (itemType == "artist") {
            val resolvedBrowseId = browseId ?: return null
            val subText = segments.drop(1).joinToString(" • ") { seg ->
                seg.joinToString("") { it.optString("text") }.trim()
            }.ifBlank { "Artist" }
            val artistDetail = ArtistDetail(
                name = cleanArtistName(rawTitle),
                description = subText,
                thumbnailUrl = thumbUrl,
                songs = emptyList(),
                browseId = resolvedBrowseId,
                subscriberCountText = subText.takeIf { it.contains("subscriber", ignoreCase = true) || it.contains("audience", ignoreCase = true) },
            )
            return SearchSuggestionItem(
                id = resolvedBrowseId,
                title = artistDetail.name,
                subtitle = if (subText.startsWith("Artist", ignoreCase = true)) subText else "Artist • $subText",
                thumbnailUrl = thumbUrl,
                type = "artist",
                artist = artistDetail,
            )
        }

        if (itemType == "album" || itemType == "playlist") {
            val resolvedBrowseId = browseId ?: watchEndpoint?.optString("playlistId") ?: return null
            val authorAndYear = segments.drop(if (firstSegLower in listOf("album", "single", "ep", "playlist", "community playlist", "featured playlist")) 1 else 0)
                .joinToString(" • ") { seg -> seg.joinToString("") { it.optString("text") }.trim() }
                .ifBlank { if (itemType == "album") "Album" else "Playlist" }
            val playlistDetail = PlaylistDetail(
                title = cleanSongTitle(rawTitle),
                description = authorAndYear,
                thumbnailUrl = thumbUrl,
                songs = emptyList(),
                browseId = resolvedBrowseId,
                type = itemType,
            )
            return SearchSuggestionItem(
                id = resolvedBrowseId,
                title = playlistDetail.title,
                subtitle = "${itemType.replaceFirstChar { it.uppercase() }} • $authorAndYear",
                thumbnailUrl = thumbUrl,
                type = itemType,
                playlist = playlistDetail,
            )
        }

        // Song or Video item: extract ALL singers/artists accurately!
        val resolvedVideoId = videoId ?: return null
        val extractedArtists = mutableListOf<SongArtist>()
        val seenArtistNames = mutableSetOf<String>()

        fun addExtractedArtist(name: String, id: String?) {
            val clean = name.replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "").trim()
            if (clean.length < 2) return
            val lower = clean.lowercase()
            if (lower in listOf("song", "video", "album", "single", "ep", "playlist", "views", "explicit")) return
            if (Regex("^\\d+:\\d{2}(:\\d{2})?$").matches(clean)) return
            if (Regex("^[\\d.,]+[KMB]?\\s*(views|plays|listeners|subscribers)$", RegexOption.IGNORE_CASE).matches(clean)) return
            if (isRecordLabelOrChannelName(clean)) return
            if (seenArtistNames.add(lower)) {
                extractedArtists.add(SongArtist(name = clean, id = id))
            }
        }

        // First collect runs that explicitly link to an Artist browseEndpoint (UC...)
        for (seg in segments) {
            for (run in seg) {
                val runText = run.optString("text").trim()
                val runBrowse = run.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")
                val runBrowseId = runBrowse?.optString("browseId")
                val runPageType = runBrowse
                    ?.optJSONObject("browseEndpointContextSupportedConfigs")
                    ?.optJSONObject("browseEndpointContextMusicConfig")
                    ?.optString("pageType")
                    .orEmpty()
                if (!runBrowseId.isNullOrBlank() && (runBrowseId.startsWith("UC") || runPageType.contains("ARTIST"))) {
                    addExtractedArtist(runText, runBrowseId)
                }
            }
        }

        // Also parse the artist segment (typically segment 0, or segment 1 if segment 0 is "Song"/"Video")
        val typeHeaderLabels = setOf("song", "video", "single", "ep", "album", "podcast", "episode")
        val artistSegmentIndex = if (firstSegLower in typeHeaderLabels && segments.size > 1) 1 else 0
        val artistSegment = segments.getOrNull(artistSegmentIndex)
        if (artistSegment != null) {
            val rawSegString = artistSegment.joinToString("") { it.optString("text") }.trim()
            val splitRegex = Regex("\\s*(?:,|&|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bwith\\b|\\bx\\b)\\s*", RegexOption.IGNORE_CASE)
            rawSegString.split(splitRegex).forEach { part ->
                val matchingRunId = artistSegment.firstOrNull {
                    it.optString("text").trim().equals(part.trim(), ignoreCase = true)
                }?.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                addExtractedArtist(part, matchingRunId)
            }
        }

        // Check if last segment is a duration (e.g. "3:42")
        if (durationText == null) {
            val lastSegText = segments.lastOrNull()?.joinToString("") { it.optString("text") }?.trim().orEmpty()
            if (Regex("^\\d+:\\d{2}(:\\d{2})?$").matches(lastSegText)) {
                durationText = lastSegText
            }
        }

        val cleanedTitle = cleanSongTitle(rawTitle)
        val tempSong = Song(
            id = "https://music.youtube.com/watch?v=$resolvedVideoId",
            videoId = resolvedVideoId,
            title = cleanedTitle,
            artist = extractedArtists.joinToString(", ") { it.name },
            thumbnailUrl = thumbUrl,
            artistId = extractedArtists.firstOrNull()?.id,
            durationText = durationText,
            artists = extractedArtists,
            isVideo = itemType == "video",
        )
        val finalArtists = if (extractedArtists.isNotEmpty()) {
            extractedArtists
        } else {
            tempSong.parseArtists()
        }
        if (finalArtists.isNotEmpty()) {
            singerCache[resolvedVideoId] = finalArtists
        }
        val finalArtistStr = finalArtists.joinToString(", ") { it.name }.ifBlank { "Unknown Artist" }
        val finalSong = tempSong.copy(
            artist = finalArtistStr,
            artistId = finalArtists.firstOrNull()?.id,
            artists = finalArtists,
        )

        val subtitlePrefix = if (itemType == "video") "Video" else "Song"
        val subtitleText = buildString {
            append(subtitlePrefix)
            append(" • ")
            append(finalSong.displayArtists)
            if (!durationText.isNullOrBlank()) {
                append(" • ")
                append(durationText)
            }
        }

        return SearchSuggestionItem(
            id = resolvedVideoId,
            title = finalSong.title,
            subtitle = subtitleText,
            thumbnailUrl = finalSong.thumbnailUrl,
            type = itemType,
            song = finalSong,
        )
    }

    /**
     * SimpMusic-exact typing search suggestions (`getSearchSuggestionsWithItems`):
     * Fetches both text query suggestions AND the most relevant rich items (matching Artist first
     * if the user types an artist name, followed by top relevant Songs, Videos, Albums, or Playlists).
     */
    suspend fun getSearchSuggestionsWithItems(
        query: String,
        cookies: String?,
    ): SearchSuggestionsResponse = withContext(fastDispatcher) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext SearchSuggestionsResponse()

        suggestionCache[trimmed.lowercase()]?.let { return@withContext it }

        supervisorScope {
            // 1. Query YouTube Music WEB_REMIX get_search_suggestions
            val webRemixSuggestionsDeferred = async {
                val payload = JSONObject().apply {
                    put("context", buildWebRemixContextJson())
                    put("input", trimmed)
                }
                postWebRemix("music/get_search_suggestions", payload, cookies)
            }

            // 2. Simultaneously run a lightweight unfiltered WEB_REMIX search to guarantee top relevant
            // entities (Artist first if matching, then top Songs/Albums/Playlists) even when
            // get_search_suggestions only returns text strings
            val topEntitiesDeferred = async {
                val payload = JSONObject().apply {
                    put("context", buildWebRemixContextJson())
                    put("query", trimmed)
                }
                postWebRemix("search", payload, cookies)
            }

            // 3. Fast NewPipe suggestion fallback
            val newPipeQueriesDeferred = async {
                try {
                    ytService.suggestionExtractor.suggestionList(trimmed)
                } catch (_: Exception) {
                    emptyList()
                }
            }

            val queries = mutableListOf<String>()
            val recommendedItems = mutableListOf<SearchSuggestionItem>()

            val suggestJson = webRemixSuggestionsDeferred.await()
            val contentsArr = suggestJson?.optJSONArray("contents")
            if (contentsArr != null) {
                for (i in 0 until contentsArr.length()) {
                    val secItems = contentsArr.optJSONObject(i)
                        ?.optJSONObject("searchSuggestionsSectionRenderer")
                        ?.optJSONArray("contents") ?: continue
                    for (j in 0 until secItems.length()) {
                        val entry = secItems.optJSONObject(j) ?: continue
                        val suggestRenderer = entry.optJSONObject("searchSuggestionRenderer")
                        if (suggestRenderer != null) {
                            val qText = suggestRenderer.optJSONObject("navigationEndpoint")
                                ?.optJSONObject("searchEndpoint")
                                ?.optString("query")
                                ?.takeIf { it.isNotBlank() }
                            if (qText != null && queries.none { it.equals(qText, ignoreCase = true) }) {
                                queries.add(qText)
                            }
                        }
                        val responsiveRenderer = entry.optJSONObject("musicResponsiveListItemRenderer")
                        if (responsiveRenderer != null) {
                            parseResponsiveListItem(responsiveRenderer)?.let { item ->
                                if (recommendedItems.none { it.id == item.id && it.type == item.type }) {
                                    recommendedItems.add(item)
                                }
                            }
                        }
                    }
                }
            }

            // Parse top entities from unfiltered WEB_REMIX search if needed or to enrich artist-first ordering
            val searchJson = topEntitiesDeferred.await()
            if (searchJson != null) {
                val searchItems = extractSearchItemsFromWebRemixResponse(searchJson)
                for (item in searchItems) {
                    if (recommendedItems.none { it.id == item.id && it.type == item.type }) {
                        recommendedItems.add(item)
                    }
                }
            }

            if (queries.isEmpty()) {
                queries.addAll(newPipeQueriesDeferred.await().take(6))
            }

            // Sort recommended items SimpMusic-style:
            // If an artist's name closely matches the typed query (or starts with / contains it),
            // place the Artist card FIRST, followed by the most relevant Songs, Albums, and Playlists!
            val qLower = trimmed.lowercase()
            val rankedItems = recommendedItems
                .sortedWith(
                    compareByDescending<SearchSuggestionItem> { item ->
                        val titleLower = item.title.lowercase()
                        when {
                            item.type == "artist" && (titleLower == qLower || titleLower.startsWith(qLower) || qLower.startsWith(titleLower)) -> 100
                            item.type == "artist" && titleLower.contains(qLower) -> 85
                            item.type == "song" && (titleLower == qLower || titleLower.startsWith(qLower)) -> 90
                            item.type == "song" && item.subtitle.lowercase().contains(qLower) -> 80
                            item.type == "album" && (titleLower == qLower || titleLower.startsWith(qLower)) -> 75
                            item.type == "playlist" && titleLower.startsWith(qLower) -> 70
                            item.type == "song" -> 65
                            item.type == "artist" -> 60
                            item.type == "album" -> 50
                            item.type == "playlist" -> 45
                            else -> 30
                        }
                    }
                )
                .take(6)

            val response = SearchSuggestionsResponse(
                queries = queries.take(6),
                recommendedItems = rankedItems,
            )
            if (response.queries.isNotEmpty() || response.recommendedItems.isNotEmpty()) {
                suggestionCache[trimmed.lowercase()] = response
            }
            response
        }
    }

    private fun extractSearchItemsFromWebRemixResponse(searchJson: JSONObject): List<SearchSuggestionItem> {
        val results = mutableListOf<SearchSuggestionItem>()
        val tabs = searchJson.optJSONObject("contents")
            ?.optJSONObject("tabbedSearchResultsRenderer")
            ?.optJSONArray("tabs")
        val sectionContents = tabs?.optJSONObject(0)
            ?.optJSONObject("tabRenderer")
            ?.optJSONObject("content")
            ?.optJSONObject("sectionListRenderer")
            ?.optJSONArray("contents")
            ?: searchJson.optJSONObject("contents")
                ?.optJSONObject("sectionListRenderer")
                ?.optJSONArray("contents")
            ?: return results

        for (i in 0 until sectionContents.length()) {
            val sec = sectionContents.optJSONObject(i) ?: continue

            // Check musicCardShelfRenderer (Top Result card on YouTube Music!)
            val cardShelf = sec.optJSONObject("musicCardShelfRenderer")
            if (cardShelf != null) {
                parseTopResultCardShelf(cardShelf)?.let { results.add(it) }
                val subContents = cardShelf.optJSONArray("contents")
                if (subContents != null) {
                    for (k in 0 until subContents.length()) {
                        val sub = subContents.optJSONObject(k)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                        parseResponsiveListItem(sub)?.let { results.add(it) }
                    }
                }
            }

            // Check musicShelfRenderer
            val shelf = sec.optJSONObject("musicShelfRenderer") ?: continue
            val shelfTitle = shelf.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
            val shelfItems = shelf.optJSONArray("contents") ?: continue
            for (j in 0 until shelfItems.length()) {
                val itemRenderer = shelfItems.optJSONObject(j)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                parseResponsiveListItem(itemRenderer, shelfTitle)?.let { results.add(it) }
            }
        }
        return results
    }

    private fun parseTopResultCardShelf(cardShelf: JSONObject): SearchSuggestionItem? {
        val titleRuns = cardShelf.optJSONObject("title")?.optJSONArray("runs")
        val rawTitle = titleRuns?.optJSONObject(0)?.optString("text")?.trim().orEmpty()
        if (rawTitle.isEmpty()) return null

        val subtitleRuns = cardShelf.optJSONObject("subtitle")?.optJSONArray("runs")
        val subtitleText = buildString {
            if (subtitleRuns != null) {
                for (i in 0 until subtitleRuns.length()) {
                    append(subtitleRuns.optJSONObject(i)?.optString("text").orEmpty())
                }
            }
        }.trim()

        val tapEndpoint = cardShelf.optJSONObject("onTap")
            ?: titleRuns?.optJSONObject(0)?.optJSONObject("navigationEndpoint")
        val browseEndpoint = tapEndpoint?.optJSONObject("browseEndpoint")
        val watchEndpoint = tapEndpoint?.optJSONObject("watchEndpoint")
        val browseId = browseEndpoint?.optString("browseId")?.takeIf { it.isNotBlank() }
        val videoId = watchEndpoint?.optString("videoId")?.takeIf { it.isNotBlank() }
        val thumbUrl = extractThumbnailFromRenderer(cardShelf, videoId)
        val subLower = subtitleText.lowercase()

        if (!browseId.isNullOrBlank() && (browseId.startsWith("UC") || subLower.startsWith("artist"))) {
            val artist = ArtistDetail(
                name = cleanArtistName(rawTitle),
                description = subtitleText,
                thumbnailUrl = thumbUrl,
                songs = emptyList(),
                browseId = browseId,
            )
            return SearchSuggestionItem(
                id = browseId,
                title = artist.name,
                subtitle = subtitleText.ifBlank { "Artist" },
                thumbnailUrl = thumbUrl,
                type = "artist",
                artist = artist,
            )
        }

        if (!videoId.isNullOrBlank()) {
            val isVid = subLower.startsWith("video")
            val artists = mutableListOf<SongArtist>()
            if (subtitleRuns != null) {
                for (i in 0 until subtitleRuns.length()) {
                    val r = subtitleRuns.optJSONObject(i) ?: continue
                    val bId = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                    val txt = r.optString("text").trim()
                    if (!bId.isNullOrBlank() && bId.startsWith("UC") && !isRecordLabelOrChannelName(txt)) {
                        artists.add(SongArtist(name = txt, id = bId))
                    }
                }
            }
            val song = Song(
                id = "https://music.youtube.com/watch?v=$videoId",
                videoId = videoId,
                title = cleanSongTitle(rawTitle),
                artist = artists.joinToString(", ") { it.name }.ifBlank { subtitleText.substringAfter("•").substringBefore("•").trim() },
                thumbnailUrl = thumbUrl,
                artistId = artists.firstOrNull()?.id,
                artists = artists,
                isVideo = isVid,
            )
            val parsed = song.parseArtists()
            val finalSong = song.copy(
                artist = parsed.joinToString(", ") { it.name }.ifBlank { song.artist },
                artists = parsed,
            )
            return SearchSuggestionItem(
                id = videoId,
                title = finalSong.title,
                subtitle = subtitleText.ifBlank { "Song • ${finalSong.displayArtists}" },
                thumbnailUrl = thumbUrl,
                type = if (isVid) "video" else "song",
                song = finalSong,
            )
        }
        return null
    }

    suspend fun getSearchSuggestions(query: String, cookies: String?): List<String> = withContext(fastDispatcher) {
        getSearchSuggestionsWithItems(query, cookies).queries
    }

    /**
     * Resolves and caches the true singers/artists for a given [Song] using YouTube Music `WEB_REMIX`
     * `next` endpoint + `SpotifyRepository` fallback so YouTube channel names (`T-Series`, `Sony Music`, etc.)
     * are replaced with actual singer names (`Arijit Singh, Shilpa Rao`).
     */
    suspend fun resolveTrueSingersForSong(song: Song, cookies: String? = null, spDcCookie: String? = null): Song = withContext(fastDispatcher) {
        val vid = song.videoId.trim()
        if (vid.isEmpty()) return@withContext song

        singerCache[vid]?.let { cached ->
            if (cached.isNotEmpty()) {
                return@withContext song.copy(
                    artist = cached.joinToString(", ") { it.name },
                    artistId = cached.firstOrNull()?.id ?: song.artistId,
                    artists = cached,
                )
            }
        }

        // 1. Query YouTube Music WEB_REMIX /next for this videoId (returns structured singer runs)
        try {
            val payload = JSONObject().apply {
                put("context", buildWebRemixContextJson())
                put("videoId", vid)
            }
            val nextJson = postWebRemix("next", payload, cookies)
            val panelContents = nextJson
                ?.optJSONObject("contents")
                ?.optJSONObject("singleColumnMusicWatchNextResultsRenderer")
                ?.optJSONObject("tabbedRenderer")
                ?.optJSONObject("watchNextTabbedResultsRenderer")
                ?.optJSONArray("tabs")
                ?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicQueueRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("playlistPanelRenderer")
                ?.optJSONArray("contents")

            if (panelContents != null && panelContents.length() > 0) {
                val firstRenderer = panelContents.optJSONObject(0)?.optJSONObject("playlistPanelVideoRenderer")
                val bylineRuns = firstRenderer?.optJSONObject("longBylineText")?.optJSONArray("runs")
                    ?: firstRenderer?.optJSONObject("shortBylineText")?.optJSONArray("runs")
                if (bylineRuns != null) {
                    val singers = mutableListOf<SongArtist>()
                    val seen = mutableSetOf<String>()
                    for (i in 0 until bylineRuns.length()) {
                        val r = bylineRuns.optJSONObject(i) ?: continue
                        val txt = r.optString("text").trim()
                        if (txt == "•") break // Stop before Album / Year segment
                        if (txt in listOf(",", "&", "and", "feat.", "ft.")) continue
                        val browseEndpoint = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")
                        val bId = browseEndpoint?.optString("browseId")
                        val pageType = browseEndpoint
                            ?.optJSONObject("browseEndpointContextSupportedConfigs")
                            ?.optJSONObject("browseEndpointContextMusicConfig")
                            ?.optString("pageType")
                            .orEmpty()
                        if (pageType.contains("ALBUM")) break
                        if (txt.length >= 2 && !isRecordLabelOrChannelName(txt) && seen.add(txt.lowercase())) {
                            singers.add(SongArtist(name = cleanArtistName(txt), id = bId))
                        }
                    }
                    if (singers.isNotEmpty()) {
                        singerCache[vid] = singers
                        return@withContext song.copy(
                            artist = singers.joinToString(", ") { it.name },
                            artistId = singers.firstOrNull()?.id ?: song.artistId,
                            artists = singers,
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("YouTubeRepo", "WEB_REMIX singer lookup fallback for $vid: ${e.message}")
        }

        // 2. Fallback to Spotify / Catalog metadata enrichment
        try {
            val enriched = SpotifyRepository.enrichSongMetadata(song, spDcCookie)
            if (enriched.artists.isNotEmpty()) {
                singerCache[vid] = enriched.artists
                return@withContext enriched
            }
        } catch (_: Exception) {
        }

        song
    }

    private fun selectBestVideoStream(
        videoOnlyStreams: List<VideoStream>,
        muxedVideoStreams: List<VideoStream>,
        preferredVideoQuality: String,
    ): VideoStream? {
        val allCandidates = (muxedVideoStreams + videoOnlyStreams).filter { !it.content.isNullOrBlank() }
        if (allCandidates.isEmpty()) return null

        val prefLower = preferredVideoQuality.lowercase()
        val targetHeight = when {
            prefLower.contains("1080") -> 1080
            prefLower.contains("720") -> 720
            prefLower.contains("480") -> 480
            prefLower.contains("360") -> 360
            else -> 720
        }

        // Exclude AV1 (av01) when H.264 (avc1) or VP9 streams exist, because AV1 often fails on mobile hardware decoders
        val nonAv1 = allCandidates.filterNot { stream ->
            val c = (stream.codec ?: "").lowercase()
            c.contains("av01") || c.contains("av1")
        }.ifEmpty { allCandidates }

        // Prefer H.264 (avc1) MP4 streams first for universal hardware decoding
        val h264Streams = nonAv1.filter { stream ->
            val c = (stream.codec ?: "").lowercase()
            val m = (stream.format?.mimeType ?: "").lowercase()
            c.contains("avc") || c.contains("h264") || (m.contains("mp4") && !c.contains("vp9"))
        }.ifEmpty { nonAv1 }

        return h264Streams.minByOrNull { stream ->
            val resDigits = Regex("(\\d{3,4})p").find(stream.resolution ?: "")?.groupValues?.getOrNull(1)?.toIntOrNull()
                ?: stream.height.takeIf { it > 0 }
                ?: 480
            val muxedBonus = if (muxedVideoStreams.contains(stream)) -40 else 0
            kotlin.math.abs(resDigits - targetHeight) + muxedBonus
        } ?: h264Streams.firstOrNull()
    }

    suspend fun getStreamingUrl(
        videoId: String,
        cookies: String? = null,
        failedClients: List<String> = emptyList(),
        targetBitrate: Int? = null,
        priority: String = "Force OPUS 160kbps",
        preferredVideoQuality: String = "auto",
    ): StreamingResult? = withContext(fastDispatcher) {
        try {
            val urls = listOf(
                "https://www.youtube.com/watch?v=$videoId",
                "https://music.youtube.com/watch?v=$videoId",
            )

            var lastException: Exception? = null
            for (url in urls) {
                try {
                    val streamInfo = StreamInfo.getInfo(ytService, url)
                    val audioStreams = streamInfo.audioStreams
                    if (audioStreams.isEmpty()) continue

                    val bestAudio = audioStreams.maxByOrNull { it.bitrate } ?: continue
                    val uploaderName = streamInfo.uploaderName.orEmpty()
                    val descContent = streamInfo.description?.content.orEmpty()
                    val isArtTrackAudioOnly = uploaderName.endsWith("- Topic", ignoreCase = true) ||
                        descContent.contains("Provided to YouTube by", ignoreCase = true) ||
                        descContent.contains("Auto-generated by YouTube", ignoreCase = true)

                    val bestVideo = selectBestVideoStream(
                        videoOnlyStreams = streamInfo.videoOnlyStreams ?: emptyList(),
                        muxedVideoStreams = streamInfo.videoStreams ?: emptyList(),
                        preferredVideoQuality = preferredVideoQuality,
                    )

                    return@withContext StreamingResult(
                        url = bestAudio.content,
                        mimeType = bestAudio.format?.mimeType ?: "audio/webm",
                        bitrate = bestAudio.bitrate,
                        contentLength = -1L,
                        audioQuality = bestAudio.quality,
                        expiresInSeconds = 3600,
                        isAudioOnly = isArtTrackAudioOnly || bestVideo == null,
                        userAgent = WEB_REMIX_USER_AGENT,
                        loudnessDb = null,
                        videoUrl = bestVideo?.content,
                        videoMimeType = bestVideo?.format?.mimeType ?: "video/mp4",
                        clientName = "NewPipe",
                    )
                } catch (e: Exception) {
                    lastException = e
                    Log.w("YouTubeRepository", "Stream extraction failed for $url", e)
                }
            }
            throw lastException ?: Exception("No audio streams found")
        } catch (e: Exception) {
            Log.e("YouTubeRepository", "All stream extraction attempts failed for $videoId", e)
            null
        }
    }
    suspend fun resolveOfficialMusicVideoStream(
        title: String,
        artist: String,
        currentVideoId: String,
        cookies: String? = null,
        preferredVideoQuality: String = "auto",
    ): Pair<String, String>? = withContext(fastDispatcher) {
        try {
            val cleanT = cleanSongTitle(title)
            val cleanA = cleanArtistName(artist)
            val query = "$cleanT $cleanA official music video".trim()
            val videos = searchSongs(
                query = query,
                cookies = cookies,
                filterVideos = false,
                filterOnlyVideos = true,
                filterOnlyAudio = false,
            )
            val candidate = videos.firstOrNull { it.videoId.isNotBlank() && it.videoId != currentVideoId }
                ?: videos.firstOrNull { it.videoId.isNotBlank() }
                ?: return@withContext null
            val stream = getStreamingUrl(
                videoId = candidate.videoId,
                cookies = cookies,
                preferredVideoQuality = preferredVideoQuality,
            )
            val vUrl = stream?.videoUrl
            if (!vUrl.isNullOrBlank()) {
                vUrl to (stream.videoMimeType ?: "video/mp4")
            } else null
        } catch (e: Exception) {
            Log.w("YouTubeRepository", "Failed to resolve official MV for $title: ${e.message}")
            null
        }
    }


    /**
     * SimpMusic-matched high-speed multi-threaded Search backend:
     * Uses YouTube Music `WEB_REMIX` InnerTube search in parallel with NewPipe fallback so:
     * 1. Every song has all its actual singers/artists (never record-label channel names),
     * 2. Relevant Artists appear prominently at the top when searching an artist or song,
     * 3. Results load in ~200ms over pooled HTTP/2 connections.
     */
    suspend fun searchAll(
        query: String,
        cookies: String?,
        filterVideos: Boolean = true,
        filterOnlyVideos: Boolean = false,
        filterOnlyAudio: Boolean = false,
        filters: List<String> = emptyList(),
    ): Triple<List<Song>, List<PlaylistDetail>, List<ArtistDetail>> = withContext(fastDispatcher) {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) return@withContext Triple(emptyList(), emptyList(), emptyList())

        val cacheKey = "$trimmedQuery|$filterVideos|$filterOnlyVideos|$filterOnlyAudio|${filters.joinToString(",")}"
        searchCache[cacheKey]?.let { return@withContext it }

        try {
            if (filters.isNotEmpty() || filterOnlyVideos || filterOnlyAudio) {
                val finalFilters = when {
                    filters.isNotEmpty() -> filters
                    filterOnlyVideos -> listOf("music_videos")
                    filterOnlyAudio -> listOf("music_songs")
                    filterVideos -> listOf("music_songs")
                    else -> emptyList()
                }
                val isVideoQuery = finalFilters.contains("music_videos") || filterOnlyVideos
                val isAlbumFilter = finalFilters.contains("music_albums")
                val isPlaylistFilter = finalFilters.contains("music_playlists")
                val isArtistFilter = finalFilters.contains("music_artists")

                // Run WEB_REMIX filtered/unfiltered search in parallel with NewPipe for maximum speed & singer accuracy
                return@withContext supervisorScope {
                    val webRemixDeferred = async {
                        val params = when {
                            isArtistFilter -> "EgWKAQIgAWoKEAkQChAFEAMQBA=="
                            isAlbumFilter -> "EgWKAQIYAWoKEAkQChAFEAMQBA=="
                            isPlaylistFilter -> "EgeKAQQoAEABagoQAxAEEAoQCRAF"
                            isVideoQuery -> "EgWKAQIQAWoKEAkQChAFEAMQBA=="
                            else -> "EgWKAQIIAWoKEAkQBRAKEAMQBA=="
                        }
                        val payload = JSONObject().apply {
                            put("context", buildWebRemixContextJson())
                            put("query", trimmedQuery)
                            put("params", params)
                        }
                        postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                    }

                    val newPipeDeferred = async {
                        try {
                            val searchInfo = SearchInfo.getInfo(
                                ytService,
                                ytService.searchQHFactory.fromQuery(trimmedQuery, finalFilters, "")
                            )
                            searchInfo.relatedItems
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val webItems = webRemixDeferred.await()
                    val webSongs = webItems.mapNotNull { it.song?.copy(isVideo = isVideoQuery || it.type == "video") }
                    val webPlaylists = webItems.mapNotNull { it.playlist }
                    val webArtists = webItems.mapNotNull { it.artist }

                    val npItems = newPipeDeferred.await()
                    val npSongs = npItems.filterIsInstance<StreamInfoItem>().map { buildSongFromStreamItem(it, isVideoQuery) }
                    val npPlaylists = npItems.filterIsInstance<PlaylistInfoItem>().map {
                        PlaylistDetail(
                            title = cleanSongTitle(it.name ?: ""),
                            description = cleanArtistName(it.uploaderName),
                            thumbnailUrl = getHighResThumbnail(it.thumbnails),
                            songs = emptyList(),
                            browseId = it.url.substringAfter("list=").substringBefore("&"),
                            type = if (isAlbumFilter || it.url.contains("OLAK5uy_")) "album" else "playlist",
                        )
                    }
                    val npArtists = npItems.filterIsInstance<ChannelInfoItem>().map {
                        ArtistDetail(
                            name = cleanArtistName(it.name),
                            description = it.description ?: "",
                            thumbnailUrl = getHighResThumbnail(it.thumbnails),
                            songs = emptyList(),
                            browseId = extractChannelId(it.url) ?: it.url.substringAfterLast("/"),
                        )
                    }

                    // Prefer WEB_REMIX songs because they carry all singer names instead of channel names!
                    val mergedSongs = (webSongs + npSongs).distinctBy { it.videoId }
                    val mergedPlaylists = (webPlaylists + npPlaylists).distinctBy { it.browseId }
                    val mergedArtists = (webArtists + npArtists).distinctBy { it.browseId }

                    val res = Triple(mergedSongs, mergedPlaylists, mergedArtists)
                    if (mergedSongs.isNotEmpty() || mergedPlaylists.isNotEmpty() || mergedArtists.isNotEmpty()) {
                        searchCache[cacheKey] = res
                    }
                    res
                }
            }

            // Full SimpMusic parallel search for SearchScreen:
            // Combines WEB_REMIX unfiltered + Songs + Videos + Artists + Albums + Playlists in parallel
            supervisorScope {
                val webUnfilteredDeferred = async {
                    val payload = JSONObject().apply {
                        put("context", buildWebRemixContextJson())
                        put("query", trimmedQuery)
                    }
                    postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                }
                val webSongsDeferred = async {
                    val payload = JSONObject().apply {
                        put("context", buildWebRemixContextJson())
                        put("query", trimmedQuery)
                        put("params", "EgWKAQIIAWoKEAkQBRAKEAMQBA==")
                    }
                    postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                }
                val webVideosDeferred = async {
                    if (filterVideos) emptyList()
                    else {
                        val payload = JSONObject().apply {
                            put("context", buildWebRemixContextJson())
                            put("query", trimmedQuery)
                            put("params", "EgWKAQIQAWoKEAkQChAFEAMQBA==")
                        }
                        postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                    }
                }
                val webArtistsDeferred = async {
                    val payload = JSONObject().apply {
                        put("context", buildWebRemixContextJson())
                        put("query", trimmedQuery)
                        put("params", "EgWKAQIgAWoKEAkQChAFEAMQBA==")
                    }
                    postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                }
                val webAlbumsDeferred = async {
                    val payload = JSONObject().apply {
                        put("context", buildWebRemixContextJson())
                        put("query", trimmedQuery)
                        put("params", "EgWKAQIYAWoKEAkQChAFEAMQBA==")
                    }
                    postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                }
                val webPlaylistsDeferred = async {
                    val payload = JSONObject().apply {
                        put("context", buildWebRemixContextJson())
                        put("query", trimmedQuery)
                        put("params", "EgeKAQQoAEABagoQAxAEEAoQCRAF")
                    }
                    postWebRemix("search", payload, cookies)?.let { extractSearchItemsFromWebRemixResponse(it) }.orEmpty()
                }

                val unfilteredItems = webUnfilteredDeferred.await()
                val songItems = webSongsDeferred.await()
                val videoItems = webVideosDeferred.await()
                val artistItems = webArtistsDeferred.await()
                val albumItems = webAlbumsDeferred.await()
                val playlistItems = webPlaylistsDeferred.await()

                val allWebItems = unfilteredItems + songItems + videoItems + artistItems + albumItems + playlistItems

                var combinedSongs = allWebItems.mapNotNull { it.song }.distinctBy { it.videoId }
                var combinedPlaylists = allWebItems.mapNotNull { it.playlist }.distinctBy { it.browseId }
                var combinedArtists = allWebItems.mapNotNull { it.artist }.distinctBy { it.browseId }

                // Fallback to NewPipe only if WEB_REMIX returned empty
                if (combinedSongs.isEmpty() && combinedArtists.isEmpty()) {
                    val npSongs = try {
                        val info = SearchInfo.getInfo(
                            ytService,
                            ytService.searchQHFactory.fromQuery(trimmedQuery, listOf("music_songs"), "")
                        )
                        info.relatedItems.filterIsInstance<StreamInfoItem>().map { buildSongFromStreamItem(it, false) }
                    } catch (_: Exception) {
                        emptyList()
                    }
                    val npArtists = try {
                        val info = SearchInfo.getInfo(
                            ytService,
                            ytService.searchQHFactory.fromQuery(trimmedQuery, listOf("music_artists"), "")
                        )
                        info.relatedItems.filterIsInstance<ChannelInfoItem>().map {
                            ArtistDetail(
                                name = cleanArtistName(it.name),
                                description = it.description ?: "",
                                thumbnailUrl = getHighResThumbnail(it.thumbnails),
                                songs = emptyList(),
                                browseId = extractChannelId(it.url) ?: it.url.substringAfterLast("/"),
                            )
                        }
                    } catch (_: Exception) {
                        emptyList()
                    }
                    combinedSongs = npSongs
                    combinedArtists = npArtists
                }

                // Rank artists so exact/prefix query match is at index 0
                val qLower = trimmedQuery.lowercase()
                combinedArtists = combinedArtists.sortedByDescending { artist ->
                    val n = artist.name.lowercase()
                    when {
                        n == qLower -> 100
                        n.startsWith(qLower) || qLower.startsWith(n) -> 80
                        n.contains(qLower) -> 60
                        else -> 20
                    }
                }

                val res = Triple(combinedSongs, combinedPlaylists, combinedArtists)
                if (combinedSongs.isNotEmpty() || combinedPlaylists.isNotEmpty() || combinedArtists.isNotEmpty()) {
                    searchCache[cacheKey] = res
                }
                res
            }
        } catch (e: Exception) {
            Log.e("YouTubeRepo", "Search failed for $query with filters $filters", e)
            Triple(emptyList(), emptyList(), emptyList())
        }
    }

    /**
     * Parses a YouTube Music `WEB_REMIX` `browse` response for Albums (`MPREb_...`, `OLAK5uy_...`)
     * and Playlists (`VL...`, `PL...`, `RD...`), ensuring albums load reliably without throwing
     * NewPipe ParsingExceptions ("No Internet Connection") and every album track receives the
     * 1:1 square album cover artwork.
     */
    private suspend fun fetchPlaylistViaWebRemix(
        rawBrowseId: String,
        cookies: String?,
        filterAudio: Boolean,
    ): PlaylistDetail? {
        val trimmed = rawBrowseId.trim()
        val isAlbumBrowse = trimmed.startsWith("MPREb") || trimmed.startsWith("OLAK5uy_")
        val webBrowseId = when {
            trimmed.startsWith("MPREb") -> trimmed
            trimmed.startsWith("VL") -> trimmed
            trimmed.startsWith("UC") || trimmed.startsWith("FE") -> trimmed
            else -> "VL$trimmed"
        }

        val payload = JSONObject().apply {
            put("context", buildWebRemixContextJson())
            put("browseId", webBrowseId)
        }
        val root = postWebRemix("browse", payload, cookies) ?: return null

        var headerRenderer = root.optJSONObject("header")
            ?.let {
                it.optJSONObject("musicDetailHeaderRenderer")
                    ?: it.optJSONObject("musicEditablePlaylistDetailHeaderRenderer")
                        ?.optJSONObject("header")?.optJSONObject("musicDetailHeaderRenderer")
                    ?: it.optJSONObject("musicResponsiveHeaderRenderer")
            }

        val twoCol = root.optJSONObject("contents")?.optJSONObject("twoColumnBrowseResultsRenderer")
        val singleCol = root.optJSONObject("contents")?.optJSONObject("singleColumnBrowseResultsRenderer")

        if (headerRenderer == null && twoCol != null) {
            val tabSecs = twoCol.optJSONArray("tabs")
                ?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")
                ?.optJSONArray("contents")
            if (tabSecs != null) {
                for (i in 0 until tabSecs.length()) {
                    val obj = tabSecs.optJSONObject(i) ?: continue
                    headerRenderer = obj.optJSONObject("musicResponsiveHeaderRenderer")
                        ?: obj.optJSONObject("musicEditablePlaylistDetailHeaderRenderer")
                            ?.optJSONObject("header")?.optJSONObject("musicResponsiveHeaderRenderer")
                        ?: obj.optJSONObject("musicDetailHeaderRenderer")
                    if (headerRenderer != null) break
                }
            }
        }

        val title = headerRenderer?.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text")
            ?.let { cleanSongTitle(it) }
            ?: root.optJSONObject("microformat")?.optJSONObject("microformatDataRenderer")?.optString("title")
                ?.substringBefore(" - YouTube Music")?.let { cleanSongTitle(it) }
            ?: ""

        var albumArtistName = ""
        var albumArtistId: String? = null
        val straplineRuns = headerRenderer?.optJSONObject("straplineTextOne")?.optJSONArray("runs")
            ?: headerRenderer?.optJSONObject("subtitle")?.optJSONArray("runs")
        if (straplineRuns != null) {
            for (i in 0 until straplineRuns.length()) {
                val r = straplineRuns.optJSONObject(i) ?: continue
                val txt = r.optString("text").trim()
                val bId = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                if (!bId.isNullOrBlank() && bId.startsWith("UC")) {
                    albumArtistName = cleanArtistName(txt)
                    albumArtistId = bId
                    break
                } else if (albumArtistName.isEmpty() && txt.length >= 2 && txt !in listOf("Album", "Single", "EP", "Playlist", "•")) {
                    albumArtistName = cleanArtistName(txt)
                }
            }
        }

        val subtitleRuns = headerRenderer?.optJSONObject("subtitle")?.optJSONArray("runs")
        val subtitleText = buildString {
            if (subtitleRuns != null) {
                for (i in 0 until subtitleRuns.length()) {
                    append(subtitleRuns.optJSONObject(i)?.optString("text").orEmpty())
                }
            }
        }.trim()

        val headerThumb = headerRenderer?.let { extractThumbnailFromRenderer(it, null) }.orEmpty()
            .ifBlank {
                val mfThumbs = root.optJSONObject("microformat")
                    ?.optJSONObject("microformatDataRenderer")
                    ?.optJSONObject("thumbnail")
                    ?.optJSONArray("thumbnails")
                mfThumbs?.optJSONObject(mfThumbs.length() - 1)?.optString("url").orEmpty()
            }
            .let { rawUrl ->
                if (rawUrl.contains("googleusercontent.com") || rawUrl.contains("ggpht.com")) {
                    rawUrl.replace(Regex("=w\\d+-h\\d+[^&?]*"), "=w544-h544-l90-rj")
                        .replace(Regex("=s\\d+[^&?]*"), "=s544")
                } else rawUrl
            }

        val sectionArrays = mutableListOf<JSONArray>()
        twoCol?.optJSONObject("secondaryContents")
            ?.optJSONObject("sectionListRenderer")
            ?.optJSONArray("contents")
            ?.let { sectionArrays.add(it) }
        singleCol?.optJSONArray("tabs")
            ?.optJSONObject(0)
            ?.optJSONObject("tabRenderer")
            ?.optJSONObject("content")
            ?.optJSONObject("sectionListRenderer")
            ?.optJSONArray("contents")
            ?.let { sectionArrays.add(it) }

        val parsedSongs = mutableListOf<Song>()
        for (secArr in sectionArrays) {
            for (i in 0 until secArr.length()) {
                val sec = secArr.optJSONObject(i) ?: continue
                val shelf = sec.optJSONObject("musicShelfRenderer")
                    ?: sec.optJSONObject("musicPlaylistShelfRenderer")
                    ?: continue
                val contents = shelf.optJSONArray("contents") ?: continue
                for (j in 0 until contents.length()) {
                    val itemRenderer = contents.optJSONObject(j)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                    val parsed = parseResponsiveListItem(itemRenderer, if (isAlbumBrowse) "album_tracks" else "playlist")?.song
                        ?: parseAlbumTrackItemFallback(itemRenderer, albumArtistName, albumArtistId, headerThumb)
                    if (parsed != null) {
                        val finalThumb = if (isAlbumBrowse && headerThumb.isNotBlank()) {
                            headerThumb
                        } else if (parsed.thumbnailUrl.isNotBlank()) {
                            parsed.thumbnailUrl
                        } else {
                            headerThumb
                        }
                        val finalArtist = if (parsed.artist.isBlank() || parsed.artist == "Unknown Artist") {
                            albumArtistName.ifBlank { "Unknown Artist" }
                        } else parsed.artist
                        val finalArtistsList = if (parsed.artists.isEmpty() && albumArtistName.isNotBlank()) {
                            listOf(SongArtist(name = albumArtistName, id = albumArtistId))
                        } else parsed.artists
                        parsedSongs.add(
                            parsed.copy(
                                artist = finalArtist,
                                artistId = parsed.artistId ?: albumArtistId,
                                artists = finalArtistsList,
                                thumbnailUrl = finalThumb,
                                isVideo = false,
                            )
                        )
                    }
                }
            }
        }

        // If MPREb_... had an audioPlaylistId (OLAK5uy_...) and parsedSongs is still empty, follow the audioPlaylistId!
        if (parsedSongs.isEmpty() && trimmed.startsWith("MPREb")) {
            val canonicalUrl = root.optJSONObject("microformat")
                ?.optJSONObject("microformatDataRenderer")
                ?.optString("urlCanonical")
                .orEmpty()
            val olakId = Regex("list=(OLAK5uy_[a-zA-Z0-9_-]+)").find(canonicalUrl)?.groupValues?.getOrNull(1)
                ?: Regex("\"(OLAK5uy_[a-zA-Z0-9_-]+)\"").find(root.toString())?.groupValues?.getOrNull(1)
            if (!olakId.isNullOrBlank() && olakId != trimmed) {
                val subDetail = fetchPlaylistViaWebRemix(olakId, cookies, filterAudio)
                if (subDetail != null && subDetail.songs.isNotEmpty()) {
                    val fixedSongs = subDetail.songs.map { s ->
                        s.copy(
                            thumbnailUrl = headerThumb.ifBlank { s.thumbnailUrl },
                            artist = if (s.artist == "Unknown Artist" && albumArtistName.isNotBlank()) albumArtistName else s.artist,
                            artistId = s.artistId ?: albumArtistId,
                            isVideo = false,
                        )
                    }
                    return PlaylistDetail(
                        title = title.ifBlank { subDetail.title },
                        description = subtitleText.ifBlank { subDetail.description },
                        thumbnailUrl = headerThumb.ifBlank { subDetail.thumbnailUrl },
                        songs = fixedSongs,
                        browseId = rawBrowseId,
                        type = "album",
                    )
                }
            }
        }

        if (parsedSongs.isEmpty()) return null

        val finalList = if (filterAudio) parsedSongs.filter { isAudioSong(it.title, it.artist) }.ifEmpty { parsedSongs } else parsedSongs
        return PlaylistDetail(
            title = title.ifBlank { "Album" },
            description = subtitleText.ifBlank { albumArtistName },
            thumbnailUrl = headerThumb.ifBlank { finalList.firstOrNull()?.thumbnailUrl.orEmpty() },
            songs = finalList,
            browseId = rawBrowseId,
            type = if (isAlbumBrowse) "album" else "playlist",
        )
    }

    private fun parseAlbumTrackItemFallback(
        itemRenderer: JSONObject,
        defaultArtistName: String,
        defaultArtistId: String?,
        albumThumbUrl: String,
    ): Song? {
        val flexColumns = itemRenderer.optJSONArray("flexColumns") ?: return null
        val titleRuns = flexColumns.optJSONObject(0)
            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")
            ?.optJSONArray("runs")
        val firstRun = titleRuns?.optJSONObject(0) ?: return null
        val rawTitle = firstRun.optString("text").trim()
        if (rawTitle.isEmpty()) return null

        val videoId = firstRun.optJSONObject("navigationEndpoint")
            ?.optJSONObject("watchEndpoint")
            ?.optString("videoId")
            ?.takeIf { it.isNotBlank() }
            ?: itemRenderer.optJSONObject("playlistItemData")?.optString("videoId")?.takeIf { it.isNotBlank() }
            ?: itemRenderer.optJSONObject("overlay")
                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")
                ?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")
                ?.optString("videoId")
                ?.takeIf { it.isNotBlank() }
            ?: return null

        val fixedCols = itemRenderer.optJSONArray("fixedColumns")
        val durationStr = fixedCols?.optJSONObject(0)
            ?.optJSONObject("musicResponsiveListItemFixedColumnRenderer")
            ?.optJSONObject("text")
            ?.optJSONArray("runs")
            ?.optJSONObject(0)
            ?.optString("text")

        val artists = if (defaultArtistName.isNotBlank()) {
            listOf(SongArtist(name = defaultArtistName, id = defaultArtistId))
        } else emptyList()

        return Song(
            id = "https://music.youtube.com/watch?v=$videoId",
            videoId = videoId,
            title = cleanSongTitle(rawTitle),
            artist = defaultArtistName.ifBlank { "Unknown Artist" },
            thumbnailUrl = albumThumbUrl.ifBlank { extractThumbnailFromRenderer(itemRenderer, videoId) },
            artistId = defaultArtistId,
            durationText = durationStr,
            artists = artists,
            isVideo = false,
        )
    }

    suspend fun fetchPlaylist(
        browseId: String,
        cookies: String?,
        selectedLanguages: Set<String>,
        filterAudio: Boolean = false,
    ): PlaylistDetail? = withContext(fastDispatcher) {
        val cleanId = browseId.removePrefix("VL").trim()
        // 1. Always try YouTube Music WEB_REMIX browse first (essential for MPREb_ albums, OLAK5uy_ albums, and YTM playlists)
        try {
            val webDetail = fetchPlaylistViaWebRemix(browseId, cookies, filterAudio)
            if (webDetail != null && webDetail.songs.isNotEmpty()) {
                return@withContext webDetail
            }
        } catch (e: Exception) {
            Log.w("YouTubeRepo", "fetchPlaylistViaWebRemix fallback for $browseId: ${e.message}")
        }

        // 2. Fallback to NewPipe PlaylistInfo for standard playlist IDs
        try {
            if (!cleanId.startsWith("MPREb")) {
                val url = if (cleanId.startsWith("http")) {
                    cleanId.replace("www.youtube.com", "music.youtube.com")
                } else {
                    "https://music.youtube.com/playlist?list=$cleanId"
                }
                val playlistInfo = PlaylistInfo.getInfo(ytService, url)

                val title = cleanSongTitle(playlistInfo.name ?: "")
                val description = cleanDescription(playlistInfo.description?.content ?: playlistInfo.uploaderName ?: "")
                val isAlbum = cleanId.startsWith("OLAK5uy_") || title.contains("Album", ignoreCase = true)
                val isSoundtrack = title.contains("Soundtrack", ignoreCase = true) || description.contains("Soundtrack", ignoreCase = true)
                val headerThumb = getHighResThumbnail(playlistInfo.thumbnails)

                val allSongs = playlistInfo.relatedItems.filterIsInstance<StreamInfoItem>().map {
                    val s = buildSongFromStreamItem(it, isVideoItem = false)
                    if (isAlbum && headerThumb.contains("googleusercontent.com")) {
                        s.copy(thumbnailUrl = headerThumb, isVideo = false)
                    } else s
                }

                if (allSongs.isNotEmpty()) {
                    return@withContext PlaylistDetail(
                        title = title,
                        description = description,
                        thumbnailUrl = headerThumb.ifEmpty { allSongs.firstOrNull()?.thumbnailUrl ?: "" },
                        songs = if (filterAudio) allSongs.filter { isAudioSong(it.title, it.artist) }.ifEmpty { allSongs } else allSongs,
                        browseId = browseId,
                        type = if (isAlbum) "album" else if (isSoundtrack) "soundtrack" else "playlist",
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("YouTubeRepo", "NewPipe fetchPlaylist fallback for $browseId: ${e.message}")
        }
        null
    }

    suspend fun fetchNextSongs(
        videoId: String,
        playlistId: String?,
        cookies: String?,
        continuation: String?,
        filterAudioOnly: Boolean = false,
    ): Pair<List<Song>, String?> = withContext(fastDispatcher) {
        // 1. Try fast WEB_REMIX /next endpoint first (returns 20+ up-next tracks with full singer lists in ~150ms)
        try {
            val payload = JSONObject().apply {
                put("context", buildWebRemixContextJson())
                put("videoId", videoId)
                if (!playlistId.isNullOrBlank()) {
                    put("playlistId", playlistId.removePrefix("VL"))
                } else {
                    put("playlistId", "RDAMVM$videoId")
                }
            }
            val nextJson = postWebRemix("next", payload, cookies)
            val panelContents = nextJson
                ?.optJSONObject("contents")
                ?.optJSONObject("singleColumnMusicWatchNextResultsRenderer")
                ?.optJSONObject("tabbedRenderer")
                ?.optJSONObject("watchNextTabbedResultsRenderer")
                ?.optJSONArray("tabs")
                ?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicQueueRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("playlistPanelRenderer")
                ?.optJSONArray("contents")

            if (panelContents != null && panelContents.length() > 1) {
                val nextSongs = mutableListOf<Song>()
                for (i in 0 until panelContents.length()) {
                    val pv = panelContents.optJSONObject(i)?.optJSONObject("playlistPanelVideoRenderer") ?: continue
                    val itemVid = pv.optString("videoId").trim()
                    if (itemVid.isEmpty() || itemVid == videoId) continue

                    val itemTitle = pv.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text").orEmpty()
                    val bylineRuns = pv.optJSONObject("longBylineText")?.optJSONArray("runs")
                        ?: pv.optJSONObject("shortBylineText")?.optJSONArray("runs")
                    val singers = mutableListOf<SongArtist>()
                    val seen = mutableSetOf<String>()
                    if (bylineRuns != null) {
                        for (rIdx in 0 until bylineRuns.length()) {
                            val r = bylineRuns.optJSONObject(rIdx) ?: continue
                            val txt = r.optString("text").trim()
                            if (txt == "•") break
                            if (txt in listOf(",", "&", "and", "feat.", "ft.")) continue
                            val bId = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                            if (txt.length >= 2 && !isRecordLabelOrChannelName(txt) && seen.add(txt.lowercase())) {
                                singers.add(SongArtist(name = cleanArtistName(txt), id = bId))
                            }
                        }
                    }
                    if (singers.isNotEmpty()) {
                        singerCache[itemVid] = singers
                    }
                    val durationStr = pv.optJSONObject("lengthText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text")
                    val thumbUrl = extractThumbnailFromRenderer(pv, itemVid)
                    val artistStr = singers.joinToString(", ") { it.name }.ifBlank { "Unknown Artist" }

                    val song = Song(
                        id = "https://music.youtube.com/watch?v=$itemVid",
                        videoId = itemVid,
                        title = cleanSongTitle(itemTitle),
                        artist = artistStr,
                        thumbnailUrl = thumbUrl,
                        artistId = singers.firstOrNull()?.id,
                        durationText = durationStr,
                        artists = singers,
                        isVideo = false,
                    )
                    if (!filterAudioOnly || isAudioSong(song.title, song.artist)) {
                        nextSongs.add(song)
                    }
                }
                if (nextSongs.isNotEmpty()) {
                    return@withContext Pair(nextSongs, null)
                }
            }
        } catch (e: Exception) {
            Log.w("YouTubeRepo", "WEB_REMIX next songs fallback: ${e.message}")
        }

        // 2. Fallback to NewPipe
        try {
            val url = if (playlistId != null) {
                "https://music.youtube.com/watch?v=$videoId&list=$playlistId"
            } else {
                "https://music.youtube.com/watch?v=$videoId&list=RD$videoId"
            }
            val streamInfo = StreamInfo.getInfo(ytService, url)
            val songs = streamInfo.relatedItems.filterIsInstance<StreamInfoItem>().map {
                buildSongFromStreamItem(it, isVideoItem = false)
            }.filter { !filterAudioOnly || isAudioSong(it.title, it.artist) }
            Pair(songs, null)
        } catch (e: Exception) {
            Pair(emptyList(), null)
        }
    }

    suspend fun searchSongs(
        query: String,
        cookies: String?,
        filterVideos: Boolean = true,
        filterOnlyVideos: Boolean = false,
        filterOnlyAudio: Boolean = false,
    ): List<Song> =
        searchAll(query, cookies, filterVideos, filterOnlyVideos, filterOnlyAudio).first

    suspend fun searchPlaylists(query: String, cookies: String?): List<PlaylistDetail> =
        searchAll(query, cookies, filters = listOf("music_playlists")).second

    suspend fun searchArtists(query: String, cookies: String?, hl: String = "en"): List<ArtistDetail> =
        searchAll(query, cookies, filters = listOf("music_artists")).third

    suspend fun searchOfficialArtist(artistName: String, cookies: String?): ArtistDetail? = withContext(fastDispatcher) {
        try {
            val webArtists = searchArtists(artistName, cookies)
            val firstArtist = webArtists.firstOrNull()
            if (firstArtist != null) {
                return@withContext fetchArtist(firstArtist.browseId, cookies)
            }
            val searchInfo = SearchInfo.getInfo(ytService, ytService.searchQHFactory.fromQuery(artistName, listOf("music_artists"), ""))
            val artistItem = searchInfo.relatedItems.filterIsInstance<ChannelInfoItem>().firstOrNull() ?: return@withContext null
            val channelId = extractChannelId(artistItem.url) ?: artistItem.url.substringAfterLast("/")
            fetchArtist(channelId, cookies)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Parses a `musicTwoRowItemRenderer` card from YouTube Music `FEmusic_home` carousels
     * (Songs, Videos, Albums, Mixes/Playlists, and Artists).
     */
    private fun parseTwoRowHomeItem(twoRow: JSONObject, shelfTitle: String): Any? {
        val titleRuns = twoRow.optJSONObject("title")?.optJSONArray("runs")
        val rawTitle = titleRuns?.optJSONObject(0)?.optString("text")?.trim().orEmpty()
        if (rawTitle.isEmpty()) return null

        val subtitleRuns = twoRow.optJSONObject("subtitle")?.optJSONArray("runs")
        val subtitleText = buildString {
            if (subtitleRuns != null) {
                for (i in 0 until subtitleRuns.length()) {
                    append(subtitleRuns.optJSONObject(i)?.optString("text").orEmpty())
                }
            }
        }.trim()

        val navEndpoint = twoRow.optJSONObject("navigationEndpoint")
        val browseEndpoint = navEndpoint?.optJSONObject("browseEndpoint")
        val watchEndpoint = navEndpoint?.optJSONObject("watchEndpoint")
            ?: twoRow.optJSONObject("thumbnailOverlay")
                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")
                ?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")
        val watchPlaylistEndpoint = navEndpoint?.optJSONObject("watchPlaylistEndpoint")

        val browseId = browseEndpoint?.optString("browseId")?.takeIf { it.isNotBlank() }
        val videoId = watchEndpoint?.optString("videoId")?.takeIf { it.isNotBlank() }
        val playlistId = watchPlaylistEndpoint?.optString("playlistId")?.takeIf { it.isNotBlank() }
            ?: watchEndpoint?.optString("playlistId")?.takeIf { it.isNotBlank() }

        val pageType = browseEndpoint
            ?.optJSONObject("browseEndpointContextSupportedConfigs")
            ?.optJSONObject("browseEndpointContextMusicConfig")
            ?.optString("pageType")
            .orEmpty()
        val musicVideoType = watchEndpoint
            ?.optJSONObject("watchEndpointMusicSupportedConfigs")
            ?.optJSONObject("watchEndpointMusicConfig")
            ?.optString("musicVideoType")
            .orEmpty()

        val rawThumb = extractThumbnailFromRenderer(twoRow, videoId)
        val aspectRatio = twoRow.optString("aspectRatio").uppercase()
        val isWideVideo = aspectRatio.contains("16_9") || musicVideoType.contains("OMV") || musicVideoType.contains("UGC") || shelfTitle.contains("video", ignoreCase = true)

        if (!videoId.isNullOrBlank()) {
            val singers = mutableListOf<SongArtist>()
            if (subtitleRuns != null) {
                for (i in 0 until subtitleRuns.length()) {
                    val r = subtitleRuns.optJSONObject(i) ?: continue
                    val txt = r.optString("text").trim()
                    if (txt in listOf("•", ",", "&", "Song", "Video")) continue
                    if (Regex("^[\\d.,]+[KMB]?\\s*views$", RegexOption.IGNORE_CASE).matches(txt)) continue
                    val bId = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                    if (txt.length >= 2 && !isRecordLabelOrChannelName(txt)) {
                        singers.add(SongArtist(name = cleanArtistName(txt), id = bId))
                    }
                }
            }
            val artistStr = singers.joinToString(", ") { it.name }.ifBlank {
                subtitleText.replace(Regex("(?i)^(Song|Video)\\s*•\\s*"), "").substringBefore("•").trim().ifBlank { "YouTube Music" }
            }
            return Song(
                id = "https://music.youtube.com/watch?v=$videoId",
                videoId = videoId,
                title = cleanSongTitle(rawTitle),
                artist = artistStr,
                thumbnailUrl = rawThumb,
                artistId = singers.firstOrNull()?.id,
                artists = singers,
                isVideo = isWideVideo,
            )
        }

        val effectiveBrowseId = browseId ?: playlistId ?: return null
        val type = when {
            pageType.contains("ARTIST") || effectiveBrowseId.startsWith("UC") -> "artist"
            pageType.contains("ALBUM") || effectiveBrowseId.startsWith("MPREb") || effectiveBrowseId.startsWith("OLAK5uy_") -> "album"
            else -> "playlist"
        }

        return mapOf(
            "title" to cleanSongTitle(rawTitle),
            "thumbnail" to rawThumb,
            "browseId" to effectiveBrowseId,
            "type" to type,
            "author" to subtitleText,
            "subtitle" to subtitleText,
        )
    }

    /**
     * Scrapes YouTube Music `FEmusic_home` (plus continuation tokens) using the user's
     * logged-in Connect cookies (`SAPISIDHASH` auth) when connected, or non-logged-in visitor
     * metadata when not connected — matching SimpMusic's exact `HomePage` scraping pipeline.
     */
    private suspend fun scrapeFEmusicHome(cookies: String?): HomeResponse? {
        try {
            val payload = JSONObject().apply {
                put("context", buildWebRemixContextJson())
                put("browseId", "FEmusic_home")
            }
            val firstRoot = postWebRemix("browse", payload, cookies) ?: return null

            val quickPicks = mutableListOf<Song>()
            val trending = mutableListOf<Song>()
            val albums = mutableListOf<Map<String, String>>()
            val shelves = mutableListOf<HomeShelf>()

            fun processSectionList(sectionListRenderer: JSONObject?) {
                val contents = sectionListRenderer?.optJSONArray("contents") ?: return
                for (i in 0 until contents.length()) {
                    val sec = contents.optJSONObject(i) ?: continue
                    val carousel = sec.optJSONObject("musicCarouselShelfRenderer")
                    val musicShelf = sec.optJSONObject("musicShelfRenderer")

                    if (carousel != null) {
                        val shelfTitle = carousel.optJSONObject("header")
                            ?.optJSONObject("musicCarouselShelfBasicHeaderRenderer")
                            ?.optJSONObject("title")
                            ?.optJSONArray("runs")
                            ?.optJSONObject(0)
                            ?.optString("text")
                            ?.trim()
                            .orEmpty()
                        val itemsArr = carousel.optJSONArray("contents") ?: continue
                        val shelfSongs = mutableListOf<Song>()
                        val shelfCards = mutableListOf<Map<String, String>>()

                        for (j in 0 until itemsArr.length()) {
                            val itemObj = itemsArr.optJSONObject(j) ?: continue
                            val respItem = itemObj.optJSONObject("musicResponsiveListItemRenderer")
                            val twoRowItem = itemObj.optJSONObject("musicTwoRowItemRenderer")

                            if (respItem != null) {
                                parseResponsiveListItem(respItem, shelfTitle)?.song?.let { shelfSongs.add(it) }
                            } else if (twoRowItem != null) {
                                when (val parsed = parseTwoRowHomeItem(twoRowItem, shelfTitle)) {
                                    is Song -> shelfSongs.add(parsed)
                                    is Map<*, *> -> {
                                        @Suppress("UNCHECKED_CAST")
                                        val card = parsed as Map<String, String>
                                        if (card["type"] == "album" && albums.none { it["browseId"] == card["browseId"] }) {
                                            albums.add(card)
                                        }
                                        shelfCards.add(card)
                                    }
                                }
                            }
                        }

                        val titleLower = shelfTitle.lowercase()
                        when {
                            titleLower.contains("quick pick") || titleLower.contains("listen again") || titleLower.contains("speed dial") -> {
                                shelfSongs.forEach { s ->
                                    if (quickPicks.none { it.videoId == s.videoId }) quickPicks.add(s)
                                }
                                if (shelfCards.isNotEmpty()) {
                                    shelves.add(HomeShelf(shelfTitle.ifBlank { "Listen again" }, shelfCards, "playlists"))
                                }
                            }
                            titleLower.contains("trending") || titleLower.contains("chart") -> {
                                shelfSongs.forEach { s ->
                                    if (trending.none { it.videoId == s.videoId }) trending.add(s)
                                }
                                if (shelfCards.isNotEmpty()) {
                                    shelves.add(HomeShelf(shelfTitle.ifBlank { "Charts" }, shelfCards, "playlists"))
                                }
                            }
                            shelfSongs.isNotEmpty() -> {
                                val isVidShelf = titleLower.contains("video") || shelfSongs.count { it.isVideo } > shelfSongs.size / 2
                                shelves.add(
                                    HomeShelf(
                                        title = shelfTitle.ifBlank { "Recommended for you" },
                                        items = shelfSongs,
                                        type = if (isVidShelf) "videos" else "songs",
                                    )
                                )
                            }
                            shelfCards.isNotEmpty() -> {
                                shelves.add(
                                    HomeShelf(
                                        title = shelfTitle.ifBlank { "Featured Mixes" },
                                        items = shelfCards,
                                        type = if (shelfCards.all { it["type"] == "artist" }) "artists" else "playlists",
                                    )
                                )
                            }
                        }
                    } else if (musicShelf != null) {
                        val shelfTitle = musicShelf.optJSONObject("title")
                            ?.optJSONArray("runs")
                            ?.optJSONObject(0)
                            ?.optString("text")
                            ?.trim()
                            .orEmpty()
                        val itemsArr = musicShelf.optJSONArray("contents") ?: continue
                        val shelfSongs = mutableListOf<Song>()
                        for (j in 0 until itemsArr.length()) {
                            val respItem = itemsArr.optJSONObject(j)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                            parseResponsiveListItem(respItem, shelfTitle)?.song?.let { shelfSongs.add(it) }
                        }
                        if (shelfSongs.isNotEmpty()) {
                            if (quickPicks.isEmpty()) {
                                quickPicks.addAll(shelfSongs.take(16))
                            } else {
                                shelves.add(HomeShelf(shelfTitle.ifBlank { "Top Picks" }, shelfSongs, "songs"))
                            }
                        }
                    }
                }
            }

            val firstSectionList = firstRoot.optJSONObject("contents")
                ?.optJSONObject("singleColumnBrowseResultsRenderer")
                ?.optJSONArray("tabs")
                ?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")

            processSectionList(firstSectionList)

            // Follow up to 2 continuation tokens from FEmusic_home just like SimpMusic HomeViewModel
            var nextContinuation = firstSectionList
                ?.optJSONArray("continuations")
                ?.optJSONObject(0)
                ?.optJSONObject("nextContinuationData")
                ?.optString("continuation")
                ?.takeIf { it.isNotBlank() }

            var contRound = 0
            while (!nextContinuation.isNullOrBlank() && contRound < 2) {
                contRound++
                val contPayload = JSONObject().apply {
                    put("context", buildWebRemixContextJson())
                    put("continuation", nextContinuation)
                }
                val contRoot = postWebRemix("browse?ctoken=$nextContinuation&continuation=$nextContinuation&type=next", contPayload, cookies)
                    ?: break
                val contSec = contRoot.optJSONObject("continuationContents")
                    ?.optJSONObject("sectionListContinuation")
                processSectionList(contSec)
                nextContinuation = contSec
                    ?.optJSONArray("continuations")
                    ?.optJSONObject(0)
                    ?.optJSONObject("nextContinuationData")
                    ?.optString("continuation")
                    ?.takeIf { it.isNotBlank() }
            }

            if (quickPicks.isNotEmpty() || shelves.isNotEmpty() || albums.isNotEmpty()) {
                return HomeResponse(
                    quickPicks = quickPicks,
                    trending = trending,
                    albums = albums,
                    shelves = shelves,
                    continuation = nextContinuation,
                )
            }
        } catch (e: Exception) {
            Log.w("YouTubeRepo", "scrapeFEmusicHome fallback: ${e.message}")
        }
        return null
    }

    suspend fun fetchHome(cookies: String?, selectedLanguages: Set<String>, location: String? = null): HomeResponse = withContext(fastDispatcher) {
        supervisorScope {
            // 1. Scrape YouTube Music FEmusic_home (uses logged-in Connect cookies when available, or non-logged-in YTM feed)
            val scrapedHomeDeferred = async {
                scrapeFEmusicHome(cookies)
            }
            val shelves = mutableListOf<HomeShelf>()

            suspend fun safeSearchSongs(
                q: String,
                filterVideos: Boolean = true,
                filterOnlyVideos: Boolean = false,
                oa: Boolean = false
            ) = try {
                searchSongs(q, cookies, filterVideos, filterOnlyVideos, oa)
            } catch (e: Exception) {
                emptyList<Song>()
            }

            val languageSuffix = selectedLanguages.joinToString(" ")
            val locationSuffix = location ?: ""
            val queryModifier = "$languageSuffix $locationSuffix".trim()

            val trendingTask = async {
                try {
                    val trendingQuery = if (queryModifier.isNotEmpty()) "Top Trending Hit Songs $queryModifier" else "Top Trending Hit Songs"
                    safeSearchSongs(trendingQuery, oa = true)
                } catch (e: Exception) {
                    safeSearchSongs("Top Trending Hit Songs", oa = true)
                }
            }

            val newReleasesTask = async {
                val q = if (queryModifier.isNotEmpty()) "New Released Hit Songs $queryModifier" else "New Released Hit Songs"
                safeSearchSongs(q, oa = true)
            }
            val videoSongsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Official Music Video Songs $queryModifier" else "Official Music Video Songs"
                safeSearchSongs(q, filterVideos = false, filterOnlyVideos = true).map { it.copy(isVideo = true) }
            }

            val playlistsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Featured Hit Playlists $queryModifier" else "Featured Hit Playlists"
                try { searchPlaylists(q, cookies) } catch (e: Exception) { emptyList() }
            }
            val rainTask = async {
                val q = if (queryModifier.isNotEmpty()) "Relaxing Chill Lofi Music $queryModifier" else "Relaxing Chill Lofi Music"
                try { searchPlaylists(q, cookies) } catch (e: Exception) { emptyList() }
            }
            val communityPlaylistsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Trending Community Music Playlists $queryModifier" else "Trending Community Music Playlists"
                try { searchPlaylists(q, cookies) } catch (e: Exception) { emptyList() }
            }
            val videoChartsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Top Music Video Charts $queryModifier" else "Global Music Video Charts"
                try { searchPlaylists(q, cookies) } catch (e: Exception) { emptyList() }
            }
            val artistsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Popular Music Singers Artists $queryModifier" else "Popular Music Singers Artists"
                try { searchArtists(q, cookies, "en") } catch (e: Exception) { emptyList() }
            }
            val livePerformancesTask = async {
                val q = if (queryModifier.isNotEmpty()) "Official Live Concert Performance $queryModifier" else "Official Live Concert Performance"
                safeSearchSongs(q, filterVideos = false, filterOnlyVideos = true).map { it.copy(isVideo = true) }
            }
            val albumsTask = async {
                val q = if (queryModifier.isNotEmpty()) "Popular Music Albums & Soundtracks $queryModifier" else "Popular Music Albums & Soundtracks"
                try {
                    val searchResult = searchAll(q, cookies, filters = listOf("music_albums"))
                    searchResult.second.map { it.copy(title = cleanSongTitle(it.title), type = "album") }
                } catch (e: Exception) { emptyList<PlaylistDetail>() }
            }

            val trendingSongs = trendingTask.await()
            val newReleases = newReleasesTask.await()
            val videoSongs = videoSongsTask.await()

            val playlists = playlistsTask.await()
            val rainPlaylists = rainTask.await()
            val communityPlaylists = communityPlaylistsTask.await()
            val videoChartPlaylists = videoChartsTask.await()
            val artists = artistsTask.await()
            val livePerformances = livePerformancesTask.await()
            val albums = albumsTask.await()

            if (playlists.isNotEmpty()) {
                shelves.add(
                    HomeShelf(
                        "Featured Playlists",
                        playlists.map {
                            mapOf("title" to it.title, "thumbnail" to it.thumbnailUrl, "browseId" to it.browseId, "type" to "playlist", "author" to it.description)
                        },
                        "playlists"
                    )
                )
            }

            if (videoSongs.isNotEmpty()) shelves.add(HomeShelf("Official Video Songs", videoSongs, "videos"))

            if (trendingSongs.isNotEmpty()) shelves.add(HomeShelf("Trending Now", trendingSongs, "trending"))

            if (communityPlaylists.isNotEmpty()) {
                shelves.add(
                    HomeShelf(
                        "Trending Community",
                        communityPlaylists.map {
                            mapOf(
                                "title" to it.title,
                                "thumbnail" to it.thumbnailUrl,
                                "browseId" to it.browseId,
                                "type" to "playlist",
                                "author" to it.description,
                            )
                        },
                        "playlists"
                    )
                )
            }

            if (artists.isNotEmpty()) {
                shelves.add(
                    HomeShelf(
                        "Discover Artists",
                        artists.map {
                            mapOf("title" to it.name, "thumbnail" to it.thumbnailUrl, "browseId" to it.browseId, "type" to "artist")
                        },
                        "artists"
                    )
                )
            }

            if (rainPlaylists.isNotEmpty()) {
                shelves.add(
                    HomeShelf(
                        "Rain Therapy",
                        rainPlaylists.map {
                            mapOf("title" to it.title, "thumbnail" to it.thumbnailUrl, "browseId" to it.browseId, "type" to "playlist", "author" to it.description)
                        },
                        "playlists"
                    )
                )
            }

            if (newReleases.isNotEmpty()) shelves.add(HomeShelf("New Releases", newReleases, "songs"))

            if (videoChartPlaylists.isNotEmpty()) {
                shelves.add(
                    HomeShelf(
                        "Video Charts",
                        videoChartPlaylists.map {
                            mapOf("title" to it.title, "thumbnail" to it.thumbnailUrl, "browseId" to it.browseId, "type" to "playlist", "author" to it.description)
                        },
                        "playlists"
                    )
                )
            }

            if (livePerformances.isNotEmpty()) {
                shelves.add(HomeShelf("Live Performances", livePerformances, "videos"))
            }

            val scrapedHome = scrapedHomeDeferred.await()
            val mergedQuickPicks = ((scrapedHome?.quickPicks ?: emptyList()) + trendingSongs + newReleases)
                .distinctBy { it.videoId }
                .take(20)
            val mergedTrending = ((scrapedHome?.trending ?: emptyList()) + trendingSongs)
                .distinctBy { it.videoId }
                .take(16)
            val mappedSearchAlbums = albums.map {
                mapOf(
                    "title" to it.title,
                    "thumbnail" to it.thumbnailUrl,
                    "browseId" to it.browseId,
                    "type" to "album",
                    "author" to it.description,
                )
            }
            val mergedAlbums = ((scrapedHome?.albums ?: emptyList()) + mappedSearchAlbums)
                .distinctBy { it["browseId"] }
            val mergedShelves = ((scrapedHome?.shelves ?: emptyList()) + shelves)
                .distinctBy { it.title.lowercase() }

            HomeResponse(
                quickPicks = mergedQuickPicks,
                trending = mergedTrending,
                albums = mergedAlbums,
                shelves = mergedShelves,
                continuation = scrapedHome?.continuation,
            )
        }
    }

    suspend fun fetchHomeContinuation(continuation: String, cookies: String?, selectedLanguages: Set<String>, location: String? = null): HomeResponse = withContext(fastDispatcher) {
        val languageSuffix = selectedLanguages.joinToString(" ")
        val locationSuffix = location ?: ""
        val queryModifier = "$languageSuffix $locationSuffix".trim()

        val q = if (queryModifier.isNotEmpty()) "Recommended Hit Songs $queryModifier" else "Recommended Hit Songs"
        val songs = try { searchSongs(q, cookies, true, false, true) } catch (e: Exception) { emptyList<Song>() }

        HomeResponse(
            shelves = listOf(HomeShelf("More for You", songs, "songs"))
        )
    }

    suspend fun fetchArtist(artistId: String, cookies: String?): ArtistDetail? = withContext(fastDispatcher) {
        try {
            if (artistId.startsWith("search:")) {
                val queryName = artistId.removePrefix("search:").trim()
                val resolved = searchOfficialArtist(queryName, cookies)
                if (resolved != null) return@withContext resolved
            }

            val url = when {
                artistId.startsWith("http") -> artistId
                artistId.startsWith("UC") -> "https://music.youtube.com/channel/$artistId"
                artistId.startsWith("FMa") -> "https://music.youtube.com/browse/$artistId"
                else -> "https://music.youtube.com/channel/$artistId"
            }

            val channelInfo = try {
                ChannelInfo.getInfo(ytService, url)
            } catch (e: Exception) {
                val searchInfo = SearchInfo.getInfo(ytService, ytService.searchQHFactory.fromQuery(artistId, listOf("music_artists"), ""))
                val firstChannel = searchInfo.relatedItems.filterIsInstance<ChannelInfoItem>().firstOrNull()
                    ?: return@withContext null
                ChannelInfo.getInfo(ytService, firstChannel.url)
            }

            val name = cleanArtistName(channelInfo.name)

            supervisorScope {
                val songsTask = async { searchSongs(name, cookies, filterVideos = true, filterOnlyVideos = false, filterOnlyAudio = true) }
                val albumsTask = async {
                    try {
                        val searchResult = searchAll(name, cookies, filters = listOf("music_albums"))
                        searchResult.second.map { it.copy(title = cleanSongTitle(it.title), type = "album") }
                    } catch (e: Exception) { emptyList<PlaylistDetail>() }
                }
                val videosTask = async {
                    try {
                        searchSongs("$name Official Video", cookies, filterVideos = false, filterOnlyVideos = true, filterOnlyAudio = false)
                            .map { it.copy(isVideo = true) }
                    } catch (e: Exception) { emptyList<Song>() }
                }
                val playlistsTask = async {
                    try {
                        searchPlaylists(name, cookies)
                    } catch (e: Exception) { emptyList<PlaylistDetail>() }
                }
                val relatedArtistsTask = async {
                    try {
                        searchArtists("$name music", cookies).filter { !it.name.equals(name, ignoreCase = true) }
                    } catch (e: Exception) { emptyList<ArtistDetail>() }
                }

                val songs = songsTask.await()
                val albums = albumsTask.await()
                val videos = videosTask.await()
                val playlists = playlistsTask.await()
                val relatedArtists = relatedArtistsTask.await()

                val items = mutableListOf<Map<String, Any>>()
                albums.take(10).forEach {
                    items.add(
                        mapOf(
                            "title" to cleanSongTitle(it.title),
                            "thumbnail" to it.thumbnailUrl,
                            "browseId" to it.browseId,
                            "subtitle" to (it.description.ifBlank { "Album" }),
                            "type" to "album",
                        )
                    )
                }
                videos.take(8).forEach { v ->
                    items.add(
                        mapOf(
                            "title" to v.title,
                            "thumbnail" to v.thumbnailUrl,
                            "videoId" to v.videoId,
                            "artist" to v.displayArtists,
                            "type" to "video",
                        )
                    )
                }
                playlists.take(8).forEach { p ->
                    items.add(
                        mapOf(
                            "title" to p.title,
                            "thumbnail" to p.thumbnailUrl,
                            "browseId" to p.browseId,
                            "subtitle" to (p.description.ifBlank { "Playlist" }),
                            "type" to "playlist",
                        )
                    )
                }
                relatedArtists.take(8).forEach { a ->
                    items.add(
                        mapOf(
                            "title" to a.name,
                            "thumbnail" to a.thumbnailUrl,
                            "browseId" to a.browseId,
                            "type" to "artist",
                        )
                    )
                }

                val descText = channelInfo.description ?: ""
                var subText: String? = null
                var listenerText: String? = null

                try {
                    val sc = channelInfo.subscriberCount
                    if (sc > 0) {
                        subText = when {
                            sc >= 1_000_000 -> "%.1fM".format(sc / 1_000_000.0)
                            sc >= 1_000 -> "%.1fK".format(sc / 1_000.0)
                            else -> "$sc"
                        } + " subscribers"
                    }
                    if (subText == null) {
                        subText = Regex("([\\d.,]+[KMB]?) subscribers", RegexOption.IGNORE_CASE)
                            .find(descText)?.groupValues?.get(1)?.let { "$it subscribers" }
                    }
                    listenerText = Regex("([\\d.,]+[KMB]?) (monthly listeners|listeners)", RegexOption.IGNORE_CASE)
                        .find(descText)?.groupValues?.get(1)?.let { "$it monthly listeners" }
                        ?: Regex("([\\d.,]+[KMB]?) (views|viewers)", RegexOption.IGNORE_CASE)
                            .find(descText)?.groupValues?.get(1)?.let { "$it views" }
                        ?: Regex("([\\d.,]+[KMB]?) monthly", RegexOption.IGNORE_CASE)
                            .find(descText)?.groupValues?.get(1)?.let { "$it monthly listeners" }
                } catch (e: Exception) {
                    Log.e("YouTubeRepo", "Error parsing artist stats", e)
                }

                ArtistDetail(
                    name = name,
                    description = cleanDescription(descText),
                    thumbnailUrl = getHighResThumbnail(channelInfo.avatars).ifEmpty {
                        songs.firstOrNull()?.thumbnailUrl ?: ""
                    },
                    songs = songs.take(20),
                    browseId = extractChannelId(channelInfo.url) ?: artistId,
                    songsBrowseId = extractChannelId(channelInfo.url) ?: artistId,
                    items = items,
                    subscriberCountText = subText,
                    listenerCountText = listenerText,
                )
            }
        } catch (e: Exception) {
            Log.e("YouTubeRepo", "Error fetching artist $artistId", e)
            null
        }
    }

    suspend fun getArtistChannel(artistName: String, cookies: String?): ArtistDetail? = withContext(fastDispatcher) {
        try {
            val webArtists = searchArtists(artistName, cookies)
            if (webArtists.isNotEmpty()) {
                return@withContext fetchArtist(webArtists.first().browseId, cookies)
            }
            val searchInfo = SearchInfo.getInfo(ytService, ytService.searchQHFactory.fromQuery(artistName, listOf("music_artists"), ""))
            val channelItem = searchInfo.relatedItems.filterIsInstance<ChannelInfoItem>().firstOrNull() ?: return@withContext null
            val channelId = extractChannelId(channelItem.url) ?: channelItem.url.substringAfterLast("/")
            fetchArtist(channelId, cookies)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun fetchArtistSongs(browseId: String, params: String?, cookies: String?): List<Song> = withContext(fastDispatcher) {
        try {
            searchSongs(browseId, cookies, true, false, filterOnlyAudio = true)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun fetchTopMusicVideos(cookies: String?): List<Song> = withContext(fastDispatcher) {
        try {
            searchSongs("Official Music Video Hits", cookies, filterVideos = false, filterOnlyVideos = true)
                .map { it.copy(isVideo = true) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun cleanDescription(raw: String): String {
        if (raw.isEmpty()) return ""
        var text = raw
        text = text.replace("\\n", "\n")
            .replace("\\r", "")
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")

        val decoded = try {
            android.text.Html.fromHtml(text, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
        } catch (e: Exception) {
            text
        }

        return decoded
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }
}
