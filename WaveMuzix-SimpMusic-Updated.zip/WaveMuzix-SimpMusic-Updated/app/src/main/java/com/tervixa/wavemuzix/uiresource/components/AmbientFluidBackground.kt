package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AmbientFluidBackground(
    modifier: Modifier = Modifier,
    baseColor: Color,
    accentColor: Color,
    playbackSpeed: Float = 1f
) {
    val performance = LocalPerformanceConfig.current

    // VSYNC-driven precise phase accumulator to ensure zero flickering during active media playback
    val phaseState = remember { mutableFloatStateOf(0f) }

    LaunchedEffect(playbackSpeed) {
        var lastTime = withFrameNanos { it }
        while (true) {
            withFrameNanos { now ->
                val delta = (now - lastTime) / 1_000_000_000f
                lastTime = now
                
                // Desired precise speed of 20.4f
                val motionSpeed = 20.4f
                phaseState.floatValue += delta * motionSpeed * playbackSpeed
            }
        }
    }

    // Smooth color transitions for the background and accents across tracks
    // Using a long duration and FastOutSlowInEasing for a deep liquid morphing feel
    val animatedBase by animateColorAsState(
        targetValue = baseColor,
        animationSpec = tween(3000, easing = FastOutSlowInEasing),
        label = "BaseColor"
    )

    val animatedAccent by animateColorAsState(
        targetValue = accentColor,
        animationSpec = tween(3000, easing = FastOutSlowInEasing),
        label = "AccentColor"
    )

    // Configuration for the fluid fields
    val blobConfigs = remember(performance.isLowSpec) {
        if (performance.isLowSpec) {
            listOf(
                BlobConfig(0.3f, 0.3f, 0.85f, 1.0f, 0.35f),
                BlobConfig(0.7f, 0.7f, 0.95f, 1.2f, 0.30f)
            )
        } else {
            listOf(
                BlobConfig(0.15f, 0.25f, 0.9f, 0.8f, 0.35f),
                BlobConfig(0.85f, 0.20f, 1.1f, 1.1f, 0.28f),
                BlobConfig(0.50f, 0.65f, 1.3f, 0.9f, 0.32f),
                BlobConfig(0.20f, 0.80f, 1.0f, 1.3f, 0.25f),
                BlobConfig(0.80f, 0.85f, 1.2f, 0.7f, 0.22f)
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .blur(if (performance.isLowSpec) 30.dp else 60.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            
            // Draw the base solid atmospheric background
            drawRect(animatedBase)

            val t = phaseState.floatValue

            blobConfigs.forEachIndexed { index, config ->
                // Superposition of prime and non-rational frequencies
                val freqX1 = 0.05f + (index * 0.013f)
                val freqX2 = 0.023f + (index * 0.007f)
                val freqX3 = 0.011f + (index * 0.003f)

                val freqY1 = 0.045f + (index * 0.011f)
                val freqY2 = 0.029f + (index * 0.009f)
                val freqY3 = 0.017f + (index * 0.005f)

                val moveX = sin(t * freqX1 + (index * 2.1f)) * cos(t * freqX2 + 0.5f) + sin(t * freqX3)
                val moveY = cos(t * freqY1 + (index * 3.4f)) * sin(t * freqY2 + 1.2f) + cos(t * freqY3)

                val maxTravelX = width * 0.35f
                val maxTravelY = height * 0.35f

                val fluidCenter = Offset(
                    x = width * config.startX + (moveX * maxTravelX),
                    y = height * config.startY + (moveY * maxTravelY)
                )

                val sizeOscFreq = 0.06f * config.speed + (index * 0.015f)
                val sizeOscillation = sin(t * sizeOscFreq) * cos(t * sizeOscFreq * 0.7f + 1.5f) * 0.22f
                val activeRadius = (width * config.baseRadiusMultiplier * (1f + sizeOscillation))
                    .coerceIn(width * 0.3f, size.maxDimension * 1.5f)

                drawFluidBlob(
                    center = fluidCenter,
                    radius = activeRadius,
                    color = animatedAccent.copy(alpha = config.alpha)
                )
            }
            
            // Vignette overlay
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f)),
                    center = Offset(width / 2, height / 2),
                    radius = size.maxDimension * 1.2f
                )
            )
        }
    }
}

private data class BlobConfig(
    val startX: Float,
    val startY: Float,
    val baseRadiusMultiplier: Float,
    val speed: Float,
    val alpha: Float
)

private fun DrawScope.drawFluidBlob(
    center: Offset,
    radius: Float,
    color: Color
) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                color,
                color.copy(alpha = color.alpha * 0.5f),
                color.copy(alpha = color.alpha * 0.15f),
                Color.Transparent
            ),
            center = center,
            radius = radius
        ),
        center = center,
        radius = radius
    )
}
