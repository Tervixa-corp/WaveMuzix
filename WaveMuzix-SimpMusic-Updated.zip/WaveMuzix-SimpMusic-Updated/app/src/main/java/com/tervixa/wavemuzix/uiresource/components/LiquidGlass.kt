package com.tervixa.wavemuzix.uiresource.components

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.MutatorMutex
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastFirstOrNull
import androidx.compose.ui.util.lerp
import androidx.core.graphics.ColorUtils
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.kashif_e.backdrop.drawBackdrop
import com.kashif_e.backdrop.effects.blur
import com.kashif_e.backdrop.effects.colorControls
import com.kashif_e.backdrop.effects.lens
import com.kashif_e.backdrop.effects.vibrancy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.sign

/**
 * Press/hold state holder for a single liquid-glass surface, ported from SimpMusic.
 */
class GlassInteraction(
    private val animationScope: CoroutineScope,
) {
    private val pressSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 300f, visibilityThreshold = 0.001f)
    private val pressAnimation = Animatable(0f, 0.001f)

    val pressProgress: Float get() = pressAnimation.value

    var touchPosition by mutableStateOf(Offset.Zero)
        private set

    suspend fun detectPress(pointer: PointerInputScope) =
        with(pointer) {
            inspectDragGestures(
                onDragStart = { down ->
                    touchPosition = down.position
                    animationScope.launch { pressAnimation.animateTo(1f, pressSpec) }
                },
                onDragEnd = { animationScope.launch { pressAnimation.animateTo(0f, pressSpec) } },
                onDragCancel = { animationScope.launch { pressAnimation.animateTo(0f, pressSpec) } },
            ) { change, _ ->
                touchPosition = change.position
            }
        }
}

@Composable
fun rememberGlassInteraction(): GlassInteraction {
    val scope = rememberCoroutineScope()
    return remember(scope) { GlassInteraction(scope) }
}

@Composable
fun rememberGlassLuminance(
    layer: GraphicsLayer,
    enabled: Boolean = true,
): State<Float> {
    var rawLuminance by remember { mutableFloatStateOf(0.25f) }
    LaunchedEffect(layer, enabled) {
        if (!enabled) {
            rawLuminance = 0.25f
            return@LaunchedEffect
        }
        while (isActive) {
            try {
                val imageBitmap = layer.toImageBitmap()
                val avg = withContext(Dispatchers.Default) {
                    val androidBmp = imageBitmap.asAndroidBitmap()
                    if (androidBmp.width <= 0 || androidBmp.height <= 0) {
                        0.25f
                    } else {
                        val thumbnail = android.graphics.Bitmap.createScaledBitmap(androidBmp, 5, 5, true)
                        var totalLum = 0.0
                        for (x in 0 until 5) {
                            for (y in 0 until 5) {
                                val pixel = thumbnail.getPixel(x, y)
                                totalLum += ColorUtils.calculateLuminance(pixel)
                            }
                        }
                        if (thumbnail !== androidBmp) {
                            thumbnail.recycle()
                        }
                        (totalLum / 25.0).toFloat()
                    }
                }
                rawLuminance = avg
            } catch (_: Exception) {
            }
            delay(100)
        }
    }
    return animateFloatAsState(
        targetValue = rawLuminance,
        animationSpec = tween(300),
        label = "glassLuminance",
    )
}

/**
 * SimpMusic 3D Liquid Glass surface with multi-stop specular 3D rim border/outline.
 * Supports `brightnessOffset` and `extraBlurDp` so Options Bottom Sheets, Artist Selection,
 * and Video Details can use higher blur and reduced brightness while standard controls keep
 * crisp refraction.
 */
@Composable
fun Modifier.drawInteractiveGlass(
    isDark: Boolean,
    backdrop: LayerBackdrop,
    layer: GraphicsLayer?,
    luminance: () -> Float,
    shape: Shape,
    interaction: GlassInteraction?,
    pressedScale: Float = 1.10f,
    blurScale: Float = 1.35f,
    extraBlurDp: Dp = 0.dp,
    brightnessOffset: Float = 0f,
    refractionHeightFactor: Float = 3.4f,
    refractionAmountFactor: Float = 1.80f,
    minScrim: Float = 0.16f,
    maxScrim: Float = 0.54f,
    accentColor: Color = Color.Transparent,
    outlineAlpha: Float = 0.34f,
    showBorder: Boolean = true,
    borderWidth: Dp = 1.15.dp,
): Modifier {
    val density = LocalDensity.current
    val layoutDirection = LocalLayoutDirection.current

    return this
        .drawBackdrop(
            backdrop = backdrop,
            shape = { shape },
            effects = {
                val l = (luminance() * 2f - 1f).let { sign(it) * it * it }
                val press = interaction?.pressProgress ?: 0f
                val isClearSheet = minScrim <= 0.01f && maxScrim <= 0.01f
                if (!isClearSheet) {
                    vibrancy()
                    colorControls(
                        brightness = (if (isDark) -0.01f else 0.06f) + brightnessOffset,
                        contrast = 1.06f,
                        saturation = 1.25f,
                    )
                }
                val baseBlurPx = if (isClearSheet) {
                    9.dp.toPx()
                } else if (l > 0f) {
                    lerp(4.5f.dp.toPx(), 8.5f.dp.toPx(), l)
                } else {
                    lerp(4.5f.dp.toPx(), 3.5f.dp.toPx(), -l)
                }
                blur(
                    radius = baseBlurPx * blurScale + extraBlurDp.toPx() + 3f.dp.toPx() * press,
                )
                if (isClearSheet) {
                    // Clean small refraction height for options bottom sheet, video details, etc.
                    lens(
                        refractionHeight = 6.dp.toPx(),
                        refractionAmount = 12.dp.toPx(),
                        depthEffect = false,
                    )
                } else {
                    lens(
                        refractionHeight = (size.minDimension / refractionHeightFactor + 2f.dp.toPx() * press) * 0.82f,
                        refractionAmount = size.minDimension / refractionAmountFactor * 0.88f,
                        depthEffect = true,
                    )
                }
            },
            onDrawBackdrop = { drawBackdrop ->
                drawBackdrop()
                if (layer != null && size.width > 0f && size.height > 0f) {
                    layer.record(density, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
                        drawBackdrop()
                    }
                }
            },
            onDrawSurface = {
                val isClearSheet = minScrim <= 0.01f && maxScrim <= 0.01f
                val lum = luminance()
                val lumNorm = ((lum - 0.25f) / 0.5f).coerceIn(0f, 1f)
                val darken = lerp(minScrim, maxScrim, lumNorm).coerceIn(0f, 1f)
                val hasCustomAccentTint = accentColor != Color.Transparent && accentColor != Color.White && accentColor != Color.Black

                if (!isClearSheet) {
                    if (hasCustomAccentTint) {
                        // Medium alpha tint of the screen's dynamic background color
                        val baseDarkAlpha = (darken * 0.45f).coerceIn(0.06f, 0.20f)
                        drawRect(Color(0xFF0A0A0E).copy(alpha = baseDarkAlpha))
                        drawRect(accentColor.copy(alpha = accentColor.alpha.coerceIn(0.24f, 0.36f)))
                    } else if (darken > 0f) {
                        val baseScrimColor = if (isDark) Color(0xFF0A0A0E) else Color.White
                        drawRect(baseScrimColor.copy(alpha = darken))
                    }

                    // Modern subtle top-to-bottom specular sheen (no heavy white tint)
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = if (isDark) 0.04f else 0.08f),
                                Color.Transparent,
                                Color.Black.copy(alpha = if (isDark) 0.06f else 0.02f),
                            ),
                        ),
                    )
                } else {
                    // Pure clear glass: NO tint and NO darkness, only a whisper-light top edge highlight
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.05f),
                                Color.Transparent,
                            ),
                        ),
                    )
                }

                val press = interaction?.pressProgress ?: 0f
                if (press > 0f) {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.24f * press),
                                Color.Transparent,
                            ),
                            center = interaction?.touchPosition ?: Offset(size.width / 2f, size.height / 2f),
                            radius = size.minDimension * 1.25f,
                        ),
                        blendMode = BlendMode.Plus,
                    )
                }

                if (showBorder) {
                    val strokeWidth = borderWidth.toPx()
                    val rimColor = if (isDark) Color.White else Color.Black
                    // Soften border outline to modern subtle alpha (no harsh white border tint)
                    val rimAlphaStart = (outlineAlpha * 0.92f + 0.08f * press).coerceIn(0f, 0.38f)
                    val rimAlphaUpperMid = (outlineAlpha * 0.50f).coerceIn(0f, 0.24f)
                    val rimAlphaMid = (outlineAlpha * 0.18f).coerceIn(0f, 0.15f)
                    val rimAlphaEnd = (outlineAlpha * 0.72f + 0.06f * press).coerceIn(0f, 0.30f)
                    val outline = shape.createOutline(size, layoutDirection, density)

                    drawOutline(
                        outline = outline,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                rimColor.copy(alpha = rimAlphaStart),
                                rimColor.copy(alpha = rimAlphaUpperMid),
                                rimColor.copy(alpha = rimAlphaMid),
                                rimColor.copy(alpha = rimAlphaEnd),
                            ),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height),
                        ),
                        style = Stroke(width = strokeWidth),
                    )
                }
            },
            layerBlock = if (interaction != null) {
                {
                    val scale = lerp(1f, pressedScale, interaction.pressProgress)
                    scaleX = scale
                    scaleY = scale
                }
            } else {
                null
            },
        )
        .then(
            if (interaction != null) {
                Modifier.pointerInput(interaction) { interaction.detectPress(this) }
            } else {
                Modifier
            },
        )
}

@Composable
fun Modifier.stableLiquidGlass(
    layer: GraphicsLayer,
    luminance: Float,
    shape: Shape,
    interaction: GlassInteraction?,
    pressedScale: Float = 1.08f,
    minScrim: Float = 0.16f,
    maxScrim: Float = 0.54f,
    blurScale: Float = 1.35f,
    extraBlurDp: Dp = 0.dp,
    brightnessOffset: Float = 0f,
    accentColor: Color = Color.Black,
    outlineAlpha: Float = 0.34f,
    showBorder: Boolean = true,
    borderWidth: Dp = 1.15.dp,
): Modifier {
    val backdrop = LocalBackdrop.current ?: return this
    val isDarkTheme = LocalIsDarkTheme.current
    val currentLuminance by rememberUpdatedState(luminance)

    return this.drawInteractiveGlass(
        isDark = isDarkTheme,
        backdrop = backdrop,
        layer = layer,
        luminance = { currentLuminance },
        shape = shape,
        interaction = interaction,
        pressedScale = pressedScale,
        blurScale = blurScale,
        extraBlurDp = extraBlurDp,
        brightnessOffset = brightnessOffset,
        minScrim = minScrim,
        maxScrim = maxScrim,
        accentColor = accentColor,
        outlineAlpha = outlineAlpha,
        showBorder = showBorder,
        borderWidth = borderWidth,
    )
}

/**
 * Spring-damped 1-D drag animation ported directly from SimpMusic's `LiquidGlassTabBar.android.kt`.
 */
class DampedDragAnimation(
    private val animationScope: CoroutineScope,
    val initialValue: Float,
    val valueRange: ClosedRange<Float>,
    val visibilityThreshold: Float = 0.001f,
    val initialScale: Float = 1f,
    val pressedScale: Float = 76f / 56f,
    val onDragStarted: DampedDragAnimation.(position: Offset) -> Unit = {},
    val onDragStopped: DampedDragAnimation.() -> Unit = {},
    val onDrag: DampedDragAnimation.(size: IntSize, dragAmount: Offset) -> Unit = { _, _ -> },
) {
    // SimpMusic exact physical spring damping and stiffness
    private val valueAnimationSpec = spring(0.65f, 380f, visibilityThreshold)
    private val velocityAnimationSpec = spring(0.55f, 320f, visibilityThreshold * 10f)
    private val pressProgressAnimationSpec = spring(0.60f, 400f, 0.001f)
    private val scaleXAnimationSpec = spring(0.65f, 380f, 0.001f)
    private val scaleYAnimationSpec = spring(0.65f, 380f, 0.001f)

    private val valueAnimation = Animatable(initialValue, visibilityThreshold)
    private val velocityAnimation = Animatable(0f, 5f)
    private val pressProgressAnimation = Animatable(0f, 0.001f)
    private val scaleXAnimation = Animatable(initialScale, 0.001f)
    private val scaleYAnimation = Animatable(initialScale, 0.001f)

    private val mutatorMutex = MutatorMutex()
    private val velocityTracker = VelocityTracker()

    val value: Float get() = valueAnimation.value
    val targetValue: Float get() = valueAnimation.targetValue
    val pressProgress: Float get() = pressProgressAnimation.value
    val scaleX: Float get() = scaleXAnimation.value
    val scaleY: Float get() = scaleYAnimation.value
    val velocity: Float get() = velocityAnimation.value

    val modifier: Modifier =
        Modifier.pointerInput(Unit) {
            inspectDragGestures(
                onDragStart = { down ->
                    onDragStarted(down.position)
                    press()
                },
                onDragEnd = {
                    onDragStopped()
                    release()
                },
                onDragCancel = {
                    onDragStopped()
                    release()
                },
            ) { _, dragAmount ->
                onDrag(size, dragAmount)
            }
        }

    fun press() {
        velocityTracker.resetTracking()
        animationScope.launch {
            launch { pressProgressAnimation.animateTo(1f, pressProgressAnimationSpec) }
            launch { scaleXAnimation.animateTo(pressedScale, scaleXAnimationSpec) }
            launch { scaleYAnimation.animateTo(pressedScale, scaleYAnimationSpec) }
        }
    }

    fun release() {
        animationScope.launch {
            withFrameNanos {}
            if (value != targetValue) {
                val span = (valueRange.endInclusive - valueRange.start).coerceAtLeast(0.001f)
                val threshold = span * 0.025f
                snapshotFlow { valueAnimation.value }
                    .filter { abs(it - valueAnimation.targetValue) < threshold }
                    .first()
            }
            launch { pressProgressAnimation.animateTo(0f, pressProgressAnimationSpec) }
            launch { scaleXAnimation.animateTo(initialScale, scaleXAnimationSpec) }
            launch { scaleYAnimation.animateTo(initialScale, scaleYAnimationSpec) }
        }
    }

    fun updateValue(value: Float) {
        val target = value.coerceIn(valueRange.start, valueRange.endInclusive)
        animationScope.launch {
            valueAnimation.animateTo(target, valueAnimationSpec) { updateVelocity() }
        }
    }

    fun animateToValue(value: Float) {
        animationScope.launch {
            mutatorMutex.mutate {
                press()
                val target = value.coerceIn(valueRange.start, valueRange.endInclusive)
                launch { valueAnimation.animateTo(target, valueAnimationSpec) }
                if (velocity != 0f) {
                    launch { velocityAnimation.animateTo(0f, velocityAnimationSpec) }
                }
                release()
            }
        }
    }

    private fun updateVelocity() {
        velocityTracker.addPosition(SystemClock.uptimeMillis(), Offset(value, 0f))
        val span = (valueRange.endInclusive - valueRange.start).coerceAtLeast(0.001f)
        val targetVelocity = velocityTracker.calculateVelocity().x / span
        animationScope.launch { velocityAnimation.animateTo(targetVelocity, velocityAnimationSpec) }
    }
}

internal suspend fun PointerInputScope.inspectDragGestures(
    onDragStart: (down: PointerInputChange) -> Unit = {},
    onDragEnd: (change: PointerInputChange) -> Unit = {},
    onDragCancel: () -> Unit = {},
    onDrag: (change: PointerInputChange, dragAmount: Offset) -> Unit,
) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val down = awaitFirstDown(requireUnconsumed = false)
        onDragStart(down)
        onDrag(down, Offset.Zero)
        val upEvent = drag(
            pointerId = down.id,
            onDrag = { onDrag(it, it.positionChange()) },
        )
        if (upEvent == null) {
            onDragCancel()
        } else {
            onDragEnd(upEvent)
        }
    }
}

private suspend fun AwaitPointerEventScope.drag(
    pointerId: PointerId,
    onDrag: (PointerInputChange) -> Unit,
): PointerInputChange? {
    val isPointerUp = currentEvent.changes.fastFirstOrNull { it.id == pointerId }?.pressed != true
    if (isPointerUp) return null
    var pointer = pointerId
    while (true) {
        val change = awaitDragOrUp(pointer) ?: return null
        if (change.isConsumed) return null
        if (change.changedToUpIgnoreConsumed()) return change
        onDrag(change)
        pointer = change.id
    }
}

private suspend fun AwaitPointerEventScope.awaitDragOrUp(pointerId: PointerId): PointerInputChange? {
    var pointer = pointerId
    while (true) {
        val event = awaitPointerEvent()
        val dragEvent = event.changes.fastFirstOrNull { it.id == pointer } ?: return null
        if (dragEvent.changedToUpIgnoreConsumed()) {
            val otherDown = event.changes.fastFirstOrNull { it.pressed }
            if (otherDown == null) return dragEvent else pointer = otherDown.id
        } else {
            if (dragEvent.previousPosition != dragEvent.position) return dragEvent
        }
    }
}

suspend fun GraphicsLayer.calculateAverageLuminance(): Float {
    return try {
        val imageBitmap = this.toImageBitmap()
        withContext(Dispatchers.Default) {
            val bitmap = imageBitmap.asAndroidBitmap()
            val width = bitmap.width
            val height = bitmap.height
            if (width <= 0 || height <= 0) return@withContext 0.25f
            val thumbnail = android.graphics.Bitmap.createScaledBitmap(bitmap, 5, 5, true)
            var totalLuminance = 0.0
            for (x in 0 until 5) {
                for (y in 0 until 5) {
                    val pixel = thumbnail.getPixel(x, y)
                    totalLuminance += ColorUtils.calculateLuminance(pixel)
                }
            }
            if (thumbnail !== bitmap) {
                thumbnail.recycle()
            }
            (totalLuminance / 25.0).toFloat()
        }
    } catch (e: Exception) {
        0.25f
    }
}
