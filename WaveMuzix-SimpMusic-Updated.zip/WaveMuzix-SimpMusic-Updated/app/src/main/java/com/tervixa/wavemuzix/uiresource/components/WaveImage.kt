package com.tervixa.wavemuzix.uiresource.components

import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.tervixa.wavemuzix.R
import java.io.File
import java.util.concurrent.Executors

private val YT_VIDEO_ID_REGEX = Regex("(?:vi|vi_webp)/([a-zA-Z0-9_-]{11})/")
private val RAW_YT_ID_REGEX = Regex("^[a-zA-Z0-9_-]{11}$")
private val GOOGLE_SIZE_PARAM_REGEX = Regex("=w(\\d+)-h(\\d+)")

/**
 * Multi-threaded high-bandwidth thumbnail prefetcher so song/playlist/artist thumbnails
 * warm into memory and disk cache immediately in parallel.
 */
object WaveThumbnailPrefetcher {
    private val executor = Executors.newFixedThreadPool(16) { runnable ->
        Thread(runnable, "WaveThumbPrefetch").apply {
            isDaemon = true
            priority = Thread.MAX_PRIORITY - 1
        }
    }

    fun prefetchThumbnails(context: Context, urls: Collection<String?>) {
        val appCtx = context.applicationContext
        urls.asSequence()
            .filterNotNull()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(48)
            .forEach { rawUrl ->
                executor.execute {
                    try {
                        val (primary, _) = resolveArtworkUrls(rawUrl)
                        if (!primary.isNullOrBlank()) {
                            Glide.with(appCtx)
                                .downloadOnly()
                                .load(primary)
                                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                .priority(Priority.IMMEDIATE)
                                .submit()
                        }
                    } catch (_: Exception) {
                    }
                }
            }
    }
}

/**
 * Detects whether a thumbnail URL is a rectangular (16:9 / landscape video) thumbnail
 * rather than a 1:1 square album/song/artist cover.
 *
 * When `isVideoHint == false` (audio songs / album tracks), YouTube `i.ytimg.com/vi/...`
 * frames often embed the 1:1 square album cover in the center with colored 16:9 sidebars
 * on the left and right. Returning `false` when `isVideoHint == false` ensures audio songs
 * use `ContentScale.Crop` inside 1:1 containers, cropping away the 16:9 sidebars so the
 * square album art fills the thumbnail cleanly.
 */
fun isLandscapeThumbnailUrl(url: String?, isVideoHint: Boolean = true): Boolean {
    if (url.isNullOrBlank()) return false
    if (!isVideoHint) return false
    val clean = url.trim()
    if (clean.contains("i.ytimg.com/vi") ||
        clean.contains("img.youtube.com/vi") ||
        clean.contains("hqdefault") ||
        clean.contains("mqdefault") ||
        clean.contains("sddefault") ||
        clean.contains("maxresdefault") ||
        clean.contains("hq720")
    ) {
        return true
    }
    val sizeMatch = GOOGLE_SIZE_PARAM_REGEX.find(clean)
    if (sizeMatch != null) {
        val w = sizeMatch.groupValues[1].toIntOrNull() ?: 0
        val h = sizeMatch.groupValues[2].toIntOrNull() ?: 0
        if (w > 0 && h > 0 && w > (h * 1.15f)) {
            return true
        }
    }
    return false
}

/**
 * Resolves the appropriate `ContentScale` inside a thumbnail box:
 * - For audio songs / albums (`isVideoHint == false`), ALWAYS use `ContentScale.Crop` so
 *   that 16:9 pillarboxed thumbnails (`i.ytimg.com/vi/...` with accent sidebars on left/right)
 *   have their sidebars cropped off and fill the 1:1 box cleanly.
 * - For explicit video items (`isVideoHint == true`), use `ContentScale.Crop` to fill the
 *   16:9 video card cleanly.
 */
fun resolveOneToOneThumbnailScale(url: String?, isVideoHint: Boolean = false): ContentScale {
    return ContentScale.Crop
}

/**
 * Normalizes and upgrades artwork URLs so thumbnails never fail when `maxresdefault.jpg`
 * returns HTTP 404 or when a raw 11-character YouTube videoId is passed.
 */
fun resolveArtworkUrls(rawUrl: String?, fallbackVideoId: String? = null): Pair<String?, String?> {
    if (rawUrl.isNullOrBlank()) {
        val cleanVid = fallbackVideoId?.trim()?.takeIf { RAW_YT_ID_REGEX.matches(it) }
        return if (cleanVid != null) {
            "https://i.ytimg.com/vi/$cleanVid/hqdefault.jpg" to "https://i.ytimg.com/vi/$cleanVid/mqdefault.jpg"
        } else {
            null to null
        }
    }
    val trimmed = rawUrl.trim().let {
        when {
            it.startsWith("//") -> "https:$it"
            it.startsWith("http://") -> "https://" + it.removePrefix("http://")
            else -> it
        }
    }

    if (RAW_YT_ID_REGEX.matches(trimmed)) {
        return "https://i.ytimg.com/vi/$trimmed/hqdefault.jpg" to "https://i.ytimg.com/vi/$trimmed/mqdefault.jpg"
    }

    val ytMatch = YT_VIDEO_ID_REGEX.find(trimmed)
    if (ytMatch != null) {
        val vid = ytMatch.groupValues[1]
        val hq = "https://i.ytimg.com/vi/$vid/hqdefault.jpg"
        val mq = "https://i.ytimg.com/vi/$vid/mqdefault.jpg"
        return if (trimmed.contains("maxresdefault") || trimmed.contains("sddefault") || trimmed.contains("vi_webp")) {
            hq to mq
        } else {
            trimmed to hq
        }
    }

    if (trimmed.contains("googleusercontent.com") || trimmed.contains("ggpht.com")) {
        val sizeMatch = GOOGLE_SIZE_PARAM_REGEX.find(trimmed)
        val isExplicitWide = if (sizeMatch != null) {
            val w = sizeMatch.groupValues[1].toIntOrNull() ?: 0
            val h = sizeMatch.groupValues[2].toIntOrNull() ?: 0
            w > (h * 1.15f)
        } else {
            false
        }
        val upgraded = if (isExplicitWide) {
            trimmed
        } else {
            trimmed
                .replace(Regex("=w\\d+-h\\d+[^&?]*"), "=w544-h544-l90-rj")
                .replace(Regex("=s\\d+[^&?]*"), "=s544")
        }
        return upgraded to trimmed
    }

    val fallbackHq = fallbackVideoId?.trim()?.takeIf { RAW_YT_ID_REGEX.matches(it) }?.let {
        "https://i.ytimg.com/vi/$it/hqdefault.jpg"
    }
    return trimmed to fallbackHq
}

/**
 * Unified artwork & thumbnail loader for WaveMuzix:
 * - Crops 16:9 sidebars on audio song / album track thumbnails (`ContentScale.Crop`) so
 *   square song thumbnails never display 16:9 colored sidebars.
 * - Uses high-priority multi-threaded Glide loading with a smooth crossfade transition.
 */
@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun WaveArtworkImage(
    url: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    videoId: String? = null,
    isVideo: Boolean = false,
    shape: Shape = RectangleShape,
    contentScale: ContentScale? = null,
    alignment: Alignment = Alignment.Center,
) {
    val context = LocalContext.current
    val holderRes = if (isVideo) R.drawable.holder_video else R.drawable.holder_square

    val (resolvedModel, fallbackUrl) = when (url) {
        null -> resolveArtworkUrls(null, videoId)
        is String -> {
            val clean = url.trim()
            if (clean.isEmpty()) {
                resolveArtworkUrls(null, videoId)
            } else if (clean.startsWith("/") || clean.startsWith("file://")) {
                val path = clean.removePrefix("file://")
                val f = File(path)
                if (f.exists()) f to null else resolveArtworkUrls(clean, videoId)
            } else {
                resolveArtworkUrls(clean, videoId)
            }
        }
        is File -> if (url.exists()) url to null else resolveArtworkUrls(null, videoId)
        else -> url to null
    }

    val urlString = (resolvedModel as? String) ?: (url as? String)
    val effectiveContentScale = contentScale ?: resolveOneToOneThumbnailScale(urlString, isVideo)

    val clippedModifier = if (shape === RectangleShape) modifier else modifier.clip(shape)
    val isEmptyModel = resolvedModel == null || (resolvedModel is String && resolvedModel.isBlank())

    var isImageLoaded by remember(resolvedModel) { mutableStateOf(false) }
    val loadedAlpha by animateFloatAsState(
        targetValue = if (isImageLoaded) 1f else 0f,
        animationSpec = tween(durationMillis = 260),
        label = "ThumbnailFadeIn",
    )
    val placeholderAlpha by animateFloatAsState(
        targetValue = if (isImageLoaded) 0f else 1f,
        animationSpec = tween(durationMillis = 260),
        label = "PlaceholderFadeOut",
    )

    if (isEmptyModel) {
        Image(
            painter = painterResource(holderRes),
            contentDescription = contentDescription,
            modifier = clippedModifier,
            contentScale = ContentScale.Crop,
            alignment = alignment,
        )
    } else {
        Box(
            modifier = clippedModifier.background(Color(0xFF121217)),
            contentAlignment = Alignment.Center,
        ) {
            if (placeholderAlpha > 0.01f) {
                Image(
                    painter = painterResource(holderRes),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = placeholderAlpha },
                    contentScale = ContentScale.Crop,
                    alignment = alignment,
                )
            }
            GlideImage(
                model = resolvedModel,
                contentDescription = contentDescription,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = loadedAlpha },
                contentScale = effectiveContentScale,
                alignment = alignment,
            ) { requestBuilder ->
                var builder = requestBuilder
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .priority(Priority.IMMEDIATE)
                    .timeout(6000)
                if (isVideo) {
                    builder = builder.dontTransform()
                } else {
                    builder = builder.centerCrop()
                }
                    .addListener(object : RequestListener<android.graphics.drawable.Drawable> {
                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<android.graphics.drawable.Drawable>,
                            isFirstResource: Boolean,
                        ): Boolean {
                            return false
                        }

                        override fun onResourceReady(
                            resource: android.graphics.drawable.Drawable,
                            model: Any,
                            target: Target<android.graphics.drawable.Drawable>?,
                            dataSource: DataSource,
                            isFirstResource: Boolean,
                        ): Boolean {
                            isImageLoaded = true
                            return false
                        }
                    })
                if (!fallbackUrl.isNullOrBlank() && fallbackUrl != resolvedModel) {
                    builder = builder.error(
                        Glide.with(context.applicationContext)
                            .load(fallbackUrl)
                            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                            .priority(Priority.IMMEDIATE)
                            .addListener(object : RequestListener<android.graphics.drawable.Drawable> {
                                override fun onLoadFailed(
                                    e: GlideException?,
                                    model: Any?,
                                    target: Target<android.graphics.drawable.Drawable>,
                                    isFirstResource: Boolean,
                                ): Boolean = false

                                override fun onResourceReady(
                                    resource: android.graphics.drawable.Drawable,
                                    model: Any,
                                    target: Target<android.graphics.drawable.Drawable>?,
                                    dataSource: DataSource,
                                    isFirstResource: Boolean,
                                ): Boolean {
                                    isImageLoaded = true
                                    return false
                                }
                            })
                    )
                }
                builder
            }
        }
    }
}

@Composable
fun rememberWavePlaceholderPainter(isVideo: Boolean = false): Painter {
    return painterResource(if (isVideo) R.drawable.holder_video else R.drawable.holder_square)
}
