package com.tervixa.wavemuzix.data

import android.content.Context
import android.util.Log
import com.tervixa.wavemuzix.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.security.MessageDigest
import java.util.TreeMap
import java.util.concurrent.TimeUnit

/**
 * Ported from SimpMusic's `Lastfm.kt` & `LastfmClient.kt`:
 * Handles all 3 Last.fm capabilities used in SimpMusic:
 * 1) `track.updateNowPlaying` — Broadcasts live "Scrobbling now" status on Last.fm when a song starts.
 * 2) `track.scrobble` — Records completed track plays (past 50% or 30s) into the user's Last.fm library & charts.
 * 3) `track.love` / `track.unlove` — Syncs liked/favorited songs to Last.fm Loved Tracks.
 */
object LastFmManager {
    private const val TAG = "LastFmManager"
    private const val API_ROOT = "https://ws.audioscrobbler.com/2.0/"
    // Default public Last.fm API key & secret (SimpMusic-compatible)
    const val DEFAULT_API_KEY = "43693facbb24d1ac893a7d33846b15cc"
    private const val DEFAULT_API_SECRET = "90d0a0c42a5969b22f46a5202b32c451"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private fun md5(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun generateApiSignature(params: Map<String, String>, secret: String = DEFAULT_API_SECRET): String {
        val sorted = TreeMap<String, String>(params)
        val sb = StringBuilder()
        for ((k, v) in sorted) {
            if (k != "format" && k != "callback") {
                sb.append(k).append(v)
            }
        }
        sb.append(secret)
        return md5(sb.toString())
    }

    suspend fun requestAuthToken(): String? = withContext(Dispatchers.IO) {
        try {
            val params = mapOf(
                "method" to "auth.getToken",
                "api_key" to DEFAULT_API_KEY,
            )
            val sig = generateApiSignature(params)
            val url = "$API_ROOT?method=auth.getToken&api_key=$DEFAULT_API_KEY&api_sig=$sig&format=json"
            val req = Request.Builder().url(url).get().build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val json = JSONObject(resp.body?.string().orEmpty())
                return@withContext json.optString("token").takeIf { it.isNotBlank() }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Last.fm requestAuthToken failed: ${e.message}")
        }
        null
    }

    suspend fun fetchWebSession(token: String): Pair<String, String>? = withContext(Dispatchers.IO) {
        try {
            val params = mapOf(
                "method" to "auth.getSession",
                "api_key" to DEFAULT_API_KEY,
                "token" to token.trim(),
            )
            val sig = generateApiSignature(params)
            val url = "$API_ROOT?method=auth.getSession&api_key=$DEFAULT_API_KEY&token=${token.trim()}&api_sig=$sig&format=json"
            val req = Request.Builder().url(url).get().build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val json = JSONObject(resp.body?.string().orEmpty())
                val sessionObj = json.optJSONObject("session") ?: return@use
                val name = sessionObj.optString("name")
                val key = sessionObj.optString("key")
                if (name.isNotBlank() && key.isNotBlank()) {
                    return@withContext name to key
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Last.fm fetchWebSession failed: ${e.message}")
        }
        null
    }

    fun updateNowPlaying(context: Context, song: Song, durationSeconds: Long) {
        val settings = SettingsManager(context)
        if (!settings.isLastFmConnected) return
        val sessionKey = settings.lastFmSessionKey
        if (sessionKey.isBlank()) return

        scope.launch {
            try {
                val artist = song.displayArtists.ifBlank { song.artist }.split(",").firstOrNull()?.trim().orEmpty()
                val params = mutableMapOf(
                    "method" to "track.updateNowPlaying",
                    "api_key" to DEFAULT_API_KEY,
                    "sk" to sessionKey,
                    "artist" to artist,
                    "track" to song.title,
                )
                if (durationSeconds > 0) {
                    params["duration"] = durationSeconds.toString()
                }
                val sig = generateApiSignature(params)
                val bodyBuilder = FormBody.Builder()
                params.forEach { (k, v) -> bodyBuilder.add(k, v) }
                bodyBuilder.add("api_sig", sig)
                bodyBuilder.add("format", "json")

                val req = Request.Builder().url(API_ROOT).post(bodyBuilder.build()).build()
                httpClient.newCall(req).execute().close()
            } catch (e: Exception) {
                Log.w(TAG, "Last.fm updateNowPlaying skipped: ${e.message}")
            }
        }
    }

    fun scrobbleTrack(context: Context, song: Song, timestampSeconds: Long = System.currentTimeMillis() / 1000L) {
        val settings = SettingsManager(context)
        if (!settings.isLastFmConnected) return
        val sessionKey = settings.lastFmSessionKey
        if (sessionKey.isBlank()) return

        scope.launch {
            try {
                val artist = song.displayArtists.ifBlank { song.artist }.split(",").firstOrNull()?.trim().orEmpty()
                val params = mapOf(
                    "method" to "track.scrobble",
                    "api_key" to DEFAULT_API_KEY,
                    "sk" to sessionKey,
                    "artist" to artist,
                    "track" to song.title,
                    "timestamp" to timestampSeconds.toString(),
                )
                val sig = generateApiSignature(params)
                val bodyBuilder = FormBody.Builder()
                params.forEach { (k, v) -> bodyBuilder.add(k, v) }
                bodyBuilder.add("api_sig", sig)
                bodyBuilder.add("format", "json")

                val req = Request.Builder().url(API_ROOT).post(bodyBuilder.build()).build()
                httpClient.newCall(req).execute().close()
            } catch (e: Exception) {
                Log.w(TAG, "Last.fm scrobbleTrack skipped: ${e.message}")
            }
        }
    }

    fun setTrackLoved(context: Context, song: Song, loved: Boolean) {
        val settings = SettingsManager(context)
        if (!settings.isLastFmConnected) return
        val sessionKey = settings.lastFmSessionKey
        if (sessionKey.isBlank()) return

        scope.launch {
            try {
                val artist = song.displayArtists.ifBlank { song.artist }.split(",").firstOrNull()?.trim().orEmpty()
                val params = mapOf(
                    "method" to if (loved) "track.love" else "track.unlove",
                    "api_key" to DEFAULT_API_KEY,
                    "sk" to sessionKey,
                    "artist" to artist,
                    "track" to song.title,
                )
                val sig = generateApiSignature(params)
                val bodyBuilder = FormBody.Builder()
                params.forEach { (k, v) -> bodyBuilder.add(k, v) }
                bodyBuilder.add("api_sig", sig)
                bodyBuilder.add("format", "json")

                val req = Request.Builder().url(API_ROOT).post(bodyBuilder.build()).build()
                httpClient.newCall(req).execute().close()
            } catch (e: Exception) {
                Log.w(TAG, "Last.fm setTrackLoved skipped: ${e.message}")
            }
        }
    }
}
