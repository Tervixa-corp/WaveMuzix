package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur

sealed interface TopBarType {
    object Home : TopBarType
    object Library : TopBarType
    object Notifications : TopBarType
    data class Search(
        val query: String,
        val onQueryChange: (String) -> Unit,
        val onSearchAction: () -> Unit,
    ) : TopBarType
    data class SubScreen(val title: String) : TopBarType
    data class Queue(
        val currentSong: com.tervixa.wavemuzix.model.Song?,
        val highResThumbnailUrl: String? = null,
    ) : TopBarType
}

/**
 * UniversalTopBar with SimpMusic's Haze 2.0 frosted blur (`barBlurStyle` with `backgroundColor(tint)`)
 * and collapsing top-row behavior:
 * - All Search and Back buttons use `GlassIconButton` so they are controlled by the "Enable Liquid Glass"
 *   setting (switching to `QueueSolidGrey` `Color(0xFF1C1C1E)` when Liquid Glass is disabled).
 * - Adds comfortable spacing between action buttons and top bar elements.
 */
@Composable
fun UniversalTopBar(
    type: TopBarType,
    modifier: Modifier = Modifier,
    hazeState: HazeState? = LocalHazeState.current,
    isCollapsed: Boolean = false,
    isLiquidGlass: Boolean = true,
    tintColor: Color = MaterialTheme.colorScheme.background,
    tintAlpha: Float = 0.58f,
    userAvatarUrl: String? = null,
    userName: String? = null,
    onAvatarClick: () -> Unit = {},
    onNotificationClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {},
    onSearchClick: () -> Unit = {},
    onBackClick: () -> Unit = {},
    bottomContent: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val isDarkTheme = LocalIsDarkTheme.current
    val liquidEnabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val resolvedTint = if (tintColor == Color.Unspecified || tintColor == Color.Transparent) {
        if (isDarkTheme) Color(0xFF0E0E12) else Color.White
    } else {
        tintColor
    }

    val baseModifier = if (hazeState != null && liquidEnabled) {
        modifier.hazeBlur(
            input = HazeInput.Sources(hazeState),
            style = barBlurStyle(
                tint = resolvedTint,
                tintAlpha = tintAlpha,
                blurRadius = 32.dp,
            ),
        )
    } else {
        modifier.background(resolvedTint.copy(alpha = 0.94f))
    }

    val hasBottomTier = (type is TopBarType.Queue && type.currentSong != null) || bottomContent != null
    val showTopRow = if (hasBottomTier) !isCollapsed else true

    Box(
        modifier = baseModifier.fillMaxWidth(),
    ) {
        CompositionLocalProvider(LocalHazeState provides hazeState) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding(),
            ) {
                AnimatedVisibility(
                    visible = showTopRow,
                    enter = expandVertically(expandFrom = Alignment.Top, animationSpec = tween(250)) +
                        slideInVertically(initialOffsetY = { -it }, animationSpec = tween(250)) +
                        fadeIn(animationSpec = tween(220)),
                    exit = shrinkVertically(shrinkTowards = Alignment.Top, animationSpec = tween(250)) +
                        slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(250)) +
                        fadeOut(animationSpec = tween(180)),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .height(52.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        when (type) {
                            is TopBarType.Home -> {
                                WaveUserAvatar(
                                    url = userAvatarUrl,
                                    name = userName,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .clickable { onAvatarClick() },
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Wave Muzix",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 21.sp,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                )
                                 IconButton(
                                     onClick = onNotificationClick,
                                     modifier = Modifier.size(40.dp)
                                 ) {
                                     Icon(
                                         imageVector = WaveIcons.Notifications,
                                         contentDescription = "Notifications",
                                         tint = MaterialTheme.colorScheme.onSurface,
                                         modifier = Modifier.size(24.dp)
                                     )
                                 }
                                 Spacer(modifier = Modifier.width(6.dp))
                                 IconButton(
                                     onClick = onSettingsClick,
                                     modifier = Modifier.size(40.dp)
                                 ) {
                                     Icon(
                                         imageVector = WaveIcons.Settings,
                                         contentDescription = "Settings",
                                         tint = MaterialTheme.colorScheme.onSurface,
                                         modifier = Modifier.size(24.dp)
                                     )
                                 }
                            }
                            is TopBarType.Library -> {
                                WaveUserAvatar(
                                    url = userAvatarUrl,
                                    name = userName,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .clickable { onAvatarClick() },
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Library",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                )
                                GlassIconButton(
                                    icon = WaveIcons.Search,
                                    onClick = onSearchClick,
                                    isLiquidGlass = isLiquidGlass,
                                    contentDescription = "Search",
                                    iconSize = 20.dp,
                                    containerSize = 40.dp,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                            is TopBarType.Notifications -> {
                                GlassIconButton(
                                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                    onClick = onBackClick,
                                    isLiquidGlass = isLiquidGlass,
                                    contentDescription = "Back",
                                    iconSize = 20.dp,
                                    containerSize = 40.dp,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Notifications",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 21.sp,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            is TopBarType.Search -> {
                                GlassIconButton(
                                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                    onClick = onBackClick,
                                    isLiquidGlass = isLiquidGlass,
                                    contentDescription = "Back",
                                    iconSize = 20.dp,
                                    containerSize = 40.dp,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                )
                                Spacer(modifier = Modifier.width(10.dp))

                                val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
                                val searchBoxBg = if (liquidEnabled) {
                                    MaterialTheme.colorScheme.onSurface.copy(alpha = 0.09f)
                                } else {
                                    QueueSolidGrey
                                }

                                TextField(
                                    value = type.query,
                                    onValueChange = type.onQueryChange,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    placeholder = {
                                        Text(
                                            "What do you want to listen to?",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = WaveIcons.Search,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp),
                                        )
                                    },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = searchBoxBg,
                                        unfocusedContainerColor = searchBoxBg,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent,
                                        cursorColor = MaterialTheme.colorScheme.primary,
                                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    ),
                                    shape = RoundedCornerShape(50),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Search,
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onSearch = {
                                            type.onSearchAction()
                                            keyboardController?.hide()
                                        },
                                    ),
                                    trailingIcon = {
                                        if (type.query.isNotEmpty()) {
                                            IconButton(onClick = { type.onQueryChange("") }) {
                                                Icon(
                                                    Icons.Rounded.Close,
                                                    contentDescription = "Clear",
                                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(20.dp),
                                                )
                                            }
                                        }
                                    },
                                )
                            }
                            is TopBarType.SubScreen -> {
                                GlassIconButton(
                                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                    onClick = onBackClick,
                                    isLiquidGlass = isLiquidGlass,
                                    contentDescription = "Back",
                                    iconSize = 20.dp,
                                    containerSize = 40.dp,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = type.title,
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            is TopBarType.Queue -> {
                                GlassIconButton(
                                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                                    onClick = onBackClick,
                                    isLiquidGlass = isLiquidGlass,
                                    contentDescription = "Back",
                                    iconSize = 20.dp,
                                    containerSize = 40.dp,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Now Playing Queue",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }

                if (type is TopBarType.Queue && type.currentSong != null) {
                    val currentSong = type.currentSong
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp)
                            .background(
                                color = if (liquidEnabled) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f) else QueueSolidGrey,
                                shape = RoundedCornerShape(18.dp),
                            )
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(18.dp),
                            )
                            .padding(12.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            WaveArtworkImage(
                                url = type.highResThumbnailUrl ?: currentSong.thumbnailUrl,
                                videoId = currentSong.videoId,
                                contentDescription = currentSong.title,
                                isVideo = false,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(56.dp),
                            )

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Now Playing",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = currentSong.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Clip,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .basicMarquee(
                                            iterations = Int.MAX_VALUE,
                                            animationMode = MarqueeAnimationMode.Immediately,
                                        )
                                        .focusable(),
                                )
                                Text(
                                    text = currentSong.artist,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Clip,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .basicMarquee(
                                            iterations = Int.MAX_VALUE,
                                            animationMode = MarqueeAnimationMode.Immediately,
                                        )
                                        .focusable(),
                                )
                            }
                        }
                    }
                }

                bottomContent?.invoke(this)
            }
        }
    }
}
