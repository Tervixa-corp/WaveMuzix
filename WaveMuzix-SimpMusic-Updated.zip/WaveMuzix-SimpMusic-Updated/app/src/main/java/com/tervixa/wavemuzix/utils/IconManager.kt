package com.tervixa.wavemuzix.utils

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.tervixa.wavemuzix.MainActivity

/**
 * IconManager handles switching between Light and Dark app icons
 * by enabling/disabling manifest activity-aliases.
 */
object IconManager {
    fun updateIcon(context: Context, themeMode: String) {
        val packageManager = context.packageManager
        val packageName = context.packageName

        // Determine which icon should be active
        val isDarkMode = when (themeMode) {
            "Dark" -> true
            "Light" -> false
            else -> {
                // For "System", check current UI mode
                val uiMode = context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK
                uiMode == android.content.res.Configuration.UI_MODE_NIGHT_YES
            }
        }

        // Use the full component name string that matches the manifest relative naming
        val lightAlias = ComponentName(packageName, "$packageName.MainActivityLight")
        val darkAlias = ComponentName(packageName, "$packageName.MainActivityDark")

        val (enableAlias, disableAlias) = if (isDarkMode) {
            darkAlias to lightAlias
        } else {
            lightAlias to darkAlias
        }

        // Enable the new one first, then disable the old one to ensure a launcher entry always exists
        if (packageManager.getComponentEnabledSetting(enableAlias) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
            packageManager.setComponentEnabledSetting(
                enableAlias,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        }

        if (packageManager.getComponentEnabledSetting(disableAlias) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
            packageManager.setComponentEnabledSetting(
                disableAlias,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
    }
}
