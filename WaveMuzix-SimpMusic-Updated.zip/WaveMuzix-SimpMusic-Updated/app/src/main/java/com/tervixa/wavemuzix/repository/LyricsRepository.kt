package com.tervixa.wavemuzix.repository

import android.util.Base64
import android.util.Log
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.isRecordLabelOrChannelName
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * SimpMusic-aligned Multi-Provider Word-by-Word Lyrics Engine with Strict Song Verification:
 * - Resolves exact `videoId` match on SimpMusic Lyrics API (`https://api-lyrics.simpmusic.org/v1/{videoId}`) first so
 *   YouTube tracks with exact IDs never mismatch.
 * - Enforces strict title + artist similarity and duration tolerance (`<= 14s` when duration is known)
 *   across BetterLyrics, SimpMusic Search, LRCLIB, Netease, and KuGou so lyrics never play for a wrong song.
 */
class LyricsRepository {
    private val client = OkHttpClient.Builder()
        .connectionPool(ConnectionPool(10, 5, TimeUnit.MINUTES))
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(7, TimeUnit.SECONDS)
        .build()

    private val userAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    data class LyricsResult(val lyrics: String, val provider: String)

    private val lyricsCache = ConcurrentHashMap<String, LyricsResult>()
    private val ongoingRequests = ConcurrentHashMap<String, Deferred<LyricsResult?>>()

    private var lastFetchedSongId: String? = null
    fun getLastSongId(): String? = lastFetchedSongId

    fun getCachedLyrics(videoId: String): String? = lyricsCache[videoId]?.lyrics
    fun getCachedProvider(videoId: String): String? = lyricsCache[videoId]?.provider

    private fun cleanTitle(title: String): String {
        return title
            .replace(Regex("(?i)\\(official (music )?video\\)"), "")
            .replace(Regex("(?i)\\[official (music )?video\\]"), "")
            .replace(Regex("(?i)\\(official (lyric )?video\\)"), "")
            .replace(Regex("(?i)\\[official (lyric )?video\\]"), "")
            .replace(Regex("(?i)\\(official visualizer\\)"), "")
            .replace(Regex("(?i)\\[official visualizer\\]"), "")
            .replace(Regex("(?i)official (music )?video"), "")
            .replace(Regex("(?i)lyric video"), "")
            .replace(Regex("(?i)lyrical video"), "")
            .replace(Regex("(?i)official audio"), "")
            .replace(Regex("(?i)high quality"), "")
            .replace(Regex("(?i)full video song"), "")
            .replace(Regex("(?i)full song"), "")
            .replace(Regex("(?i)video song"), "")
            .replace(Regex("(?i)\\bMV\\b"), "")
            .replace(Regex("(?i)\\bHD\\b"), "")
            .replace(Regex("(?i)\\b4K\\b"), "")
            .replace(Regex("(?i)\\(lyrics\\)"), "")
            .replace(Regex("(?i)\\[lyrics\\]"), "")
            .replace(Regex("(?i)\\(feat\\.? .*?\\)"), "")
            .replace(Regex("(?i)\\[feat\\.? .*?\\]"), "")
            .replace(Regex("(?i)feat\\.? .*"), "")
            .replace(Regex("\\|.*"), "")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }

    private fun normalizeForComparison(text: String): String =
        text.lowercase()
            .replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^a-z0-9\\p{L}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /**
     * Strict candidate verification ported from SimpMusic's `LyricsRepositoryImpl`:
     * Rejects candidates whose title does not match the target song title, whose artist
     * conflicts with the target artist, or whose duration differs by more than `maxDurationDiffSec`.
     */
    private fun isCandidateMatch(
        expectedTitle: String,
        expectedArtist: String,
        candidateTitle: String?,
        candidateArtist: String?,
        expectedDurationSec: Int?,
        candidateDurationSec: Int?,
        maxDurationDiffSec: Int = 14,
    ): Boolean {
        if (expectedDurationSec != null && expectedDurationSec > 20 &&
            candidateDurationSec != null && candidateDurationSec > 20
        ) {
            if (abs(expectedDurationSec - candidateDurationSec) > maxDurationDiffSec) {
                return false
            }
        }

        val expTitleNorm = normalizeForComparison(expectedTitle)
        val candTitleNorm = normalizeForComparison(candidateTitle.orEmpty())
        if (expTitleNorm.isNotEmpty() && candTitleNorm.isNotEmpty()) {
            val titleMatches = expTitleNorm == candTitleNorm ||
                candTitleNorm.contains(expTitleNorm) ||
                expTitleNorm.contains(candTitleNorm) ||
                tokenOverlapRatio(expTitleNorm, candTitleNorm) >= 0.65f
            if (!titleMatches) return false
        }

        val expArtistNorm = normalizeForComparison(expectedArtist)
        val candArtistNorm = normalizeForComparison(candidateArtist.orEmpty())
        if (expArtistNorm.isNotEmpty() && candArtistNorm.isNotEmpty()) {
            val artistMatches = expArtistNorm == candArtistNorm ||
                candArtistNorm.contains(expArtistNorm) ||
                expArtistNorm.contains(candArtistNorm) ||
                tokenOverlapRatio(expArtistNorm, candArtistNorm) >= 0.50f
            if (!artistMatches) return false
        }

        return true
    }

    private fun tokenOverlapRatio(a: String, b: String): Float {
        val tokensA = a.split(" ").filter { it.length >= 2 }.toSet()
        val tokensB = b.split(" ").filter { it.length >= 2 }.toSet()
        if (tokensA.isEmpty() || tokensB.isEmpty()) return 0f
        val intersection = tokensA.intersect(tokensB).size.toFloat()
        return intersection / minOf(tokensA.size, tokensB.size).toFloat()
    }

    private fun parseDurationSeconds(durationText: String?): Int? {
        if (durationText.isNullOrBlank()) return null
        val parts = durationText.trim().split(":").mapNotNull { it.toIntOrNull() }
        return when (parts.size) {
            2 -> parts[0] * 60 + parts[1]
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            else -> null
        }?.takeIf { it > 0 }
    }

    suspend fun fetchLyrics(
        song: Song,
        preferredProvider: String = "Auto",
        dao: com.tervixa.wavemuzix.data.database.SongDao? = null,
        targetDurationSeconds: Int? = null,
    ): LyricsResult? = coroutineScope {
        val videoId = song.videoId
        lastFetchedSongId = videoId
        lyricsCache[videoId]?.let { return@coroutineScope it }

        if (dao != null) {
            try {
                val dbResult = dao.getLyricsByVideoId(videoId)
                if (dbResult != null && dbResult.lyrics.isNotBlank()) {
                    val normalized = normalizeAndEnhanceLrc(dbResult.lyrics)
                    val result = LyricsResult(normalized, dbResult.provider)
                    lyricsCache[videoId] = result
                    return@coroutineScope result
                }
            } catch (e: Exception) {
                Log.e("LyricsRepo", "DB read error", e)
            }
        }

        ongoingRequests[videoId]?.let { return@coroutineScope it.await() }

        val deferred = async(Dispatchers.IO) {
            try {
                val cleanedTitle = cleanTitle(song.title)
                val fullArtistStr = song.displayArtists
                val primaryArtist = fullArtistStr
                    .split(Regex("(?i),|feat\\.?|&|/| x "))[0]
                    .replace(Regex("(?i)- Topic$"), "")
                    .trim()
                    .let { if (isRecordLabelOrChannelName(it)) "" else it }

                val durationSec = targetDurationSeconds ?: parseDurationSeconds(song.durationText)

                // 0. Exact videoId lookup on SimpMusic Lyrics API first (zero false-positive risk!)
                if (videoId.isNotBlank() && (preferredProvider == "Auto" || preferredProvider.isBlank() || preferredProvider.equals("SimpMusic", ignoreCase = true) || preferredProvider.equals("BetterLyrics", ignoreCase = true))) {
                    val exactByVideoId = fetchSimpMusicExactVideoId(videoId, durationSec)
                    if (!exactByVideoId.isNullOrBlank()) {
                        val normalized = normalizeAndEnhanceLrc(exactByVideoId)
                        val lyricsResult = LyricsResult(normalized, "SimpMusic")
                        saveToDb(dao, videoId, normalized, "SimpMusic")
                        return@async lyricsResult
                    }
                }

                val defaultChain = listOf("BetterLyrics", "SimpMusic", "LRCLIB", "Netease", "KuGou", "Alsong")
                val providers = mutableListOf<String>()
                if (preferredProvider == "Auto" || preferredProvider.isBlank() || preferredProvider.equals("BetterLyrics", ignoreCase = true)) {
                    providers.addAll(defaultChain)
                } else {
                    providers.add(preferredProvider)
                    defaultChain.forEach { fallback ->
                        if (!fallback.equals(preferredProvider, ignoreCase = true)) {
                            providers.add(fallback)
                        }
                    }
                }

                val searchVariations = mutableListOf<Pair<String, String>>()
                if (primaryArtist.isNotBlank()) {
                    searchVariations.add(primaryArtist to cleanedTitle)
                }
                if (fullArtistStr.isNotBlank() && fullArtistStr != primaryArtist && !isRecordLabelOrChannelName(fullArtistStr)) {
                    searchVariations.add(fullArtistStr to cleanedTitle)
                }
                if (cleanedTitle.contains(" - ")) {
                    val parts = cleanedTitle.split(" - ", limit = 2)
                    searchVariations.add(parts[0].trim() to parts[1].trim())
                    searchVariations.add(parts[1].trim() to parts[0].trim())
                }
                if (searchVariations.isEmpty()) {
                    searchVariations.add("" to cleanedTitle)
                }

                for (provider in providers) {
                    if (provider.equals("SimpMusic", ignoreCase = true) && videoId.isNotBlank()) {
                        val bySimp = try {
                            fetchSimpMusicLyricsByVideoId(videoId, cleanedTitle, primaryArtist, durationSec)
                        } catch (_: Exception) {
                            null
                        }
                        if (!bySimp.isNullOrBlank()) {
                            val normalized = normalizeAndEnhanceLrc(bySimp)
                            val lyricsResult = LyricsResult(normalized, "SimpMusic")
                            saveToDb(dao, videoId, normalized, "SimpMusic")
                            return@async lyricsResult
                        }
                        continue
                    }

                    for ((artistQuery, titleQuery) in searchVariations.distinct()) {
                        if (artistQuery.isBlank() && titleQuery.isBlank()) continue

                        val rawLyrics = try {
                            when (provider) {
                                "BetterLyrics" -> fetchBetterLyrics(artistQuery, titleQuery, durationSec)
                                "LRCLIB" -> fetchLrcLibLyrics(artistQuery, titleQuery, durationSec)
                                "Netease" -> fetchNeteaseLyrics(artistQuery, titleQuery, durationSec)
                                "KuGou" -> fetchKuGouLyrics(artistQuery, titleQuery, durationSec)
                                "Alsong" -> if (artistQuery.isNotBlank()) fetchAlsongLyrics(artistQuery, titleQuery) else null
                                else -> null
                            }
                        } catch (e: Exception) {
                            Log.w("LyricsRepo", "Provider $provider failed for $artistQuery - $titleQuery: ${e.message}")
                            null
                        }

                        if (!rawLyrics.isNullOrBlank()) {
                            val normalized = normalizeAndEnhanceLrc(rawLyrics)
                            val lyricsResult = LyricsResult(normalized, provider)
                            saveToDb(dao, videoId, normalized, provider)
                            return@async lyricsResult
                        }
                    }
                }

                null
            } catch (e: Exception) {
                Log.e("LyricsRepo", "Global error in fetchLyrics", e)
                null
            } finally {
                ongoingRequests.remove(videoId)
            }
        }

        ongoingRequests[videoId] = deferred
        val result = deferred.await()
        if (result != null) lyricsCache[videoId] = result
        result
    }

    private suspend fun saveToDb(
        dao: com.tervixa.wavemuzix.data.database.SongDao?,
        videoId: String,
        lyrics: String,
        provider: String,
    ) {
        if (dao == null) return
        try {
            dao.insertLyrics(
                com.tervixa.wavemuzix.data.database.LyricsCacheEntity(
                    videoId = videoId,
                    lyrics = lyrics,
                    provider = provider,
                )
            )
        } catch (e: Exception) {
            Log.e("LyricsRepo", "DB write error", e)
        }
    }

    /**
     * Exact `videoId` lookup on SimpMusic Lyrics API (`https://api-lyrics.simpmusic.org/v1/{videoId}`).
     */
    private suspend fun fetchSimpMusicExactVideoId(
        videoId: String,
        durationSec: Int?,
    ): String? = withContext(Dispatchers.IO) {
        try {
            val directUrl = "https://api-lyrics.simpmusic.org/v1/$videoId"
            val req = Request.Builder()
                .url(directUrl)
                .header("User-Agent", "SimpMusic/1.0")
                .header("Accept", "application/json")
                .build()

            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string().orEmpty()
                    extractSimpMusicJsonLyrics(
                        rawBody = body,
                        expectedTitle = "",
                        expectedArtist = "",
                        targetDurationSec = durationSec,
                        requireMetadataMatch = false,
                    )?.let { return@withContext it }
                }
            }
        } catch (_: Exception) {
        }
        null
    }

    /**
     * Primary Provider: **BetterLyrics** (`https://lyrics-api.boidu.dev/getLyrics`)
     * Supports TTML word/syllable syncing and rich LRC. Requires non-blank artist to avoid wrong-song matches.
     */
    private suspend fun fetchBetterLyrics(artist: String, title: String, durationSec: Int?): String? = withContext(Dispatchers.IO) {
        if (title.isBlank() || artist.isBlank()) return@withContext null
        try {
            val urlBuilder = StringBuilder("https://lyrics-api.boidu.dev/getLyrics?")
            urlBuilder.append("s=").append(URLEncoder.encode(title, "UTF-8"))
            urlBuilder.append("&a=").append(URLEncoder.encode(artist, "UTF-8"))
            if (durationSec != null && durationSec > 0) {
                urlBuilder.append("&d=").append(durationSec)
            }

            val req = Request.Builder()
                .url(urlBuilder.toString())
                .header("User-Agent", userAgent)
                .header("Accept", "application/json, text/plain, */*")
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val body = resp.body?.string()?.trim().orEmpty()
                if (body.isEmpty() || body == "null") return@use

                if (body.startsWith("{")) {
                    val json = JSONObject(body)
                    val ttml = json.optString("ttml").takeIf { it.isNotBlank() && it != "null" }
                    if (ttml != null) {
                        val converted = convertTtmlToRichLrc(ttml)
                        if (!converted.isNullOrBlank()) return@withContext converted
                    }
                    val richLrc = json.optString("richSyncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                        ?: json.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                        ?: json.optString("lyrics").takeIf { it.isNotBlank() && it != "null" }
                    if (richLrc != null) {
                        if (richLrc.contains("<tt") || richLrc.contains("<p ")) {
                            convertTtmlToRichLrc(richLrc)?.let { return@withContext it }
                        }
                        return@withContext richLrc
                    }
                } else if (body.contains("<tt") || body.contains("<p ")) {
                    convertTtmlToRichLrc(body)?.let { return@withContext it }
                } else if (body.contains("[")) {
                    return@withContext body
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "BetterLyrics error: ${e.message}")
        }
        null
    }

    /**
     * Fallback 1: **SimpMusic Lyrics API** (`https://api-lyrics.simpmusic.org/v1`)
     */
    private suspend fun fetchSimpMusicLyricsByVideoId(
        videoId: String,
        title: String,
        artist: String,
        durationSec: Int?,
    ): String? = withContext(Dispatchers.IO) {
        try {
            fetchSimpMusicExactVideoId(videoId, durationSec)?.let { return@withContext it }

            if (title.isNotBlank()) {
                val searchUrl = buildString {
                    append("https://api-lyrics.simpmusic.org/v1/search?title=")
                    append(URLEncoder.encode(title, "UTF-8"))
                    if (artist.isNotBlank()) {
                        append("&artist=").append(URLEncoder.encode(artist, "UTF-8"))
                    }
                }
                val sReq = Request.Builder()
                    .url(searchUrl)
                    .header("User-Agent", "SimpMusic/1.0")
                    .header("Accept", "application/json")
                    .build()
                client.newCall(sReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string().orEmpty()
                        extractSimpMusicJsonLyrics(
                            rawBody = body,
                            expectedTitle = title,
                            expectedArtist = artist,
                            targetDurationSec = durationSec,
                            requireMetadataMatch = true,
                        )?.let { return@withContext it }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "SimpMusic lyrics fallback: ${e.message}")
        }
        null
    }

    private fun extractSimpMusicJsonLyrics(
        rawBody: String,
        expectedTitle: String,
        expectedArtist: String,
        targetDurationSec: Int?,
        requireMetadataMatch: Boolean,
    ): String? {
        if (rawBody.isBlank()) return null
        return try {
            val root = JSONObject(rawBody)
            val dataArray = root.optJSONArray("data")
            val candidates = mutableListOf<JSONObject>()
            if (dataArray != null) {
                for (i in 0 until dataArray.length()) {
                    dataArray.optJSONObject(i)?.let { candidates.add(it) }
                }
            } else {
                root.optJSONObject("data")?.let { candidates.add(it) } ?: candidates.add(root)
            }

            val filtered = if (requireMetadataMatch) {
                candidates.filter { item ->
                    val candTitle = item.optString("songTitle").ifBlank { item.optString("title") }
                    val candArtist = item.optString("artistName").ifBlank { item.optString("artist") }
                    val candDur = item.optInt("duration", 0).takeIf { it > 0 }
                    isCandidateMatch(
                        expectedTitle = expectedTitle,
                        expectedArtist = expectedArtist,
                        candidateTitle = candTitle,
                        candidateArtist = candArtist,
                        expectedDurationSec = targetDurationSec,
                        candidateDurationSec = candDur,
                    )
                }
            } else {
                candidates.filter { item ->
                    val candDur = item.optInt("duration", 0).takeIf { it > 0 }
                    if (targetDurationSec != null && targetDurationSec > 20 && candDur != null) {
                        abs(targetDurationSec - candDur) <= 18
                    } else true
                }
            }

            val sorted = if (targetDurationSec != null && targetDurationSec > 0) {
                filtered.sortedBy { obj ->
                    val d = obj.optInt("duration", targetDurationSec)
                    abs(d - targetDurationSec)
                }
            } else filtered

            for (item in sorted) {
                val rich = item.optString("richSyncLyrics").takeIf { it.isNotBlank() && it != "null" }
                val synced = item.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                val plain = item.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                if (rich != null) return mergeRichAndSyncedLrc(rich, synced)
                if (synced != null) return synced
                if (plain != null) return plain
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun mergeRichAndSyncedLrc(richSync: String, syncedLrc: String?): String {
        if (richSync.contains("[") && richSync.contains("<")) return richSync
        return richSync.ifBlank { syncedLrc.orEmpty() }
    }

    /**
     * Fallback 2: **LRCLIB** with strict title, artist, and duration matching (`<= 14s`).
     */
    private suspend fun fetchLrcLibLyrics(artist: String, title: String, durationSec: Int?): String? = withContext(Dispatchers.IO) {
        try {
            if (artist.isNotBlank() && title.isNotBlank()) {
                val getUrl = buildString {
                    append("https://lrclib.net/api/get?artist_name=")
                    append(URLEncoder.encode(artist, "UTF-8"))
                    append("&track_name=")
                    append(URLEncoder.encode(title, "UTF-8"))
                    if (durationSec != null && durationSec > 0) {
                        append("&duration=").append(durationSec)
                    }
                }
                client.newCall(Request.Builder().url(getUrl).header("User-Agent", userAgent).build()).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        if (body.isNotEmpty() && body != "null") {
                            val json = JSONObject(body)
                            val candDur = json.optDouble("duration", 0.0).toInt().takeIf { it > 0 }
                            if (isCandidateMatch(
                                    expectedTitle = title,
                                    expectedArtist = artist,
                                    candidateTitle = json.optString("trackName"),
                                    candidateArtist = json.optString("artistName"),
                                    expectedDurationSec = durationSec,
                                    candidateDurationSec = candDur,
                                )
                            ) {
                                val lyrics = json.optString("syncedLyrics").takeIf { !it.isNullOrBlank() && it != "null" }
                                    ?: json.optString("plainLyrics").takeIf { !it.isNullOrBlank() && it != "null" }
                                if (lyrics != null) return@withContext lyrics
                            }
                        }
                    }
                }
            }

            val query = if (artist.isNotBlank()) "$artist $title" else title
            val searchUrl = "https://lrclib.net/api/search?q=${URLEncoder.encode(query, "UTF-8")}"
            client.newCall(Request.Builder().url(searchUrl).header("User-Agent", userAgent).build()).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    if (body.isNotEmpty() && body != "null") {
                        val results = JSONArray(body)
                        val candidates = mutableListOf<JSONObject>()
                        for (i in 0 until results.length()) {
                            results.optJSONObject(i)?.let { candidates.add(it) }
                        }
                        val validCandidates = candidates.filter { obj ->
                            val candTitle = obj.optString("trackName").ifBlank { obj.optString("name") }
                            val candArtist = obj.optString("artistName")
                            val candDur = obj.optDouble("duration", 0.0).toInt().takeIf { it > 0 }
                            isCandidateMatch(
                                expectedTitle = title,
                                expectedArtist = artist,
                                candidateTitle = candTitle,
                                candidateArtist = candArtist,
                                expectedDurationSec = durationSec,
                                candidateDurationSec = candDur,
                            )
                        }
                        val bestCandidates = validCandidates.sortedWith(
                            compareBy<JSONObject> { obj ->
                                val hasSynced = !obj.optString("syncedLyrics").isNullOrBlank() && obj.optString("syncedLyrics") != "null"
                                if (hasSynced) 0 else 1
                            }.thenBy { obj ->
                                if (durationSec != null && durationSec > 0) {
                                    val candDur = obj.optDouble("duration", durationSec.toDouble()).toInt()
                                    abs(candDur - durationSec)
                                } else 0
                            }
                        )
                        for (match in bestCandidates) {
                            val lyrics = match.optString("syncedLyrics").takeIf { !it.isNullOrBlank() && it != "null" }
                                ?: match.optString("plainLyrics").takeIf { !it.isNullOrBlank() && it != "null" }
                            if (lyrics != null) return@withContext lyrics
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "LRCLIB error: ${e.message}")
        }
        null
    }

    /**
     * Fallback 3: **Netease Cloud Music** with `yrc` word-by-word karaoke conversion + strict candidate matching.
     */
    private suspend fun fetchNeteaseLyrics(artist: String, title: String, durationSec: Int?): String? = withContext(Dispatchers.IO) {
        try {
            val query = if (artist.isBlank()) title else "$artist $title"
            val searchUrl = "https://music.163.com/api/cloudsearch/get/web?s=${URLEncoder.encode(query, "UTF-8")}&type=1&offset=0&total=true&limit=6"
            val request = Request.Builder()
                .url(searchUrl)
                .addHeader("User-Agent", userAgent)
                .addHeader("Referer", "https://music.163.com")
                .addHeader("Cookie", "os=pc; osver=Microsoft-Windows-10-Professional-build-10586-64bit; appver=2.0.3.131777")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) return@use
                val jsonResponse = JSONObject(body)
                val resultObj = jsonResponse.optJSONObject("result") ?: return@use
                val songs = resultObj.optJSONArray("songs") ?: return@use

                val songList = mutableListOf<JSONObject>()
                for (i in 0 until songs.length()) {
                    songs.optJSONObject(i)?.let { songObj ->
                        val candTitle = songObj.optString("name")
                        val arArr = songObj.optJSONArray("ar") ?: songObj.optJSONArray("artists")
                        val candArtist = arArr?.optJSONObject(0)?.optString("name").orEmpty()
                        val dtSec = (songObj.optLong("dt", 0L) / 1000L).toInt().takeIf { it > 0 }
                        if (isCandidateMatch(title, artist, candTitle, candArtist, durationSec, dtSec)) {
                            songList.add(songObj)
                        }
                    }
                }
                val sortedSongs = if (durationSec != null && durationSec > 0) {
                    songList.sortedBy { s ->
                        val dtSec = (s.optLong("dt", durationSec * 1000L) / 1000L).toInt()
                        abs(dtSec - durationSec)
                    }
                } else songList

                for (songObj in sortedSongs.take(3)) {
                    val id = songObj.optLong("id")
                    if (id <= 0L) continue
                    val lyricUrl = "https://music.163.com/api/song/lyric?id=$id&lv=1&kv=1&tv=-1&yv=1"
                    val lyricRequest = Request.Builder()
                        .url(lyricUrl)
                        .addHeader("User-Agent", userAgent)
                        .addHeader("Referer", "https://music.163.com")
                        .build()

                    client.newCall(lyricRequest).execute().use { lyrResponse ->
                        val lyrBody = lyrResponse.body?.string().orEmpty()
                        if (lyrBody.isNotBlank()) {
                            val lyrJson = JSONObject(lyrBody)
                            val yrcRaw = lyrJson.optJSONObject("yrc")?.optString("lyric")
                            if (!yrcRaw.isNullOrBlank() && yrcRaw != "null") {
                                convertNeteaseYrcToRichLrc(yrcRaw)?.let { return@withContext it }
                            }
                            val lrc = lyrJson.optJSONObject("lrc")?.optString("lyric")
                            if (!lrc.isNullOrBlank() && lrc != "null" && !lrc.contains("纯音乐") && lrc.length >= 15) {
                                return@withContext lrc
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "Netease error: ${e.message}")
        }
        null
    }

    /**
     * Fallback 4: **KuGou Lyrics** (matched by song title, artist, and duration).
     */
    private suspend fun fetchKuGouLyrics(artist: String, title: String, durationSec: Int?): String? = withContext(Dispatchers.IO) {
        try {
            val keyword = if (artist.isNotBlank()) "$artist - $title" else title
            val durMs = (durationSec ?: 200) * 1000
            val searchUrl = "http://lyrics.kugou.com/search?ver=1&man=yes&client=pc&keyword=${URLEncoder.encode(keyword, "UTF-8")}&duration=$durMs"
            val req = Request.Builder().url(searchUrl).header("User-Agent", userAgent).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val json = JSONObject(resp.body?.string().orEmpty())
                val candidates = json.optJSONArray("candidates") ?: return@use
                for (i in 0 until candidates.length()) {
                    val cand = candidates.optJSONObject(i) ?: continue
                    val candTitle = cand.optString("song")
                    val candSinger = cand.optString("singer")
                    val candDurSec = (cand.optLong("duration", 0L) / 1000L).toInt().takeIf { it > 0 }
                    if (!isCandidateMatch(title, artist, candTitle, candSinger, durationSec, candDurSec)) {
                        continue
                    }
                    val id = cand.optString("id")
                    val accessKey = cand.optString("accesskey")
                    if (id.isBlank() || accessKey.isBlank()) continue

                    val dlUrl = "http://lyrics.kugou.com/download?ver=1&client=pc&id=$id&accesskey=$accessKey&fmt=lrc&charset=utf8"
                    client.newCall(Request.Builder().url(dlUrl).header("User-Agent", userAgent).build()).execute().use { dlResp ->
                        if (!dlResp.isSuccessful) return@use
                        val dlJson = JSONObject(dlResp.body?.string().orEmpty())
                        val contentBase64 = dlJson.optString("content")
                        if (contentBase64.isNotBlank()) {
                            val decoded = String(Base64.decode(contentBase64, Base64.DEFAULT), Charsets.UTF_8)
                            if (decoded.contains("[")) return@withContext decoded
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "KuGou error: ${e.message}")
        }
        null
    }

    /**
     * Fallback 5: **Alsong** SOAP service.
     */
    private suspend fun fetchAlsongLyrics(artist: String, title: String): String? = withContext(Dispatchers.IO) {
        try {
            val escapedTitle = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
            val escapedArtist = artist.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

            val xml = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetResembleLyricList2 xmlns="ALSongWebServer">
      <stQuery>
        <strTitle>$escapedTitle</strTitle>
        <strArtistName>$escapedArtist</strArtistName>
        <nCurPageNum>0</nCurPageNum>
      </stQuery>
    </GetResembleLyricList2>
  </soap:Body>
</soap:Envelope>"""

            val mediaType = "text/xml; charset=utf-8".toMediaTypeOrNull()
            val body = xml.toRequestBody(mediaType)
            val request = Request.Builder()
                .url("http://lyrics.alsong.co.kr/alsongwebservice/service1.asmx")
                .post(body)
                .addHeader("SOAPAction", "ALSongWebServer/GetResembleLyricList2")
                .addHeader("User-Agent", "Alsong Android")
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: return@use
                val lyricRegex = Regex("<strLyric>(.*?)</strLyric>", RegexOption.DOT_MATCHES_ALL)
                for (match in lyricRegex.findAll(responseBody)) {
                    val lrc = match.groupValues[1]
                        .replace("&lt;", "<")
                        .replace("&gt;", ">")
                        .replace("&amp;", "&")
                        .replace("&quot;", "\"")
                        .replace("&apos;", "'")
                        .replace("<br>", "\n")
                        .replace("&#xD;", "")
                        .replace("&#xA;", "\n")
                        .trim()
                    if (lrc.isNotBlank() && lrc != "null" && lrc.contains("[")) {
                        return@withContext lrc
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("LyricsRepo", "Alsong error: ${e.message}")
        }
        null
    }

    // --- WORD-BY-WORD & TIMESTAMP NORMALIZATION HELPERS ---

    private fun formatMsToTag(ms: Long, bracket: Char = '['): String {
        val safe = ms.coerceAtLeast(0L)
        val mins = safe / 60000L
        val secs = (safe % 60000L) / 1000L
        val hundredths = (safe % 1000L) / 10L
        val close = if (bracket == '[') ']' else '>'
        return "%c%02d:%02d.%02d%c".format(bracket, mins, secs, hundredths, close)
    }

    private fun parseTtmlTimeToMs(raw: String): Long? {
        val s = raw.trim()
        if (s.isEmpty()) return null
        if (s.endsWith("ms")) return s.removeSuffix("ms").toDoubleOrNull()?.toLong()
        if (s.endsWith("s")) return ((s.removeSuffix("s").toDoubleOrNull() ?: return null) * 1000.0).toLong()
        val parts = s.split(":")
        return when (parts.size) {
            3 -> {
                val h = parts[0].toLongOrNull() ?: 0L
                val m = parts[1].toLongOrNull() ?: 0L
                val sec = parts[2].toDoubleOrNull() ?: 0.0
                h * 3600_000L + m * 60_000L + (sec * 1000.0).toLong()
            }
            2 -> {
                val m = parts[0].toLongOrNull() ?: 0L
                val sec = parts[1].toDoubleOrNull() ?: 0.0
                m * 60_000L + (sec * 1000.0).toLong()
            }
            else -> (s.toDoubleOrNull()?.times(1000.0))?.toLong()
        }
    }

    private fun convertTtmlToRichLrc(ttml: String): String? {
        val pRegex = Regex("<p\\b[^>]*?begin=[\"']([^\"']+)[\"'][^>]*>(.*?)</p>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val spanRegex = Regex("<span\\b[^>]*?begin=[\"']([^\"']+)[\"'][^>]*>(.*?)</span>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val lines = mutableListOf<String>()

        for (pMatch in pRegex.findAll(ttml)) {
            val pBeginMs = parseTtmlTimeToMs(pMatch.groupValues[1]) ?: continue
            val pInner = pMatch.groupValues[2]
            val linePrefix = formatMsToTag(pBeginMs, '[')

            val spans = spanRegex.findAll(pInner).toList()
            if (spans.isNotEmpty()) {
                val richBuilder = StringBuilder(linePrefix)
                for (span in spans) {
                    val wMs = parseTtmlTimeToMs(span.groupValues[1]) ?: pBeginMs
                    val wText = span.groupValues[2]
                        .replace(Regex("<[^>]+>"), "")
                        .replace("&amp;", "&")
                        .replace("&apos;", "'")
                        .replace("&#39;", "'")
                        .replace("&quot;", "\"")
                        .trim()
                    if (wText.isNotEmpty()) {
                        richBuilder.append(formatMsToTag(wMs, '<')).append(wText).append(' ')
                    }
                }
                lines.add(richBuilder.toString().trim())
            } else {
                val plainText = pInner
                    .replace(Regex("<[^>]+>"), "")
                    .replace("&amp;", "&")
                    .replace("&apos;", "'")
                    .replace("&#39;", "'")
                    .replace("&quot;", "\"")
                    .trim()
                if (plainText.isNotEmpty()) {
                    lines.add("$linePrefix $plainText")
                }
            }
        }
        return lines.takeIf { it.isNotEmpty() }?.joinToString("\n")
    }

    private fun convertNeteaseYrcToRichLrc(yrc: String): String? {
        val lineRegex = Regex("^\\[(\\d+),(\\d+)\\](.+)$")
        val wordRegex = Regex("\\((\\d+),(\\d+),\\d+\\)([^\\(]+)")
        val outLines = mutableListOf<String>()

        for (rawLine in yrc.lines()) {
            val trimmed = rawLine.trim()
            val m = lineRegex.find(trimmed) ?: continue
            val startMs = m.groupValues[1].toLongOrNull() ?: continue
            val rest = m.groupValues[3]
            val words = wordRegex.findAll(rest).toList()
            if (words.isEmpty()) continue
            val sb = StringBuilder(formatMsToTag(startMs, '['))
            for (w in words) {
                val wStart = w.groupValues[1].toLongOrNull() ?: startMs
                val wText = w.groupValues[3].trim()
                if (wText.isNotEmpty()) {
                    sb.append(formatMsToTag(wStart, '<')).append(wText).append(' ')
                }
            }
            outLines.add(sb.toString().trim())
        }
        return outLines.takeIf { it.isNotEmpty() }?.joinToString("\n")
    }

    private fun normalizeAndEnhanceLrc(rawLrc: String): String {
        if (!rawLrc.contains("[")) return rawLrc

        val offsetRegex = Regex("\\[offset:\\s*([+-]?\\d+)\\s*\\]", RegexOption.IGNORE_CASE)
        val offsetMs = offsetRegex.find(rawLrc)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L

        val lineTimeRegex = Regex("^\\[(\\d{1,2}):(\\d{2})(?:[:.](\\d{1,3}))?\\](.*)$")

        data class ParsedLine(val timeMs: Long, val content: String)
        val parsedLines = mutableListOf<ParsedLine>()

        for (line in rawLrc.lines()) {
            val m = lineTimeRegex.find(line.trim()) ?: continue
            val min = m.groupValues[1].toLongOrNull() ?: 0L
            val sec = m.groupValues[2].toLongOrNull() ?: 0L
            val fracStr = m.groupValues[3]
            val fracMs = when (fracStr.length) {
                1 -> (fracStr.toLongOrNull() ?: 0L) * 100L
                2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                3 -> fracStr.toLongOrNull() ?: 0L
                else -> 0L
            }
            val rawMs = (min * 60_000L + sec * 1_000L + fracMs - offsetMs).coerceAtLeast(0L)
            val content = m.groupValues[4].trim()
            if (content.isNotEmpty()) {
                parsedLines.add(ParsedLine(rawMs, content))
            }
        }

        if (parsedLines.isEmpty()) return rawLrc
        val sorted = parsedLines.sortedBy { it.timeMs }

        return sorted.mapIndexed { index, item ->
            val lineTag = formatMsToTag(item.timeMs, '[')
            if (item.content.contains(Regex("<\\d{2}:\\d{2}\\.\\d{2,3}>"))) {
                "$lineTag ${item.content}"
            } else {
                val words = item.content.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.size <= 1) {
                    "$lineTag ${formatMsToTag(item.timeMs, '<')}${item.content}"
                } else {
                    val nextLineMs = sorted.getOrNull(index + 1)?.timeMs ?: (item.timeMs + 3500L)
                    val availableDuration = (nextLineMs - item.timeMs - 180L)
                        .coerceIn(500L, (words.size * 460L).coerceAtLeast(1100L))
                    val totalWeight = words.sumOf { it.length.coerceIn(2, 10) }.toFloat().coerceAtLeast(1f)
                    var elapsed = 0f
                    val richWords = words.joinToString(" ") { word ->
                        val wordStartMs = item.timeMs + (availableDuration * (elapsed / totalWeight)).toLong()
                        elapsed += word.length.coerceIn(2, 10)
                        "${formatMsToTag(wordStartMs, '<')}$word"
                    }
                    "$lineTag $richWords"
                }
            }
        }.joinToString("\n")
    }
}
