package com.tervixa.wavemuzix.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = AccentPrimary,
    secondary = AccentSecondary,
    tertiary = Pink80,
    background = DeepBlack,
    surface = SoftBlack,
    surfaceContainer = Color(0xFF1C1C22),
    surfaceContainerHigh = Color(0xFF26262E),
    surfaceContainerHighest = Color(0xFF32323C),
    onPrimary = TextPrimary,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = Color(0xFFA8A8A8),
    surfaceVariant = SurfaceVariant,
)

private val LightColorScheme = lightColorScheme(
    primary = AccentPrimary,
    secondary = AccentSecondary,
    tertiary = Pink40,
    background = Color(0xFFFAFAFA),
    surface = Color(0xFFF3F3F7),
    surfaceContainer = Color(0xFFECECF2),
    surfaceContainerHigh = Color(0xFFE4E4EC),
    surfaceContainerHighest = Color(0xFFDADAE4),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF111114),
    onSurface = Color(0xFF111114),
    onSurfaceVariant = Color(0xFF5A5A66),
    surfaceVariant = Color(0xFFE5E5EA),
)

@Composable
fun WaveMuzixTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accentColor: Color = AccentPrimary,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme.copy(primary = accentColor)
        else -> LightColorScheme.copy(primary = accentColor)
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    val poppinsFontFamily = rememberPoppinsFontFamily()
    val appTypography = buildSimpTypography(
        fontFamily = poppinsFontFamily,
        colorScheme = colorScheme,
    )

    // Use true 1.0x native device density (removed the old 0.85x forced縮小 scale that shrank the UI)
    CompositionLocalProvider(
        LocalPoppinsFontFamily provides poppinsFontFamily,
        com.tervixa.wavemuzix.uiresource.components.LocalIsDarkTheme provides darkTheme,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = appTypography,
            content = content,
        )
    }
}
