package com.tervixa.wavemuzix.uiresource.screens

import android.annotation.SuppressLint
import android.webkit.CookieManager as AndroidWebCookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Cookie
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.LastFmManager
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.repository.SpotifyRepository
import kotlinx.coroutines.launch
import org.json.JSONObject

private const val DISCORD_TOKEN_JS_SNIPPET =
    "javascript:(function()%7Bvar%20i%3Ddocument.createElement('iframe')%3Bdocument.body.appendChild(i)%3Balert(i.contentWindow.localStorage.token.slice(1,-1))%7D)()"

private val SPOTIFY_STATUS_URL_REGEX =
    Regex("https://accounts\\.spotify\\.com/([a-z]{2}(-[a-zA-Z]{2,4})?/)?status(\\?.*)?")

/**
 * Ported directly from SimpMusic's `Cookies.android.kt`, `SpotifyLoginScreen.kt`, `DiscordLoginScreen.kt`,
 * and `LastfmLoginScreen.kt`:
 * - **YouTube Music**: Captures `SAPISID` / `SID` cookies from `music.youtube.com` and scrapes account handle.
 * - **Spotify**: Matches SimpMusic's `SPOTIFY_STATUS_URL_REGEX` across all regional locales (e.g. `/en/status`,
 *   `/en-IN/status`, `/status`), captures `sp_dc` from `.spotify.com` / `accounts.spotify.com` / `open.spotify.com`,
 *   scrapes `<script id="session">`, and provides SimpMusic's Cookie Bottom Sheet for direct `sp_dc` entry.
 * - **Discord**: Intercepts `/app` and `/channels/@me` in `shouldOverrideUrlLoading`, `doUpdateVisitedHistory`,
 *   and `onPageFinished`, executes `DISCORD_TOKEN_JS_SNIPPET` + webpack/localStorage token hook, and captures
 *   the token via `onJsAlert` or JS bridge.
 * - **Last.fm**: Supports 2-step Web Auth (`last.fm/api/auth`) + direct username verification.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ConnectServiceLoginDialog(
    service: String,
    isCurrentlyConnected: Boolean,
    onDismiss: () -> Unit,
    onConnected: (accountLabel: String, credential: String) -> Unit,
    onDisconnect: () -> Unit,
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }
    val waveCookieManager = remember { CookieManager(context) }
    val scope = rememberCoroutineScope()

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isLoadingPage by remember { mutableStateOf(true) }
    var lastFmToken by remember { mutableStateOf<String?>(null) }
    var lastFmAuthorizedInBrowser by remember { mutableStateOf(false) }
    var manualUsername by remember { mutableStateOf(settingsManager.lastFmUsername) }

    var showManualTokenSheet by remember { mutableStateOf(false) }
    var manualTokenInput by remember(service) {
        mutableStateOf(
            when (service) {
                "Spotify" -> settingsManager.spotifySpDcCookie
                "Discord" -> settingsManager.discordToken
                else -> ""
            }
        )
    }
    var hasCompletedLogin by remember { mutableStateOf(false) }

    val startUrl = remember(service, lastFmToken) {
        when (service) {
            "YouTube Music" ->
                "https://accounts.google.com/ServiceLogin?ltmpl=music&service=youtube&passive=true&continue=https%3A%2F%2Fmusic.youtube.com%2F"
            "Spotify" ->
                "https://accounts.spotify.com/en/login"
            "Discord" ->
                "https://discord.com/login"
            "Last.fm" -> {
                val tok = lastFmToken
                if (!tok.isNullOrBlank()) {
                    "https://www.last.fm/api/auth/?api_key=${LastFmManager.DEFAULT_API_KEY}&token=$tok"
                } else {
                    "https://www.last.fm/login"
                }
            }
            else -> "https://music.youtube.com/"
        }
    }

    LaunchedEffect(service) {
        if (service == "Last.fm") {
            val tok = LastFmManager.requestAuthToken()
            if (!tok.isNullOrBlank()) {
                lastFmToken = tok
            }
        }
    }

    fun completeDiscordToken(rawToken: String?): Boolean {
        if (hasCompletedLogin) return true
        val cleaned = rawToken
            ?.trim()
            ?.removeSurrounding("\"")
            ?.removeSurrounding("'")
            ?.trim()
            .orEmpty()
        if (cleaned.length > 20 && cleaned != "undefined" && cleaned != "null" && !cleaned.contains(" ")) {
            hasCompletedLogin = true
            settingsManager.discordToken = cleaned
            settingsManager.isDiscordConnected = true
            Toast.makeText(context, "Discord Rich Presence connected!", Toast.LENGTH_SHORT).show()
            onConnected("Discord Rich Presence", cleaned)
            return true
        }
        return false
    }

    fun completeSpotifySpDc(rawCookieOrValue: String?): Boolean {
        if (hasCompletedLogin) return true
        val input = rawCookieOrValue?.trim().orEmpty()
        if (input.isBlank()) return false
        val spDcValue = if (input.contains("sp_dc=")) {
            input.split(";")
                .map { it.trim() }
                .firstOrNull { it.startsWith("sp_dc=") }
                ?.substringAfter("sp_dc=")
                ?.trim()
                .orEmpty()
        } else {
            input.removeSurrounding("\"").trim()
        }
        if (spDcValue.length > 15) {
            hasCompletedLogin = true
            settingsManager.spotifySpDcCookie = spDcValue
            settingsManager.isSpotifyConnected = true
            settingsManager.isSpotifyMetadataEnabled = true
            AndroidWebCookieManager.getInstance().flush()
            Toast.makeText(context, "Spotify connected via sp_dc!", Toast.LENGTH_SHORT).show()
            onConnected("Spotify Web Player", spDcValue)
            return true
        }
        return false
    }

    fun tryCompleteCookieCapture(currentUrl: String?, showNotReadyToast: Boolean = false): Boolean {
        if (hasCompletedLogin) return true
        val cookieMgr = AndroidWebCookieManager.getInstance()
        when (service) {
            "YouTube Music" -> {
                val ytCookie = listOfNotNull(
                    cookieMgr.getCookie("https://music.youtube.com"),
                    cookieMgr.getCookie("https://www.youtube.com"),
                    currentUrl?.let { cookieMgr.getCookie(it) },
                ).joinToString("; ")
                if (ytCookie.isNotBlank() && (ytCookie.contains("SAPISID") || ytCookie.contains("SID=") || ytCookie.contains("__Secure-3PAPISID"))) {
                    hasCompletedLogin = true
                    waveCookieManager.saveCookies(ytCookie)
                                        MusicPlayer.cookies = ytCookie
                    settingsManager.isYouTubeMusicConnected = true
                    val accountHandle = settingsManager.ytmAccountName.ifBlank { "YouTube Music Account" }
                    settingsManager.ytmAccountName = accountHandle
                    AndroidWebCookieManager.getInstance().flush()
                    Toast.makeText(context, "YouTube Music connected!", Toast.LENGTH_SHORT).show()
                    onConnected(accountHandle, ytCookie)
                    return true
                }
            }
            "Spotify" -> {
                val spCookie = listOfNotNull(
                    currentUrl?.let { cookieMgr.getCookie(it) },
                    cookieMgr.getCookie("https://accounts.spotify.com"),
                    cookieMgr.getCookie("https://open.spotify.com"),
                    cookieMgr.getCookie("https://spotify.com"),
                    cookieMgr.getCookie("https://www.spotify.com"),
                ).joinToString("; ")
                if (completeSpotifySpDc(spCookie)) {
                    return true
                }
            }
            "Discord" -> {
                webViewRef?.loadUrl(DISCORD_TOKEN_JS_SNIPPET)
                webViewRef?.evaluateJavascript(
                    """
                    (function() {
                        try {
                            var i = document.createElement('iframe');
                            document.body.appendChild(i);
                            var t = i.contentWindow.localStorage.token;
                            if (t) return t.replace(/^"|"$/g, '');
                        } catch (e) {}
                        try {
                            var found = '';
                            (window.webpackChunkdiscord_app = window.webpackChunkdiscord_app || []).push([
                                [Math.random()], {}, function(req) {
                                    for (let m of Object.keys(req.c).map(x => req.c[x].exports).filter(x => x)) {
                                        if (m.default && m.default.getToken !== undefined) {
                                            found = m.default.getToken();
                                        }
                                        if (m.getToken !== undefined) {
                                            found = m.getToken();
                                        }
                                    }
                                }
                            ]);
                            if (found) return found;
                        } catch (e) {}
                        return '';
                    })();
                    """.trimIndent()
                ) { res ->
                    if (!completeDiscordToken(res) && showNotReadyToast) {
                        Toast.makeText(context, "Finish signing in on Discord or tap the Key icon at top right to paste token", Toast.LENGTH_SHORT).show()
                    }
                }
                return false
            }
            "Last.fm" -> {
                val tok = lastFmToken
                if (!tok.isNullOrBlank()) {
                    scope.launch {
                        val session = LastFmManager.fetchWebSession(tok)
                        if (session != null) {
                            hasCompletedLogin = true
                            val (username, sessionKey) = session
                            settingsManager.lastFmUsername = username
                            settingsManager.lastFmSessionKey = sessionKey
                            settingsManager.isLastFmConnected = true
                            Toast.makeText(context, "Connected to Last.fm as @$username!", Toast.LENGTH_SHORT).show()
                            onConnected(username, sessionKey)
                        } else if (manualUsername.isNotBlank()) {
                            hasCompletedLogin = true
                            settingsManager.lastFmUsername = manualUsername.trim()
                            settingsManager.isLastFmConnected = true
                            Toast.makeText(context, "Connected Last.fm (@${manualUsername.trim()})!", Toast.LENGTH_SHORT).show()
                            onConnected(manualUsername.trim(), "")
                        } else if (showNotReadyToast) {
                            Toast.makeText(context, "Please click 'Yes, allow access' on the Last.fm page first", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return true
                }
            }
        }
        if (showNotReadyToast) {
            Toast.makeText(context, "Please finish signing in first, then tap Save Login", Toast.LENGTH_SHORT).show()
        }
        return false
    }

    if (showManualTokenSheet && (service == "Spotify" || service == "Discord")) {
        ModalBottomSheet(
            onDismissRequest = { showManualTokenSheet = false },
            containerColor = Color(0xFF16161E),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = if (service == "Spotify") "Enter Spotify sp_dc Cookie" else "Enter Discord Auth Token",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                )
                Text(
                    text = if (service == "Spotify") {
                        "Paste your sp_dc cookie value from open.spotify.com if WebView login is blocked by 2FA or passkey."
                    } else {
                        "Paste your Discord authorization token if WebView login is blocked by captcha or 2FA."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f),
                )
                OutlinedTextField(
                    value = manualTokenInput,
                    onValueChange = { manualTokenInput = it },
                    label = { Text(if (service == "Spotify") "sp_dc cookie value" else "Discord Token") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                    ),
                )
                Button(
                    onClick = {
                        val ok = if (service == "Spotify") {
                            completeSpotifySpDc(manualTokenInput)
                        } else {
                            completeDiscordToken(manualTokenInput)
                        }
                        if (ok) {
                            showManualTokenSheet = false
                        } else {
                            Toast.makeText(context, "Invalid credential format", Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                ) {
                    Text("Save & Connect", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color(0xFF0E0E13),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Log in to $service",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                ),
                                color = Color.White,
                            )
                            Text(
                                text = when (service) {
                                    "YouTube Music" -> "Sign in to sync your YouTube Music mixes & library"
                                    "Spotify" -> "Sign in to capture sp_dc & Spotify Canvas/Lyrics session"
                                    "Discord" -> "Sign in to broadcast live Discord Rich Presence"
                                    else -> "Authorize WaveMuzix to scrobble your tracks to Last.fm"
                                },
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                color = Color.White.copy(alpha = 0.68f),
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                            )
                        }
                    },
                    actions = {
                        if (service == "Spotify" || service == "Discord") {
                            IconButton(onClick = { showManualTokenSheet = true }) {
                                Icon(
                                    imageVector = Icons.Rounded.Key,
                                    contentDescription = "Manual Cookie / Token",
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                        if (isCurrentlyConnected) {
                            IconButton(
                                onClick = {
                                    AndroidWebCookieManager.getInstance().removeAllCookies(null)
                                    AndroidWebCookieManager.getInstance().flush()
                                    WebStorage.getInstance().deleteAllData()
                                    onDisconnect()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Disconnect",
                                    tint = Color(0xFFFF453A),
                                )
                            }
                        }
                        IconButton(onClick = { webViewRef?.reload() }) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Reload",
                                tint = Color.White,
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF14141C),
                    ),
                )
            },
            floatingActionButton = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (service == "Spotify" || service == "Discord") {
                        SmallFloatingActionButton(
                            onClick = { showManualTokenSheet = true },
                            containerColor = Color(0xFF242430),
                            contentColor = Color.White,
                            shape = CircleShape,
                        ) {
                            Icon(Icons.Rounded.Key, contentDescription = "Enter Cookie/Token")
                        }
                    }
                    ExtendedFloatingActionButton(
                        onClick = {
                            tryCompleteCookieCapture(webViewRef?.url, showNotReadyToast = true)
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.Black,
                        shape = CircleShape,
                        icon = {
                            Icon(
                                imageVector = if (service == "Last.fm") Icons.Rounded.Check else Icons.Rounded.Cookie,
                                contentDescription = null,
                            )
                        },
                        text = {
                            Text(
                                text = if (service == "Last.fm") "Complete Auth" else "Save Login",
                                fontWeight = FontWeight.Bold,
                            )
                        },
                    )
                }
            },
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (isLoadingPage) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }

                if (service == "Last.fm") {
                    Surface(
                        color = Color(0xFF181822),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedTextField(
                                value = manualUsername,
                                onValueChange = { manualUsername = it },
                                label = { Text("Last.fm Username (or authorize below)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Button(
                                onClick = {
                                    tryCompleteCookieCapture(webViewRef?.url, showNotReadyToast = true)
                                },
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Text("Verify")
                            }
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                webViewRef = this
                                val cookieMgr = AndroidWebCookieManager.getInstance()
                                cookieMgr.setAcceptCookie(true)
                                cookieMgr.setAcceptThirdPartyCookies(this, true)

                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    // Clean standard WebView User-Agent (matches SimpMusic Cookies.android.kt)
                                    // so Discord & Spotify never redirect to Play Store / native app deep links!
                                    userAgentString = settings.userAgentString
                                        .replace("; wv", "")
                                }

                                addJavascriptInterface(
                                    object {
                                        @JavascriptInterface
                                        fun onSpotifySessionScraped(sessionJson: String?) {
                                            if (sessionJson.isNullOrBlank()) return
                                            try {
                                                val json = JSONObject(sessionJson)
                                                val accessToken = json.optString("accessToken")
                                                val clientId = json.optString("clientId")
                                                val expMs = json.optLong("accessTokenExpirationTimestampMs", System.currentTimeMillis() + 3000_000L)
                                                SpotifyRepository.updateScrapedSession(accessToken, clientId, expMs)
                                                if (clientId.isNotBlank()) {
                                                    settingsManager.spotifyClientToken = clientId
                                                }
                                            } catch (_: Exception) {}
                                        }

                                        @JavascriptInterface
                                        fun onDiscordTokenCaptured(token: String?) {
                                            if (!token.isNullOrBlank()) {
                                                post { completeDiscordToken(token) }
                                            }
                                        }
                                    },
                                    "SimpSpotifyBridge"
                                )

                                webChromeClient = object : android.webkit.WebChromeClient() {
                                    override fun onJsAlert(
                                        view: WebView?,
                                        url: String?,
                                        message: String?,
                                        result: android.webkit.JsResult?,
                                    ): Boolean {
                                        if (service == "Discord" && !message.isNullOrBlank() && message != "undefined") {
                                            completeDiscordToken(message)
                                        }
                                        result?.confirm()
                                        return true
                                    }
                                }

                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        request: WebResourceRequest?,
                                    ): Boolean {
                                        val nextUrl = request?.url?.toString().orEmpty()
                                        if (nextUrl.startsWith("spotify://") || nextUrl.startsWith("discord://") || nextUrl.startsWith("intent://")) {
                                            tryCompleteCookieCapture(view?.url, showNotReadyToast = false)
                                            return true
                                        }
                                        // SimpMusic Cookies.android.kt exact Discord interception:
                                        if (service == "Discord" && (nextUrl.endsWith("/app") || nextUrl.contains("/channels/"))) {
                                            view?.stopLoading()
                                            view?.loadUrl(DISCORD_TOKEN_JS_SNIPPET)
                                            return false
                                        }
                                        return false
                                    }

                                    @Deprecated("Deprecated in Java")
                                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                        val nextUrl = url.orEmpty()
                                        if (nextUrl.startsWith("spotify://") || nextUrl.startsWith("discord://") || nextUrl.startsWith("intent://")) {
                                            tryCompleteCookieCapture(view?.url, showNotReadyToast = false)
                                            return true
                                        }
                                        if (service == "Discord" && (nextUrl.endsWith("/app") || nextUrl.contains("/channels/"))) {
                                            view?.stopLoading()
                                            view?.loadUrl(DISCORD_TOKEN_JS_SNIPPET)
                                            return false
                                        }
                                        return false
                                    }

                                    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                        super.doUpdateVisitedHistory(view, url, isReload)
                                        val currentUrl = url.orEmpty()
                                        when (service) {
                                            "Discord" -> {
                                                if (currentUrl.endsWith("/app") || currentUrl.contains("/channels/")) {
                                                    view?.stopLoading()
                                                    view?.loadUrl(DISCORD_TOKEN_JS_SNIPPET)
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                            "Spotify" -> {
                                                if (SPOTIFY_STATUS_URL_REGEX.matches(currentUrl) ||
                                                    currentUrl.contains("/status") ||
                                                    currentUrl.contains("open.spotify.com")
                                                ) {
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                            "YouTube Music" -> {
                                                if (currentUrl.contains("music.youtube.com")) {
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                        }
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        isLoadingPage = false
                                        val currentUrl = url.orEmpty()

                                        when (service) {
                                            "YouTube Music" -> {
                                                if (currentUrl.contains("music.youtube.com")) {
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                            "Spotify" -> {
                                                view?.evaluateJavascript(
                                                    "(function() { var s = document.getElementById('session'); if (s && window.SimpSpotifyBridge) { window.SimpSpotifyBridge.onSpotifySessionScraped(s.innerHTML); } })();",
                                                    null
                                                )
                                                if (SPOTIFY_STATUS_URL_REGEX.matches(currentUrl) ||
                                                    currentUrl.contains("/status") ||
                                                    currentUrl.contains("open.spotify.com")
                                                ) {
                                                    if (!tryCompleteCookieCapture(currentUrl, showNotReadyToast = false) &&
                                                        !currentUrl.contains("open.spotify.com")
                                                    ) {
                                                        view?.loadUrl("https://open.spotify.com")
                                                    }
                                                }
                                            }
                                            "Discord" -> {
                                                if (currentUrl.endsWith("/app") || currentUrl.contains("/channels/")) {
                                                    view?.loadUrl(DISCORD_TOKEN_JS_SNIPPET)
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                            "Last.fm" -> {
                                                if (currentUrl.contains("/api/auth") && !lastFmAuthorizedInBrowser) {
                                                    tryCompleteCookieCapture(currentUrl, showNotReadyToast = false)
                                                }
                                            }
                                        }
                                    }
                                }

                                loadUrl(startUrl)
                            }
                        },
                        update = { view ->
                            if (service == "Last.fm" && lastFmToken != null && view.url?.contains("token=") != true) {
                                view.loadUrl(startUrl)
                            }
                        }
                    )
                }
            }
        }
    }
}
