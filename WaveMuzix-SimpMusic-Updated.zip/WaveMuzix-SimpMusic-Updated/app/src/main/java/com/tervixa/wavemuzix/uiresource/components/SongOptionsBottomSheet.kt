package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.SongArtist
import com.tervixa.wavemuzix.model.parseArtists

/**
 * SimpMusic Floating 3D Liquid Glass Song Options Bottom Sheet:
 * - **Floating in air** (`padding(horizontal = 14.dp, vertical = 12.dp)` detached from phone edges).
 * - **Increased vertical height & breathing room**: Taller header and option rows for comfortable touch targets.
 * - **Increased blur & reduced brightness** (`deepFrostedSheet = true`, `baseAlpha = 0.90f`, `blurScale = 2.65f`).
 * - **Controlled by Enable Liquid Glass setting**: Replaces with Queue screen solid grey (`Color(0xFF1C1C1E)`) when disabled.
 * - Supports screen-specific actions (`extraOptionLabel`, `extraOptionIcon`, `onExtraOptionClick`, e.g. "Remove from queue" or "Remove from playlist").
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongOptionsBottomSheet(
    song: Song,
    isFavorite: Boolean,
    isDownloaded: Boolean,
    onDismiss: () -> Unit,
    onFavoriteClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onPlayNextClick: () -> Unit,
    onAddToQueueClick: () -> Unit,
    onArtistClick: (String) -> Unit,
    onAddToPlaylistClick: () -> Unit,
    onShareClick: () -> Unit,
    isLiquidGlass: Boolean = true,
    extraOptionLabel: String? = null,
    extraOptionIcon: ImageVector? = null,
    extraOptionTint: Color = Color(0xFFFF453A),
    onExtraOptionClick: (() -> Unit)? = null,
) {
    val parsedArtists = remember(song) { song.parseArtists() }
    var showArtistSelector by remember { mutableStateOf(false) }

    if (showArtistSelector) {
        ArtistModalBottomSheet(
            artists = parsedArtists,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showArtistSelector = false },
            onSelectArtist = { selectedArtist ->
                showArtistSelector = false
                onDismiss()
                val targetId = selectedArtist.id?.takeIf { it.isNotBlank() }
                    ?: "search:${selectedArtist.name}"
                onArtistClick(targetId)
            }
        )
    }

    val floatingCardShape = RoundedCornerShape(30.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassContainer(
                        isLiquidGlass = isLiquidGlass,
                        shape = floatingCardShape,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp,
                    )
                    .clip(floatingCardShape)
                    .padding(horizontal = 18.dp, vertical = 18.dp),
            ) {
                // Drag Handle Pill
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 14.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.34f))
                )

                // Song Info Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    WaveArtworkImage(
                        url = song.thumbnailUrl,
                        videoId = song.videoId,
                        contentDescription = song.title,
                        isVideo = false,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.size(56.dp),
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(
                                    iterations = Int.MAX_VALUE,
                                    animationMode = MarqueeAnimationMode.Immediately,
                                    initialDelayMillis = 1200,
                                )
                                .focusable(),
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = song.displayArtists,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(
                                    iterations = Int.MAX_VALUE,
                                    animationMode = MarqueeAnimationMode.Immediately,
                                    initialDelayMillis = 1200,
                                )
                                .focusable(),
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    WaveHeartButton(
                        isFavorite = isFavorite,
                        onToggle = onFavoriteClick,
                        iconSize = 24.dp,
                        buttonSize = 42.dp,
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
                Spacer(modifier = Modifier.height(8.dp))

                OptionItem(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    label = if (isFavorite) "Liked" else "Like",
                    iconTint = if (isFavorite) Color(0xFFFF2D55) else MaterialTheme.colorScheme.onSurface,
                ) {
                    onFavoriteClick()
                    onDismiss()
                }

                OptionItem(
                    icon = if (isDownloaded) Icons.Rounded.DownloadDone else Icons.Rounded.DownloadForOffline,
                    label = if (isDownloaded) "Downloaded" else "Download",
                    iconTint = if (isDownloaded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                ) {
                    onDownloadClick()
                    onDismiss()
                }

                OptionItem(
                    icon = Icons.AutoMirrored.Rounded.PlaylistPlay,
                    label = "Play next",
                ) {
                    onPlayNextClick()
                    onDismiss()
                }

                OptionItem(
                    icon = Icons.AutoMirrored.Rounded.QueueMusic,
                    label = "Add to queue",
                ) {
                    onAddToQueueClick()
                    onDismiss()
                }

                OptionItem(
                    icon = WaveIcons.Artist,
                    label = if (parsedArtists.size > 1) "Artists (${parsedArtists.size})" else "View Artist",
                ) {
                    if (parsedArtists.size > 1) {
                        showArtistSelector = true
                    } else {
                        val first = parsedArtists.firstOrNull()
                        val targetId = first?.id?.takeIf { it.isNotBlank() }
                            ?: song.artistId?.takeIf { it.isNotBlank() }
                            ?: "search:${first?.name ?: song.artist}"
                        onArtistClick(targetId)
                        onDismiss()
                    }
                }

                OptionItem(
                    icon = Icons.AutoMirrored.Rounded.PlaylistAdd,
                    label = "Add to a playlist",
                ) {
                    onAddToPlaylistClick()
                }

                if (!extraOptionLabel.isNullOrBlank() && onExtraOptionClick != null) {
                    OptionItem(
                        icon = extraOptionIcon ?: Icons.Rounded.DeleteOutline,
                        label = extraOptionLabel,
                        iconTint = extraOptionTint,
                        textColor = extraOptionTint,
                    ) {
                        onExtraOptionClick()
                        onDismiss()
                    }
                }

                OptionItem(
                    icon = Icons.Rounded.Share,
                    label = "Share",
                ) {
                    onShareClick()
                }

                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

/**
 * SimpMusic Floating 3D Liquid Glass `ArtistModalBottomSheet` with increased blur & reduced brightness
 * (`deepFrostedSheet = true`) and solid Queue-screen grey fallback when Liquid Glass is disabled.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistModalBottomSheet(
    artists: List<SongArtist>,
    onDismiss: () -> Unit,
    onSelectArtist: (SongArtist) -> Unit,
    isLiquidGlass: Boolean = true,
) {
    val floatingCardShape = RoundedCornerShape(30.dp)
    WaveGlassBottomSheet(
        onDismissRequest = onDismiss,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassContainer(
                        isLiquidGlass = isLiquidGlass,
                        shape = floatingCardShape,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp,
                    )
                    .clip(floatingCardShape)
                    .padding(horizontal = 18.dp, vertical = 18.dp),
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 14.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.34f))
                )

                Text(
                    text = "Select Artist",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                )

                Spacer(modifier = Modifier.height(6.dp))

                artists.forEach { artist ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelectArtist(artist) }
                            .padding(horizontal = 10.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = WaveIcons.Artist,
                                contentDescription = artist.name,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = artist.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "View artist profile",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionItem(
    icon: ImageVector,
    label: String,
    iconTint: Color = MaterialTheme.colorScheme.onSurface,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 13.5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = label, tint = iconTint, modifier = Modifier.size(23.dp))
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            text = label,
            color = textColor,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            ),
        )
    }
}
