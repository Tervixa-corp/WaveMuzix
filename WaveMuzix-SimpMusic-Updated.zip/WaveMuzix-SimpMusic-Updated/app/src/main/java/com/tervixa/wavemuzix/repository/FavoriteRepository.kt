package com.tervixa.wavemuzix.repository

import android.content.Context
import com.tervixa.wavemuzix.data.DataBackupManager
import com.tervixa.wavemuzix.data.FirebaseSyncManager
import com.tervixa.wavemuzix.data.LastFmManager
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.data.database.FavoriteSongEntity
import com.tervixa.wavemuzix.data.database.SongDao
import com.tervixa.wavemuzix.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class FavoriteRepository(private val songDao: SongDao, private val context: Context? = null) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val favorites: Flow<List<Song>> = songDao.getAllFavorites().map { entities ->
        entities.map { it.toSong() }
    }

    suspend fun toggleFavorite(song: Song) {
        val wasFavorite = songDao.isFavorite(song.videoId)
        val entity = song.toEntity()
        if (wasFavorite) {
            songDao.deleteFavorite(entity)
        } else {
            songDao.insertFavorite(entity)
        }
        context?.let { ctx ->
            if (!wasFavorite) {
                if (SettingsManager(ctx).autoDownloadLikedSongs) {
                    val db = com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(ctx)
                    val existing = db.songDao().getDownloadByVideoId(song.videoId)
                    val alreadyDownloaded = existing != null && java.io.File(existing.filePath).exists()
                    if (!alreadyDownloaded) {
                        MusicPlayer.enqueueAutoDownloadForSong(ctx, song)
                    }
                }
                LastFmManager.setTrackLoved(ctx, song, true)
                scope.launch { FirebaseSyncManager.pushFavorite(ctx, entity) }
            } else {
                LastFmManager.setTrackLoved(ctx, song, false)
                scope.launch { FirebaseSyncManager.removeFavorite(song.videoId) }
            }
            DataBackupManager.backupAll(ctx)
            scope.launch { FirebaseSyncManager.syncToFirebase(ctx) }
        }
    }

    suspend fun isFavorite(videoId: String): Boolean {
        return songDao.isFavorite(videoId)
    }

    private fun Song.toEntity() = FavoriteSongEntity(
        videoId = videoId,
        title = title,
        artist = artist,
        thumbnailUrl = thumbnailUrl,
        artistId = artistId
    )

    private fun FavoriteSongEntity.toSong() = Song(
        id = videoId,
        title = title,
        artist = artist,
        thumbnailUrl = thumbnailUrl,
        videoId = videoId,
        artistId = artistId
    )
}
