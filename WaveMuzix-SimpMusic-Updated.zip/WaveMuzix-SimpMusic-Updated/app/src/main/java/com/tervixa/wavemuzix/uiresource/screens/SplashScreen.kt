package com.tervixa.wavemuzix.uiresource.screens

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.ui.theme.AccentPrimary
import com.tervixa.wavemuzix.ui.theme.DeepBlack
import com.tervixa.wavemuzix.uiresource.components.ExpressiveLoader
import kotlinx.coroutines.delay

/**
 * Modern + minimal Splash Screen with a fast, snappy entry time (~900ms total).
 * Features the minimalist WaveMuzix acoustic wave emblem, clean Poppins typography,
 * and the new ExpressiveLoader.
 */
@Composable
fun SplashScreen(
    onFinished: () -> Unit,
    onPreloadTrigger: () -> Unit = {},
) {
    var entered by remember { mutableStateOf(false) }

    val contentAlpha by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "splashAlpha",
    )

    val emblemScale by animateFloatAsState(
        targetValue = if (entered) 1f else 0.86f,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = 320f),
        label = "splashScale",
    )

    val waveDrawProgress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(durationMillis = 550, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)),
        label = "waveDraw",
    )

    LaunchedEffect(Unit) {
        entered = true
        // Trigger home feed preload immediately so Home opens ready
        onPreloadTrigger()
        // Short, snappy minimal entry time (~900ms)
        delay(880)
        onFinished()
    }

    val accent = MaterialTheme.colorScheme.primary.takeIf { it != Color.Unspecified } ?: AccentPrimary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack),
        contentAlignment = Alignment.Center,
    ) {
        // Subtle ambient center glow
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .alpha(contentAlpha * 0.42f),
        ) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accent.copy(alpha = 0.22f),
                        Color.Transparent,
                    ),
                    center = Offset(size.width / 2f, size.height * 0.44f),
                    radius = size.minDimension * 0.58f,
                ),
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .graphicsLayer {
                    alpha = contentAlpha
                    scaleX = emblemScale
                    scaleY = emblemScale
                },
        ) {
            // Minimalist rounded squircle emblem with the signature WaveMuzix acoustic wave
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color(0xFF17171C)),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(modifier = Modifier.size(56.dp)) {
                    val w = size.width
                    val h = size.height
                    val path = Path().apply {
                        moveTo(w * 0.08f, h * 0.55f)
                        cubicTo(
                            w * 0.18f, h * 0.36f,
                            w * 0.24f, h * 0.36f,
                            w * 0.32f, h * 0.64f,
                        )
                        cubicTo(
                            w * 0.38f, h * 0.82f,
                            w * 0.46f, h * 0.18f,
                            w * 0.54f, h * 0.26f,
                        )
                        cubicTo(
                            w * 0.62f, h * 0.34f,
                            w * 0.66f, h * 0.80f,
                            w * 0.74f, h * 0.70f,
                        )
                        cubicTo(
                            w * 0.82f, h * 0.58f,
                            w * 0.88f, h * 0.42f,
                            w * 0.94f, h * 0.46f,
                        )
                    }
                    drawPath(
                        path = path,
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.White,
                                accent,
                                Color.White.copy(alpha = 0.85f),
                            ),
                            startX = 0f,
                            endX = w * waveDrawProgress.coerceAtLeast(0.1f),
                        ),
                        style = Stroke(
                            width = 6.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round,
                        ),
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "WaveMuzix",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.3).sp,
                ),
                color = Color.White,
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Pure Sound",
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.sp,
                    letterSpacing = 1.5.sp,
                ),
                color = Color.White.copy(alpha = 0.5f),
            )
        }

        // Expressive Loader anchored cleanly near bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 72.dp)
                .alpha(contentAlpha),
        ) {
            ExpressiveLoader(
                size = 38.dp,
                color = accent,
            )
        }
    }
}
