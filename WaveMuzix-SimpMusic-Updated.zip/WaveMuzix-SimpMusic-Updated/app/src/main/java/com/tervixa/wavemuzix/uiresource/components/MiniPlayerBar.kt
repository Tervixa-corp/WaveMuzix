package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * SimpMusic 3D Glass MiniPlayerBar:
 * - Slightly taller vertical height (`58.dp`, upgraded from `53.dp`) per user request.
 * - Sculpted 3D glass border outline (`1.2.dp` multi-stop specular rim) in both Liquid Glass ON and OFF modes.
 * - Circular progress ring (`40.dp`) wrapping a `28.dp` round `WaveArtworkImage`, smooth marquee
 *   title & artist, `WaveHeartButton` burst celebration, and Play/Pause button with loading indicator.
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun MiniPlayerBar(
    isLiquidGlass: Boolean,
    modifier: Modifier = Modifier,
    isCompact: Boolean = false,
    screenTint: Color = Color.Transparent,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
    onClick: () -> Unit,
) {
    val currentSong = MusicPlayer.currentSong ?: return
    val isPlaying = MusicPlayer.isPlaying
    val isLoading = MusicPlayer.isLoading
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val performance = LocalPerformanceConfig.current
    val coroutineScope = rememberCoroutineScope()
    val interactionSource = remember { MutableInteractionSource() }
    val glassInteraction = rememberGlassInteraction()

    val progress = if (MusicPlayer.duration > 0) {
        (MusicPlayer.currentPosition.toFloat() / MusicPlayer.duration).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = ProgressIndicatorDefaults.ProgressAnimationSpec,
        label = "miniPlayerProgress",
    )

    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }
    val dismissScale = remember { Animatable(1f) }
    val dismissAlpha = remember { Animatable(1f) }
    var isDismissing by remember { mutableStateOf(false) }

    LaunchedEffect(currentSong.videoId) {
        if (isDismissing) {
            isDismissing = false
            offsetY.snapTo(0f)
            dismissScale.snapTo(1f)
            dismissAlpha.snapTo(1f)
        }
    }

    val miniPlayerShape = RoundedCornerShape(18.dp)
    val graphicsLayer = rememberGraphicsLayer()
    val useGlassSurface = isLiquidGlass && performance.isLiquidGlassEnabled
    val luminance by rememberGlassLuminance(graphicsLayer, enabled = useGlassSurface)
    val isDarkTheme = LocalIsDarkTheme.current

    val dynamicContentColor by animateColorAsState(
        targetValue = if (useGlassSurface) {
            if (isDarkTheme) Color.White else Color.Black
        } else {
            MaterialTheme.colorScheme.onSurface
        },
        animationSpec = tween(400),
        label = "MiniPlayerTextColor",
    )

    val dragFraction = (offsetY.value / 160f).coerceIn(0f, 1f)
    val dragShrinkScale = lerp(1f, 0.84f, dragFraction)
    val combinedScale = dismissScale.value * dragShrinkScale
    val combinedAlpha = (dismissAlpha.value * lerp(1f, 0.35f, (offsetY.value / 240f).coerceIn(0f, 1f))).coerceIn(0f, 1f)

    val backdrop = LocalBackdrop.current
    val isFlat = !useGlassSurface || backdrop == null
    val rimColor = if (isDarkTheme) Color.White else Color.Black

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(58.dp)
            .offset { IntOffset(0, offsetY.value.roundToInt()) }
            .graphicsLayer {
                scaleX = combinedScale
                scaleY = combinedScale
                alpha = combinedAlpha
                transformOrigin = TransformOrigin(0.5f, 1f)
                clip = false
            }
            .hoverable(interactionSource)
            .then(
                if (!isFlat && backdrop != null) {
                    Modifier.drawInteractiveGlass(
                        isDark = isDarkTheme,
                        backdrop = backdrop,
                        layer = graphicsLayer,
                        luminance = { luminance },
                        shape = miniPlayerShape,
                        interaction = glassInteraction,
                        pressedScale = 1.05f,
                        blurScale = 1.10f,
                        minScrim = 0.12f,
                        maxScrim = 0.34f,
                        accentColor = screenTint,
                        outlineAlpha = 0.22f,
                        showBorder = true,
                        borderWidth = 1.2.dp,
                    )
                } else {
                    Modifier
                        .clip(miniPlayerShape)
                        .background(MaterialTheme.colorScheme.surfaceContainer, miniPlayerShape)
                        .then(
                            if (screenTint != Color.Transparent) {
                                Modifier.background(screenTint, miniPlayerShape)
                            } else Modifier
                        )
                        .border(
                            width = 1.0.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    rimColor.copy(alpha = 0.16f),
                                    rimColor.copy(alpha = 0.05f),
                                    rimColor.copy(alpha = 0.12f),
                                ),
                                start = Offset.Zero,
                                end = Offset(800f, 180f),
                            ),
                            shape = miniPlayerShape,
                        )
                },
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    if (!isDismissing) onClick()
                },
            )
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = {},
                    onVerticalDrag = { change, dragAmount ->
                        if (isDismissing) return@detectVerticalDragGestures
                        val nextY = offsetY.value + dragAmount * 1.8f
                        if (nextY > 0f) {
                            change.consume()
                            coroutineScope.launch {
                                offsetY.snapTo(nextY)
                            }
                        } else if (nextY < -45f) {
                            change.consume()
                            onClick()
                        }
                    },
                    onDragCancel = {
                        if (!isDismissing) {
                            coroutineScope.launch {
                                launch { offsetY.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 400f)) }
                                launch { dismissScale.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 400f)) }
                            }
                        }
                    },
                    onDragEnd = {
                        if (isDismissing) return@detectVerticalDragGestures
                        coroutineScope.launch {
                            if (offsetY.value > 65f) {
                                isDismissing = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                coroutineScope {
                                    launch {
                                        dismissScale.animateTo(
                                            targetValue = 0.68f,
                                            animationSpec = spring(dampingRatio = 0.65f, stiffness = 450f),
                                        )
                                    }
                                    launch {
                                        offsetY.animateTo(
                                            targetValue = 240f,
                                            animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                                        )
                                    }
                                    launch {
                                        dismissAlpha.animateTo(
                                            targetValue = 0f,
                                            animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
                                        )
                                    }
                                }
                                MusicPlayer.stopPlayback()
                                isDismissing = false
                                offsetY.snapTo(0f)
                                dismissScale.snapTo(1f)
                                dismissAlpha.snapTo(1f)
                            } else {
                                launch {
                                    offsetY.animateTo(
                                        targetValue = 0f,
                                        animationSpec = spring(dampingRatio = 0.55f, stiffness = 380f),
                                    )
                                }
                                launch {
                                    dismissScale.animateTo(
                                        targetValue = 1f,
                                        animationSpec = spring(dampingRatio = 0.55f, stiffness = 380f),
                                    )
                                }
                            }
                        }
                    },
                )
            },
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 11.dp),
        ) {
            Box(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onDragStart = {},
                                onHorizontalDrag = { change, dragAmount ->
                                    change.consume()
                                    coroutineScope.launch {
                                        offsetX.snapTo(offsetX.value + dragAmount * 2f)
                                    }
                                },
                                onDragCancel = {
                                    coroutineScope.launch {
                                        if (offsetX.value > 200f) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            MusicPlayer.playPreviousInQueue(context)
                                        } else if (offsetX.value < -120f) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            MusicPlayer.playNextInQueue(context)
                                        }
                                        offsetX.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 350f))
                                    }
                                },
                                onDragEnd = {
                                    coroutineScope.launch {
                                        if (offsetX.value > 200f) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            MusicPlayer.playPreviousInQueue(context)
                                        } else if (offsetX.value < -120f) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            MusicPlayer.playNextInQueue(context)
                                        }
                                        offsetX.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 350f))
                                    }
                                },
                            )
                        },
                ) {
                    // Left: 40.dp CircularProgressIndicator ring wrapping 28.dp Round Artwork
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .align(Alignment.CenterVertically),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = if (isFlat) {
                                MaterialTheme.colorScheme.surfaceContainerHighest
                            } else {
                                dynamicContentColor.copy(alpha = 0.16f)
                            },
                            strokeWidth = 3.dp,
                            strokeCap = StrokeCap.Round,
                        )
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .then(
                                    if (sharedTransitionScope != null && animatedVisibilityScope != null) {
                                        with(sharedTransitionScope) {
                                            Modifier.sharedElement(
                                                rememberSharedContentState(key = "artwork"),
                                                animatedVisibilityScope = animatedVisibilityScope,
                                                boundsTransform = { _, _ ->
                                                    spring(dampingRatio = 0.5f, stiffness = 300f)
                                                },
                                                placeholderSize = SharedTransitionScope.PlaceholderSize.AnimatedSize,
                                                renderInOverlayDuringTransition = true,
                                            )
                                        }
                                    } else Modifier,
                                ),
                        ) {
                            Crossfade(
                                targetState = currentSong.thumbnailUrl,
                                animationSpec = tween(400),
                                label = "MiniPlayerArtCrossfade",
                            ) { thumbnailUrl ->
                                WaveArtworkImage(
                                    url = thumbnailUrl,
                                    contentDescription = currentSong.title,
                                    isVideo = false,
                                    shape = CircleShape,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    AnimatedContent(
                        targetState = currentSong,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.CenterStart,
                        transitionSpec = {
                            (slideInHorizontally { width -> width } + fadeIn(animationSpec = tween(350)))
                                .togetherWith(slideOutHorizontally { width -> -width } + fadeOut(animationSpec = tween(260)))
                                .using(SizeTransform(clip = false))
                        },
                        label = "SongInfoTransition",
                    ) { targetSong ->
                        Column(
                            modifier = Modifier
                                .wrapContentHeight()
                                .align(Alignment.CenterVertically),
                        ) {
                            Text(
                                text = targetSong.title,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                ),
                                color = dynamicContentColor,
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .basicMarquee(
                                        iterations = Int.MAX_VALUE,
                                        animationMode = MarqueeAnimationMode.Immediately,
                                        initialDelayMillis = 1200,
                                    )
                                    .focusable(),
                            )
                            Text(
                                text = targetSong.displayArtists.ifBlank { targetSong.artist },
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                ),
                                color = if (isFlat) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    dynamicContentColor.copy(alpha = 0.78f)
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .basicMarquee(
                                        iterations = Int.MAX_VALUE,
                                        animationMode = MarqueeAnimationMode.Immediately,
                                        initialDelayMillis = 1200,
                                    )
                                    .focusable(),
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            val isFavorite = MusicPlayer.isFavorite
            WaveHeartButton(
                isFavorite = isFavorite,
                onToggle = { MusicPlayer.toggleFavorite(context, currentSong) },
                iconSize = 22.dp,
                buttonSize = 40.dp,
                activeColor = Color(0xFFFF2D55),
                inactiveColor = dynamicContentColor,
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable { MusicPlayer.togglePlayPause(context) },
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(
                    targetState = isLoading,
                    animationSpec = tween(250),
                    label = "PlayPauseCrossfade",
                ) { loading ->
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = dynamicContentColor,
                            strokeWidth = 2.5.dp,
                            strokeCap = StrokeCap.Round,
                        )
                    } else {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = dynamicContentColor,
                            modifier = Modifier.size(27.dp),
                        )
                    }
                }
            }
        }
    }
}
