package com.tervixa.wavemuzix.uiresource.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.data.AudioFxManager
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DataBackupManager
import com.tervixa.wavemuzix.data.FirebaseSyncManager
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.uiresource.components.AmbientThemeGlow
import com.tervixa.wavemuzix.uiresource.components.BuiltInEqualizerBottomSheet
import com.tervixa.wavemuzix.uiresource.components.TutorialOverlay
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.launch

/**
 * SimpMusic's flat section structure with requested alignment:
 * - Section Headings are placed close to the left edge (`padding(start = 0.dp)` inside the list).
 * - Setting items inside each section have a clean left indentation spacing (`padding(start = 16.dp)`)
 *   and clear SimpMusic descriptions so every setting is easy to scan and understand.
 */
@Composable
fun SettingGroup(
    title: String,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    footer: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 22.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
            ),
            color = accentColor,
            modifier = Modifier.padding(
                top = 6.dp,
                bottom = 8.dp,
                start = 0.dp,
                end = 4.dp,
            ),
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp),
            content = content,
        )
        if (footer != null) {
            Box(
                Modifier.padding(
                    start = 18.dp,
                    end = 4.dp,
                    top = 6.dp,
                    bottom = 6.dp,
                ),
            ) {
                footer()
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f),
            thickness = 0.5.dp,
        )
    }
}

/**
 * SimpMusic's flat `SettingItem` row:
 * Indented cleanly from the section heading with a clear title + descriptive subtitle (`description`).
 */
@Composable
fun SimpSettingItem(
    title: String,
    subtitle: String? = null,
    smallSubtitle: Boolean = false,
    isEnable: Boolean = true,
    onClick: (() -> Unit)? = null,
    switch: Pair<Boolean, (Boolean) -> Unit>? = null,
    otherView: @Composable (() -> Unit)? = null,
) {
    val disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .then(
                if (onClick != null && isEnable) {
                    Modifier.clickable { onClick.invoke() }
                } else if (switch != null && isEnable) {
                    Modifier.clickable { switch.second.invoke(!switch.first) }
                } else {
                    Modifier
                },
            ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 12.dp,
                    horizontal = 6.dp,
                ),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start,
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                    ),
                    color = if (isEnable) MaterialTheme.colorScheme.onSurface else disabledContentColor,
                )
                if (!subtitle.isNullOrEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = if (smallSubtitle) {
                            MaterialTheme.typography.bodySmall
                        } else {
                            MaterialTheme.typography.bodyMedium
                        },
                        color = if (isEnable) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            disabledContentColor
                        },
                    )
                }
                otherView?.let {
                    Spacer(Modifier.height(14.dp))
                    it.invoke()
                }
            }
            if (switch != null) {
                Spacer(Modifier.width(12.dp))
                Switch(
                    modifier = Modifier.wrapContentWidth(),
                    checked = switch.first,
                    onCheckedChange = { switch.second.invoke(it) },
                    enabled = isEnable,
                )
            }
        }
    }
}

@Composable
fun AccentColorPickerDialog(
    current: Color,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (Color) -> Unit,
) {
    val colors = listOf(
        Color(0xFFFF2D55),
        Color(0xFFFF3B30),
        Color(0xFFFF9500),
        Color(0xFFFFCC00),
        Color(0xFF34C759),
        Color(0xFF00C7BE),
        Color(0xFF30B0C7),
        Color(0xFF32ADE6),
        Color(0xFF007AFF),
        Color(0xFF5856D6),
        Color(0xFFAF52DE),
        Color(0xFF8ECAE6),
        Color(0xFF4C82EF),
        Color(0xFFA2845E),
        Color(0xFF8E8E93),
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Accent Colour", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 52.dp),
                modifier = Modifier.height(260.dp),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                flingBehavior = rememberSmoothFlingBehavior(),
            ) {
                items(colors) { color ->
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (color == current) 3.dp else if (isLiquidGlass) 0.dp else 1.dp,
                                color = if (color == current) Color.White else Color.White.copy(alpha = 0.2f),
                                shape = CircleShape,
                            )
                            .clickable { onSelect(color) },
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.Gray) }
        },
        containerColor = if (isLiquidGlass) Color(0xE618181B) else Color(0xFF1A1A1A),
        shape = RoundedCornerShape(28.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingTopBar(
    title: String = "Settings",
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    TopAppBar(
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                ),
                color = MaterialTheme.colorScheme.onSurface,
            )
        },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent,
        ),
        modifier = modifier,
    )
}

@OptIn(androidx.media3.common.util.UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onAccentColorChange: (Color) -> Unit,
    onLiquidGlassChange: (Boolean) -> Unit,
    onUpdateTrigger: () -> Unit = {},
    onManageAccountClick: () -> Unit,
    onNavigateToPlayer: () -> Unit = {},
    isLiquidGlass: Boolean = false,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }
    var showSettingsTutorial by remember { mutableStateOf(!settingsManager.hasSeenSettingsTutorial) }
    val scope = rememberCoroutineScope()

    var liquidGlassEnabled by remember { mutableStateOf(settingsManager.isLiquidGlass) }
    var translucentBarEnabled by remember { mutableStateOf(settingsManager.translucentBottomBar) }
    var blurPlayerBg by remember { mutableStateOf(settingsManager.blurPlayerBackground) }
    var playerType by remember { mutableStateOf(settingsManager.playerType) }
    var themeMode by remember { mutableStateOf(settingsManager.themeMode) }
    var themeColorSource by remember { mutableStateOf(settingsManager.themeColorSource) }
    var accentColorInt by remember { mutableIntStateOf(settingsManager.accentColor) }
    val accentColor = Color(accentColorInt)
    var isAmbientEnabled by remember { mutableStateOf(settingsManager.isAmbientBackgroundEnabled) }
    var keepScreenOn by remember { mutableStateOf(settingsManager.isKeepScreenOn) }

    var contentCountry by remember { mutableStateOf(settingsManager.contentCountry) }
    var preferredAudioLanguage by remember { mutableStateOf(settingsManager.preferredAudioLanguage) }
    var streamingQuality by remember { mutableStateOf(settingsManager.streamingQuality) }
    var downloadQuality by remember { mutableStateOf(settingsManager.downloadQuality) }
    var downloadThreads by remember { mutableIntStateOf(settingsManager.downloadThreads) }
    var autoDownloadLiked by remember { mutableStateOf(settingsManager.autoDownloadLikedSongs) }
    var smartDownloadsEnabled by remember { mutableStateOf(settingsManager.smartDownloadsEnabled) }
    var smartDownloadsCount by remember { mutableIntStateOf(settingsManager.smartDownloadsCount) }
    var explicitContentEnabled by remember { mutableStateOf(settingsManager.explicitContentEnabled) }
    var sendBackToGoogle by remember { mutableStateOf(settingsManager.sendBackToGoogle) }
    var usingProxy by remember { mutableStateOf(settingsManager.usingProxy) }
    var proxyType by remember { mutableStateOf(settingsManager.proxyType) }
    var proxyHost by remember { mutableStateOf(settingsManager.proxyHost) }
    var proxyPort by remember { mutableIntStateOf(settingsManager.proxyPort) }

    val cookieManager = remember { CookieManager(context) }
    var isYtmConnected by remember { mutableStateOf(settingsManager.isYouTubeMusicConnected || !cookieManager.getCookies().isNullOrBlank()) }
    var ytmAccountName by remember { mutableStateOf(settingsManager.ytmAccountName) }
    var isSpotifyConnected by remember { mutableStateOf(settingsManager.isSpotifyConnected) }
    var spotifySpDc by remember { mutableStateOf(settingsManager.spotifySpDcCookie) }
    var isSpotifyMetadataEnabled by remember { mutableStateOf(settingsManager.isSpotifyMetadataEnabled) }
    var isSpotifyCanvasEnabled by remember { mutableStateOf(settingsManager.isSpotifyCanvasEnabled) }
    var isLastFmConnected by remember { mutableStateOf(settingsManager.isLastFmConnected) }
    var lastFmUsername by remember { mutableStateOf(settingsManager.lastFmUsername) }
    var isDiscordConnected by remember { mutableStateOf(settingsManager.isDiscordConnected) }
    var discordToken by remember { mutableStateOf(settingsManager.discordToken) }
    var activeConnectDialog by remember { mutableStateOf<String?>(null) }

    var isNormalizeVolume by remember { mutableStateOf(settingsManager.isNormalizeVolume) }
    var isPeakLimiterEnabled by remember { mutableStateOf(settingsManager.isPeakLimiterEnabled) }
    var isGaplessEnabled by remember { mutableStateOf(settingsManager.isGaplessRenderingEnabled) }
    var isDvcEnabled by remember { mutableStateOf(settingsManager.isDirectVolumeControlEnabled) }
    var isSkipSilenceEnabled by remember { mutableStateOf(settingsManager.isSkipSilenceEnabled) }
    var equalizerType by remember { mutableStateOf(settingsManager.equalizerType) }

    var isSavePlaybackState by remember { mutableStateOf(settingsManager.isSavePlaybackState) }
    var isSaveLastPlayed by remember { mutableStateOf(settingsManager.isSaveLastPlayed) }
    var isKeepServiceAlive by remember { mutableStateOf(settingsManager.isKeepServiceAlive) }
    var isCrossfadeEnabled by remember { mutableStateOf(settingsManager.isCrossfadeEnabled) }
    var crossfadeDurationSeconds by remember { mutableIntStateOf(settingsManager.crossfadeDurationSeconds) }
    var crossfadeDjMode by remember { mutableStateOf(settingsManager.crossfadeDjMode) }
    var crossfadeSkipAlbum by remember { mutableStateOf(settingsManager.crossfadeSkipAlbum) }

    var isSponsorBlockEnabled by remember { mutableStateOf(settingsManager.isSponsorBlockEnabled) }
    var skipSponsorMentions by remember { mutableStateOf(settingsManager.skipSponsorMentions) }
    var skipIntroOutro by remember { mutableStateOf(settingsManager.skipIntroOutro) }
    var skipNonMusicSkits by remember { mutableStateOf(settingsManager.skipNonMusicSkits) }
    var networkBufferSizeMs by remember { mutableLongStateOf(settingsManager.networkBufferSizeMs) }
    var isDataSaverEnabled by remember { mutableStateOf(settingsManager.isDataSaverEnabled) }
    var isPlayVideoIfAvailable by remember { mutableStateOf(settingsManager.isPlayVideoIfAvailable) }
    var preferredVideoQuality by remember { mutableStateOf(settingsManager.preferredVideoQuality) }
    var radioAudioOnly by remember { mutableStateOf(settingsManager.radioAudioOnly) }

    var lyricsProvider by remember { mutableStateOf(settingsManager.lyricsProvider) }
    var lyricsStyle by remember { mutableStateOf(settingsManager.lyricsStyle) }
    var lyricsRomanization by remember { mutableStateOf(settingsManager.lyricsRomanization) }
    var lyricsOffsetMs by remember { mutableIntStateOf(settingsManager.lyricsOffsetMs) }
    var translationLanguage by remember { mutableStateOf(settingsManager.translationLanguage) }

    var limitPlayerCacheMb by remember { mutableIntStateOf(settingsManager.limitPlayerCacheMb) }
    var autoBackupEnabled by remember { mutableStateOf(settingsManager.autoBackupEnabled) }
    var autoBackupFrequency by remember { mutableStateOf(settingsManager.autoBackupFrequency) }
    var autoCheckUpdate by remember { mutableStateOf(settingsManager.autoCheckUpdate) }

    var cacheSizeMb by remember {
        mutableStateOf(
            try {
                val bytes = context.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                String.format("%.1f MB", bytes / (1024.0 * 1024.0))
            } catch (_: Exception) {
                "0.0 MB"
            },
        )
    }

    var showColorPicker by remember { mutableStateOf(false) }
    var showPlayerTypeDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showThemeColorSourceDialog by remember { mutableStateOf(false) }
    var showCountryDialog by remember { mutableStateOf(false) }
    var showLanguageSelection by remember { mutableStateOf(false) }
    var showArtistSelection by remember { mutableStateOf(false) }
    var showStreamingQualityDialog by remember { mutableStateOf(false) }
    var showDownloadQualityDialog by remember { mutableStateOf(false) }
    var showThreadsDialog by remember { mutableStateOf(false) }
    var showSmartDownloadsDialog by remember { mutableStateOf(false) }
    var showEqualizerTypeDialog by remember { mutableStateOf(false) }
    var showCrossfadeDurationDialog by remember { mutableStateOf(false) }
    var showBufferDialog by remember { mutableStateOf(false) }
    var showVideoQualityDialog by remember { mutableStateOf(false) }
    var showLyricsProviderDialog by remember { mutableStateOf(false) }
    var showLyricsStyleDialog by remember { mutableStateOf(false) }
    var showLyricsOffsetDialog by remember { mutableStateOf(false) }
    var showCacheLimitDialog by remember { mutableStateOf(false) }
    var showBackupFrequencyDialog by remember { mutableStateOf(false) }
    var showProxyDialog by remember { mutableStateOf(false) }

    fun syncSettings() {
        scope.launch {
            FirebaseSyncManager.syncToFirebase(context)
        }
    }

    val lazyListState = rememberLazyListState()
    val hazeState = remember { HazeState() }
    val statusBarTopDp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val atTop by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex == 0 && lazyListState.firstVisibleItemScrollOffset < 16
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = hazeState)
                .background(MaterialTheme.colorScheme.background),
        ) {
            AmbientThemeGlow(
                tint = accentColor,
                scrollState = lazyListState,
            )

            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(
                    top = statusBarTopDp + 64.dp,
                    bottom = 190.dp,
                ),
                flingBehavior = rememberSmoothFlingBehavior(),
            ) {
                // GROUP 1: USER INTERFACE & APPEARANCE
                item(key = "group_ui") {
                    SettingGroup(
                        title = "User Interface & Appearance",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Translucent Bottom & Top Bars",
                            subtitle = "Enable frosted Haze blur across the bottom navigation bar, mini player, and top headers",
                            smallSubtitle = true,
                            switch = translucentBarEnabled to {
                                translucentBarEnabled = it
                                settingsManager.translucentBottomBar = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Enable Liquid Glass Effect",
                            subtitle = "3D refractive lens optics, vibrancy saturation, specular borders, and fluid spring motion",
                            smallSubtitle = true,
                            switch = liquidGlassEnabled to {
                                liquidGlassEnabled = it
                                settingsManager.isLiquidGlass = it
                                onLiquidGlassChange(it)
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Now Playing / Player Screen Design",
                            subtitle = "$playerType • Choose between SimpMusic Classic or Material 3 Expressive player layout",
                            smallSubtitle = true,
                            onClick = { showPlayerTypeDialog = true },
                        )
                        SimpSettingItem(
                            title = "Theme Mode",
                            subtitle = themeMode,
                            smallSubtitle = true,
                            onClick = { showThemeDialog = true },
                        )
                        SimpSettingItem(
                            title = "Theme Colour Source",
                            subtitle = themeColorSource,
                            smallSubtitle = true,
                            onClick = { showThemeColorSourceDialog = true },
                        )
                        SimpSettingItem(
                            title = "Accent Colour",
                            subtitle = "#${Integer.toHexString(accentColorInt).uppercase().takeLast(6)}",
                            smallSubtitle = true,
                            onClick = { showColorPicker = true },
                        )
                        SimpSettingItem(
                            title = "Ambient Universe Background",
                            subtitle = "Render dynamic artwork-tinted fluid gradients behind the player and main screens",
                            smallSubtitle = true,
                            switch = isAmbientEnabled to {
                                isAmbientEnabled = it
                                settingsManager.isAmbientBackgroundEnabled = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Blur Player Background",
                            subtitle = "Apply progressive artwork blur and smoothstep tint on Now Playing",
                            smallSubtitle = true,
                            switch = blurPlayerBg to {
                                blurPlayerBg = it
                                settingsManager.blurPlayerBackground = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Keep Screen On",
                            subtitle = null,
                            switch = keepScreenOn to {
                                keepScreenOn = it
                                settingsManager.isKeepScreenOn = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                    }
                }

                // GROUP 1.5: CONNECT TO WAVE (Real SimpMusic WebView Login UI + Hidden Spotify Scraper)
                item(key = "group_connect_to_wave") {
                    SettingGroup(
                        title = "Connect To Wave",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "YouTube Music",
                            subtitle = if (isYtmConnected) {
                                "Connected" + (if (ytmAccountName.isNotBlank()) " • $ytmAccountName" else " • Syncing personalized mixes & library")
                            } else {
                                "Sign in with Google WebView to sync your YouTube Music library, mixes & history"
                            },
                            smallSubtitle = true,
                            onClick = { activeConnectDialog = "YouTube Music" },
                        )
                        SimpSettingItem(
                            title = "Spotify",
                            subtitle = if (isSpotifyConnected) {
                                "Connected • Hidden Spotify session scraper & sp_dc active"
                            } else {
                                "Log in with Spotify WebView (or use built-in hidden Spotify scraper) for multi-singer credits & Canvas"
                            },
                            smallSubtitle = true,
                            onClick = { activeConnectDialog = "Spotify" },
                        )
                        SimpSettingItem(
                            title = "Spotify Metadata Fetching",
                            subtitle = "Automatically enrich tracks with true singer names, HD cover art, and exact durations via Spotify",
                            smallSubtitle = true,
                            switch = isSpotifyMetadataEnabled to {
                                isSpotifyMetadataEnabled = it
                                settingsManager.isSpotifyMetadataEnabled = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Spotify Canvas",
                            subtitle = "Fetch looping visual canvas clips when available from Spotify",
                            smallSubtitle = true,
                            switch = isSpotifyCanvasEnabled to {
                                isSpotifyCanvasEnabled = it
                                settingsManager.isSpotifyCanvasEnabled = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Last.fm Scrobbling",
                            subtitle = if (isLastFmConnected && lastFmUsername.isNotBlank()) {
                                "Connected as @$lastFmUsername • Live Now Playing, Scrobbling & Loved Tracks active"
                            } else {
                                "Log in with Last.fm to broadcast Now Playing, scrobble tracks, and sync Loved Songs"
                            },
                            smallSubtitle = true,
                            onClick = { activeConnectDialog = "Last.fm" },
                        )
                        SimpSettingItem(
                            title = "Discord Rich Presence",
                            subtitle = if (isDiscordConnected) {
                                "Connected • Broadcasting live Now Playing status to Discord"
                            } else {
                                "Log in with Discord WebView to display your live listening activity on your profile"
                            },
                            smallSubtitle = true,
                            onClick = { activeConnectDialog = "Discord" },
                        )
                    }
                }

                // GROUP 2: ACCOUNT & CONTENT
                item(key = "group_content") {
                    SettingGroup(
                        title = "Account & Content",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Manage Account",
                            subtitle = null,
                            onClick = onManageAccountClick,
                        )
                        SimpSettingItem(
                            title = "Content Country",
                            subtitle = contentCountry,
                            smallSubtitle = true,
                            onClick = { showCountryDialog = true },
                        )
                        SimpSettingItem(
                            title = "Content Languages",
                            subtitle = settingsManager.selectedLanguages.joinToString(", ") { it.replaceFirstChar { c -> c.uppercase() } },
                            smallSubtitle = true,
                            onClick = { showLanguageSelection = true },
                        )
                        SimpSettingItem(
                            title = "Preferred Audio Language",
                            subtitle = preferredAudioLanguage,
                            smallSubtitle = true,
                            onClick = {
                                val nextLang = when (preferredAudioLanguage) {
                                    "Original Audio" -> "English (en)"
                                    "English (en)" -> "Hindi (hi)"
                                    "Hindi (hi)" -> "Malayalam (ml)"
                                    else -> "Original Audio"
                                }
                                preferredAudioLanguage = nextLang
                                settingsManager.preferredAudioLanguage = nextLang
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Artist Selection",
                            subtitle = null,
                            onClick = { showArtistSelection = true },
                        )
                        SimpSettingItem(
                            title = "Streaming Audio Quality",
                            subtitle = streamingQuality,
                            smallSubtitle = true,
                            onClick = { showStreamingQualityDialog = true },
                        )
                        SimpSettingItem(
                            title = "Download Quality",
                            subtitle = downloadQuality,
                            smallSubtitle = true,
                            onClick = { showDownloadQualityDialog = true },
                        )
                        SimpSettingItem(
                            title = "Download Threads",
                            subtitle = "$downloadThreads Threads • Number of parallel chunks used by the download engine",
                            smallSubtitle = true,
                            onClick = { showThreadsDialog = true },
                        )
                        SimpSettingItem(
                            title = "Auto Download Liked Songs",
                            subtitle = "Automatically download any song to offline storage as soon as you tap the heart icon",
                            smallSubtitle = true,
                            switch = autoDownloadLiked to {
                                autoDownloadLiked = it
                                settingsManager.autoDownloadLikedSongs = it
                                if (it) {
                                    MusicPlayer.triggerAutoDownloadLikedSongs(context)
                                }
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Smart Downloads",
                            subtitle = "Automatically download your most played songs in the background for offline listening",
                            smallSubtitle = true,
                            switch = smartDownloadsEnabled to {
                                smartDownloadsEnabled = it
                                settingsManager.smartDownloadsEnabled = it
                                if (it) {
                                    MusicPlayer.triggerSmartDownloads(context)
                                }
                                syncSettings()
                            },
                        )
                        AnimatedVisibility(visible = smartDownloadsEnabled) {
                            SimpSettingItem(
                                title = "Smart Downloads Limit",
                                subtitle = "$smartDownloadsCount songs • Maximum number of top tracks to keep cached offline",
                                smallSubtitle = true,
                                onClick = { showSmartDownloadsDialog = true },
                            )
                        }
                        SimpSettingItem(
                            title = "Play Explicit Content",
                            subtitle = null,
                            switch = explicitContentEnabled to {
                                explicitContentEnabled = it
                                settingsManager.explicitContentEnabled = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Send Back Listening Data to YouTube",
                            subtitle = "Report playback progress to YouTube Music to improve your personalized mixes",
                            smallSubtitle = true,
                            switch = sendBackToGoogle to {
                                sendBackToGoogle = it
                                settingsManager.sendBackToGoogle = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Proxy",
                            subtitle = if (usingProxy) "$proxyType · $proxyHost:$proxyPort" else "Route streaming and metadata traffic through a custom HTTP or SOCKS proxy",
                            smallSubtitle = true,
                            switch = usingProxy to {
                                usingProxy = it
                                settingsManager.usingProxy = it
                                syncSettings()
                            },
                        )
                        Crossfade(targetState = usingProxy, label = "proxyCrossfade") { enabled ->
                            if (enabled) {
                                SimpSettingItem(
                                    title = "Configure Proxy Server",
                                    subtitle = "$proxyType://$proxyHost:$proxyPort",
                                    smallSubtitle = true,
                                    onClick = { showProxyDialog = true },
                                )
                            }
                        }
                    }
                }

                // GROUP 3: NEXT-GEN AUDIO ENGINE (3D Surround Virtualizer removed per user request)
                item(key = "group_audio") {
                    SettingGroup(
                        title = "Next-Gen Audio Engine",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Limit Volume (Normalize Loudness)",
                            subtitle = "Balance loudness differences across tracks so quiet and loud songs play at a consistent level",
                            smallSubtitle = true,
                            switch = isNormalizeVolume to {
                                isNormalizeVolume = it
                                settingsManager.isNormalizeVolume = it
                                MusicPlayer.updateAudioEffects()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Anti-Clip Peak Limiter",
                            subtitle = "Hardware dynamics limiter that prevents distortion during bass boost or EQ gain",
                            smallSubtitle = true,
                            switch = isPeakLimiterEnabled to {
                                isPeakLimiterEnabled = it
                                settingsManager.isPeakLimiterEnabled = it
                                MusicPlayer.updateAudioEffects()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Seamless Gapless Playback",
                            subtitle = "Pre-buffer upcoming queue tracks in ExoPlayer for zero-silence transitions",
                            smallSubtitle = true,
                            switch = isGaplessEnabled to {
                                isGaplessEnabled = it
                                settingsManager.isGaplessRenderingEnabled = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Direct Volume Control (Hi-Res DVC)",
                            subtitle = "Bypass system notification ducking for uninterrupted high-resolution audio output",
                            smallSubtitle = true,
                            switch = isDvcEnabled to {
                                isDvcEnabled = it
                                settingsManager.isDirectVolumeControlEnabled = it
                                MusicPlayer.updateDvcState()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Skip Non-Music Silence",
                            subtitle = "Cut non-music dead air at track boundaries without speeding up beats or musical pauses",
                            smallSubtitle = true,
                            switch = isSkipSilenceEnabled to {
                                isSkipSilenceEnabled = it
                                settingsManager.isSkipSilenceEnabled = it
                                MusicPlayer.skipSilenceEnabled = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Equalizer Engine",
                            subtitle = "$equalizerType • Choose between WaveMuzix's built-in 10-band AudioFX or system equalizer",
                            smallSubtitle = true,
                            onClick = { showEqualizerTypeDialog = true },
                        )
                        SimpSettingItem(
                            title = "Open Wave AudioFX Equalizer",
                            subtitle = "Configure 10-band graphic EQ, 22 SimpMusic presets, Bass Boost, and Preamp gain",
                            smallSubtitle = true,
                            onClick = {
                                MusicPlayer.openEqualizer(context)
                            },
                        )
                    }
                }

                // GROUP 4: PLAYBACK & CROSSFADE (Audio Visualizer removed per user request)
                item(key = "group_playback") {
                    SettingGroup(
                        title = "Playback & Crossfade",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Save Playback State",
                            subtitle = "Save exact millisecond song timestamp, cached audio stream, and queue so playback resumes instantly on reopen",
                            smallSubtitle = true,
                            switch = isSavePlaybackState to {
                                isSavePlaybackState = it
                                settingsManager.isSavePlaybackState = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Save Last Played",
                            subtitle = null,
                            switch = isSaveLastPlayed to {
                                isSaveLastPlayed = it
                                settingsManager.isSaveLastPlayed = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Keep Service Alive",
                            subtitle = "Keep background media playback service active when swiping the app away",
                            smallSubtitle = true,
                            switch = isKeepServiceAlive to {
                                isKeepServiceAlive = it
                                settingsManager.isKeepServiceAlive = it
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Crossfade",
                            subtitle = "Smoothly overlap the end of the outgoing song with the pre-buffered incoming song",
                            smallSubtitle = true,
                            switch = isCrossfadeEnabled to {
                                isCrossfadeEnabled = it
                                settingsManager.isCrossfadeEnabled = it
                                MusicPlayer.updateCrossfadeState(context)
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        AnimatedVisibility(visible = isCrossfadeEnabled) {
                            Column {
                                SimpSettingItem(
                                    title = "Crossfade DJ Mode",
                                    subtitle = "Seamless club-style blend without volume fade dips, using midpoint EQ bass handoff",
                                    smallSubtitle = true,
                                    switch = crossfadeDjMode to {
                                        crossfadeDjMode = it
                                        settingsManager.crossfadeDjMode = it
                                        if (it) {
                                            isSkipSilenceEnabled = true
                                            settingsManager.isSkipSilenceEnabled = true
                                            MusicPlayer.skipSilenceEnabled = true
                                        }
                                        MusicPlayer.updateCrossfadeState(context)
                                        syncSettings()
                                    },
                                )
                                SimpSettingItem(
                                    title = "Skip Crossfade Within Same Album",
                                    subtitle = "Use natural gapless transitions when consecutive tracks belong to the same album",
                                    smallSubtitle = true,
                                    switch = crossfadeSkipAlbum to {
                                        crossfadeSkipAlbum = it
                                        settingsManager.crossfadeSkipAlbum = it
                                        syncSettings()
                                    },
                                )
                            }
                        }
                    }
                }

                // GROUP 5: EXTREME CONTROL (THE COCKPIT) & SPONSORBLOCK
                item(key = "group_cockpit") {
                    SettingGroup(
                        title = "Extreme Control (The Cockpit) & SponsorBlock",
                        accentColor = accentColor,
                        footer = {
                            Text(
                                text = "SponsorBlock crowd-sourced segment data provided by https://sponsor.ajay.app/",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            )
                        },
                    ) {
                        SimpSettingItem(
                            title = "Enable SponsorBlock (NEXT_SYNC)",
                            subtitle = "Automatically trim and bypass non-music segments on video tracks before playback starts",
                            smallSubtitle = true,
                            switch = isSponsorBlockEnabled to {
                                isSponsorBlockEnabled = it
                                settingsManager.isSponsorBlockEnabled = it
                                MusicPlayer.updateSponsorBlockSettings()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Skip Sponsor Mentions",
                            subtitle = "Bypass paid promotions and sponsor segments inside music videos",
                            smallSubtitle = true,
                            isEnable = isSponsorBlockEnabled,
                            switch = skipSponsorMentions to {
                                skipSponsorMentions = it
                                settingsManager.skipSponsorMentions = it
                                MusicPlayer.updateSponsorBlockSettings()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Skip Intro / Outro Silence",
                            subtitle = "Bypass long video intros, intermissions, and endcards",
                            smallSubtitle = true,
                            isEnable = isSponsorBlockEnabled,
                            switch = skipIntroOutro to {
                                skipIntroOutro = it
                                settingsManager.skipIntroOutro = it
                                MusicPlayer.updateSponsorBlockSettings()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        SimpSettingItem(
                            title = "Skip Non-Music Skits & Dialogues",
                            subtitle = "Bypass acting skits and dialogue tangents in official music videos",
                            smallSubtitle = true,
                            isEnable = isSponsorBlockEnabled,
                            switch = skipNonMusicSkits to {
                                skipNonMusicSkits = it
                                settingsManager.skipNonMusicSkits = it
                                MusicPlayer.updateSponsorBlockSettings()
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        val currentBufferLabel = when (networkBufferSizeMs) {
                            0L -> "AI Auto (Adaptive)"
                            10000L -> "Low Latency (10s)"
                            30000L -> "Balanced (30s)"
                            45000L -> "Stable (45s)"
                            60000L -> "Extreme Cache (60s)"
                            else -> "AI Auto (Adaptive)"
                        }
                        SimpSettingItem(
                            title = "Network Buffer Size",
                            subtitle = "$currentBufferLabel • Amount of audio preloaded into memory ahead of playback",
                            smallSubtitle = true,
                            onClick = { showBufferDialog = true },
                        )
                        SimpSettingItem(
                            title = "Data Saver Mode",
                            subtitle = "Reduce stream bitrate and disable background video streams on cellular networks",
                            smallSubtitle = true,
                            switch = isDataSaverEnabled to {
                                isDataSaverEnabled = it
                                settingsManager.isDataSaverEnabled = it
                                if (it) {
                                    isPlayVideoIfAvailable = false
                                    settingsManager.isPlayVideoIfAvailable = false
                                }
                                syncSettings()
                                onUpdateTrigger()
                            },
                        )
                        AnimatedVisibility(visible = !isDataSaverEnabled) {
                            SimpSettingItem(
                                title = "Preferred Video Quality",
                                subtitle = preferredVideoQuality,
                                smallSubtitle = true,
                                onClick = { showVideoQualityDialog = true },
                            )
                        }
                        SimpSettingItem(
                            title = "Radio Audio Only",
                            subtitle = "Prefer official 1:1 album audio tracks over music videos when curating endless radio queues",
                            smallSubtitle = true,
                            switch = radioAudioOnly to {
                                radioAudioOnly = it
                                settingsManager.radioAudioOnly = it
                                syncSettings()
                            },
                        )
                    }
                }

                // GROUP 6: LYRICS & ROMANIZATION
                item(key = "group_lyrics") {
                    SettingGroup(
                        title = "Lyrics & Translation",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Main Lyrics Provider",
                            subtitle = "$lyricsProvider • Primary source for word-synced and line-synced lyrics",
                            smallSubtitle = true,
                            onClick = { showLyricsProviderDialog = true },
                        )
                        SimpSettingItem(
                            title = "Lyrics Style",
                            subtitle = lyricsStyle,
                            smallSubtitle = true,
                            onClick = { showLyricsStyleDialog = true },
                        )
                        SimpSettingItem(
                            title = "Lyrics Romanization",
                            subtitle = "Automatically transliterate non-Latin scripts (Hindi, Malayalam, Japanese, Korean) into Latin phonetics",
                            smallSubtitle = true,
                            switch = lyricsRomanization to {
                                lyricsRomanization = it
                                settingsManager.lyricsRomanization = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Lyrics Offset",
                            subtitle = "${if (lyricsOffsetMs > 0) "+$lyricsOffsetMs ms" else "$lyricsOffsetMs ms"} • Fine-tune lyric synchronization timing",
                            smallSubtitle = true,
                            onClick = { showLyricsOffsetDialog = true },
                        )
                        SimpSettingItem(
                            title = "Translation Language",
                            subtitle = translationLanguage.uppercase(),
                            smallSubtitle = true,
                            onClick = {
                                val nextTrans = when (translationLanguage) {
                                    "en" -> "hi"
                                    "hi" -> "ml"
                                    "ml" -> "es"
                                    "es" -> "ja"
                                    else -> "en"
                                }
                                translationLanguage = nextTrans
                                settingsManager.translationLanguage = nextTrans
                                syncSettings()
                            },
                        )
                    }
                }

                // GROUP 7: STORAGE & CLOUD BACKUP (Local Listening History Tracking toggle removed; permanently ON by default)
                item(key = "group_storage_backup") {
                    SettingGroup(
                        title = "Storage & Cloud Backup",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Player & Thumbnail Cache",
                            subtitle = "$cacheSizeMb · Tap to clear temporary cached thumbnails and streams",
                            smallSubtitle = true,
                            onClick = {
                                try {
                                    context.cacheDir.deleteRecursively()
                                    cacheSizeMb = "0.0 MB"
                                    Toast.makeText(context, "Cache cleared", Toast.LENGTH_SHORT).show()
                                } catch (_: Exception) {}
                            },
                        )
                        SimpSettingItem(
                            title = "Limit Player Cache Size",
                            subtitle = "${if (limitPlayerCacheMb >= 1024) "${limitPlayerCacheMb / 1024} GB" else "$limitPlayerCacheMb MB"} • Maximum disk space reserved for instant song resume caching",
                            smallSubtitle = true,
                            onClick = { showCacheLimitDialog = true },
                        )
                        SimpSettingItem(
                            title = "Auto Cloud & Local Backup",
                            subtitle = "Automatically back up all settings, analytics, listening history, liked songs, most played, followed artists, and playlists to Firebase Cloud",
                            smallSubtitle = true,
                            switch = autoBackupEnabled to {
                                autoBackupEnabled = it
                                settingsManager.autoBackupEnabled = it
                                syncSettings()
                            },
                        )
                        AnimatedVisibility(visible = autoBackupEnabled) {
                            SimpSettingItem(
                                title = "Backup Frequency",
                                subtitle = autoBackupFrequency,
                                smallSubtitle = true,
                                onClick = { showBackupFrequencyDialog = true },
                            )
                        }
                        SimpSettingItem(
                            title = "Backup Now",
                            subtitle = null,
                            onClick = {
                                scope.launch {
                                    DataBackupManager.backupAll(context)
                                    FirebaseSyncManager.syncToFirebase(context)
                                    Toast.makeText(context, "Full cloud & local backup completed", Toast.LENGTH_SHORT).show()
                                }
                            },
                        )
                        SimpSettingItem(
                            title = "Restore Saved Data",
                            subtitle = null,
                            onClick = {
                                scope.launch {
                                    DataBackupManager.restoreAll(context)
                                    FirebaseSyncManager.syncFromFirebase(context)
                                    Toast.makeText(context, "Backup restored", Toast.LENGTH_SHORT).show()
                                }
                            },
                        )
                    }
                }

                // GROUP 8: CONTACT US
                item(key = "group_contact") {
                    SettingGroup(
                        title = "Contact Us",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Email Support",
                            subtitle = "hritvikkrishnansajeev@gmail.com • Direct developer support",
                            smallSubtitle = true,
                            onClick = {
                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:hritvikkrishnansajeev@gmail.com")
                                }
                                context.startActivity(intent)
                            },
                        )
                        SimpSettingItem(
                            title = "Email WaveMuzix",
                            subtitle = "wavemuzix@gmail.com • Official inquiries & feedback",
                            smallSubtitle = true,
                            onClick = {
                                val intent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:wavemuzix@gmail.com")
                                }
                                context.startActivity(intent)
                            },
                        )
                        SimpSettingItem(
                            title = "WhatsApp",
                            subtitle = "+91 75111 55295 • Chat with WaveMuzix support",
                            smallSubtitle = true,
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    data = Uri.parse("https://api.whatsapp.com/send?phone=917511155295")
                                }
                                context.startActivity(intent)
                            },
                        )
                    }
                }

                // GROUP 9: ABOUT US
                item(key = "group_about") {
                    SettingGroup(
                        title = "About Us",
                        accentColor = accentColor,
                    ) {
                        SimpSettingItem(
                            title = "Version",
                            subtitle = "v1.0.0 (stable) • SimpMusic Next-Gen Engine",
                            smallSubtitle = true,
                        )
                        SimpSettingItem(
                            title = "Auto Check for Updates",
                            subtitle = null,
                            switch = autoCheckUpdate to {
                                autoCheckUpdate = it
                                settingsManager.autoCheckUpdate = it
                                syncSettings()
                            },
                        )
                        SimpSettingItem(
                            title = "Author",
                            subtitle = "Tervixa-Corp",
                            smallSubtitle = true,
                        )
                        SimpSettingItem(
                            title = "Sub-Author",
                            subtitle = "Tervixa Forge",
                            smallSubtitle = true,
                        )
                    }
                }
            }
        }

        val settingBarTint = MaterialTheme.colorScheme.background
        SettingTopBar(
            onBack = onBack,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .then(
                    if (atTop) {
                        Modifier.background(Color.Transparent)
                    } else {
                        Modifier.hazeBlur(
                            input = HazeInput.Sources(hazeState),
                            style = barBlurStyle(tint = settingBarTint, tintAlpha = 0.62f, blurRadius = 32.dp),
                        )
                    }
                ),
        )

        if (showSettingsTutorial) {
            TutorialOverlay(
                title = "The Command Center",
                description = "Fine-tune your audio engine, customize the 'Ambient Universe', and manage your account. Everything you need to control the experience.",
                onDismiss = {
                    showSettingsTutorial = false
                    settingsManager.hasSeenSettingsTutorial = true
                },
            )
        }
    }

    // --- DIALOGS ---
    if (showColorPicker) {
        AccentColorPickerDialog(
            current = accentColor,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showColorPicker = false },
            onSelect = { color ->
                accentColorInt = color.toArgb()
                settingsManager.accentColor = accentColorInt
                onAccentColorChange(color)
                syncSettings()
                showColorPicker = false
            },
        )
    }

    if (showPlayerTypeDialog) {
        PlayerTypeSelectionDialog(
            current = playerType,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showPlayerTypeDialog = false },
            onSelect = {
                playerType = it
                settingsManager.playerType = it
                syncSettings()
                showPlayerTypeDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showThemeDialog) {
        ThemeSelectionDialog(
            current = themeMode,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showThemeDialog = false },
            onSelect = {
                themeMode = it
                settingsManager.themeMode = it
                syncSettings()
                showThemeDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showThemeColorSourceDialog) {
        SingleChoiceSettingDialog(
            title = "Theme Colour Source",
            options = listOf("Default", "Dynamic Wallpaper", "Custom"),
            current = themeColorSource,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showThemeColorSourceDialog = false },
            onSelect = {
                themeColorSource = it
                settingsManager.themeColorSource = it
                syncSettings()
                showThemeColorSourceDialog = false
                if (it == "Custom") showColorPicker = true
            },
        )
    }

    if (showCountryDialog) {
        CountrySelectionDialog(
            current = contentCountry,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showCountryDialog = false },
            onSelect = {
                contentCountry = it
                settingsManager.contentCountry = it
                syncSettings()
                showCountryDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showLanguageSelection) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = {
                showLanguageSelection = false
                syncSettings()
            },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            LanguageSelectionScreen(
                settingsManager = settingsManager,
                onContinue = {
                    showLanguageSelection = false
                    syncSettings()
                    onUpdateTrigger()
                },
            )
        }
    }

    if (showArtistSelection) {
        val repo = MusicPlayer.unifiedRepository
        if (repo != null) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = {
                    showArtistSelection = false
                    syncSettings()
                },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            ) {
                ArtistSelectionScreen(
                    unifiedRepository = repo,
                    settingsManager = settingsManager,
                    onFinish = {
                        showArtistSelection = false
                        syncSettings()
                        onUpdateTrigger()
                    },
                )
            }
        } else {
            showArtistSelection = false
        }
    }

    if (showStreamingQualityDialog) {
        SingleChoiceSettingDialog(
            title = "Streaming Audio Quality",
            options = listOf("High (OPUS 160kbps)", "Ultra (AAC 256kbps)", "Balanced (128kbps)", "Data Saver (64kbps)"),
            current = streamingQuality,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showStreamingQualityDialog = false },
            onSelect = {
                streamingQuality = it
                settingsManager.streamingQuality = it
                syncSettings()
                showStreamingQualityDialog = false
            },
        )
    }

    if (showDownloadQualityDialog) {
        DownloadQualitySelectionDialog(
            current = downloadQuality,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showDownloadQualityDialog = false },
            onSelect = {
                downloadQuality = it
                settingsManager.downloadQuality = it
                syncSettings()
                showDownloadQualityDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showThreadsDialog) {
        DownloadThreadsSelectionDialog(
            current = downloadThreads,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showThreadsDialog = false },
            onSelect = {
                downloadThreads = it
                settingsManager.downloadThreads = it
                syncSettings()
                showThreadsDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showSmartDownloadsDialog) {
        SingleChoiceSettingDialog(
            title = "Smart Downloads Limit",
            options = listOf("25", "50", "100"),
            current = smartDownloadsCount.toString(),
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showSmartDownloadsDialog = false },
            onSelect = {
                val count = it.toIntOrNull() ?: 50
                smartDownloadsCount = count
                settingsManager.smartDownloadsCount = count
                if (smartDownloadsEnabled) {
                    MusicPlayer.triggerSmartDownloads(context)
                }
                syncSettings()
                showSmartDownloadsDialog = false
            },
        )
    }

    if (showEqualizerTypeDialog) {
        SingleChoiceSettingDialog(
            title = "Equalizer Type",
            options = listOf("System Equalizer", "Built-in AudioFX"),
            current = equalizerType,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showEqualizerTypeDialog = false },
            onSelect = {
                equalizerType = it
                settingsManager.equalizerType = it
                syncSettings()
                showEqualizerTypeDialog = false
            },
        )
    }


    if (showBufferDialog) {
        BufferSelectionDialog(
            current = networkBufferSizeMs,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showBufferDialog = false },
            onSelect = {
                networkBufferSizeMs = it
                settingsManager.networkBufferSizeMs = it
                syncSettings()
                showBufferDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showVideoQualityDialog) {
        VideoQualitySelectionDialog(
            current = preferredVideoQuality,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showVideoQualityDialog = false },
            onSelect = {
                preferredVideoQuality = it
                settingsManager.preferredVideoQuality = it
                syncSettings()
                showVideoQualityDialog = false
                onUpdateTrigger()
            },
        )
    }

    if (showLyricsProviderDialog) {
        LyricsProviderSelectionDialog(
            current = lyricsProvider,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showLyricsProviderDialog = false },
            onSelect = {
                lyricsProvider = it
                settingsManager.lyricsProvider = it
                syncSettings()
                showLyricsProviderDialog = false
            },
        )
    }

    if (showLyricsStyleDialog) {
        SingleChoiceSettingDialog(
            title = "Lyrics Style",
            options = listOf("Classic", "Apple Music (Blur)"),
            current = lyricsStyle,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showLyricsStyleDialog = false },
            onSelect = {
                lyricsStyle = it
                settingsManager.lyricsStyle = it
                syncSettings()
                showLyricsStyleDialog = false
            },
        )
    }

    if (showLyricsOffsetDialog) {
        val offsets = listOf(-1000, -500, -250, 0, 250, 500, 1000)
        SingleChoiceSettingDialog(
            title = "Lyrics Offset (ms)",
            options = offsets.map { if (it > 0) "+$it ms" else "$it ms" },
            current = if (lyricsOffsetMs > 0) "+$lyricsOffsetMs ms" else "$lyricsOffsetMs ms",
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showLyricsOffsetDialog = false },
            onSelect = { label ->
                val ms = label.removeSuffix(" ms").removePrefix("+").toIntOrNull() ?: 0
                lyricsOffsetMs = ms
                settingsManager.lyricsOffsetMs = ms
                syncSettings()
                showLyricsOffsetDialog = false
            },
        )
    }

    if (showCacheLimitDialog) {
        val limits = listOf(256, 512, 1024, 2048, 4096)
        SingleChoiceSettingDialog(
            title = "Limit Player Cache Size",
            options = limits.map { if (it >= 1024) "${it / 1024} GB" else "$it MB" },
            current = if (limitPlayerCacheMb >= 1024) "${limitPlayerCacheMb / 1024} GB" else "$limitPlayerCacheMb MB",
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showCacheLimitDialog = false },
            onSelect = { selected ->
                val mb = if (selected.endsWith("GB")) {
                    (selected.removeSuffix(" GB").toIntOrNull() ?: 1) * 1024
                } else {
                    selected.removeSuffix(" MB").toIntOrNull() ?: 512
                }
                limitPlayerCacheMb = mb
                settingsManager.limitPlayerCacheMb = mb
                syncSettings()
                showCacheLimitDialog = false
            },
        )
    }

    if (showBackupFrequencyDialog) {
        SingleChoiceSettingDialog(
            title = "Backup Frequency",
            options = listOf("Daily", "Weekly", "Monthly"),
            current = autoBackupFrequency,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showBackupFrequencyDialog = false },
            onSelect = {
                autoBackupFrequency = it
                settingsManager.autoBackupFrequency = it
                syncSettings()
                showBackupFrequencyDialog = false
            },
        )
    }

    if (AudioFxManager.showEqualizerSheet) {
        BuiltInEqualizerBottomSheet(
            onDismiss = { AudioFxManager.showEqualizerSheet = false }
        )
    }

    // Real SimpMusic WebView Login UI for Connect To Wave (YouTube Music, Spotify, Last.fm, Discord)
    if (activeConnectDialog != null) {
        val service = activeConnectDialog!!
        val isServiceConnected = when (service) {
            "YouTube Music" -> isYtmConnected
            "Spotify" -> isSpotifyConnected
            "Last.fm" -> isLastFmConnected
            "Discord" -> isDiscordConnected
            else -> false
        }
        ConnectServiceLoginDialog(
            service = service,
            isCurrentlyConnected = isServiceConnected,
            onDismiss = { activeConnectDialog = null },
            onConnected = { accountLabel, credential ->
                when (service) {
                    "YouTube Music" -> {
                        ytmAccountName = accountLabel
                        isYtmConnected = true
                    }
                    "Spotify" -> {
                        spotifySpDc = credential
                        isSpotifyConnected = true
                        isSpotifyMetadataEnabled = true
                    }
                    "Last.fm" -> {
                        lastFmUsername = accountLabel
                        isLastFmConnected = true
                    }
                    "Discord" -> {
                        discordToken = credential
                        isDiscordConnected = true
                    }
                }
                syncSettings()
                activeConnectDialog = null
            },
            onDisconnect = {
                when (service) {
                    "YouTube Music" -> {
                        isYtmConnected = false
                        ytmAccountName = ""
                        settingsManager.isYouTubeMusicConnected = false
                        settingsManager.ytmAccountName = ""
                        cookieManager.clearCookies()
                    }
                    "Spotify" -> {
                        isSpotifyConnected = false
                        spotifySpDc = ""
                        settingsManager.isSpotifyConnected = false
                        settingsManager.spotifySpDcCookie = ""
                    }
                    "Last.fm" -> {
                        isLastFmConnected = false
                        lastFmUsername = ""
                        settingsManager.isLastFmConnected = false
                        settingsManager.lastFmUsername = ""
                        settingsManager.lastFmSessionKey = ""
                    }
                    "Discord" -> {
                        isDiscordConnected = false
                        discordToken = ""
                        settingsManager.isDiscordConnected = false
                        settingsManager.discordToken = ""
                    }
                }
                syncSettings()
                activeConnectDialog = null
            },
        )
    }

    if (showProxyDialog) {
        var editType by remember { mutableStateOf(proxyType) }
        var editHost by remember { mutableStateOf(proxyHost) }
        var editPort by remember { mutableStateOf(proxyPort.toString()) }
        AlertDialog(
            onDismissRequest = { showProxyDialog = false },
            title = { Text("Configure Proxy Server", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf("HTTP", "SOCKS").forEach { t ->
                            FilterChip(
                                selected = editType == t,
                                onClick = { editType = t },
                                label = { Text(t) },
                            )
                        }
                    }
                    OutlinedTextField(
                        value = editHost,
                        onValueChange = { editHost = it },
                        label = { Text("Proxy Host") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = editPort,
                        onValueChange = { editPort = it },
                        label = { Text("Proxy Port") },
                        singleLine = true,
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        proxyType = editType
                        proxyHost = editHost.ifBlank { "127.0.0.1" }
                        proxyPort = editPort.toIntOrNull() ?: 8080
                        settingsManager.proxyType = proxyType
                        settingsManager.proxyHost = proxyHost
                        settingsManager.proxyPort = proxyPort
                        syncSettings()
                        showProxyDialog = false
                    },
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showProxyDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = Color(0xFF1A1A1A),
        )
    }
}

@Composable
fun SingleChoiceSettingDialog(
    title: String,
    options: List<String>,
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(option) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(
                            selected = option == current,
                            onClick = { onSelect(option) },
                            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(option, color = Color.White)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        containerColor = if (isLiquidGlass) Color(0xE618181B) else Color(0xFF1A1A1A),
        shape = RoundedCornerShape(28.dp),
    )
}

@Composable
fun PlayerTypeSelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Select Player Design",
        options = listOf("Classic", "Material 3"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun BufferSelectionDialog(
    current: Long,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (Long) -> Unit,
) {
    val options = listOf(
        0L to "AI Auto (Adaptive)",
        10000L to "Low Latency (10s)",
        30000L to "Balanced (30s)",
        45000L to "Stable (45s)",
        60000L to "Extreme Cache (60s)",
    )
    SingleChoiceSettingDialog(
        title = "Network Buffer Size",
        options = options.map { it.second },
        current = options.firstOrNull { it.first == current }?.second ?: "AI Auto (Adaptive)",
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = { label ->
            val ms = options.firstOrNull { it.second == label }?.first ?: 0L
            onSelect(ms)
        },
    )
}

@Composable
fun PrioritySelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Audio Source Priority",
        options = listOf("Force OPUS 160kbps", "Fallback to AAC", "Prefer Low-Bandwidth"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun VideoQualitySelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Video Quality",
        options = listOf("auto(recommended)", "4k", "2k", "1080p", "720p", "480p"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun DownloadQualitySelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Download Quality",
        options = listOf("Standard (OPUS 160kbps)", "High (AAC 256kbps)", "Data Saver"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun DownloadThreadsSelectionDialog(
    current: Int,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
) {
    val options = listOf(1, 2, 4, 8, 12, 16)
    SingleChoiceSettingDialog(
        title = "Download Threads",
        options = options.map { "$it Threads" },
        current = "$current Threads",
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = { label ->
            val threads = label.removeSuffix(" Threads").toIntOrNull() ?: 4
            onSelect(threads)
        },
    )
}

@Composable
fun LyricsProviderSelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Select Lyrics Provider",
        options = listOf("BetterLyrics", "Auto", "SimpMusic", "LRCLIB", "Netease", "KuGou", "Alsong"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun CountrySelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Select Country",
        options = listOf("US", "IN", "GB", "CA", "AU", "DE", "FR", "JP", "KR", "BR"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}

@Composable
fun ThemeSelectionDialog(
    current: String,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    SingleChoiceSettingDialog(
        title = "Select Theme Mode",
        options = listOf("Light", "Dark", "System"),
        current = current,
        isLiquidGlass = isLiquidGlass,
        onDismiss = onDismiss,
        onSelect = onSelect,
    )
}
