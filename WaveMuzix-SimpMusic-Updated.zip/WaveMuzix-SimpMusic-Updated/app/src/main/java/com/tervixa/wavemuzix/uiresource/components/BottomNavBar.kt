package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.lerp
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.kashif_e.backdrop.drawBackdrop
import com.kashif_e.backdrop.effects.blur
import com.kashif_e.backdrop.effects.colorControls
import com.kashif_e.backdrop.effects.lens
import com.kashif_e.backdrop.effects.vibrancy
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.math.sign

private val CapsuleShape = RoundedCornerShape(percent = 50)
private val TabWidth = 92.dp
internal val BarHeight = 64.dp
private val BlobHeight = 56.dp
private val BarInset = 6.dp
private val BarEdgePadding = 16.dp
private val SearchGap = 10.dp
private val SearchSize = 58.dp
internal val CollapsedBarSize = 50.dp
private const val BAR_MORPH_MS = 300

private data class WaveNavTab(
    val route: String,
    val title: String,
    val icon: ImageVector,
)

private val CapsuleNavTabs = listOf(
    WaveNavTab(route = "home", title = "Home", icon = WaveIcons.Home),
    WaveNavTab(route = "library", title = "Library", icon = WaveIcons.Library),
    WaveNavTab(route = "analytics", title = "Analytics", icon = WaveIcons.Analytics),
)

private val SearchNavTab = WaveNavTab(
    route = "search",
    title = "Search",
    icon = WaveIcons.Search,
)

private fun isHomeSubScreenRoute(route: String?): Boolean {
    if (route == null) return false
    return route == "settings" ||
        route == "manage_account" ||
        route == "notifications" ||
        route.startsWith("playlist/") ||
        route.startsWith("local_playlist/") ||
        route.startsWith("artist/")
}

private fun resolveConcreteRoute(entry: NavBackStackEntry?): String? {
    val pattern = entry?.destination?.route ?: return null
    val args = entry.arguments
    return when {
        pattern == "playlist/{browseId}" -> {
            val id = args?.getString("browseId") ?: return null
            "playlist/$id"
        }
        pattern == "local_playlist/{playlistId}" -> {
            val id = args?.getString("playlistId") ?: return null
            "local_playlist/$id"
        }
        pattern == "artist/{artistId}" -> {
            val id = args?.getString("artistId") ?: return null
            "artist/$id"
        }
        else -> pattern
    }
}

/**
 * Combined SimpMusic-ported 3D Liquid Glass Bottom Navigation Bar + MiniPlayerBar morphing container:
 * - Features `Home`, `Library`, and `Analytics` inside the capsule + `Search` circular FAB.
 * - Implements smart two-stage Home button navigation:
 *   1) When on `playlist`, `manage_account`, `artist`, `settings`, or `notifications`, tapping Home
 *      navigates directly to the `home` screen.
 *   2) If the user was on a Home-accessible sub-screen (`settings`, `playlist`, `artist`,
 *      `manage_account`, `notifications`) and tapped another Nav Bar tab (`library`, `analytics`,
 *      `search`), tapping Home once returns them to that sub-screen, and tapping Home a second
 *      time takes them to the main `home` screen!
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun BottomNavBar(
    navController: NavController,
    isLiquidGlass: Boolean,
    isScrolledToTop: Boolean = true,
    includeMiniPlayer: Boolean = false,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
    onOpenNowPlaying: () -> Unit = {},
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"
    val performance = LocalPerformanceConfig.current
    val backdrop = LocalBackdrop.current
    val useLiquidGlass = isLiquidGlass && performance.isLiquidGlassEnabled && backdrop != null

    val navGraphicsLayer = rememberGraphicsLayer()
    val navLuminance = rememberGlassLuminance(navGraphicsLayer, enabled = useLiquidGlass)
    val searchFabInteraction = rememberGlassInteraction()
    val isDarkTheme = LocalIsDarkTheme.current

    // Tracks a Home-accessible sub-screen (e.g., settings, playlist, artist, account, notifications)
    // when the user switches to Library / Analytics / Search via the navigation bar.
    var savedHomeSubRoute by rememberSaveable { mutableStateOf<String?>(null) }

    fun safeNavigate(targetRoute: String) {
        // Ensure navigation requests are not silently dropped during screen transitions
        if (navController.currentBackStackEntry?.lifecycle?.currentState?.isAtLeast(Lifecycle.State.CREATED) != true) return

        if (targetRoute == "home") {
            if (isHomeSubScreenRoute(currentRoute)) {
                // Currently on playlist / artist / settings / account / notifications -> go straight to Home!
                savedHomeSubRoute = null
                val popped = navController.popBackStack("home", inclusive = false)
                if (!popped) {
                    navController.navigate("home") {
                        popUpTo(navController.graph.findStartDestination().id) {
                            inclusive = false
                        }
                        launchSingleTop = true
                    }
                }
                return
            }

            if (currentRoute != "home" && savedHomeSubRoute != null) {
                // User was in a Home sub-screen (like Settings) before switching to another tab:
                // 1st click on Home returns to that sub-screen; 2nd click will hit isHomeSubScreenRoute above and go to Home!
                val restoreRoute = savedHomeSubRoute!!
                navController.navigate(restoreRoute) {
                    launchSingleTop = true
                }
                return
            }

            if (currentRoute == "home") return
            navController.navigate("home") {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
            return
        }

        // Navigating to a non-Home tab (library, analytics, search):
        // If we are currently on a Home sub-screen, remember it so clicking Home brings us back to it first!
        if (isHomeSubScreenRoute(currentRoute)) {
            savedHomeSubRoute = resolveConcreteRoute(navBackStackEntry)
        } else if (currentRoute == "home") {
            savedHomeSubRoute = null
        }

        if (currentRoute == targetRoute) return
        navController.navigate(targetRoute) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val isInSearchDestination = currentRoute == "search"
    var isExpanded by rememberSaveable { mutableStateOf(true) }

    val isUntintedScreen = currentRoute == "home" ||
        currentRoute == "library" ||
        currentRoute == "settings" ||
        currentRoute == "search"

    val dynamicScreenBg = MusicPlayer.activeScreenAccentTint
    val screenTint = when {
        isUntintedScreen -> Color.Transparent
        dynamicScreenBg != null -> dynamicScreenBg.copy(alpha = 0.32f)
        currentRoute.startsWith("analytics") -> Color(0xFF141824).copy(alpha = 0.32f)
        currentRoute.startsWith("artist") -> Color(0xFF141E2B).copy(alpha = 0.32f)
        currentRoute.startsWith("playlist") -> Color(0xFF1A142B).copy(alpha = 0.32f)
        currentRoute.startsWith("album") -> Color(0xFF221424).copy(alpha = 0.32f)
        else -> Color(0xFF161622).copy(alpha = 0.30f)
    }

    LaunchedEffect(isInSearchDestination) {
        isExpanded = !isInSearchDestination
    }

    LaunchedEffect(isScrolledToTop, isInSearchDestination) {
        if (!isInSearchDestination) {
            isExpanded = isScrolledToTop
        }
    }

    val isShowMiniPlayer = includeMiniPlayer && MusicPlayer.currentSong != null

    val effectiveTabRoute = when {
        currentRoute == "library" -> "library"
        currentRoute == "analytics" -> "analytics"
        currentRoute == "search" -> "search"
        else -> "home"
    }

    val activeTab = when (effectiveTabRoute) {
        "library" -> CapsuleNavTabs[1]
        "analytics" -> CapsuleNavTabs[2]
        "search" -> SearchNavTab
        else -> CapsuleNavTabs[0]
    }

    val collapsedCircle: @Composable () -> Unit = {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(enabled = !isExpanded) { isExpanded = true },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = activeTab.icon,
                contentDescription = activeTab.title,
                tint = if (useLiquidGlass) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp),
            )
        }
    }

    val expandProgress by animateFloatAsState(
        targetValue = if (isExpanded) 1f else 0f,
        animationSpec = tween(durationMillis = BAR_MORPH_MS, easing = FastOutSlowInEasing),
        label = "barMorphProgress",
    )

    val miniPlayerVisibilityProgress by animateFloatAsState(
        targetValue = if (isShowMiniPlayer) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 320f),
        label = "miniPlayerVisibility",
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
    ) {
        val capsuleBudget = maxWidth - BarEdgePadding * 2 - SearchGap - SearchSize
        val capsuleWidth = if (useLiquidGlass) {
            liquidGlassTabBarWidth(CapsuleNavTabs.size, capsuleBudget)
        } else {
            flatTabBarWidth(CapsuleNavTabs.size, capsuleBudget)
        }
        val miniPlayerPadding = 16.dp
        val miniPlayerGap = 10.dp

        val toolbarComposable: @Composable () -> Unit = {
            Layout(
                content = {
                    if (useLiquidGlass && backdrop != null) {
                        LiquidGlassTabBar(
                            tabs = CapsuleNavTabs,
                            selectedTab = CapsuleNavTabs.indexOfFirst { it.route == effectiveTabRoute },
                            backdrop = backdrop,
                            layer = navGraphicsLayer,
                            luminance = navLuminance,
                            availableWidth = capsuleBudget,
                            onTabSelected = { index -> safeNavigate(CapsuleNavTabs[index].route) },
                            collapsedContent = collapsedCircle,
                            screenTint = screenTint,
                        )
                        Box(
                            modifier = Modifier
                                .size(SearchSize)
                                .drawInteractiveGlass(
                                    isDark = isDarkTheme,
                                    backdrop = backdrop,
                                    layer = null,
                                    luminance = { navLuminance.value },
                                    shape = CircleShape,
                                    interaction = searchFabInteraction,
                                    pressedScale = 1.14f,
                                    blurScale = 1.20f,
                                    minScrim = 0.12f,
                                    maxScrim = 0.34f,
                                    accentColor = screenTint,
                                    outlineAlpha = 0.38f,
                                    borderWidth = 1.2.dp,
                                )
                                .clip(CircleShape)
                                .clickable { safeNavigate("search") },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = WaveIcons.Search,
                                contentDescription = "Search",
                                tint = if (currentRoute == "search") {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    } else {
                        FlatTabBar(
                            tabs = CapsuleNavTabs,
                            selectedRoute = effectiveTabRoute,
                            availableWidth = capsuleBudget,
                            onTabSelected = { tab -> safeNavigate(tab.route) },
                            collapsedContent = collapsedCircle,
                            modifier = if (screenTint != Color.Transparent) Modifier.background(screenTint, CapsuleShape) else Modifier,
                        )
                        FlatSearchButton(
                            selected = currentRoute == "search",
                            onClick = { safeNavigate("search") },
                        )
                    }
                },
            ) { measurables, constraints ->
                val folded = CollapsedBarSize.roundToPx()
                val capsule = capsuleWidth.roundToPx()
                val gap = SearchGap.roundToPx()
                val search = SearchSize.roundToPx()
                val expanded = capsule + gap + search
                val width = if (constraints.hasFixedWidth) {
                    constraints.maxWidth
                } else {
                    expanded.coerceIn(constraints.minWidth, constraints.maxWidth)
                }
                val height = if (constraints.hasFixedHeight) {
                    constraints.maxHeight
                } else {
                    BarHeight.roundToPx().coerceIn(constraints.minHeight, constraints.maxHeight)
                }
                val progress = ((width - folded).toFloat() / (expanded - folded).coerceAtLeast(1)).coerceIn(0f, 1f)
                val bar = measurables[0].measure(Constraints.fixed(lerp(folded, capsule, progress), height))
                val fab = measurables[1].measure(Constraints.fixed(search, search))
                val fabAlpha = ((progress - 0.5f) / 0.5f).coerceIn(0f, 1f)
                layout(width, height) {
                    bar.placeRelativeWithLayer(0, 0) {
                        clip = false
                    }
                    if (fabAlpha > 0f) {
                        fab.placeRelativeWithLayer(capsule + gap, (height - search) / 2) {
                            alpha = fabAlpha
                            scaleX = lerp(0.8f, 1f, fabAlpha)
                            scaleY = scaleX
                            clip = false
                        }
                    }
                }
            }
        }

        if (!includeMiniPlayer) {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.BottomCenter,
            ) {
                val density = LocalDensity.current
                val foldedPx = with(density) { CollapsedBarSize.roundToPx() }
                val expandedWidthPx = with(density) { (capsuleWidth + SearchGap + SearchSize).roundToPx() }
                val currentWidthDp = with(density) { lerp(foldedPx, expandedWidthPx, expandProgress).toDp() }
                val currentHeightDp = with(density) {
                    lerp(CollapsedBarSize.roundToPx(), BarHeight.roundToPx(), expandProgress).toDp()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = BarEdgePadding),
                    contentAlignment = if (expandProgress < 0.99f) Alignment.CenterStart else Alignment.Center,
                ) {
                    Box(modifier = Modifier.size(currentWidthDp, currentHeightDp)) {
                        toolbarComposable()
                    }
                }
            }
        } else {
            Layout(
                content = {
                    toolbarComposable()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = miniPlayerPadding)
                            .height(58.dp),
                    ) {
                        MiniPlayerBar(
                            isLiquidGlass = isLiquidGlass,
                            isCompact = expandProgress < 0.5f,
                            screenTint = screenTint,
                            sharedTransitionScope = sharedTransitionScope,
                            animatedVisibilityScope = animatedVisibilityScope,
                            onClick = onOpenNowPlaying,
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { measurables, constraints ->
                val maxW = constraints.maxWidth
                val edgePadPx = BarEdgePadding.roundToPx()
                val foldedSizePx = CollapsedBarSize.roundToPx()
                val barHeightPx = BarHeight.roundToPx()
                val miniHeightPx = 58.dp.roundToPx()
                val gapPx = miniPlayerGap.roundToPx()
                val padPx = miniPlayerPadding.roundToPx()

                val expandedToolbarW = (capsuleWidth + SearchGap + SearchSize).roundToPx()
                    .coerceAtMost(maxW - edgePadPx * 2)
                val toolbarW = lerp(foldedSizePx, expandedToolbarW, expandProgress)
                val toolbarH = lerp(foldedSizePx, barHeightPx, expandProgress)

                val toolbarPlaceable = measurables[0].measure(Constraints.fixed(toolbarW, toolbarH))

                val collapsedMiniStartX = edgePadPx + foldedSizePx + gapPx - padPx
                val collapsedMiniW = (maxW - collapsedMiniStartX).coerceAtLeast(0)
                val currentMiniW = lerp(collapsedMiniW, maxW, expandProgress)
                val miniPlaceable = measurables[1].measure(Constraints.fixed(currentMiniW, miniHeightPx))

                val expandedTotalH = if (miniPlayerVisibilityProgress > 0.01f) {
                    barHeightPx + lerp(0, miniHeightPx + gapPx, miniPlayerVisibilityProgress)
                } else {
                    barHeightPx
                }
                val collapsedTotalH = maxOf(foldedSizePx, if (miniPlayerVisibilityProgress > 0.01f) miniHeightPx else foldedSizePx)
                val totalH = lerp(collapsedTotalH, expandedTotalH, expandProgress)

                val expandedToolbarX = (maxW - expandedToolbarW) / 2
                val toolbarX = lerp(edgePadPx, expandedToolbarX, expandProgress)
                val toolbarY = totalH - toolbarH

                val miniX = lerp(collapsedMiniStartX, 0, expandProgress)
                val collapsedMiniY = (totalH - miniHeightPx) / 2
                val expandedMiniY = toolbarY - gapPx - miniHeightPx
                val baseMiniY = lerp(collapsedMiniY, expandedMiniY, expandProgress)
                val hiddenDropOffset = ((1f - miniPlayerVisibilityProgress) * (miniHeightPx + gapPx)).roundToInt()
                val miniY = baseMiniY + hiddenDropOffset

                layout(maxW, totalH.coerceAtLeast(foldedSizePx)) {
                    if (miniPlayerVisibilityProgress > 0.01f) {
                        miniPlaceable.placeRelativeWithLayer(miniX, miniY) {
                            alpha = miniPlayerVisibilityProgress
                            val shrink = lerp(0.75f, 1f, miniPlayerVisibilityProgress)
                            scaleX = shrink
                            scaleY = shrink
                            transformOrigin = TransformOrigin(0.5f, 1f)
                            clip = false
                        }
                    }
                    toolbarPlaceable.placeRelativeWithLayer(toolbarX, toolbarY) {
                        clip = false
                    }
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassTabBar(
    tabs: List<WaveNavTab>,
    selectedTab: Int,
    backdrop: LayerBackdrop,
    layer: GraphicsLayer,
    luminance: State<Float>,
    modifier: Modifier = Modifier,
    availableWidth: Dp = Dp.Unspecified,
    onTabSelected: (Int) -> Unit,
    screenTint: Color = Color.Transparent,
    collapsedContent: (@Composable () -> Unit)? = null,
) {
    val density = LocalDensity.current
    val layoutDirection = LocalLayoutDirection.current
    val tabsCount = tabs.size
    val tabWidth = tabWidthFor(tabsCount, availableWidth)
    val fullWidth = tabWidth * tabsCount + BarInset * 2
    val tabWidthPx = with(density) { tabWidth.toPx() }
    val currentTabWidthPx by rememberUpdatedState(tabWidthPx)
    val isLtr = layoutDirection == LayoutDirection.Ltr
    val animationScope = rememberCoroutineScope()
    val barInteraction = rememberGlassInteraction()
    val isDark = LocalIsDarkTheme.current

    var currentIndex by remember { mutableIntStateOf(selectedTab.coerceAtLeast(0)) }
    val draggedFlag = remember { booleanArrayOf(false) }
    val tapPulseProgress = remember { Animatable(0f) }

    val dampedDrag = remember(animationScope, tabsCount) {
        DampedDragAnimation(
            animationScope = animationScope,
            initialValue = selectedTab.coerceAtLeast(0).toFloat(),
            valueRange = 0f..(tabsCount - 1).toFloat(),
            visibilityThreshold = 0.001f,
            initialScale = 1f,
            pressedScale = 78f / 56f,
            onDragStarted = { draggedFlag[0] = false },
            onDragStopped = {
                if (draggedFlag[0]) {
                    val target = targetValue.roundToInt().coerceIn(0, tabsCount - 1)
                    currentIndex = target
                    animateToValue(target.toFloat())
                    onTabSelected(target)
                }
            },
            onDrag = { _, dragAmount ->
                if (dragAmount.x != 0f) draggedFlag[0] = true
                updateValue(
                    (targetValue + dragAmount.x / currentTabWidthPx * if (isLtr) 1f else -1f)
                        .coerceIn(0f, (tabsCount - 1).toFloat()),
                )
            },
        )
    }

    LaunchedEffect(selectedTab) {
        if (selectedTab >= 0 && currentIndex != selectedTab) {
            currentIndex = selectedTab
        }
    }

    LaunchedEffect(dampedDrag) {
        snapshotFlow { currentIndex }
            .drop(1)
            .collectLatest { index ->
                dampedDrag.animateToValue(index.toFloat())
                if (draggedFlag[0]) onTabSelected(index)
            }
    }

    val indicatorVisibleAlpha by animateFloatAsState(
        targetValue = if (selectedTab >= 0 || draggedFlag[0]) 1f else 0f,
        animationSpec = tween(250),
        label = "blobVisibilityAlpha",
    )

    val combinedPressProgress = maxOf(
        barInteraction.pressProgress,
        dampedDrag.pressProgress,
        tapPulseProgress.value
    ).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .height(BarHeight)
            .width(fullWidth)
            .graphicsLayer {
                val scaleXVal = lerp(1f, 1.075f, combinedPressProgress)
                val scaleYVal = lerp(1f, 1.11f, combinedPressProgress)
                scaleX = scaleXVal
                scaleY = scaleYVal
                clip = false
            }
            .pointerInput(barInteraction) { barInteraction.detectPress(this) },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .matchParentSize()
                .drawInteractiveGlass(
                    isDark = isDark,
                    backdrop = backdrop,
                    layer = layer,
                    luminance = { luminance.value },
                    shape = CapsuleShape,
                    interaction = barInteraction,
                    pressedScale = 1.08f,
                    blurScale = 1.20f,
                    accentColor = screenTint,
                    outlineAlpha = 0.38f,
                    borderWidth = 1.2.dp,
                ),
        )

        Box(Modifier.matchParentSize().unfoldingTabs(fullWidth, CapsuleShape)) {
            Box(
                Modifier
                    .wrapContentSize(Alignment.CenterStart, unbounded = true)
                    .size(fullWidth, BarHeight),
                contentAlignment = Alignment.CenterStart,
            ) {
                Box(
                    Modifier
                        .graphicsLayer {
                            alpha = indicatorVisibleAlpha
                            translationX =
                                (if (isLtr) dampedDrag.value else (tabsCount - 1) - dampedDrag.value) * tabWidthPx +
                                    BarInset.toPx()
                        }
                        .drawBackdrop(
                            backdrop = backdrop,
                            shape = { CapsuleShape },
                            effects = {
                                val l = (luminance.value * 2f - 1f).let { sign(it) * it * it }
                                val progress = maxOf(dampedDrag.pressProgress, tapPulseProgress.value)
                                vibrancy()
                                colorControls(
                                    brightness = if (isDark) 0.06f else 0.08f,
                                    contrast = 1.08f,
                                    saturation = 1.65f,
                                )
                                blur(
                                    radius = (if (l > 0f) lerp(12f.dp.toPx(), 22f.dp.toPx(), l) else lerp(12f.dp.toPx(), 6f.dp.toPx(), -l)) +
                                        10f.dp.toPx(),
                                )
                                lens(
                                    refractionHeight = 12f.dp.toPx() * progress.coerceAtLeast(0.25f),
                                    refractionAmount = 18f.dp.toPx() * progress.coerceAtLeast(0.25f),
                                    depthEffect = true,
                                )
                            },
                            layerBlock = {
                                scaleX = dampedDrag.scaleX
                                scaleY = dampedDrag.scaleY
                                val velocity = dampedDrag.velocity / 10f
                                scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                                scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                            },
                            onDrawSurface = {
                                val lumNorm = ((luminance.value - 0.3f) / 0.5f).coerceIn(0f, 1f)
                                val darken = if (isDark) lerp(0.16f, 0.38f, lumNorm) else lerp(0.06f, 0.14f, lumNorm)
                                if (screenTint != Color.Transparent) {
                                    drawRect(Color.Black.copy(alpha = darken * 0.45f))
                                    drawRect(screenTint.copy(alpha = 0.36f))
                                } else {
                                    drawRect(Color.Black.copy(alpha = darken))
                                }

                                val progress = maxOf(dampedDrag.pressProgress, tapPulseProgress.value)
                                if (progress > 0f) {
                                    drawRect(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                Color.White.copy(alpha = 0.24f * progress),
                                                Color.Transparent,
                                            ),
                                            center = Offset(size.width / 2f, size.height / 2f),
                                            radius = size.maxDimension * 0.85f,
                                        ),
                                        blendMode = BlendMode.Plus,
                                    )
                                }

                                drawOutline(
                                    outline = CapsuleShape.createOutline(size, layoutDirection, density),
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.28f),
                                            Color.White.copy(alpha = 0.08f),
                                            Color.White.copy(alpha = 0.18f),
                                        ),
                                        start = Offset.Zero,
                                        end = Offset(size.width, size.height),
                                    ),
                                    style = Stroke(width = 1.0.dp.toPx()),
                                )
                            },
                        )
                        .width(tabWidth)
                        .height(BlobHeight),
                )

                Row(
                    Modifier
                        .matchParentSize()
                        .padding(horizontal = BarInset)
                        .then(dampedDrag.modifier),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    tabs.forEachIndexed { position, tab ->
                        LiquidGlassTab(
                            tab = tab,
                            selected = selectedTab == position,
                            width = tabWidth,
                        ) {
                            animationScope.launch {
                                launch {
                                    tapPulseProgress.animateTo(1f, spring(0.5f, 500f))
                                    delay(90)
                                    tapPulseProgress.animateTo(0f, spring(0.55f, 320f))
                                }
                                dampedDrag.press()
                                delay(140)
                                dampedDrag.release()
                            }
                            if (position == currentIndex) {
                                onTabSelected(position)
                            } else {
                                currentIndex = position
                                onTabSelected(position)
                            }
                        }
                    }
                }
            }
        }

        if (collapsedContent != null) {
            Box(Modifier.matchParentSize().foldedCircle(fullWidth), contentAlignment = Alignment.Center) {
                collapsedContent()
            }
        }
    }
}

private fun tabWidthFor(
    tabsCount: Int,
    availableWidth: Dp,
): Dp =
    if (availableWidth.isSpecified && availableWidth > 0.dp) {
        ((availableWidth - BarInset * 2) / tabsCount).coerceAtMost(TabWidth)
    } else {
        TabWidth
    }

internal fun liquidGlassTabBarWidth(
    tabsCount: Int,
    availableWidth: Dp,
): Dp = tabWidthFor(tabsCount, availableWidth) * tabsCount + BarInset * 2

@Composable
private fun LiquidGlassTab(
    tab: WaveNavTab,
    selected: Boolean,
    width: Dp,
    onClick: () -> Unit,
) {
    val color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .width(width)
            .fillMaxHeight()
            .clip(CapsuleShape)
            .clickable(
                interactionSource = null,
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            ),
        verticalArrangement = Arrangement.spacedBy(2.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CompositionLocalProvider(LocalContentColor provides color) {
            Icon(
                imageVector = tab.icon,
                contentDescription = tab.title,
                tint = color,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = tab.title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = color,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun FlatTabBar(
    tabs: List<WaveNavTab>,
    selectedRoute: String,
    availableWidth: Dp,
    onTabSelected: (WaveNavTab) -> Unit,
    modifier: Modifier = Modifier,
    collapsedContent: (@Composable () -> Unit)? = null,
) {
    val capsuleColor = MaterialTheme.colorScheme.surfaceContainer
    val indicatorColor = MaterialTheme.colorScheme.surfaceContainerHighest
    val tabWidth = flatTabWidth(tabs.size, availableWidth)
    val fullWidth = tabWidth * tabs.size + BarInset * 2
    val selectedPosition = tabs.indexOfFirst { it.route == selectedRoute }
    var dragPosition by remember { mutableStateOf<Float?>(null) }
    val indicatorOffset by animateDpAsState(
        targetValue = tabWidth * (dragPosition ?: selectedPosition.coerceAtLeast(0).toFloat()),
        animationSpec = if (dragPosition != null) snap() else spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "flatBarIndicator",
    )
    val activePosition = dragPosition?.roundToInt() ?: selectedPosition
    val isLtr = LocalLayoutDirection.current == LayoutDirection.Ltr
    val pressScale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val isDarkTheme = LocalIsDarkTheme.current
    val rimColor = if (isDarkTheme) Color.White else Color.Black

    Box(
        modifier = modifier
            .height(BarHeight)
            .width(fullWidth)
            .graphicsLayer {
                scaleX = pressScale.value
                scaleY = pressScale.value
            }
            .clip(RoundedCornerShape(BarHeight / 2))
            .background(capsuleColor)
            .border(
                width = 1.0.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        rimColor.copy(alpha = 0.16f),
                        rimColor.copy(alpha = 0.05f),
                        rimColor.copy(alpha = 0.12f),
                    ),
                ),
                shape = RoundedCornerShape(BarHeight / 2),
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.matchParentSize().unfoldingTabs(fullWidth, clipShape = null)) {
            Box(
                modifier = Modifier
                    .wrapContentSize(Alignment.CenterStart, unbounded = true)
                    .size(fullWidth, BarHeight)
                    .padding(horizontal = BarInset)
                    .pointerInput(tabs, tabWidth, isLtr) {
                        fun positionAt(x: Float): Float {
                            val fromStart = if (isLtr) x else size.width - x
                            return (fromStart / tabWidth.toPx() - 0.5f).coerceIn(0f, tabs.lastIndex.toFloat())
                        }
                        detectHorizontalDragGestures(
                            onDragStart = {
                                dragPosition = positionAt(it.x)
                                scope.launch { pressScale.animateTo(1.07f, spring(0.55f, 400f)) }
                            },
                            onDragEnd = {
                                val target = dragPosition?.roundToInt()?.let(tabs::get)
                                dragPosition = null
                                scope.launch { pressScale.animateTo(1f, spring(0.55f, 320f)) }
                                if (target != null && target.route != selectedRoute) onTabSelected(target)
                            },
                            onDragCancel = {
                                dragPosition = null
                                scope.launch { pressScale.animateTo(1f, spring(0.55f, 320f)) }
                            },
                        ) { change, _ ->
                            change.consume()
                            dragPosition = positionAt(change.position.x)
                        }
                    },
                contentAlignment = Alignment.CenterStart,
            ) {
                if (activePosition >= 0) {
                    Box(
                        modifier = Modifier
                            .offset(x = indicatorOffset)
                            .size(width = tabWidth, height = BlobHeight)
                            .clip(RoundedCornerShape(BlobHeight / 2))
                            .background(indicatorColor),
                    )
                }
                Row {
                    tabs.forEachIndexed { position, tab ->
                        val selected = position == activePosition
                        val contentColor = if (selected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Column(
                            modifier = Modifier
                                .width(tabWidth)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(BlobHeight / 2))
                                .clickable(
                                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                    indication = null, // No instant click highlight ripple
                                ) {
                                    scope.launch {
                                        pressScale.animateTo(1.07f, spring(0.5f, 450f))
                                        delay(80)
                                        pressScale.animateTo(1f, spring(0.55f, 320f))
                                    }
                                    onTabSelected(tab)
                                },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = contentColor,
                                modifier = Modifier.size(22.dp),
                            )
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = contentColor,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
        if (collapsedContent != null) {
            Box(Modifier.matchParentSize().foldedCircle(fullWidth), contentAlignment = Alignment.Center) {
                collapsedContent()
            }
        }
    }
}

@Composable
private fun FlatSearchButton(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val contentColor = if (selected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    val isDarkTheme = LocalIsDarkTheme.current
    val rimColor = if (isDarkTheme) Color.White else Color.Black
    Box(
        modifier = modifier
            .size(SearchSize)
            .clip(CircleShape)
            .background(
                if (selected) MaterialTheme.colorScheme.surfaceContainerHighest
                else MaterialTheme.colorScheme.surfaceContainer,
            )
            .border(
                width = 1.15.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        rimColor.copy(alpha = 0.34f),
                        rimColor.copy(alpha = 0.08f),
                        rimColor.copy(alpha = 0.22f),
                    ),
                ),
                shape = CircleShape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = WaveIcons.Search,
            contentDescription = "Search",
            tint = contentColor,
            modifier = Modifier.size(24.dp),
        )
    }
}

private fun flatTabWidth(
    tabsCount: Int,
    availableWidth: Dp,
): Dp =
    if (availableWidth.isSpecified && availableWidth > 0.dp) {
        ((availableWidth - BarInset * 2) / tabsCount).coerceAtMost(TabWidth)
    } else {
        TabWidth
    }

internal fun flatTabBarWidth(
    tabsCount: Int,
    availableWidth: Dp,
): Dp = flatTabWidth(tabsCount, availableWidth) * tabsCount + BarInset * 2

private fun Density.foldProgress(
    width: Int,
    fullWidth: Dp,
): Float {
    val folded = CollapsedBarSize.roundToPx()
    return ((width - folded).toFloat() / (fullWidth.roundToPx() - folded).coerceAtLeast(1)).coerceIn(0f, 1f)
}

internal fun Modifier.unfoldingTabs(
    fullWidth: Dp,
    clipShape: Shape?,
): Modifier =
    layout { measurable, constraints ->
        val progress = foldProgress(constraints.maxWidth, fullWidth)
        val placeable = measurable.measure(constraints)
        layout(placeable.width, placeable.height) {
            val tabsAlpha = ((progress - 0.3f) / 0.7f).coerceIn(0f, 1f)
            if (tabsAlpha > 0f) {
                placeable.placeRelativeWithLayer(0, 0) {
                    alpha = tabsAlpha
                    if (clipShape != null) {
                        clip = progress < 1f
                        shape = clipShape
                    }
                }
            }
        }
    }

internal fun Modifier.foldedCircle(fullWidth: Dp): Modifier =
    layout { measurable, constraints ->
        val progress = foldProgress(constraints.maxWidth, fullWidth)
        val size = CollapsedBarSize.roundToPx()
        val placeable = measurable.measure(Constraints.fixed(size, size))
        layout(constraints.maxWidth, constraints.maxHeight) {
            val circleAlpha = (1f - progress / 0.4f).coerceIn(0f, 1f)
            if (circleAlpha > 0f) {
                placeable.placeRelativeWithLayer(0, (constraints.maxHeight - size) / 2) {
                    alpha = circleAlpha
                }
            }
        }
    }
