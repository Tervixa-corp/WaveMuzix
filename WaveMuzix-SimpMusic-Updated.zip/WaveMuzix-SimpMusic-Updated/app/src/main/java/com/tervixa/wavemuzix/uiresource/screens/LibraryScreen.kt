package com.tervixa.wavemuzix.uiresource.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DataBackupManager
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.FirebaseSyncManager
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.model.Song as SongModel
import com.tervixa.wavemuzix.repository.ArtistRepository
import com.tervixa.wavemuzix.repository.FavoriteRepository
import com.tervixa.wavemuzix.repository.PlaylistRepository
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import com.tervixa.wavemuzix.uiresource.components.AddToPlaylistDialog
import com.tervixa.wavemuzix.uiresource.components.AmbientThemeGlow
import com.tervixa.wavemuzix.uiresource.components.GlassIconButton
import com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet
import com.tervixa.wavemuzix.uiresource.components.StandardLoader
import com.tervixa.wavemuzix.uiresource.components.TutorialOverlay
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveIcons
import com.tervixa.wavemuzix.uiresource.components.WaveUserAvatar
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.kashif_e.backdrop.backdrops.layerBackdrop
import com.kashif_e.backdrop.backdrops.rememberLayerBackdrop
import com.tervixa.wavemuzix.uiresource.components.LocalBackdrop
import com.tervixa.wavemuzix.uiresource.components.WaveGlassBottomSheet
import com.tervixa.wavemuzix.uiresource.components.glassContainer
import com.tervixa.wavemuzix.uiresource.components.isScrollingUp
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import com.tervixa.wavemuzix.uiresource.components.WaveFilterChip
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * SimpMusic-ported LibraryScreen:
 * - Features SimpMusic's exact `LibraryTilingBox` at the top:
 *   1) Full-width 132.dp `FavoriteCard` with radial glow, Heart badge, track count, and 3-card tilted `SleeveFan`
 *   2) 2x2 grid of 118.dp `CollectionCard`s (`Followed`, `Most Played`, `Downloaded`, `Playlists`) with 2-card `SleeveFan` / dashed `EmptySleeve`
 * - Tapping any of the top cards (`Favorite`, `Followed`, `Most Played`, `Downloaded`, `Playlists`) opens a dedicated full-screen
 *   `LibraryCategoryDetailScreen` with Back navigation, Play All, Shuffle, and search instead of sorting below!
 */
@Composable
fun LibraryScreen(
    unifiedRepository: UnifiedMusicRepository,
    onPlaylistClick: (String) -> Unit,
    onSearchClick: () -> Unit,
    onLoginClick: () -> Unit,
    onManageAccountClick: () -> Unit,
    isLiquidGlass: Boolean,
    onScrolling: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settingsManager = remember { SettingsManager(context) }
    var showLibraryTutorial by remember { mutableStateOf(!settingsManager.hasSeenLibraryTutorial) }
    val cookieManager = remember { CookieManager(context) }
    val auth = remember { Firebase.auth }

    val db = remember(context) { AppDatabase.getDatabase(context.applicationContext) }
    val playlistRepository = remember(db) { PlaylistRepository(db.playlistDao(), context) }
    val playlists by remember(playlistRepository) { playlistRepository.allPlaylists }.collectAsState(initial = emptyList())
    val songDao = remember(db) { db.songDao() }
    val favoriteRepository = remember(songDao) { FavoriteRepository(songDao, context) }
    val artistRepository = remember(songDao) { ArtistRepository(songDao, context) }

    val followedArtists by artistRepository.followedArtists.collectAsState(initial = emptyList())
    val mostPlayedSongs by songDao.getMostPlayedSongs().collectAsState(initial = emptyList())
    val downloadedSongs by songDao.getAllDownloads().collectAsState(initial = emptyList())
    val likedSongs by songDao.getAllFavorites().collectAsState(initial = emptyList())

    var isSyncing by remember { mutableStateOf(false) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var showPlaylistDialogFor by remember { mutableStateOf<SongModel?>(null) }

    // Full-screen category screen opened when tapping top cards in SimpLibraryTilingBox
    var openedCategoryScreen by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = openedCategoryScreen != null) {
        openedCategoryScreen = null
    }

    LaunchedEffect(auth.currentUser?.uid) {
        val currentUserId = auth.currentUser?.uid
        if (currentUserId != null && FirebaseSyncManager.needsSync(currentUserId)) {
            isSyncing = true
            try {
                val startTime = System.currentTimeMillis()
                FirebaseSyncManager.syncFromFirebase(context)
                DataBackupManager.restoreAll(context)
                FirebaseSyncManager.markSynced(currentUserId)
                val elapsedTime = System.currentTimeMillis() - startTime
                if (elapsedTime < 800) delay(800 - elapsedTime)
            } catch (e: Exception) {
                android.util.Log.e("LibraryScreen", "Initial sync/restore failed", e)
            } finally {
                isSyncing = false
            }
        } else {
            isSyncing = false
        }
    }

    var activeTab by remember { mutableStateOf("Recently Added") }
    var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }
    var userName by remember { mutableStateOf<String?>(null) }
    var userAvatarUrl by remember { mutableStateOf<String?>(null) }

    val musicVideos = remember { mutableStateListOf<SongModel>() }
    var isVideoLoading by remember { mutableStateOf(false) }

    LaunchedEffect(activeTab) {
        if (activeTab == "Videos" && musicVideos.isEmpty()) {
            isVideoLoading = true
            try {
                val videoResults = unifiedRepository.fetchTopMusicVideos(cookieManager.getCookies())
                if (videoResults.isNotEmpty()) {
                    musicVideos.addAll(videoResults)
                } else {
                    val searchResults = unifiedRepository.searchSongs("trending music videos", cookieManager.getCookies(), filterOnlyVideos = true)
                    musicVideos.addAll(searchResults)
                }
            } catch (e: Exception) {
                android.util.Log.e("LibraryScreen", "Failed to fetch top music videos", e)
            } finally {
                isVideoLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        auth.addAuthStateListener { firebaseAuth ->
            isLoggedIn = firebaseAuth.currentUser != null
        }
    }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            val userId = auth.currentUser?.uid
            if (userId != null) {
                Firebase.firestore.collection("users").document(userId).get()
                    .addOnSuccessListener { doc ->
                        userName = doc.getString("displayName") ?: auth.currentUser?.displayName
                        userAvatarUrl = doc.getString("photoUrl") ?: auth.currentUser?.photoUrl?.toString()
                    }
            } else {
                userName = auth.currentUser?.displayName
                userAvatarUrl = auth.currentUser?.photoUrl?.toString()
            }
        } else {
            userName = null
            userAvatarUrl = null
        }
    }

    if (showPlaylistDialogFor != null) {
        AddToPlaylistDialog(
            song = showPlaylistDialogFor!!,
            playlists = playlists,
            onDismiss = { showPlaylistDialogFor = null },
            onPlaylistSelected = { playlist ->
                scope.launch {
                    playlistRepository.addSongToPlaylist(playlist.id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
            onCreatePlaylist = { name ->
                scope.launch {
                    val id = playlistRepository.createPlaylist(name)
                    playlistRepository.addSongToPlaylist(id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Created and added to $name", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            }
        )
    }

    if (showCreatePlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showCreatePlaylistDialog = false },
            title = { Text("Create new playlist", style = MaterialTheme.typography.titleMedium) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    placeholder = { Text("Playlist name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            scope.launch {
                                playlistRepository.createPlaylist(newPlaylistName.trim())
                                newPlaylistName = ""
                                showCreatePlaylistDialog = false
                            }
                        }
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePlaylistDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val libraryHazeState = remember { HazeState() }
    val density = LocalDensity.current
    val statusBarTopDp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val listState = rememberLazyListState()
    val isScrollingUp by listState.isScrollingUp()
    val atTop by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 16
        }
    }
    var expandedTopBarHeightDp by remember(statusBarTopDp) {
        mutableStateOf(statusBarTopDp + 76.dp)
    }

    LaunchedEffect(atTop, isScrollingUp) {
        onScrolling(atTop || isScrollingUp)
    }

    // Combined Recently Added items (Liked + Downloaded + Most Played)
    val recentlyAddedSongs = remember(likedSongs, downloadedSongs, mostPlayedSongs) {
        val list = mutableListOf<SongModel>()
        likedSongs.forEach { s ->
            list.add(SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId))
        }
        downloadedSongs.forEach { s ->
            list.add(SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId, thumbnailPath = s.thumbnailPath, lyrics = s.lyrics))
        }
        mostPlayedSongs.forEach { s ->
            list.add(SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId))
        }
        list.distinctBy { it.videoId }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Main Content Area (Haze Source with opaque background so Haze blur works over all song cards!)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = libraryHazeState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AmbientThemeGlow(
                tint = MusicPlayer.accentColors.firstOrNull() ?: MaterialTheme.colorScheme.primary,
                scrollState = listState
            )

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                flingBehavior = rememberSmoothFlingBehavior(),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = expandedTopBarHeightDp + 12.dp,
                    bottom = 190.dp
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1) SimpMusic LibraryTilingBox (Favorite Hero Card + 2x2 Collection Grid)
                // Tapping any top card opens a dedicated full-screen view instead of sorting below!
                item(key = "simp_library_tiling_box") {
                    SimpLibraryTilingBox(
                        favoriteThumbs = likedSongs.take(3).map { it.thumbnailUrl },
                        favoriteCount = likedSongs.size,
                        followedThumbs = followedArtists.take(2).map { it.thumbnailUrl },
                        followedCount = followedArtists.size,
                        mostPlayedThumbs = mostPlayedSongs.take(2).map { it.thumbnailUrl },
                        mostPlayedCount = mostPlayedSongs.size,
                        downloadedThumbs = downloadedSongs.take(2).map { it.thumbnailUrl },
                        downloadedCount = downloadedSongs.size,
                        playlistCount = playlists.size,
                        onSelectCategory = { category ->
                            openedCategoryScreen = category
                        }
                    )
                }

                // 2) SimpMusic Category Filter Chips Row
                item(key = "simp_library_filter_chips") {
                    val categories = remember {
                        listOf("Recently Added", "Playlists", "Videos")
                    }
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        flingBehavior = rememberSmoothFlingBehavior()
                    ) {
                        items(categories, key = { it }) { cat ->
                            val isSelected = activeTab == cat
                            WaveFilterChip(
                                text = cat,
                                selected = isSelected,
                                onClick = { activeTab = cat },
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.24f),
                                selectedTextColor = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // 3) Active Category List (SimpMusic flat full-width song/playlist/artist rows)
                when (activeTab) {
                    "Recently Added" -> {
                        item(key = "recently_added_header") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp, bottom = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Recently Added",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                if (isLoggedIn) {
                                    TextButton(onClick = {
                                        scope.launch {
                                            isSyncing = true
                                            FirebaseSyncManager.syncFromFirebase(context)
                                            delay(500)
                                            isSyncing = false
                                            Toast.makeText(context, "Library Synced", Toast.LENGTH_SHORT).show()
                                        }
                                    }) {
                                        Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Sync", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }

                        if (recentlyAddedSongs.isEmpty()) {
                            item(key = "empty_recent") {
                                EmptyLibrarySectionState(
                                    icon = Icons.Rounded.LibraryMusic,
                                    title = "Your library is waiting",
                                    subtitle = "Like, play, or download songs to see them here"
                                )
                            }
                        } else {
                            itemsIndexed(
                                items = recentlyAddedSongs,
                                key = { idx, s -> "recent_${s.videoId}_$idx" }
                            ) { _, songModel ->
                                var showOptions by remember { mutableStateOf(false) }
                                val isDownloaded = downloadedSongs.any { it.videoId == songModel.videoId }
                                val isFavorite = likedSongs.any { it.videoId == songModel.videoId }

                                LibraryListItem(
                                    title = songModel.title,
                                    subtitle = songModel.displayArtists,
                                    leadingIcon = Icons.Rounded.MusicNote,
                                    imageUrl = songModel.thumbnailUrl,
                                    isLiquidGlass = isLiquidGlass,
                                    modifier = Modifier.clickable {
                                        MusicPlayer.playSong(
                                            context = context,
                                            song = songModel,
                                            playlist = recentlyAddedSongs,
                                            cookies = cookieManager.getCookies(),
                                            isFromFixedList = true
                                        )
                                    },
                                    onMoreClick = { showOptions = true }
                                )

                                if (showOptions) {
                                    SongOptionsBottomSheet(
                                        song = songModel,
                                        isFavorite = isFavorite,
                                        isDownloaded = isDownloaded,
                                        isLiquidGlass = isLiquidGlass,
                                        onDismiss = { showOptions = false },
                                        onFavoriteClick = { scope.launch { favoriteRepository.toggleFavorite(songModel) } },
                                        onDownloadClick = {
                                            scope.launch {
                                                val result = unifiedRepository.getStreamingUrl(songModel.videoId, cookieManager.getCookies())
                                                if (result != null) {
                                                    DownloadManager.updateProgress(songModel.videoId, songModel.title, 0)
                                                    val request = androidx.work.OneTimeWorkRequestBuilder<com.tervixa.wavemuzix.data.DownloadWorker>()
                                                        .setInputData(androidx.work.workDataOf(
                                                            "url" to result.url,
                                                            "videoId" to songModel.videoId,
                                                            "title" to songModel.title,
                                                            "artist" to songModel.artist,
                                                            "thumbnailUrl" to songModel.thumbnailUrl,
                                                            "artistId" to songModel.artistId,
                                                            "userAgent" to result.userAgent,
                                                            "cookies" to cookieManager.getCookies()
                                                        )).build()
                                                    androidx.work.WorkManager.getInstance(context).enqueue(request)
                                                    Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        onPlayNextClick = { MusicPlayer.playNext(songModel) },
                                        onAddToQueueClick = { MusicPlayer.addToQueue(songModel) },
                                        onArtistClick = {},
                                        onAddToPlaylistClick = {
                                            showOptions = false
                                            showPlaylistDialogFor = songModel
                                        },
                                        onShareClick = {
                                            val sendIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(Intent.EXTRA_TEXT, "Check out ${songModel.title} by ${songModel.artist}: https://www.youtube.com/watch?v=${songModel.videoId}")
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(sendIntent, null))
                                        }
                                    )
                                }
                            }
                        }
                    }

                    "Playlists" -> {
                        item(key = "playlists_header") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Your Playlists (${playlists.size})",
                                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 20.sp),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                FilledTonalButton(
                                    onClick = { showCreatePlaylistDialog = true },
                                    shape = CircleShape,
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("New", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }

                        if (playlists.isEmpty()) {
                            item(key = "empty_playlists") {
                                EmptyLibrarySectionState(
                                    icon = Icons.AutoMirrored.Rounded.PlaylistPlay,
                                    title = "No custom playlists yet",
                                    subtitle = "Tap + New to create your first custom playlist"
                                )
                            }
                        }

                        items(
                            items = playlists,
                            key = { it.id }
                        ) { playlist ->
                            LibraryListItem(
                                title = playlist.name,
                                subtitle = "Custom Playlist",
                                leadingIcon = Icons.Rounded.QueueMusic,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable { onPlaylistClick("local_${playlist.id}") }
                            )
                        }
                    }

                    "Videos" -> {
                        item(key = "videos_header") {
                            Text(
                                text = "Music Videos",
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 20.sp),
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }

                        if (isVideoLoading) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    StandardLoader()
                                }
                            }
                        } else if (musicVideos.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = WaveIcons.Video,
                                    title = "No videos found",
                                    subtitle = "Check your connection to browse top music videos"
                                )
                            }
                        }

                        itemsIndexed(musicVideos, key = { idx, v -> "lib_video_${v.videoId}_$idx" }) { _, video ->
                            LibraryListItem(
                                title = video.title,
                                subtitle = "${video.artist} • Video",
                                leadingIcon = WaveIcons.Video,
                                imageUrl = video.thumbnailUrl,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable {
                                    MusicPlayer.playSong(context, video, cookies = cookieManager.getCookies())
                                }
                            )
                        }
                    }
                }
            }
        }

        // 2. Sibling Collapsing Haze TopBar
        val barTint = MaterialTheme.colorScheme.background
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .onGloballyPositioned { coords ->
                    val measured = with(density) { coords.size.height.toDp() }
                    if (measured > expandedTopBarHeightDp) {
                        expandedTopBarHeightDp = measured
                    }
                }
                .then(
                    if (atTop) {
                        Modifier.background(Color.Transparent)
                    } else {
                        Modifier.hazeBlur(
                            input = HazeInput.Sources(libraryHazeState),
                            style = barBlurStyle(tint = barTint, tintAlpha = 0.60f, blurRadius = 32.dp)
                        )
                    }
                )
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val onProfileClick = {
                    if (isLoggedIn) onManageAccountClick() else onLoginClick()
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Library",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 24.sp
                        )
                    )
                    val currentUserName = auth.currentUser?.displayName ?: userName
                    if (isLoggedIn && !currentUserName.isNullOrBlank()) {
                        Text(
                            text = currentUserName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.72f)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onSearchClick) {
                        Icon(
                            imageVector = WaveIcons.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable { onProfileClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoggedIn) {
                            WaveUserAvatar(
                                url = userAvatarUrl ?: auth.currentUser?.photoUrl?.toString(),
                                name = userName ?: auth.currentUser?.displayName,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            IconButton(onClick = onProfileClick) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Login,
                                    contentDescription = "Login",
                                    tint = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Dedicated Full-Screen Category Screen when tapping Favorite / Followed / Most Played / Downloaded / Playlists cards
        AnimatedVisibility(
            visible = openedCategoryScreen != null,
            enter = slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(260)) + fadeIn(tween(220)),
            exit = slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(240)) + fadeOut(tween(180))
        ) {
            val currentCategory = openedCategoryScreen ?: "Favorite"
            LibraryCategoryDetailScreen(
                category = currentCategory,
                likedSongs = likedSongs,
                followedArtists = followedArtists,
                mostPlayedSongs = mostPlayedSongs,
                downloadedSongs = downloadedSongs,
                playlists = playlists,
                isLiquidGlass = isLiquidGlass,
                unifiedRepository = unifiedRepository,
                favoriteRepository = favoriteRepository,
                songDao = songDao,
                cookies = cookieManager.getCookies(),
                onBack = { openedCategoryScreen = null },
                onPlaylistClick = { id ->
                    openedCategoryScreen = null
                    onPlaylistClick(id)
                },
                onCreatePlaylistClick = { showCreatePlaylistDialog = true },
                onAddToPlaylistClick = { song -> showPlaylistDialogFor = song }
            )
        }

        if (isSyncing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.85f))
                    .clickable(enabled = false) { },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(32.dp)
                        .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp))
                        .padding(32.dp)
                ) {
                    StandardLoader(size = 48.dp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "Restoring Library",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Bringing back your favorites and playlists...",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        if (showLibraryTutorial) {
            TutorialOverlay(
                title = "Your Personal Universe",
                description = "Manage your music here. Sync with YouTube to bring your likes, or explore your collections.",
                onDismiss = {
                    showLibraryTutorial = false
                    settingsManager.hasSeenLibraryTutorial = true
                }
            )
        }
    }
}

@Composable
private fun LibraryCategoryDetailScreen(
    category: String,
    likedSongs: List<com.tervixa.wavemuzix.data.database.FavoriteSongEntity>,
    followedArtists: List<com.tervixa.wavemuzix.repository.FollowedArtist>,
    mostPlayedSongs: List<com.tervixa.wavemuzix.data.database.MostPlayedSongEntity>,
    downloadedSongs: List<com.tervixa.wavemuzix.data.database.DownloadedSongEntity>,
    playlists: List<com.tervixa.wavemuzix.data.database.PlaylistEntity>,
    isLiquidGlass: Boolean,
    unifiedRepository: UnifiedMusicRepository,
    favoriteRepository: FavoriteRepository,
    songDao: com.tervixa.wavemuzix.data.database.SongDao,
    cookies: String?,
    onBack: () -> Unit,
    onPlaylistClick: (String) -> Unit,
    onCreatePlaylistClick: () -> Unit,
    onAddToPlaylistClick: (SongModel) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val detailListState = rememberLazyListState()
    var filterQuery by remember { mutableStateOf("") }

    val categoryPlayableSongs = remember(category, likedSongs, mostPlayedSongs, downloadedSongs) {
        when (category) {
            "Favorite" -> likedSongs.map { s ->
                SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId)
            }
            "Most Played" -> mostPlayedSongs.map { s ->
                SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId)
            }
            "Downloaded" -> downloadedSongs.map { s ->
                SongModel(id = s.videoId, videoId = s.videoId, title = s.title, artist = s.artist, thumbnailUrl = s.thumbnailUrl, artistId = s.artistId, thumbnailPath = s.thumbnailPath, lyrics = s.lyrics)
            }
            else -> emptyList()
        }
    }

    val bgCol = MaterialTheme.colorScheme.background
    val categoryBackdrop = rememberLayerBackdrop {
        drawRect(bgCol)
        drawContent()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgCol)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .layerBackdrop(categoryBackdrop)
                .background(bgCol)
        ) {
            AmbientThemeGlow(
                tint = MusicPlayer.accentColors.firstOrNull() ?: MaterialTheme.colorScheme.primary,
                scrollState = detailListState
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Top Header Bar (sibling of categoryBackdrop)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CompositionLocalProvider(LocalBackdrop provides categoryBackdrop) {
                        GlassIconButton(
                            icon = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            onClick = onBack,
                            isLiquidGlass = isLiquidGlass
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = when (category) {
                                "Favorite" -> "Favorite Songs"
                                "Followed" -> "Followed Artists"
                                "Most Played" -> "Most Played"
                                "Downloaded" -> "Downloaded Songs"
                                "Playlists" -> "Your Playlists"
                                else -> category
                            },
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        )
                        val countSubtitle = when (category) {
                            "Favorite" -> "${likedSongs.size} tracks"
                            "Followed" -> "${followedArtists.size} artists"
                            "Most Played" -> "${mostPlayedSongs.size} tracks"
                            "Downloaded" -> "${downloadedSongs.size} offline tracks"
                            "Playlists" -> "${playlists.size} custom playlists"
                            else -> ""
                        }
                        Text(
                            text = countSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (category == "Playlists") {
                    FilledTonalButton(
                        onClick = onCreatePlaylistClick,
                        shape = CircleShape,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("New", style = MaterialTheme.typography.labelMedium)
                    }
                } else if (category == "Downloaded" && downloadedSongs.isNotEmpty()) {
                    TextButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            DownloadManager.exportAllSongsToStorage(context, downloadedSongs)
                        }
                    }) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Export All")
                    }
                }
            }

            // Play All / Shuffle Action Strip for song collections
            if (categoryPlayableSongs.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            MusicPlayer.shuffleEnabled = false
                            if (category == "Downloaded") {
                                val firstDown = downloadedSongs.first()
                                MusicPlayer.playOffline(
                                    context = context,
                                    filePath = firstDown.filePath,
                                    song = categoryPlayableSongs.first(),
                                    playlist = categoryPlayableSongs,
                                    mimeType = firstDown.mimeType,
                                    isFromFixedList = true
                                )
                            } else {
                                MusicPlayer.playSong(
                                    context = context,
                                    song = categoryPlayableSongs.first(),
                                    playlist = categoryPlayableSongs,
                                    cookies = cookies,
                                    isFromFixedList = true
                                )
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Play All", fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = {
                            val shuffled = categoryPlayableSongs.shuffled()
                            MusicPlayer.shuffleEnabled = true
                            MusicPlayer.playSong(
                                context = context,
                                song = shuffled.first(),
                                playlist = shuffled,
                                cookies = cookies,
                                isFromFixedList = true
                            )
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Shuffle", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Quick Filter Bar
            OutlinedTextField(
                value = filterQuery,
                onValueChange = { filterQuery = it },
                placeholder = { Text("Filter in $category...") },
                leadingIcon = { Icon(WaveIcons.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (filterQuery.isNotEmpty()) {
                        IconButton(onClick = { filterQuery = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            )

            LazyColumn(
                state = detailListState,
                modifier = Modifier.fillMaxSize(),
                flingBehavior = rememberSmoothFlingBehavior(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 190.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (category) {
                    "Favorite" -> {
                        val filtered = likedSongs.filter {
                            filterQuery.isBlank() || it.title.contains(filterQuery, true) || it.artist.contains(filterQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = Icons.Rounded.FavoriteBorder,
                                    title = "No favorite songs yet",
                                    subtitle = "Tap the heart button on any song to save it here"
                                )
                            }
                        }
                        itemsIndexed(filtered, key = { idx, s -> "fav_screen_${s.videoId}_$idx" }) { _, song ->
                            val songModel = SongModel(
                                id = song.videoId,
                                videoId = song.videoId,
                                title = song.title,
                                artist = song.artist,
                                thumbnailUrl = song.thumbnailUrl,
                                artistId = song.artistId
                            )
                            var showOptions by remember { mutableStateOf(false) }
                            val isDownloaded = downloadedSongs.any { it.videoId == song.videoId }

                            LibraryListItem(
                                title = song.title,
                                subtitle = song.artist,
                                leadingIcon = Icons.Rounded.MusicNote,
                                imageUrl = song.thumbnailUrl,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable {
                                    MusicPlayer.playSong(
                                        context = context,
                                        song = songModel,
                                        playlist = categoryPlayableSongs,
                                        cookies = cookies,
                                        isFromFixedList = true
                                    )
                                },
                                onMoreClick = { showOptions = true }
                            )

                            if (showOptions) {
                                SongOptionsBottomSheet(
                                    song = songModel,
                                    isFavorite = true,
                                    isDownloaded = isDownloaded,
                                    isLiquidGlass = isLiquidGlass,
                                    onDismiss = { showOptions = false },
                                    onFavoriteClick = { scope.launch { favoriteRepository.toggleFavorite(songModel) } },
                                    onDownloadClick = {
                                        scope.launch {
                                            if (isDownloaded) {
                                                songDao.deleteDownload(song.videoId)
                                                downloadedSongs.find { it.videoId == song.videoId }?.filePath?.let { File(it).delete() }
                                                Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                                            } else {
                                                MusicPlayer.enqueueAutoDownloadForSong(context, songModel)
                                                Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    onPlayNextClick = { MusicPlayer.playNext(songModel) },
                                    onAddToQueueClick = { MusicPlayer.addToQueue(songModel) },
                                    onArtistClick = {},
                                    onAddToPlaylistClick = {
                                        showOptions = false
                                        onAddToPlaylistClick(songModel)
                                    },
                                    onShareClick = {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Check out ${song.title} by ${song.artist}: https://www.youtube.com/watch?v=${song.videoId}")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, null))
                                    }
                                )
                            }
                        }
                    }

                    "Followed" -> {
                        val filtered = followedArtists.filter {
                            filterQuery.isBlank() || it.name.contains(filterQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = WaveIcons.Artist,
                                    title = "No followed artists yet",
                                    subtitle = "Follow artists to quickly access their releases"
                                )
                            }
                        }
                        items(filtered, key = { it.artistId }) { artist ->
                            LibraryListItem(
                                title = artist.name,
                                subtitle = "Followed Artist",
                                leadingIcon = WaveIcons.Artist,
                                imageUrl = artist.thumbnailUrl,
                                isCircleImage = true,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable {
                                    scope.launch {
                                        val songs = unifiedRepository.fetchArtistSongs(artist.name, null, cookies)
                                        if (songs.isNotEmpty()) {
                                            MusicPlayer.playSong(context, songs.first(), songs, cookies, isFromFixedList = true)
                                        }
                                    }
                                }
                            )
                        }
                    }

                    "Most Played" -> {
                        val filtered = mostPlayedSongs.filter {
                            filterQuery.isBlank() || it.title.contains(filterQuery, true) || it.artist.contains(filterQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = Icons.AutoMirrored.Rounded.TrendingUp,
                                    title = "No play history yet",
                                    subtitle = "Your top tracks will appear here as you listen"
                                )
                            }
                        }
                        itemsIndexed(filtered, key = { idx, s -> "mp_screen_${s.videoId}_$idx" }) { _, song ->
                            var showOptions by remember { mutableStateOf(false) }
                            val isDownloaded = downloadedSongs.any { it.videoId == song.videoId }
                            val isFavorite = likedSongs.any { it.videoId == song.videoId }
                            val songModel = SongModel(
                                id = song.videoId,
                                videoId = song.videoId,
                                title = song.title,
                                artist = song.artist,
                                thumbnailUrl = song.thumbnailUrl,
                                artistId = song.artistId
                            )

                            LibraryListItem(
                                title = song.title,
                                subtitle = "${song.artist} • ${song.playCount} plays",
                                leadingIcon = Icons.Rounded.MusicNote,
                                imageUrl = song.thumbnailUrl,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable {
                                    MusicPlayer.playSong(
                                        context = context,
                                        song = songModel,
                                        playlist = categoryPlayableSongs,
                                        cookies = cookies,
                                        isFromFixedList = true
                                    )
                                },
                                onMoreClick = { showOptions = true }
                            )

                            if (showOptions) {
                                SongOptionsBottomSheet(
                                    song = songModel,
                                    isFavorite = isFavorite,
                                    isDownloaded = isDownloaded,
                                    isLiquidGlass = isLiquidGlass,
                                    onDismiss = { showOptions = false },
                                    onFavoriteClick = { scope.launch { favoriteRepository.toggleFavorite(songModel) } },
                                    onDownloadClick = {
                                        MusicPlayer.enqueueAutoDownloadForSong(context, songModel)
                                        Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                                    },
                                    onPlayNextClick = { MusicPlayer.playNext(songModel) },
                                    onAddToQueueClick = { MusicPlayer.addToQueue(songModel) },
                                    onArtistClick = {},
                                    onAddToPlaylistClick = {
                                        showOptions = false
                                        onAddToPlaylistClick(songModel)
                                    },
                                    onShareClick = {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, "Check out ${song.title} by ${song.artist}: https://www.youtube.com/watch?v=${song.videoId}")
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, null))
                                    }
                                )
                            }
                        }
                    }

                    "Downloaded" -> {
                        val filtered = downloadedSongs.filter {
                            filterQuery.isBlank() || it.title.contains(filterQuery, true) || it.artist.contains(filterQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = Icons.Rounded.DownloadForOffline,
                                    title = "No downloads found",
                                    subtitle = "Download songs for offline playback anytime"
                                )
                            }
                        }
                        itemsIndexed(filtered, key = { idx, s -> "dl_screen_${s.videoId}_$idx" }) { _, song ->
                            var showActionDialog by remember { mutableStateOf(false) }
                            val songModel = SongModel(
                                id = song.videoId,
                                videoId = song.videoId,
                                title = song.title,
                                artist = song.artist,
                                thumbnailUrl = song.thumbnailUrl,
                                artistId = song.artistId,
                                thumbnailPath = song.thumbnailPath,
                                lyrics = song.lyrics
                            )
                            val displayImageUrl = remember(song.thumbnailPath, song.thumbnailUrl) {
                                if (song.thumbnailPath != null && File(song.thumbnailPath).exists()) {
                                    song.thumbnailPath
                                } else {
                                    song.thumbnailUrl
                                }
                            }

                            LibraryListItem(
                                title = song.title,
                                subtitle = song.artist,
                                leadingIcon = Icons.Rounded.MusicNote,
                                imageUrl = displayImageUrl,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable {
                                    MusicPlayer.playOffline(
                                        context = context,
                                        filePath = song.filePath,
                                        song = songModel,
                                        playlist = categoryPlayableSongs,
                                        mimeType = song.mimeType,
                                        isFromFixedList = true
                                    )
                                },
                                onMoreClick = { showActionDialog = true }
                            )

                            if (showActionDialog) {
                                DownloadActionDialog(
                                    song = songModel,
                                    filePath = song.filePath,
                                    mimeType = song.mimeType,
                                    isLiquidGlass = isLiquidGlass,
                                    onDismiss = { showActionDialog = false },
                                    onDelete = {
                                        scope.launch {
                                            songDao.deleteDownload(song.videoId)
                                            val file = File(song.filePath)
                                            if (file.exists()) file.delete()
                                            song.thumbnailPath?.let { path ->
                                                val thumbFile = File(path)
                                                if (thumbFile.exists()) thumbFile.delete()
                                            }
                                            Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                                        }
                                        showActionDialog = false
                                    },
                                    onFavoriteToggle = {
                                        scope.launch {
                                            favoriteRepository.toggleFavorite(songModel)
                                        }
                                    }
                                )
                            }
                        }
                    }

                    "Playlists" -> {
                        val filtered = playlists.filter {
                            filterQuery.isBlank() || it.name.contains(filterQuery, true)
                        }
                        if (filtered.isEmpty()) {
                            item {
                                EmptyLibrarySectionState(
                                    icon = Icons.AutoMirrored.Rounded.PlaylistPlay,
                                    title = "No custom playlists yet",
                                    subtitle = "Tap + New to create your first custom playlist"
                                )
                            }
                        }
                        items(filtered, key = { it.id }) { playlist ->
                            LibraryListItem(
                                title = playlist.name,
                                subtitle = "Custom Playlist",
                                leadingIcon = Icons.Rounded.QueueMusic,
                                isLiquidGlass = isLiquidGlass,
                                modifier = Modifier.clickable { onPlaylistClick("local_${playlist.id}") }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * SimpMusic `LibraryTilingBox` ported 1:1
 */
@Composable
private fun SimpLibraryTilingBox(
    favoriteThumbs: List<String>,
    favoriteCount: Int,
    followedThumbs: List<String>,
    followedCount: Int,
    mostPlayedThumbs: List<String>,
    mostPlayedCount: Int,
    downloadedThumbs: List<String>,
    downloadedCount: Int,
    playlistCount: Int,
    onSelectCategory: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SimpFavoriteCard(
            thumbs = favoriteThumbs,
            trackCount = favoriteCount,
            onClick = { onSelectCategory("Favorite") }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SimpCollectionCard(
                title = "Followed",
                subtitle = "$followedCount artists",
                icon = WaveIcons.Artist,
                accentColor = MaterialTheme.colorScheme.tertiary,
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                thumbs = followedThumbs,
                modifier = Modifier.weight(1f),
                onClick = { onSelectCategory("Followed") }
            )
            SimpCollectionCard(
                title = "Most Played",
                subtitle = "$mostPlayedCount tracks",
                icon = Icons.AutoMirrored.Rounded.TrendingUp,
                accentColor = MaterialTheme.colorScheme.secondary,
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                thumbs = mostPlayedThumbs,
                modifier = Modifier.weight(1f),
                onClick = { onSelectCategory("Most Played") }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SimpCollectionCard(
                title = "Downloaded",
                subtitle = "$downloadedCount tracks",
                icon = Icons.Rounded.DownloadForOffline,
                accentColor = MaterialTheme.colorScheme.primary,
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                thumbs = downloadedThumbs,
                modifier = Modifier.weight(1f),
                onClick = { onSelectCategory("Downloaded") }
            )
            SimpCollectionCard(
                title = "Playlists",
                subtitle = "$playlistCount playlists",
                icon = Icons.AutoMirrored.Rounded.PlaylistPlay,
                accentColor = MaterialTheme.colorScheme.tertiary,
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                thumbs = emptyList(),
                modifier = Modifier.weight(1f),
                onClick = { onSelectCategory("Playlists") }
            )
        }
    }
}

@Composable
private fun SimpFavoriteCard(
    thumbs: List<String>,
    trackCount: Int,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer
    val surfaceHigh = MaterialTheme.colorScheme.surfaceContainerHigh
    val onContainer = MaterialTheme.colorScheme.onPrimaryContainer
    val shape = RoundedCornerShape(24.dp)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(132.dp)
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        color = Color.Transparent,
        border = BorderStroke(1.dp, primary.copy(alpha = 0.24f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            primaryContainer.copy(alpha = 0.90f),
                            surfaceHigh.copy(alpha = 0.95f)
                        ),
                        start = Offset.Zero,
                        end = Offset(1000f, 500f)
                    )
                )
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(primary.copy(alpha = 0.34f), Color.Transparent),
                            center = Offset(size.width * 0.85f, size.height * 0.2f),
                            radius = size.width * 0.55f
                        ),
                        radius = size.width * 0.55f,
                        center = Offset(size.width * 0.85f, size.height * 0.2f)
                    )
                }
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .align(Alignment.CenterStart),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(primary.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Favorite,
                        contentDescription = "Favorite",
                        tint = primary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = "Favorite",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = onContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$trackCount liked tracks",
                        style = MaterialTheme.typography.bodySmall,
                        color = onContainer.copy(alpha = 0.72f)
                    )
                }
            }

            Box(
                modifier = Modifier.align(Alignment.CenterEnd),
                contentAlignment = Alignment.Center
            ) {
                SleeveFan(
                    thumbs = thumbs,
                    sleeveSize = 72.dp,
                    cornerRadius = 14.dp,
                    maxCount = 3,
                    emptyIcon = Icons.Rounded.Favorite,
                    accentColor = primary
                )
            }
        }
    }
}

@Composable
private fun SimpCollectionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    containerColor: Color,
    thumbs: List<String>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val surface = MaterialTheme.colorScheme.surfaceContainer
    val onSurface = MaterialTheme.colorScheme.onSurface
    val shape = RoundedCornerShape(20.dp)

    Surface(
        modifier = modifier
            .height(118.dp)
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        color = Color.Transparent,
        border = BorderStroke(1.dp, onSurface.copy(alpha = 0.08f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            surface,
                            containerColor.copy(alpha = 0.55f)
                        ),
                        start = Offset.Zero,
                        end = Offset(500f, 400f)
                    )
                )
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accentColor.copy(alpha = 0.18f))
                    .align(Alignment.TopStart),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Box(
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                SleeveFan(
                    thumbs = thumbs,
                    sleeveSize = 46.dp,
                    cornerRadius = 10.dp,
                    maxCount = 2,
                    emptyIcon = icon,
                    accentColor = accentColor
                )
            }

            Column(
                modifier = Modifier.align(Alignment.BottomStart)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = onSurface.copy(alpha = 0.65f),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun SleeveFan(
    thumbs: List<String>,
    sleeveSize: Dp,
    cornerRadius: Dp,
    maxCount: Int,
    emptyIcon: ImageVector,
    accentColor: Color
) {
    val visible = thumbs.take(maxCount)
    if (visible.isEmpty()) {
        EmptySleeve(
            size = sleeveSize,
            cornerRadius = cornerRadius,
            icon = emptyIcon,
            accentColor = accentColor
        )
        return
    }

    val step = sleeveSize * 0.34f
    val totalWidth = sleeveSize + step * (visible.size - 1)
    val shape = RoundedCornerShape(cornerRadius)

    val rotations = when (visible.size) {
        1 -> listOf(4f)
        2 -> listOf(-8f, 6f)
        else -> listOf(-14f, -4f, 6f)
    }

    Box(
        modifier = Modifier
            .width(totalWidth)
            .height(sleeveSize),
        contentAlignment = Alignment.CenterStart
    ) {
        visible.forEachIndexed { index, url ->
            val rotation = rotations.getOrElse(index) { 0f }
            Box(
                modifier = Modifier
                    .offset(x = step * index)
                    .size(sleeveSize)
                    .graphicsLayer {
                        rotationZ = rotation
                        transformOrigin = TransformOrigin(0.5f, 0.9f)
                    }
                    .shadow(elevation = 6.dp, shape = shape, clip = false)
                    .clip(shape)
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.18f),
                        shape = shape
                    )
            ) {
                WaveArtworkImage(
                    url = url,
                    contentDescription = null,
                    isVideo = false,
                    shape = shape,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun EmptySleeve(
    size: Dp,
    cornerRadius: Dp,
    icon: ImageVector,
    accentColor: Color
) {
    val shape = RoundedCornerShape(cornerRadius)
    val dashEffect = remember {
        PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    Box(
        modifier = Modifier
            .size(size)
            .graphicsLayer { rotationZ = 5f }
            .clip(shape)
            .background(accentColor.copy(alpha = 0.08f))
            .drawWithContent {
                drawContent()
                val strokeWidth = 1.2.dp.toPx()
                val radius = cornerRadius.toPx()
                drawRoundRect(
                    color = accentColor.copy(alpha = 0.38f),
                    style = Stroke(width = strokeWidth, pathEffect = dashEffect),
                    cornerRadius = CornerRadius(radius, radius)
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor.copy(alpha = 0.55f),
            modifier = Modifier.size(size * 0.42f)
        )
    }
}

@Composable
private fun EmptyLibrarySectionState(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 36.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadActionDialog(
    song: SongModel,
    filePath: String,
    mimeType: String? = null,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val favoriteRepository = remember { FavoriteRepository(AppDatabase.getDatabase(context).songDao(), context) }
    var isFavorite by remember { mutableStateOf(false) }

    LaunchedEffect(song.videoId) {
        isFavorite = favoriteRepository.isFavorite(song.videoId)
    }

    val floatingShape = RoundedCornerShape(28.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassContainer(
                        shape = floatingShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true
                    )
                    .padding(bottom = 16.dp, start = 16.dp, end = 16.dp, top = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 10.dp)
                        .width(38.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.30f))
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WaveArtworkImage(
                        url = song.thumbnailUrl,
                        contentDescription = song.title,
                        isVideo = false,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = MaterialTheme.colorScheme.onSurface,
                            color = Color.White, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 15.5.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                                .focusable()
                        )
                        Text(
                            text = song.artist,
                            color = Color.White.copy(alpha = 0.88f),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                                .focusable()
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(6.dp))

                ActionItem(
                    icon = Icons.Rounded.Queue,
                    text = "Add to Queue",
                    onClick = {
                        MusicPlayer.addToQueue(song)
                        Toast.makeText(context, "Added to queue", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }
                )

                ActionItem(
                    icon = Icons.AutoMirrored.Rounded.PlaylistPlay,
                    text = "Play Next",
                    onClick = {
                        MusicPlayer.playNext(song)
                        Toast.makeText(context, "Will play next", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }
                )

                ActionItem(
                    icon = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    text = if (isFavorite) "Remove from Favorites" else "Add to Favorites",
                    iconColor = if (isFavorite) Color(0xFFFF2D55) else MaterialTheme.colorScheme.onSurface,
                    onClick = {
                        onFavoriteToggle()
                        isFavorite = !isFavorite
                    }
                )

                ActionItem(
                    icon = Icons.Rounded.Share,
                    text = "Share Song",
                    onClick = {
                        try {
                            val file = File(filePath)
                            val uri = FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.provider",
                                file
                            )
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "audio/*"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                putExtra(Intent.EXTRA_SUBJECT, "Sharing ${song.title}")
                                putExtra(Intent.EXTRA_TEXT, "Check out ${song.title} by ${song.artist}")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share via"))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Failed to share: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    }
                )

                ActionItem(
                    icon = Icons.Rounded.Download,
                    text = "Export to Storage",
                    onClick = {
                        scope.launch {
                            try {
                                DownloadManager.exportSongToStorage(context, song, filePath, mimeType)
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "Export error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        onDismiss()
                    }
                )

                ActionItem(
                    icon = Icons.Rounded.Delete,
                    text = "Delete Download",
                    iconColor = Color.Red.copy(alpha = 0.85f),
                    onClick = onDelete
                )
            }
        }
    }
}

@Composable
private fun ActionItem(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit,
    iconColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun LibraryListItem(
    title: String,
    subtitle: String,
    leadingIcon: ImageVector,
    isLiquidGlass: Boolean,
    modifier: Modifier = Modifier,
    imageUrl: String? = null,
    isCircleImage: Boolean = false,
    onMoreClick: (() -> Unit)? = null
) {
    val imgShape = if (isCircleImage) CircleShape else RoundedCornerShape(10.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .padding(vertical = 4.5.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!imageUrl.isNullOrBlank()) {
            WaveArtworkImage(
                url = imageUrl,
                contentDescription = title,
                isVideo = false,
                shape = imgShape,
                modifier = Modifier.size(44.dp)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(imgShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    leadingIcon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200
                    )
                    .focusable()
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200
                    )
                    .focusable()
            )
        }
        if (onMoreClick != null) {
            IconButton(onClick = onMoreClick) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "More",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
