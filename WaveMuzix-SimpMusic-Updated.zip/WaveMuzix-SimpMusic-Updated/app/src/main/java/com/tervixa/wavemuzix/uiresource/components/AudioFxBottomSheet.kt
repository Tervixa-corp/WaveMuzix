package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.data.AudioFxManager
import kotlin.math.roundToInt

/**
 * Clean SimpMusic-style Filter Chip without Material3's `ElevatedFilterChip` hardware shadow caster,
 * completely eliminating the transparent rectangular box artifact behind the text on translucent surfaces.
 */
@Composable
fun WaveFilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selectedContainerColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.24f),
    unselectedContainerColor: Color = Color.White.copy(alpha = 0.07f),
    selectedTextColor: Color = Color.White,
    unselectedTextColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) selectedContainerColor else unselectedContainerColor,
        animationSpec = tween(180),
        label = "chipBg",
    )
    val borderColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.12f),
        animationSpec = tween(180),
        label = "chipBorder",
    )
    val textColor by animateColorAsState(
        targetValue = if (selected) selectedTextColor else unselectedTextColor,
        animationSpec = tween(180),
        label = "chipText",
    )

    val chipShape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(chipShape)
            .background(bgColor, chipShape)
            .border(width = 1.dp, color = borderColor, shape = chipShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 13.sp,
                lineHeight = 16.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                background = Color.Transparent,
            ),
            color = textColor,
            maxLines = 1,
        )
    }
}

/**
 * SimpMusic Built-In AudioFX Equalizer Modal Bottom Sheet:
 * Interactive 10-band graphic EQ with frequency response curve, 22 SimpMusic presets,
 * Bass Boost, 3D Virtualizer, and Preamp gain control.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuiltInEqualizerBottomSheet(
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    AudioFxManager.ensureLoaded(context)
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val accent = MaterialTheme.colorScheme.primary
    val isEnabled = AudioFxManager.isEnabled
    val currentPreset = AudioFxManager.currentPreset
    val bandGains = AudioFxManager.bandGainsDb

    val floatingShape = RoundedCornerShape(30.dp)
    WaveGlassBottomSheet(
        onDismissRequest = onDismiss,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .glassContainer(
                    shape = floatingShape,
                    isLiquidGlass = true,
                    baseAlpha = 0.88f,
                    blurScale = 1.28f,
                    deepFrostedSheet = true,
                    borderWidth = 1.2.dp,
                )
                .clip(floatingShape)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp),
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Equalizer,
                            contentDescription = "Built-In Equalizer",
                            tint = accent,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                    Column {
                        Text(
                            text = "Wave AudioFX Equalizer",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                            ),
                            color = Color.White,
                        )
                        Text(
                            text = if (isEnabled) "Active • $currentPreset" else "Bypassed",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.6f),
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { AudioFxManager.resetToFlat(context) }) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Reset to Flat",
                            tint = Color.White.copy(alpha = 0.75f),
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { AudioFxManager.setEnabled(context, it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = accent,
                        ),
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 22 SimpMusic Presets Row
            Text(
                text = "Presets",
                style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                color = Color.White.copy(alpha = 0.7f),
            )
            Spacer(modifier = Modifier.height(8.dp))
            val presetNames = AudioFxManager.PRESETS.keys.toList()
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(end = 8.dp),
            ) {
                items(presetNames, key = { it }) { preset ->
                    WaveFilterChip(
                        text = preset,
                        selected = currentPreset == preset,
                        onClick = { AudioFxManager.selectPreset(context, preset) },
                        selectedContainerColor = accent.copy(alpha = 0.28f),
                        selectedTextColor = Color.White,
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Real-time Frequency Response Spline Curve
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1A1A22))
                    .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                val points = bandGains.toList()
                Canvas(modifier = Modifier.fillMaxWidth().fillMaxHeight()) {
                    val w = size.width
                    val h = size.height
                    val midY = h / 2f

                    // 0 dB center line
                    drawLine(
                        color = Color.White.copy(alpha = 0.12f),
                        start = Offset(0f, midY),
                        end = Offset(w, midY),
                        strokeWidth = 1.dp.toPx(),
                    )

                    if (points.size >= 2) {
                        val stepX = w / (points.size - 1).toFloat()
                        val coords = points.mapIndexed { idx, db ->
                            val normalized = (db.coerceIn(-12f, 12f) / 12f)
                            val x = idx * stepX
                            val y = midY - normalized * (midY * 0.82f)
                            Offset(x, y)
                        }

                        val curvePath = Path().apply {
                            moveTo(coords.first().x, coords.first().y)
                            for (i in 0 until coords.size - 1) {
                                val p0 = coords[i]
                                val p1 = coords[i + 1]
                                val ctrlX = (p0.x + p1.x) / 2f
                                cubicTo(ctrlX, p0.y, ctrlX, p1.y, p1.x, p1.y)
                            }
                        }

                        val fillPath = Path().apply {
                            addPath(curvePath)
                            lineTo(coords.last().x, h)
                            lineTo(coords.first().x, h)
                            close()
                        }

                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    accent.copy(alpha = if (isEnabled) 0.34f else 0.1f),
                                    Color.Transparent,
                                )
                            ),
                        )

                        drawPath(
                            path = curvePath,
                            color = if (isEnabled) accent else Color.White.copy(alpha = 0.35f),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
                        )

                        coords.forEach { pt ->
                            drawCircle(
                                color = if (isEnabled) Color.White else Color.White.copy(alpha = 0.4f),
                                radius = 3.5.dp.toPx(),
                                center = pt,
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 10-Band Vertical Sliders
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                AudioFxManager.FREQUENCY_LABELS.forEachIndexed { index, freqLabel ->
                    val gain = bandGains.getOrElse(index) { 0f }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(42.dp),
                    ) {
                        Text(
                            text = "%+.0f".format(gain),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                            color = if (gain != 0f && isEnabled) accent else Color.White.copy(alpha = 0.5f),
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Slider(
                            value = gain,
                            onValueChange = { newDb ->
                                AudioFxManager.setBandGain(context, index, newDb)
                            },
                            enabled = isEnabled,
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = accent,
                                inactiveTrackColor = Color.White.copy(alpha = 0.15f),
                            ),
                            modifier = Modifier
                                .graphicsLayer {
                                    rotationZ = 270f
                                    transformOrigin = TransformOrigin(0f, 0f)
                                }
                                .layout { measurable, constraints ->
                                    val placeable = measurable.measure(
                                        Constraints(
                                            minWidth = constraints.minHeight,
                                            maxWidth = constraints.maxHeight,
                                            minHeight = constraints.minWidth,
                                            maxHeight = constraints.maxHeight,
                                        )
                                    )
                                    layout(placeable.height, placeable.width) {
                                        placeable.place(-placeable.width, 0)
                                    }
                                }
                                .width(148.dp)
                                .height(36.dp),
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = freqLabel,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                            ),
                            color = Color.White.copy(alpha = 0.7f),
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // DSP Knobs / Sliders: Bass Boost, 3D Virtualizer, Preamp Gain
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1A1A22))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Bass Boost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Bass Boost",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                    )
                    Text(
                        text = "${(AudioFxManager.bassBoostStrength / 10f).roundToInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                    )
                }
                Slider(
                    value = AudioFxManager.bassBoostStrength.toFloat(),
                    onValueChange = { AudioFxManager.setBassBoost(context, it.roundToInt()) },
                    enabled = isEnabled,
                    valueRange = 0f..1000f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f),
                    ),
                )

                // 3D Spatializer / Virtualizer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "3D Spatializer & Surround",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                    )
                    Text(
                        text = "${(AudioFxManager.virtualizerStrength / 10f).roundToInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                    )
                }
                Slider(
                    value = AudioFxManager.virtualizerStrength.toFloat(),
                    onValueChange = { AudioFxManager.setVirtualizer(context, it.roundToInt()) },
                    enabled = isEnabled,
                    valueRange = 0f..1000f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f),
                    ),
                )

                // Preamp Gain
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Preamp Gain",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                    )
                    Text(
                        text = "%+.1f dB".format(AudioFxManager.preampDb),
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                    )
                }
                Slider(
                    value = AudioFxManager.preampDb,
                    onValueChange = { AudioFxManager.setPreamp(context, it) },
                    enabled = isEnabled,
                    valueRange = -8f..8f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f),
                    ),
                )
            }
        }
    }
}
