package com.tervixa.wavemuzix.utils

import android.content.Context
import com.tervixa.wavemuzix.data.PerformanceConfig

object PerformanceUtils {
    fun getPerformanceConfig(context: Context): PerformanceConfig {
        return PerformanceConfig()
    }
}
