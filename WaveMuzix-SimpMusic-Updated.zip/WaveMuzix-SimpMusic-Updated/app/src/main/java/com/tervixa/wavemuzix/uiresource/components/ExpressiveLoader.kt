package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Modern Material 3 Expressive + OriginOS-inspired harmonic wave-orbit loader.
 * Combines:
 * 1) A breathing scalloped/wavy outer track ring,
 * 2) A sweeping variable-arc comet trail, and
 * 3) A luminous orbiting droplet that accelerates and decelerates smoothly.
 */
@Composable
fun ExpressiveLoader(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ExpressiveLoader")

    val orbitProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1350, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "orbitProgress",
    )

    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "wavePhase",
    )

    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "breathScale",
    )

    val expressiveEasing = CubicBezierEasing(0.55f, 0.05f, 0.35f, 0.95f)

    Canvas(modifier = modifier.size(size)) {
        val diameter = size.toPx()
        val center = Offset(diameter / 2f, diameter / 2f)
        val strokeWidth = (diameter * 0.085f).coerceAtLeast(2.5.dp.toPx())
        val baseRadius = (diameter - strokeWidth * 2.2f) / 2f * breathScale

        // 1) Expressive wavy harmonic ring path (8 gentle lobes)
        val waveAmplitude = diameter * 0.032f
        val wavePath = Path()
        val steps = 72
        for (i in 0..steps) {
            val theta = (i.toFloat() / steps) * (2f * PI.toFloat())
            val r = baseRadius + waveAmplitude * sin(6f * theta + wavePhase)
            val px = center.x + r * cos(theta)
            val py = center.y + r * sin(theta)
            if (i == 0) wavePath.moveTo(px, py) else wavePath.lineTo(px, py)
        }
        wavePath.close()

        drawPath(
            path = wavePath,
            color = color.copy(alpha = 0.18f),
            style = Stroke(width = strokeWidth * 0.75f, cap = StrokeCap.Round),
        )

        // 2) Sweeping variable-length arc comet
        val eased = expressiveEasing.transform(orbitProgress)
        val headAngleDeg = eased * 360f - 90f
        val sweepDeg = 75f + 85f * sin(orbitProgress * PI.toFloat())

        rotate(degrees = headAngleDeg, pivot = center) {
            drawArc(
                brush = Brush.sweepGradient(
                    0f to Color.Transparent,
                    0.55f to color.copy(alpha = 0.35f),
                    1f to color,
                    center = center,
                ),
                startAngle = 360f - sweepDeg,
                sweepAngle = sweepDeg,
                useCenter = false,
                topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                size = Size(baseRadius * 2f, baseRadius * 2f),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
        }

        // 3) Orbiting luminous head droplet
        val headRad = (headAngleDeg * PI / 180.0).toFloat()
        val dotX = center.x + baseRadius * cos(headRad)
        val dotY = center.y + baseRadius * sin(headRad)
        val dotRadius = strokeWidth * 0.78f

        drawCircle(
            color = color.copy(alpha = 0.32f),
            radius = dotRadius * 1.65f,
            center = Offset(dotX, dotY),
        )
        drawCircle(
            color = color,
            radius = dotRadius,
            center = Offset(dotX, dotY),
        )
    }
}
