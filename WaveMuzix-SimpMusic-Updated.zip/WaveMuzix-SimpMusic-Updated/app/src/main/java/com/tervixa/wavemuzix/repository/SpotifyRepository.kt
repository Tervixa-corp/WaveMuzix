package com.tervixa.wavemuzix.repository

import android.util.Log
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.SongArtist
import com.tervixa.wavemuzix.model.isRecordLabelOrChannelName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class SpotifyTrackMetadata(
    val trackId: String,
    val title: String,
    val artists: List<SongArtist>,
    val albumName: String?,
    val artworkUrl: String?,
    val durationMs: Long?,
    val canvasUrl: String? = null,
)

/**
 * SimpMusic-style Spotify & Hidden Web Scraper Metadata Repository:
 * - Implements SimpMusic's hidden Spotify Web Scraper:
 *   1) Scrapes `<script id="session" data-testid="session" type="application/json">` from `https://open.spotify.com/`
 *      (just like SimpMusic's `SpotifyLoginScreen.kt` / `Spotify.kt`) to obtain anonymous or authenticated
 *      `accessToken` and `clientId` without requiring a Spotify Developer API key!
 *   2) Scrapes `https://open.spotify.com/embed/track/<id>` (`__NEXT_DATA__` JSON payload) for zero-auth track
 *      and multi-singer credits, 640x640 HD cover art, and exact duration.
 *   3) Supports authenticated `sp_dc` cookie exchange and iTunes/Apple Music 600x600 fallback.
 */
object SpotifyRepository {
    private val metadataCache = ConcurrentHashMap<String, SpotifyTrackMetadata>()

    @Volatile
    private var cachedAccessToken: String? = null

    @Volatile
    private var cachedClientId: String? = null

    @Volatile
    private var tokenExpiresAtMs: Long = 0L

    private val SESSION_SCRIPT_REGEX = Regex(
        "<script\\s+id=\"session\"[^>]*>(.*?)</script>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE),
    )
    private val NEXT_DATA_SCRIPT_REGEX = Regex(
        "<script\\s+id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE),
    )

    private val httpClient: OkHttpClient by lazy {
        val dispatcher = Dispatcher(Executors.newFixedThreadPool(12)).apply {
            maxRequests = 48
            maxRequestsPerHost = 16
        }
        OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()
    }

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    /**
     * Updates the cached Spotify session credentials directly when captured by the hidden WebView scraper
     * in `ConnectServiceLoginScreen`.
     */
    fun updateScrapedSession(accessToken: String?, clientId: String?, expiresAtMs: Long = System.currentTimeMillis() + 3000_000L) {
        if (!accessToken.isNullOrBlank()) {
            cachedAccessToken = accessToken
            tokenExpiresAtMs = expiresAtMs
        }
        if (!clientId.isNullOrBlank()) {
            cachedClientId = clientId
        }
    }

    /**
     * SimpMusic's hidden Spotify scraper:
     * Fetches `https://open.spotify.com/` (or `/get_access_token`) with the optional `sp_dc` cookie,
     * extracts `<script id="session" data-testid="session" type="application/json">{accessToken, clientId}</script>`,
     * and caches the live web player bearer token!
     */
    private suspend fun getSpotifyAccessToken(spDcCookie: String?): String? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val existing = cachedAccessToken
        if (!existing.isNullOrBlank() && now < tokenExpiresAtMs) {
            return@withContext existing
        }

        val cookieHeader = spDcCookie?.trim()?.takeIf { it.isNotEmpty() }?.let {
            if (it.contains("sp_dc=")) it else "sp_dc=$it"
        }

        // 1. SimpMusic Hidden HTML <script id="session"> Scraper on open.spotify.com
        try {
            val pageReq = Request.Builder()
                .url("https://open.spotify.com/")
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .apply {
                    if (cookieHeader != null) header("Cookie", cookieHeader)
                }
                .build()

            httpClient.newCall(pageReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val html = resp.body?.string().orEmpty()
                    val sessionJsonStr = SESSION_SCRIPT_REGEX.find(html)?.groupValues?.getOrNull(1)?.trim()
                    if (!sessionJsonStr.isNullOrBlank()) {
                        val json = JSONObject(sessionJsonStr)
                        val token = json.optString("accessToken").takeIf { it.isNotBlank() }
                        val clientId = json.optString("clientId").takeIf { it.isNotBlank() }
                        val expMs = json.optLong("accessTokenExpirationTimestampMs", now + 1800_000L)
                        if (clientId != null) cachedClientId = clientId
                        if (token != null) {
                            cachedAccessToken = token
                            tokenExpiresAtMs = expMs - 30_000L
                            return@withContext token
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SpotifyRepository", "Hidden HTML session scrape fallback: ${e.message}")
        }

        // 2. Direct web_player get_access_token endpoint fallback
        try {
            val reqBuilder = Request.Builder()
                .url("https://open.spotify.com/get_access_token?reason=transport&productType=web_player")
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
            if (cookieHeader != null) {
                reqBuilder.header("Cookie", cookieHeader)
            }

            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val body = resp.body?.string().orEmpty()
                if (body.isBlank()) return@use
                val json = JSONObject(body)
                val token = json.optString("accessToken").takeIf { it.isNotBlank() } ?: return@use
                val expiresMs = json.optLong("accessTokenExpirationTimestampMs", now + 1800_000L)
                cachedAccessToken = token
                tokenExpiresAtMs = expiresMs - 30_000L
                return@withContext token
            }
        } catch (e: Exception) {
            Log.w("SpotifyRepository", "Spotify web token fetch skipped: ${e.message}")
        }
        null
    }

    /**
     * Hidden Spotify Embed Scraper (`https://open.spotify.com/embed/track/<trackId>`):
     * Parses `__NEXT_DATA__` from Spotify's public embed page without needing any OAuth key.
     */
    suspend fun scrapeSpotifyEmbedTrack(trackId: String): SpotifyTrackMetadata? = withContext(Dispatchers.IO) {
        if (trackId.isBlank()) return@withContext null
        try {
            val req = Request.Builder()
                .url("https://open.spotify.com/embed/track/$trackId")
                .header("User-Agent", USER_AGENT)
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val html = resp.body?.string().orEmpty()
                val nextDataStr = NEXT_DATA_SCRIPT_REGEX.find(html)?.groupValues?.getOrNull(1)?.trim() ?: return@use
                val entity = JSONObject(nextDataStr)
                    .optJSONObject("props")
                    ?.optJSONObject("pageProps")
                    ?.optJSONObject("state")
                    ?.optJSONObject("data")
                    ?.optJSONObject("entity") ?: return@use

                val title = entity.optString("title").ifBlank { entity.optString("name") }
                val durationMs = entity.optLong("duration").takeIf { it > 0L }
                val artistsArr = entity.optJSONArray("artists")
                val artists = mutableListOf<SongArtist>()
                if (artistsArr != null) {
                    for (i in 0 until artistsArr.length()) {
                        val a = artistsArr.getJSONObject(i)
                        val name = a.optString("name").trim()
                        if (name.isNotEmpty()) artists.add(SongArtist(name = name))
                    }
                }
                val coverSources = entity.optJSONObject("visualIdentity")
                    ?.optJSONObject("image")
                val coverArr = coverSources?.optJSONArray("sources")
                val artworkUrl = if (coverArr != null && coverArr.length() > 0) {
                    coverArr.getJSONObject(0).optString("url")
                } else null

                if (title.isNotBlank() && artists.isNotEmpty()) {
                    return@withContext SpotifyTrackMetadata(
                        trackId = trackId,
                        title = title,
                        artists = artists,
                        albumName = null,
                        artworkUrl = artworkUrl,
                        durationMs = durationMs,
                    )
                }
            }
        } catch (e: Exception) {
            Log.w("SpotifyRepository", "Embed scrape failed: ${e.message}")
        }
        null
    }

    /**
     * Resolves accurate track metadata (all singers/artists, high-res cover art, exact duration)
     * using SimpMusic's hidden Spotify scraper + Web API + public catalog fallback.
     */
    suspend fun searchTrackMetadata(
        title: String,
        artistHint: String,
        spDcCookie: String? = null,
    ): SpotifyTrackMetadata? = withContext(Dispatchers.IO) {
        val cleanTitle = cleanQueryTitle(title)
        if (cleanTitle.isBlank()) return@withContext null

        val cleanArtist = if (isRecordLabelOrChannelName(artistHint)) "" else {
            artistHint.replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "").trim()
        }
        val cacheKey = "${cleanTitle.lowercase()}|${cleanArtist.lowercase()}"
        metadataCache[cacheKey]?.let { return@withContext it }

        val query = if (cleanArtist.isNotBlank()) "$cleanTitle $cleanArtist" else cleanTitle

        // 1. Try Spotify Web API using scraped session token (or sp_dc token)
        val token = getSpotifyAccessToken(spDcCookie)
        if (!token.isNullOrBlank()) {
            try {
                val url = "https://api.spotify.com/v1/search?type=track&limit=3&q=${URLEncoder.encode(query, "UTF-8")}"
                val req = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .header("User-Agent", USER_AGENT)
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = JSONObject(resp.body?.string().orEmpty())
                        val items = json.optJSONObject("tracks")?.optJSONArray("items")
                        if (items != null && items.length() > 0) {
                            val trackObj = items.getJSONObject(0)
                            val trackId = trackObj.optString("id")
                            val trackName = trackObj.optString("name", cleanTitle)
                            val durationMs = trackObj.optLong("duration_ms").takeIf { it > 0L }
                            val artistsArr = trackObj.optJSONArray("artists")
                            val artists = mutableListOf<SongArtist>()
                            if (artistsArr != null) {
                                for (i in 0 until artistsArr.length()) {
                                    val a = artistsArr.getJSONObject(i)
                                    val aName = a.optString("name").trim()
                                    if (aName.isNotEmpty()) {
                                        artists.add(SongArtist(name = aName, id = null))
                                    }
                                }
                            }
                            val albumObj = trackObj.optJSONObject("album")
                            val albumName = albumObj?.optString("name")
                            val imagesArr = albumObj?.optJSONArray("images")
                            val artworkUrl = if (imagesArr != null && imagesArr.length() > 0) {
                                imagesArr.getJSONObject(0).optString("url")
                            } else null

                            if (artists.isNotEmpty()) {
                                val meta = SpotifyTrackMetadata(
                                    trackId = trackId,
                                    title = trackName,
                                    artists = artists,
                                    albumName = albumName,
                                    artworkUrl = artworkUrl,
                                    durationMs = durationMs,
                                )
                                metadataCache[cacheKey] = meta
                                return@withContext meta
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("SpotifyRepository", "Spotify API search fallback: ${e.message}")
            }
        }

        // 2. Fast zero-auth music catalog fallback (iTunes Search API returns full singer credits & 600x600 artwork)
        try {
            val itunesUrl = "https://itunes.apple.com/search?media=music&entity=song&limit=3&term=${URLEncoder.encode(query, "UTF-8")}"
            val req = Request.Builder()
                .url(itunesUrl)
                .header("User-Agent", USER_AGENT)
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val body = resp.body?.string().orEmpty()
                    if (body.isNotBlank()) {
                        val json = JSONObject(body)
                        val results = json.optJSONArray("results")
                        if (results != null && results.length() > 0) {
                            val item = results.getJSONObject(0)
                            val artistNameRaw = item.optString("artistName").trim()
                            val trackName = item.optString("trackName", cleanTitle)
                            val albumName = item.optString("collectionName").takeIf { it.isNotBlank() }
                            val artwork = item.optString("artworkUrl100")
                                .takeIf { it.isNotBlank() }
                                ?.replace("100x100bb", "600x600bb")
                            val durationMs = item.optLong("trackTimeMillis").takeIf { it > 0L }

                            if (artistNameRaw.isNotBlank() && !isRecordLabelOrChannelName(artistNameRaw)) {
                                val splitRegex = Regex("\\s*(?:,|&|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bwith\\b|\\bx\\b)\\s*", RegexOption.IGNORE_CASE)
                                val parsedArtists = artistNameRaw.split(splitRegex)
                                    .map { it.trim() }
                                    .filter { it.length >= 2 }
                                    .map { SongArtist(name = it) }
                                if (parsedArtists.isNotEmpty()) {
                                    val meta = SpotifyTrackMetadata(
                                        trackId = item.optLong("trackId").toString(),
                                        title = trackName,
                                        artists = parsedArtists,
                                        albumName = albumName,
                                        artworkUrl = artwork,
                                        durationMs = durationMs,
                                    )
                                    metadataCache[cacheKey] = meta
                                    return@withContext meta
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("SpotifyRepository", "Catalog metadata lookup failed: ${e.message}")
        }

        null
    }

    suspend fun enrichSongMetadata(song: Song, spDcCookie: String? = null): Song {
        val meta = searchTrackMetadata(song.title, song.artist, spDcCookie) ?: return song
        val mergedArtists = if (meta.artists.isNotEmpty()) {
            meta.artists.mapIndexed { idx, a ->
                val existingId = song.artists.firstOrNull { it.name.equals(a.name, ignoreCase = true) }?.id
                    ?: if (idx == 0 && !isRecordLabelOrChannelName(song.artist)) song.artistId else null
                SongArtist(name = a.name, id = existingId)
            }
        } else {
            song.artists
        }
        val mergedArtistString = mergedArtists.joinToString(", ") { it.name }.ifBlank { song.artist }
        val mergedThumb = song.thumbnailUrl.ifBlank { meta.artworkUrl.orEmpty() }
        return song.copy(
            artist = mergedArtistString,
            artists = mergedArtists,
            thumbnailUrl = mergedThumb,
        )
    }

    private fun cleanQueryTitle(raw: String): String {
        return raw
            .replace(Regex("\\(\\s*official.*?\\)", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[\\s*official.*?\\]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\(\\s*(?:full\\s*video|video\\s*song|lyric\\s*video|audio|hd|4k).*?\\)", RegexOption.IGNORE_CASE), "")
            .substringBefore("|")
            .trim()
    }
}
