package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Clean, modern custom geometric vector icons crafted for WaveMuzix.
 * Replaces generic Material icons for Home, Library, Analytics, Search, Gear/Settings, Notifications,
 * Video Song toggle, Lyrics, Radio, Queue, and Artist.
 */
object WaveIcons {

    val Home: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveHome",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(3.8f, 10.4f)
                lineTo(10.65f, 4.15f)
                curveTo(11.42f, 3.45f, 12.58f, 3.45f, 13.35f, 4.15f)
                lineTo(20.2f, 10.4f)
                curveTo(20.71f, 10.87f, 21f, 11.53f, 21f, 12.22f)
                lineTo(21f, 18.5f)
                curveTo(21f, 19.88f, 19.88f, 21f, 18.5f, 21f)
                lineTo(5.5f, 21f)
                curveTo(4.12f, 21f, 3f, 19.88f, 3f, 18.5f)
                lineTo(3f, 12.22f)
                curveTo(3f, 11.53f, 3.29f, 10.87f, 3.8f, 10.4f)
                close()
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(9.5f, 21f)
                lineTo(9.5f, 15.2f)
                curveTo(9.5f, 13.82f, 10.62f, 12.7f, 12f, 12.7f)
                curveTo(13.38f, 12.7f, 14.5f, 13.82f, 14.5f, 15.2f)
                lineTo(14.5f, 21f)
            }
        }.build()
    }

    val Library: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveLibrary",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4.5f, 5.5f)
                lineTo(4.5f, 19.5f)
                moveTo(8.5f, 4.5f)
                lineTo(8.5f, 19.5f)
                moveTo(12.5f, 5.2f)
                curveTo(12.5f, 4.26f, 13.26f, 3.5f, 14.2f, 3.5f)
                lineTo(18.8f, 3.5f)
                curveTo(19.74f, 3.5f, 20.5f, 4.26f, 20.5f, 5.2f)
                lineTo(20.5f, 18.8f)
                curveTo(20.5f, 19.74f, 19.74f, 20.5f, 18.8f, 20.5f)
                lineTo(14.2f, 20.5f)
                curveTo(13.26f, 20.5f, 12.5f, 19.74f, 12.5f, 18.8f)
                close()
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(15.5f, 14.2f)
                arcTo(1.3f, 1.3f, 0f, true, true, 15.49f, 14.2f)
                moveTo(16.8f, 14.2f)
                lineTo(16.8f, 8.8f)
                lineTo(18.5f, 9.6f)
            }
        }.build()
    }

    val Analytics: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveAnalytics",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            // SimpMusic-style Analytics pulse + bar chart icon
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4f, 19.5f)
                lineTo(20f, 19.5f)
                moveTo(6.5f, 16f)
                lineTo(6.5f, 12f)
                moveTo(11f, 16f)
                lineTo(11f, 7.5f)
                moveTo(15.5f, 16f)
                lineTo(15.5f, 10.5f)
                moveTo(19f, 16f)
                lineTo(19f, 5f)
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.6f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(5.5f, 8.5f)
                lineTo(10.5f, 5.2f)
                lineTo(14.5f, 7.2f)
                lineTo(19f, 3.8f)
            }
        }.build()
    }

    val Search: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveSearch",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.1f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(11f, 4f)
                curveTo(14.866f, 4f, 18f, 7.134f, 18f, 11f)
                curveTo(18f, 14.866f, 14.866f, 18f, 11f, 18f)
                curveTo(7.134f, 18f, 4f, 14.866f, 4f, 11f)
                curveTo(4f, 7.134f, 7.134f, 4f, 11f, 4f)
                close()
                moveTo(16.4f, 16.4f)
                lineTo(20.2f, 20.2f)
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.4f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(8.2f, 8.4f)
                curveTo(8.9f, 7.5f, 9.9f, 7.0f, 11.0f, 7.0f)
            }
        }.build()
    }

    val Settings: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveSettings",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.95f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(10.325f, 4.317f)
                curveTo(10.751f, 2.561f, 13.249f, 2.561f, 13.675f, 4.317f)
                curveTo(13.95f, 5.451f, 15.242f, 5.986f, 16.243f, 5.38f)
                curveTo(17.791f, 4.443f, 19.557f, 6.209f, 18.62f, 7.757f)
                curveTo(18.014f, 8.758f, 18.549f, 10.05f, 19.683f, 10.325f)
                curveTo(21.439f, 10.751f, 21.439f, 13.249f, 19.683f, 13.675f)
                curveTo(18.549f, 13.95f, 18.014f, 15.242f, 18.62f, 16.243f)
                curveTo(19.557f, 17.791f, 17.791f, 19.557f, 16.243f, 18.62f)
                curveTo(15.242f, 18.014f, 13.95f, 18.549f, 13.675f, 19.683f)
                curveTo(13.249f, 21.439f, 10.751f, 21.439f, 10.325f, 19.683f)
                curveTo(10.05f, 18.549f, 8.758f, 18.014f, 7.757f, 18.62f)
                curveTo(6.209f, 19.557f, 4.443f, 17.791f, 5.38f, 16.243f)
                curveTo(5.986f, 15.242f, 5.451f, 13.95f, 4.317f, 13.675f)
                curveTo(2.561f, 13.249f, 2.561f, 10.751f, 4.317f, 10.325f)
                curveTo(5.451f, 10.05f, 5.986f, 8.758f, 5.38f, 7.757f)
                curveTo(4.443f, 6.209f, 6.209f, 4.443f, 7.757f, 5.38f)
                curveTo(8.758f, 5.986f, 10.05f, 5.451f, 10.325f, 4.317f)
                close()
            }
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
            ) {
                moveTo(12f, 9f)
                curveTo(13.657f, 9f, 15f, 10.343f, 15f, 12f)
                curveTo(15f, 13.657f, 13.657f, 15f, 12f, 15f)
                curveTo(10.343f, 15f, 9f, 13.657f, 9f, 12f)
                curveTo(9f, 10.343f, 10.343f, 9f, 12f, 9f)
                close()
            }
        }.build()
    }

    val Notifications: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveNotifications",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(18f, 9.5f)
                curveTo(18f, 6.186f, 15.314f, 3.5f, 12f, 3.5f)
                curveTo(8.686f, 3.5f, 6f, 6.186f, 6f, 9.5f)
                curveTo(6f, 14.2f, 4.2f, 16.0f, 4.2f, 16.0f)
                lineTo(19.8f, 16.0f)
                curveTo(19.8f, 16.0f, 18f, 14.2f, 18f, 9.5f)
                close()
                moveTo(10.1f, 19.5f)
                curveTo(10.55f, 20.3f, 11.22f, 20.8f, 12f, 20.8f)
                curveTo(12.78f, 20.8f, 13.45f, 20.3f, 13.9f, 19.5f)
            }
        }.build()
    }

    val Video: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveVideo",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.95f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(5.5f, 5.5f)
                lineTo(15.5f, 5.5f)
                curveTo(16.88f, 5.5f, 18f, 6.62f, 18f, 8f)
                lineTo(18f, 16f)
                curveTo(18f, 17.38f, 16.88f, 18.5f, 15.5f, 18.5f)
                lineTo(5.5f, 18.5f)
                curveTo(4.12f, 18.5f, 3f, 17.38f, 3f, 16f)
                lineTo(3f, 8f)
                curveTo(3f, 6.62f, 4.12f, 5.5f, 5.5f, 5.5f)
                close()
                moveTo(18f, 10.2f)
                lineTo(21.4f, 8.0f)
                lineTo(21.4f, 16.0f)
                lineTo(18f, 13.8f)
            }
            path(
                fill = SolidColor(Color.White),
                pathFillType = PathFillType.NonZero,
            ) {
                moveTo(9.2f, 9.6f)
                lineTo(13.4f, 12.0f)
                lineTo(9.2f, 14.4f)
                close()
            }
        }.build()
    }

    val VideoOff: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveVideoOff",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 1.95f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(3.5f, 3.5f)
                lineTo(20.5f, 20.5f)
                moveTo(9.5f, 5.5f)
                lineTo(15.5f, 5.5f)
                curveTo(16.88f, 5.5f, 18f, 6.62f, 18f, 8f)
                lineTo(18f, 13.5f)
                moveTo(18f, 10.2f)
                lineTo(21.4f, 8.0f)
                lineTo(21.4f, 16.0f)
                lineTo(18.5f, 14.1f)
                moveTo(15.5f, 18.5f)
                lineTo(5.5f, 18.5f)
                curveTo(4.12f, 18.5f, 3f, 17.38f, 3f, 16f)
                lineTo(3f, 8f)
                curveTo(3f, 6.85f, 3.78f, 5.88f, 4.85f, 5.59f)
            }
        }.build()
    }

    val Queue: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveQueue",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(4f, 6.5f)
                lineTo(19f, 6.5f)
                moveTo(4f, 11.5f)
                lineTo(14f, 11.5f)
                moveTo(4f, 16.5f)
                lineTo(11f, 16.5f)
                moveTo(16f, 13.5f)
                lineTo(20.5f, 16.2f)
                lineTo(16f, 18.9f)
                close()
            }
        }.build()
    }

    val Lyrics: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveLyrics",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(5.5f, 4.5f)
                lineTo(18.5f, 4.5f)
                curveTo(19.88f, 4.5f, 21f, 5.62f, 21f, 7f)
                lineTo(21f, 15f)
                curveTo(21f, 16.38f, 19.88f, 17.5f, 18.5f, 17.5f)
                lineTo(9.5f, 17.5f)
                lineTo(4.5f, 20.5f)
                lineTo(4.5f, 7f)
                curveTo(4.5f, 5.62f, 5.62f, 4.5f, 7f, 4.5f)
                close()
                moveTo(8.5f, 9f)
                lineTo(16.5f, 9f)
                moveTo(8.5f, 13f)
                lineTo(13.5f, 13f)
            }
        }.build()
    }

    val Artist: ImageVector by lazy {
        ImageVector.Builder(
            name = "WaveArtist",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).apply {
            path(
                fill = SolidColor(Color.Transparent),
                stroke = SolidColor(Color.White),
                strokeLineWidth = 2.0f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            ) {
                moveTo(12f, 5f)
                curveTo(14.07f, 5f, 15.75f, 6.68f, 15.75f, 8.75f)
                curveTo(15.75f, 10.82f, 14.07f, 12.5f, 12f, 12.5f)
                curveTo(9.93f, 12.5f, 8.25f, 10.82f, 8.25f, 8.75f)
                curveTo(8.25f, 6.68f, 9.93f, 5f, 12f, 5f)
                close()
                moveTo(4.8f, 19.5f)
                curveTo(5.9f, 16.3f, 8.7f, 14.8f, 12f, 14.8f)
                curveTo(15.3f, 14.8f, 18.1f, 16.3f, 19.2f, 19.5f)
            }
        }.build()
    }
}
