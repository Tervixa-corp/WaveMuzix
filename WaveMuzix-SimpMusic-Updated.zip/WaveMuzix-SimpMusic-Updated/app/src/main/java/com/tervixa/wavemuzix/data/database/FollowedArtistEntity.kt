package com.tervixa.wavemuzix.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "followed_artists")
data class FollowedArtistEntity(
    @PrimaryKey
    val artistId: String,
    val name: String,
    val thumbnailUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)
