package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tervixa.wavemuzix.data.LocalPerformanceConfig

/**
 * Standard loader component that delegates to the new modern [ExpressiveLoader].
 * On low-spec devices, it falls back to a standard CircularProgressIndicator.
 */
@Composable
fun StandardLoader(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    val performance = LocalPerformanceConfig.current
    val resolvedSize = if (size > 64.dp) 48.dp else size

    if (performance.isLowSpec) {
        CircularProgressIndicator(
            modifier = modifier.size(resolvedSize.coerceAtMost(40.dp)),
            color = color,
            strokeWidth = if (resolvedSize < 20.dp) 2.dp else 3.dp,
        )
    } else {
        ExpressiveLoader(
            modifier = modifier,
            size = resolvedSize,
            color = color,
        )
    }
}
