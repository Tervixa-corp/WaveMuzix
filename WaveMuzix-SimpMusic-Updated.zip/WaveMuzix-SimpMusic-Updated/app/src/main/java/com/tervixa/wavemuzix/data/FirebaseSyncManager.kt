package com.tervixa.wavemuzix.data

import android.content.Context
import android.util.Log
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.data.database.FavoriteSongEntity
import com.tervixa.wavemuzix.data.database.FollowedArtistEntity
import com.tervixa.wavemuzix.data.database.MostPlayedSongEntity
import com.tervixa.wavemuzix.data.database.PlaylistEntity
import com.tervixa.wavemuzix.data.database.PlaylistSongEntity
import com.tervixa.wavemuzix.utils.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration.Companion.seconds

object FirebaseSyncManager {
    private const val TAG = "FirebaseSyncManager"
    private const val SYNC_TIMEOUT_MS = 20000L

    @Volatile
    private var hasSyncedThisSession = false
    private var lastSyncedUserId: String? = null

    fun needsSync(userId: String?): Boolean {
        if (userId == null) return false
        return !hasSyncedThisSession || lastSyncedUserId != userId
    }

    fun markSynced(userId: String?) {
        hasSyncedThisSession = true
        lastSyncedUserId = userId
    }

    fun resetSyncStatus() {
        hasSyncedThisSession = false
        lastSyncedUserId = null
    }

    private const val USERS_COLLECTION = "users"
    private const val FAVORITES_COLLECTION = "library"
    private const val PLAYLISTS_COLLECTION = "playlists"
    private const val MOST_PLAYED_COLLECTION = "most_played"
    private const val FOLLOWED_ARTISTS_COLLECTION = "followed_artists"

    data class PlaylistFirestore(
        val id: Long = 0,
        val name: String = "",
        val createdAt: Long = 0
    )

    data class PlaylistSongFirestore(
        val playlistId: Long = 0,
        val videoId: String = "",
        val title: String = "",
        val artist: String = "",
        val thumbnailUrl: String = "",
        val artistId: String? = null,
        val addedAt: Long = 0
    )

    data class FavoriteSongFirestore(
        val videoId: String = "",
        val title: String = "",
        val artist: String = "",
        val thumbnailUrl: String = "",
        val artistId: String? = null,
        val timestamp: Long = 0
    )

    data class MostPlayedFirestore(
        val videoId: String = "",
        val title: String = "",
        val artist: String = "",
        val thumbnailUrl: String = "",
        val artistId: String? = null,
        val playCount: Int = 0,
        val lastPlayedTimestamp: Long = 0
    )

    data class FollowedArtistFirestore(
        val artistId: String = "",
        val name: String = "",
        val thumbnailUrl: String = "",
        val timestamp: Long = 0
    )

    data class UserDataFirestore(
        val email: String? = null,
        val displayName: String? = null,
        val phoneNumber: String? = null,
        val isLiquidGlass: Boolean? = null,
        val themeMode: String? = null,
        val themeColorSource: String? = null,
        val translucentBottomBar: Boolean? = null,
        val blurPlayerBackground: Boolean? = null,
        val contentCountry: String? = null,
        val userLocation: String? = null,
        val preferredAudioLanguage: String? = null,
        val isPreferHighQuality: Boolean? = null,
        val isNormalizeVolume: Boolean? = null,
        val isSavePlaybackState: Boolean? = null,
        val isSaveLastPlayed: Boolean? = null,
        val lastPlayedSongId: String? = null,
        val lastPlayedPositionMs: Long? = null,
        val isKeepServiceAlive: Boolean? = null,
        val isCrossfadeEnabled: Boolean? = null,
        val crossfadeDurationSeconds: Int? = null,
        val crossfadeDjMode: Boolean? = null,
        val isSponsorBlockEnabled: Boolean? = null,
        val accentColor: Int? = null,
        val lyricsProvider: String? = null,
        val lyricsStyle: String? = null,
        val lyricsRomanization: Boolean? = null,
        val translationLanguage: String? = null,
        val isSpotifyMetadataEnabled: Boolean? = null,
        val isOnboardingComplete: Boolean? = null,
        val selectedLanguages: List<String>? = null,
        val selectedArtists: List<String>? = null,
        val searchHistory: List<String>? = null,
        val isKeepScreenOn: Boolean? = null,
        val downloadQuality: String? = null,
        val autoDownloadLikedSongs: Boolean? = null,
        val smartDownloadsEnabled: Boolean? = null,
        val isSkipSilenceEnabled: Boolean? = null,
        val isVisualizerEnabled: Boolean? = null,
        val lastIgnoredVersion: Int? = null,
        val downloadThreads: Int? = null,
        val shouldShowLoginPrompt: Boolean? = null,
        val isPeakLimiterEnabled: Boolean? = null,
        val isGaplessRenderingEnabled: Boolean? = null,
        val surroundMode: String? = null,
        val isDirectVolumeControlEnabled: Boolean? = null,
        val networkBufferSizeMs: Long? = null,
        val skipSponsorMentions: Boolean? = null,
        val skipIntroOutro: Boolean? = null,
        val skipNonMusicSkits: Boolean? = null,
        val isDataSaverEnabled: Boolean? = null,
        val isAmbientBackgroundEnabled: Boolean? = null,
        val isPlayVideoIfAvailable: Boolean? = null,
        val preferredVideoQuality: String? = null,
        val sendBackToGoogle: Boolean? = null,
        val isYouTubeMusicConnected: Boolean? = null,
        val isDiscordConnected: Boolean? = null,
        val isLastFmConnected: Boolean? = null,
        val lastFmUsername: String? = null,
        val hasSeenPlayerTutorial: Boolean? = null,
        val hasSeenLibraryTutorial: Boolean? = null,
        val hasSeenSettingsTutorial: Boolean? = null,
        val totalMinutesPlayed: Double? = null,
        val totalSongsPlayed: Long? = null,
        val lastLogin: Long? = null
    )

    suspend fun pushFavorite(context: Context, song: FavoriteSongEntity) {
        val user = Firebase.auth.currentUser ?: return
        val db = Firebase.firestore
        val firestoreSong = FavoriteSongFirestore(
            song.videoId, song.title, song.artist, song.thumbnailUrl, song.artistId, song.timestamp
        )
        try {
            db.collection(USERS_COLLECTION).document(user.uid)
                .collection(FAVORITES_COLLECTION).document(song.videoId)
                .set(firestoreSong).await()
            Log.d(TAG, "Favorite pushed to library collection")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to push favorite", e)
        }
    }

    suspend fun removeFavorite(videoId: String) {
        val user = Firebase.auth.currentUser ?: return
        val db = Firebase.firestore
        try {
            db.collection(USERS_COLLECTION).document(user.uid)
                .collection(FAVORITES_COLLECTION).document(videoId)
                .delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to remove favorite", e)
        }
    }

    suspend fun incrementPlayCount(
        context: Context,
        videoId: String,
        title: String,
        artist: String,
        thumbnailUrl: String,
        artistId: String?,
        durationMs: Long
    ) {
        val user = Firebase.auth.currentUser ?: return
        val db = Firebase.firestore
        val userRef = db.collection(USERS_COLLECTION).document(user.uid)

        try {
            val mostPlayedRef = userRef.collection(MOST_PLAYED_COLLECTION).document(videoId)
            db.runTransaction { transaction ->
                val snapshot = transaction.get(mostPlayedRef)
                if (snapshot.exists()) {
                    val currentCount = snapshot.getLong("playCount") ?: 0
                    transaction.update(mostPlayedRef, "playCount", currentCount + 1)
                    transaction.update(mostPlayedRef, "lastPlayedTimestamp", System.currentTimeMillis())
                } else {
                    val newEntry = MostPlayedFirestore(
                        videoId, title, artist, thumbnailUrl, artistId, 1, System.currentTimeMillis()
                    )
                    transaction.set(mostPlayedRef, newEntry)
                }
                null
            }.await()

            val minutesPlayed = (durationMs.coerceAtLeast(180_000L) / 60000.0)
            userRef.update(
                "mostPlayedSummary.$videoId", com.google.firebase.firestore.FieldValue.increment(1),
                "totalSongsPlayed", com.google.firebase.firestore.FieldValue.increment(1),
                "totalMinutesPlayed", com.google.firebase.firestore.FieldValue.increment(minutesPlayed)
            ).await()

            Log.d(TAG, "Play count and minutes ($minutesPlayed) incremented in Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to increment play count", e)
        }
    }

    /**
     * Full Cloud Backup:
     * Backs up every setting, analytics summary, search history, liked songs,
     * custom playlists, most played history, and followed artists to Firebase Firestore.
     */
    suspend fun syncToFirebase(context: Context) {
        val user = Firebase.auth.currentUser ?: return
        val userId = user.uid
        val db = Firebase.firestore
        val localDb = AppDatabase.getDatabase(context)

        withContext(Dispatchers.IO + kotlinx.coroutines.NonCancellable) {
            try {
                withTimeoutOrNull(SYNC_TIMEOUT_MS) {
                    val settings = SettingsManager(context)
                    val mostPlayed = localDb.songDao().getMostPlayedSongs().first()
                    val favorites = localDb.songDao().getAllFavorites().first()
                    val followedArtists = localDb.songDao().getAllFollowedArtists().first()

                    val totalPlaysCount = mostPlayed.sumOf { it.playCount }.toLong()
                    val estimatedMinutes = totalPlaysCount * 3.45

                    // 1. Sync All User Settings, Search History & Analytics Summary
                    val userDataRef = db.collection(USERS_COLLECTION).document(userId)
                    val userDataMap = mutableMapOf<String, Any?>(
                        "email" to user.email,
                        "displayName" to (user.displayName ?: settings.phoneNumber),
                        "phoneNumber" to settings.phoneNumber.ifEmpty { user.phoneNumber ?: "" },
                        "userLocation" to settings.userLocation,
                        "preferredAudioLanguage" to settings.preferredAudioLanguage,
                        "isLiquidGlass" to settings.isLiquidGlass,
                        "themeMode" to settings.themeMode,
                        "themeColorSource" to settings.themeColorSource,
                        "translucentBottomBar" to settings.translucentBottomBar,
                        "blurPlayerBackground" to settings.blurPlayerBackground,
                        "contentCountry" to settings.contentCountry,
                        "isPreferHighQuality" to settings.isPreferHighQuality,
                        "isNormalizeVolume" to settings.isNormalizeVolume,
                        "isSavePlaybackState" to settings.isSavePlaybackState,
                        "isSaveLastPlayed" to settings.isSaveLastPlayed,
                        "lastPlayedSongId" to settings.lastPlayedSongId,
                        "lastPlayedPositionMs" to settings.lastPlayedPositionMs,
                        "isKeepServiceAlive" to settings.isKeepServiceAlive,
                        "isCrossfadeEnabled" to settings.isCrossfadeEnabled,
                        "crossfadeDurationSeconds" to settings.crossfadeDurationSeconds,
                        "crossfadeDjMode" to settings.crossfadeDjMode,
                        "isSponsorBlockEnabled" to settings.isSponsorBlockEnabled,
                        "accentColor" to settings.accentColor,
                        "lyricsProvider" to settings.lyricsProvider,
                        "lyricsStyle" to settings.lyricsStyle,
                        "lyricsRomanization" to settings.lyricsRomanization,
                        "translationLanguage" to settings.translationLanguage,
                        "isSpotifyMetadataEnabled" to settings.isSpotifyMetadataEnabled,
                        "isOnboardingComplete" to settings.isOnboardingComplete,
                        "selectedLanguages" to settings.selectedLanguages.toList(),
                        "selectedArtists" to settings.selectedArtists.toList(),
                        "searchHistory" to settings.searchHistory,
                        "isKeepScreenOn" to settings.isKeepScreenOn,
                        "downloadQuality" to settings.downloadQuality,
                        "autoDownloadLikedSongs" to settings.autoDownloadLikedSongs,
                        "smartDownloadsEnabled" to settings.smartDownloadsEnabled,
                        "isSkipSilenceEnabled" to settings.isSkipSilenceEnabled,
                        "isVisualizerEnabled" to false,
                        "lastIgnoredVersion" to settings.lastIgnoredVersion,
                        "downloadThreads" to settings.downloadThreads,
                        "shouldShowLoginPrompt" to settings.shouldShowLoginPrompt,
                        "isPeakLimiterEnabled" to settings.isPeakLimiterEnabled,
                        "isGaplessRenderingEnabled" to settings.isGaplessRenderingEnabled,
                        "surroundMode" to "None",
                        "isDirectVolumeControlEnabled" to settings.isDirectVolumeControlEnabled,
                        "networkBufferSizeMs" to settings.networkBufferSizeMs,
                        "skipSponsorMentions" to settings.skipSponsorMentions,
                        "skipIntroOutro" to settings.skipIntroOutro,
                        "skipNonMusicSkits" to settings.skipNonMusicSkits,
                        "isDataSaverEnabled" to settings.isDataSaverEnabled,
                        "isAmbientBackgroundEnabled" to settings.isAmbientBackgroundEnabled,
                        "isPlayVideoIfAvailable" to settings.isPlayVideoIfAvailable,
                        "preferredVideoQuality" to settings.preferredVideoQuality,
                        "sendBackToGoogle" to settings.sendBackToGoogle,
                        "isYouTubeMusicConnected" to settings.isYouTubeMusicConnected,
                        "isDiscordConnected" to settings.isDiscordConnected,
                        "isLastFmConnected" to settings.isLastFmConnected,
                        "lastFmUsername" to settings.lastFmUsername,
                        "hasSeenPlayerTutorial" to settings.hasSeenPlayerTutorial,
                        "hasSeenLibraryTutorial" to settings.hasSeenLibraryTutorial,
                        "hasSeenSettingsTutorial" to settings.hasSeenSettingsTutorial,
                        "totalSongsPlayed" to totalPlaysCount,
                        "totalMinutesPlayed" to estimatedMinutes,
                        "favoritesCount" to favorites.size,
                        "followedArtistsCount" to followedArtists.size,
                        "lastLogin" to System.currentTimeMillis()
                    )

                    userDataRef.set(userDataMap, com.google.firebase.firestore.SetOptions.merge()).await()
                    AppLogger.debug("User data & analytics synced to cloud: ${user.email}")

                    // 2. Sync Favorites (Liked Songs)
                    val favoritesRef = userDataRef.collection(FAVORITES_COLLECTION)
                    favorites.chunked(400).forEach { chunk ->
                        val batch = db.batch()
                        for (song in chunk) {
                            val firestoreSong = FavoriteSongFirestore(
                                song.videoId, song.title, song.artist, song.thumbnailUrl, song.artistId, song.timestamp
                            )
                            batch.set(favoritesRef.document(song.videoId), firestoreSong)
                        }
                        batch.commit().await()
                    }

                    // 3. Sync Playlists
                    val playlists = localDb.playlistDao().getAllPlaylists().first()
                    for (playlist in playlists) {
                        val playlistRef = userDataRef.collection(PLAYLISTS_COLLECTION).document(playlist.id.toString())
                        val firestorePlaylist = PlaylistFirestore(playlist.id, playlist.name, playlist.createdAt)
                        db.runBatch { batch ->
                            batch.set(playlistRef, firestorePlaylist)
                        }.await()

                        val songs = localDb.playlistDao().getSongsInPlaylist(playlist.id).first()
                        val songsRef = playlistRef.collection("songs")
                        songs.chunked(400).forEach { chunk ->
                            val batch = db.batch()
                            for (song in chunk) {
                                val firestoreSong = PlaylistSongFirestore(
                                    song.playlistId, song.videoId, song.title, song.artist, song.thumbnailUrl, song.artistId, song.addedAt
                                )
                                batch.set(songsRef.document(song.videoId), firestoreSong)
                            }
                            batch.commit().await()
                        }
                    }

                    // 4. Sync Most Played / Listening History & Analytics
                    val mostPlayedRef = userDataRef.collection(MOST_PLAYED_COLLECTION)
                    mostPlayed.chunked(400).forEach { chunk ->
                        val batch = db.batch()
                        for (song in chunk) {
                            val firestoreSong = MostPlayedFirestore(
                                song.videoId, song.title, song.artist, song.thumbnailUrl, song.artistId, song.playCount, song.lastPlayedTimestamp
                            )
                            batch.set(mostPlayedRef.document(song.videoId), firestoreSong)
                        }
                        batch.commit().await()
                    }

                    // 5. Sync Followed Artists
                    val followedRef = userDataRef.collection(FOLLOWED_ARTISTS_COLLECTION)
                    followedArtists.chunked(400).forEach { chunk ->
                        val batch = db.batch()
                        for (artist in chunk) {
                            val firestoreArtist = FollowedArtistFirestore(
                                artist.artistId, artist.name, artist.thumbnailUrl, artist.timestamp
                            )
                            batch.set(followedRef.document(artist.artistId), firestoreArtist)
                        }
                        batch.commit().await()
                    }

                    Log.d(TAG, "All settings, analytics, history, liked, most played, followed artists, and playlists synced to Firebase")
                } ?: Log.w(TAG, "Sync to Firebase timed out")
            } catch (e: Exception) {
                Log.e(TAG, "Sync to Firebase failed", e)
            }
        }
    }

    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun syncFromFirebase(context: Context) {
        val user = Firebase.auth.currentUser ?: return
        val userId = user.uid
        val db = Firebase.firestore
        val localDb = AppDatabase.getDatabase(context)

        withContext(Dispatchers.IO) {
            try {
                val userDataSnapshot = db.collection(USERS_COLLECTION).document(userId).get().await()

                if (!userDataSnapshot.exists()) {
                    Log.d(TAG, "New user profile detected. Initializing cloud with local data.")
                    syncToFirebase(context)
                    return@withContext
                }

                val cloudEmail = userDataSnapshot.getString("email")
                if (cloudEmail.isNullOrBlank()) {
                    syncToFirebase(context)
                }

                val userData = userDataSnapshot.toObject(UserDataFirestore::class.java)
                if (userData != null) {
                    val settings = SettingsManager(context)

                    userData.isLiquidGlass?.let { settings.isLiquidGlass = it }
                    userData.themeMode?.let { settings.themeMode = it }
                    userData.themeColorSource?.let { settings.themeColorSource = it }
                    userData.translucentBottomBar?.let { settings.translucentBottomBar = it }
                    userData.blurPlayerBackground?.let { settings.blurPlayerBackground = it }
                    userData.contentCountry?.let { settings.contentCountry = it }
                    userData.userLocation?.let { settings.userLocation = it }
                    userData.preferredAudioLanguage?.let { settings.preferredAudioLanguage = it }
                    userData.isPreferHighQuality?.let { settings.isPreferHighQuality = it }
                    userData.isNormalizeVolume?.let { settings.isNormalizeVolume = it }
                    userData.isSavePlaybackState?.let { settings.isSavePlaybackState = it }
                    userData.isSaveLastPlayed?.let { settings.isSaveLastPlayed = it }
                    userData.lastPlayedSongId?.let { settings.lastPlayedSongId = it }
                    userData.lastPlayedPositionMs?.let { settings.lastPlayedPositionMs = it }
                    userData.isKeepServiceAlive?.let { settings.isKeepServiceAlive = it }
                    userData.isCrossfadeEnabled?.let { settings.isCrossfadeEnabled = it }
                    userData.crossfadeDurationSeconds?.let { settings.crossfadeDurationSeconds = it }
                    userData.crossfadeDjMode?.let { settings.crossfadeDjMode = it }
                    userData.isSponsorBlockEnabled?.let { settings.isSponsorBlockEnabled = it }
                    userData.accentColor?.let { settings.accentColor = it }
                    userData.lyricsProvider?.let { settings.lyricsProvider = it }
                    userData.lyricsStyle?.let { settings.lyricsStyle = it }
                    userData.lyricsRomanization?.let { settings.lyricsRomanization = it }
                    userData.translationLanguage?.let { settings.translationLanguage = it }
                    userData.isSpotifyMetadataEnabled?.let { settings.isSpotifyMetadataEnabled = it }
                    userData.phoneNumber?.let { settings.phoneNumber = it }

                    if (userData.isOnboardingComplete == true) {
                        settings.isOnboardingComplete = true
                    }

                    if (!userData.selectedLanguages.isNullOrEmpty()) {
                        settings.selectedLanguages = userData.selectedLanguages.toSet()
                    }
                    if (!userData.selectedArtists.isNullOrEmpty()) {
                        settings.selectedArtists = userData.selectedArtists.toSet()
                    }
                    if (!userData.searchHistory.isNullOrEmpty()) {
                        settings.searchHistory = userData.searchHistory
                    }

                    userData.isKeepScreenOn?.let { settings.isKeepScreenOn = it }
                    userData.downloadQuality?.let { settings.downloadQuality = it }
                    userData.autoDownloadLikedSongs?.let { settings.autoDownloadLikedSongs = it }
                    userData.smartDownloadsEnabled?.let { settings.smartDownloadsEnabled = it }
                    userData.isSkipSilenceEnabled?.let { settings.isSkipSilenceEnabled = it }
                    userData.lastIgnoredVersion?.let { settings.lastIgnoredVersion = it }
                    userData.downloadThreads?.let { settings.downloadThreads = it }
                    userData.shouldShowLoginPrompt?.let { settings.shouldShowLoginPrompt = it }
                    userData.isPeakLimiterEnabled?.let { settings.isPeakLimiterEnabled = it }
                    userData.isGaplessRenderingEnabled?.let { settings.isGaplessRenderingEnabled = it }
                    userData.isDirectVolumeControlEnabled?.let { settings.isDirectVolumeControlEnabled = it }
                    userData.networkBufferSizeMs?.let { settings.networkBufferSizeMs = it }
                    userData.skipSponsorMentions?.let { settings.skipSponsorMentions = it }
                    userData.skipIntroOutro?.let { settings.skipIntroOutro = it }
                    userData.skipNonMusicSkits?.let { settings.skipNonMusicSkits = it }
                    userData.isDataSaverEnabled?.let { settings.isDataSaverEnabled = it }
                    userData.isAmbientBackgroundEnabled?.let { settings.isAmbientBackgroundEnabled = it }
                    userData.isPlayVideoIfAvailable?.let { settings.isPlayVideoIfAvailable = it }
                    userData.preferredVideoQuality?.let { settings.preferredVideoQuality = it }
                    userData.sendBackToGoogle?.let { settings.sendBackToGoogle = it }
                    userData.isYouTubeMusicConnected?.let { settings.isYouTubeMusicConnected = it }
                    userData.isDiscordConnected?.let { settings.isDiscordConnected = it }
                    userData.isLastFmConnected?.let { settings.isLastFmConnected = it }
                    userData.lastFmUsername?.let { settings.lastFmUsername = it }
                    userData.hasSeenPlayerTutorial?.let { settings.hasSeenPlayerTutorial = it }
                    userData.hasSeenLibraryTutorial?.let { settings.hasSeenLibraryTutorial = it }
                    userData.hasSeenSettingsTutorial?.let { settings.hasSeenSettingsTutorial = it }

                    markSynced(userId)
                }

                syncScope.launch {
                    try {
                        withTimeoutOrNull(30.seconds) {
                            val userDoc = db.collection(USERS_COLLECTION).document(userId)

                            // 2. Restore Favorites (Liked Songs)
                            val favoritesSnapshot = userDoc.collection(FAVORITES_COLLECTION).get().await()
                            favoritesSnapshot.documents.forEach { doc ->
                                val fSong = doc.toObject(FavoriteSongFirestore::class.java)
                                if (fSong != null && fSong.videoId.isNotBlank()) {
                                    localDb.songDao().insertFavorite(
                                        FavoriteSongEntity(
                                            fSong.videoId, fSong.title, fSong.artist, fSong.thumbnailUrl, fSong.artistId, fSong.timestamp
                                        )
                                    )
                                }
                            }

                            // 3. Restore Playlists
                            val playlistsSnapshot = userDoc.collection(PLAYLISTS_COLLECTION).get().await()
                            playlistsSnapshot.documents.forEach { doc ->
                                val fPlaylist = doc.toObject(PlaylistFirestore::class.java)
                                if (fPlaylist != null && fPlaylist.name.isNotBlank()) {
                                    var localId = localDb.playlistDao()
                                        .getPlaylistByNameAndTimestamp(fPlaylist.name, fPlaylist.createdAt)?.id
                                    if (localId == null) {
                                        localId = localDb.playlistDao().createPlaylist(
                                            PlaylistEntity(name = fPlaylist.name, createdAt = fPlaylist.createdAt)
                                        )
                                    }

                                    val songsSnapshot = doc.reference.collection("songs").get().await()
                                    songsSnapshot.documents.forEach { songDoc ->
                                        val fSong = songDoc.toObject(PlaylistSongFirestore::class.java)
                                        if (fSong != null && fSong.videoId.isNotBlank()) {
                                            localDb.playlistDao().addSongToPlaylist(
                                                PlaylistSongEntity(
                                                    playlistId = localId,
                                                    videoId = fSong.videoId,
                                                    title = fSong.title,
                                                    artist = fSong.artist,
                                                    thumbnailUrl = fSong.thumbnailUrl,
                                                    artistId = fSong.artistId,
                                                    addedAt = fSong.addedAt
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // 4. Restore Most Played / Listening History & Analytics
                            val mostPlayedSnapshot = userDoc.collection(MOST_PLAYED_COLLECTION).get().await()
                            mostPlayedSnapshot.documents.forEach { doc ->
                                val fSong = doc.toObject(MostPlayedFirestore::class.java)
                                if (fSong != null && fSong.videoId.isNotBlank()) {
                                    localDb.songDao().insertMostPlayed(
                                        MostPlayedSongEntity(
                                            fSong.videoId, fSong.title, fSong.artist, fSong.thumbnailUrl, fSong.artistId, fSong.playCount, fSong.lastPlayedTimestamp
                                        )
                                    )
                                }
                            }

                            // 5. Restore Followed Artists
                            val followedSnapshot = userDoc.collection(FOLLOWED_ARTISTS_COLLECTION).get().await()
                            followedSnapshot.documents.forEach { doc ->
                                val fArtist = doc.toObject(FollowedArtistFirestore::class.java)
                                if (fArtist != null && fArtist.artistId.isNotBlank()) {
                                    localDb.songDao().insertFollowedArtist(
                                        FollowedArtistEntity(
                                            fArtist.artistId, fArtist.name, fArtist.thumbnailUrl, fArtist.timestamp
                                        )
                                    )
                                }
                            }

                            // Also push any local items that weren't in cloud yet
                            syncToFirebase(context)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Background library restore failed", e)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Restoration from Firebase failed", e)
            }
        }
    }
}
