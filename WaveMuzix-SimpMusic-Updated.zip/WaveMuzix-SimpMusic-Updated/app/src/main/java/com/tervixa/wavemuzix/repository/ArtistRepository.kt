package com.tervixa.wavemuzix.repository

import android.content.Context
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.tervixa.wavemuzix.data.FirebaseSyncManager
import com.tervixa.wavemuzix.data.database.FollowedArtistEntity
import com.tervixa.wavemuzix.data.database.SongDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class ArtistRepository(private val songDao: SongDao, private val context: Context? = null) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val followedArtists: Flow<List<FollowedArtist>> = songDao.getAllFollowedArtists().map { entities ->
        entities.map { it.toModel() }
    }

    suspend fun toggleFollow(artistId: String, name: String, thumbnailUrl: String) {
        val existing = songDao.getFollowedArtistById(artistId)
        val user = Firebase.auth.currentUser
        if (existing != null) {
            songDao.deleteFollowedArtist(existing)
            if (user != null) {
                scope.launch {
                    try {
                        Firebase.firestore.collection("users").document(user.uid)
                            .collection("followed_artists").document(artistId).delete()
                    } catch (_: Exception) {}
                }
            }
        } else {
            val entity = FollowedArtistEntity(artistId, name, thumbnailUrl)
            songDao.insertFollowedArtist(entity)
            if (user != null) {
                scope.launch {
                    try {
                        Firebase.firestore.collection("users").document(user.uid)
                            .collection("followed_artists").document(artistId)
                            .set(
                                FirebaseSyncManager.FollowedArtistFirestore(
                                    artistId = artistId,
                                    name = name,
                                    thumbnailUrl = thumbnailUrl,
                                    timestamp = entity.timestamp
                                )
                            )
                    } catch (_: Exception) {}
                }
            }
        }
        context?.let { ctx ->
            scope.launch { FirebaseSyncManager.syncToFirebase(ctx) }
        }
    }

    suspend fun isFollowing(artistId: String): Boolean {
        return songDao.isArtistFollowed(artistId)
    }

    private fun FollowedArtistEntity.toModel() = FollowedArtist(
        artistId = artistId,
        name = name,
        thumbnailUrl = thumbnailUrl
    )
}

data class FollowedArtist(
    val artistId: String,
    val name: String,
    val thumbnailUrl: String
)
