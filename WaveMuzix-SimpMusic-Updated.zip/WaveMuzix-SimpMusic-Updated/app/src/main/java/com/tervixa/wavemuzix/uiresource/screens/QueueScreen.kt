package com.tervixa.wavemuzix.uiresource.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.parseArtists
import com.tervixa.wavemuzix.ui.theme.SoftBlack
import com.tervixa.wavemuzix.ui.theme.TextSecondary
import com.tervixa.wavemuzix.uiresource.components.AmbientThemeGlow
import com.tervixa.wavemuzix.uiresource.components.ArtistModalBottomSheet
import com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet
import com.tervixa.wavemuzix.data.database.AppDatabase
import kotlinx.coroutines.launch
import com.tervixa.wavemuzix.uiresource.components.ExpressiveLoader
import com.tervixa.wavemuzix.uiresource.components.LocalBackdrop
import com.tervixa.wavemuzix.uiresource.components.TopBarType
import com.tervixa.wavemuzix.uiresource.components.UniversalTopBar
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveIcons
import com.tervixa.wavemuzix.uiresource.components.isScrollingUp
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.delay

/**
 * SimpMusic Audio Visualizer Spectrum overlay displayed inside the song thumbnail box
 * for the currently playing song in `QueueScreen`.
 */
@Composable
private fun QueueAudioSpectrumOverlay(
    isPlaying: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "queueSpectrumTransition")
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.24f,
        targetValue = 0.92f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 390, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "spectrumBar1",
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 0.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 310, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "spectrumBar2",
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.98f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 460, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "spectrumBar3",
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 0.76f,
        targetValue = 0.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "spectrumBar4",
    )

    val heights = if (isPlaying) {
        listOf(bar1, bar2, bar3, bar4)
    } else {
        listOf(0.22f, 0.34f, 0.26f, 0.20f)
    }

    Box(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.54f)),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(26.dp, 22.dp)) {
            val barCount = heights.size
            val gapPx = 3.dp.toPx()
            val barWidth = (size.width - gapPx * (barCount - 1)) / barCount
            val radius = CornerRadius(barWidth / 2f, barWidth / 2f)

            heights.forEachIndexed { idx, fraction ->
                val h = (size.height * fraction.coerceIn(0.18f, 1f))
                val x = idx * (barWidth + gapPx)
                val y = (size.height - h) / 2f
                drawRoundRect(
                    color = accentColor,
                    topLeft = Offset(x, y),
                    size = Size(barWidth, h),
                    cornerRadius = radius,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@Composable
fun QueueScreen(
    isLiquidGlass: Boolean,
    onBack: () -> Unit,
    onArtistClick: (String) -> Unit,
    onPlaylistClick: (Song) -> Unit,
    backdrop: LayerBackdrop? = null,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val statusBarTopDp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val queue = MusicPlayer.queue
    val currentIndex = MusicPlayer.currentIndex
    val currentSong = MusicPlayer.currentSong
    val isRefreshingQueue = MusicPlayer.isRefreshingQueue
    val listState = rememberLazyListState()
    val isScrollingUp by listState.isScrollingUp()
    val atTop by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 16
        }
    }

    LaunchedEffect(Unit) {
        if (currentIndex > 0 && currentIndex < queue.size) {
            listState.scrollToItem(currentIndex)
        }
    }

    val nearEndOfQueue by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisible >= total - 5
        }
    }

    LaunchedEffect(nearEndOfQueue, queue.size) {
        if (nearEndOfQueue && currentSong != null && !isRefreshingQueue) {
            MusicPlayer.requestMoreQueueSongs(context)
        }
    }

    val scope = rememberCoroutineScope()
    val songDao = remember(context) { AppDatabase.getDatabase(context).songDao() }
    val likedSongs by songDao.getAllFavorites().collectAsState(initial = emptyList())
    val downloadedSongs by songDao.getAllDownloads().collectAsState(initial = emptyList())
    var selectedQueueSongForOptions by remember { mutableStateOf<Pair<Int, Song>?>(null) }
    var artistPickerSong by remember { mutableStateOf<Song?>(null) }

    if (selectedQueueSongForOptions != null) {
        val (qIdx, qSong) = selectedQueueSongForOptions!!
        val isFav = likedSongs.any { it.videoId == qSong.videoId }
        val isDown = downloadedSongs.any { it.videoId == qSong.videoId }
        SongOptionsBottomSheet(
            song = qSong,
            isFavorite = isFav,
            isDownloaded = isDown,
            isLiquidGlass = isLiquidGlass,
            extraOptionLabel = "Remove from queue",
            extraOptionIcon = Icons.Default.Delete,
            onExtraOptionClick = {
                MusicPlayer.removeFromQueue(qIdx)
            },
            onDismiss = { selectedQueueSongForOptions = null },
            onFavoriteClick = { MusicPlayer.toggleFavorite(context, qSong) },
            onDownloadClick = {
                DownloadManager.downloadSong(
                    context = context,
                    song = qSong,
                    repository = MusicPlayer.unifiedRepository,
                    cookies = CookieManager(context).getCookies(),
                )
            },
            onPlayNextClick = { MusicPlayer.playNext(qSong) },
            onAddToQueueClick = { MusicPlayer.addToQueue(qSong) },
            onArtistClick = { targetId ->
                selectedQueueSongForOptions = null
                onArtistClick(targetId)
            },
            onAddToPlaylistClick = {
                selectedQueueSongForOptions = null
                onPlaylistClick(qSong)
            },
            onShareClick = {
                val sendIntent = android.content.Intent().apply {
                    action = android.content.Intent.ACTION_SEND
                    putExtra(
                        android.content.Intent.EXTRA_TEXT,
                        "Listen to ${qSong.title} by ${qSong.artist} on WaveMuzix: https://www.youtube.com/watch?v=${qSong.videoId}",
                    )
                    type = "text/plain"
                }
                context.startActivity(android.content.Intent.createChooser(sendIntent, null))
                selectedQueueSongForOptions = null
            },
        )
    }
    if (artistPickerSong != null) {
        val artists = remember(artistPickerSong) { artistPickerSong!!.parseArtists() }
        ArtistModalBottomSheet(
            artists = artists,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { artistPickerSong = null },
            onSelectArtist = { selected ->
                artistPickerSong = null
                val targetId = selected.id?.takeIf { it.isNotBlank() } ?: "search:${selected.name}"
                onArtistClick(targetId)
            }
        )
    }

    CompositionLocalProvider(LocalBackdrop provides backdrop) {
        BackHandler(onBack = onBack)

        var draggingIndex by remember { mutableStateOf<Int?>(null) }
        var dragOffset by remember { mutableFloatStateOf(0f) }
        var targetIndex by remember { mutableStateOf<Int?>(null) }
        val hazeState = remember { HazeState() }
        var expandedTopBarHeightDp by remember(statusBarTopDp) {
            mutableStateOf(statusBarTopDp + 168.dp)
        }

        LaunchedEffect(draggingIndex) {
            if (draggingIndex == null) return@LaunchedEffect
            while (true) {
                val layoutInfo = listState.layoutInfo
                val draggingItem = layoutInfo.visibleItemsInfo.find { it.index == draggingIndex }
                if (draggingItem != null) {
                    val viewportHeight = layoutInfo.viewportSize.height.toFloat()
                    val top = draggingItem.offset + dragOffset
                    val bottom = top + draggingItem.size

                    val threshold = 120f
                    val maxScrollSpeed = 30f

                    var scrollAmount = 0f
                    if (top < threshold) {
                        val proximity = ((threshold - top) / threshold).coerceIn(0f, 1f)
                        scrollAmount = -(proximity * maxScrollSpeed)
                    } else if (bottom > viewportHeight - threshold) {
                        val proximity = ((bottom - (viewportHeight - threshold)) / threshold).coerceIn(0f, 1f)
                        scrollAmount = proximity * maxScrollSpeed
                    }

                    if (scrollAmount != 0f) {
                        val actualScroll = listState.scrollBy(scrollAmount)
                        dragOffset += actualScroll
                    }

                    val dragCenterY = draggingItem.offset + dragOffset + draggingItem.size / 2
                    val newTarget = layoutInfo.visibleItemsInfo
                        .minByOrNull { item ->
                            val itemCenter = item.offset + item.size / 2
                            kotlin.math.abs(dragCenterY - itemCenter)
                        }?.index
                    if (newTarget != null && newTarget != targetIndex) {
                        targetIndex = newTarget
                    }
                }
                delay(10)
            }
        }

        val queueBgColor = Color(0xFF121216)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(queueBgColor),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .hazeSource(state = hazeState)
                    .background(queueBgColor),
            ) {
                AmbientThemeGlow(
                    tint = MusicPlayer.accentColors.firstOrNull() ?: MaterialTheme.colorScheme.primary,
                    scrollState = listState
                )

                if (queue.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            ExpressiveLoader(size = 44.dp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Curating your endless queue...",
                                color = Color.White.copy(alpha = 0.75f),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { offset ->
                                        val padTopPx = with(density) { (expandedTopBarHeightDp + 12.dp).toPx() }
                                        val adjustedY = offset.y - padTopPx
                                        listState.layoutInfo.visibleItemsInfo
                                            .firstOrNull { item ->
                                                adjustedY.toInt() in item.offset..(item.offset + item.size)
                                            }
                                            ?.let { item ->
                                                if (item.index in queue.indices) {
                                                    draggingIndex = item.index
                                                    targetIndex = item.index
                                                }
                                            }
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        dragOffset += dragAmount.y

                                        draggingIndex?.let { startIdx ->
                                            val currentItem = listState.layoutInfo.visibleItemsInfo.find { it.index == startIdx }
                                            if (currentItem != null) {
                                                val dragY = currentItem.offset + dragOffset
                                                val newTarget = listState.layoutInfo.visibleItemsInfo
                                                    .filter { it.index in queue.indices }
                                                    .minByOrNull { item ->
                                                        val itemCenter = item.offset + item.size / 2
                                                        kotlin.math.abs(dragY + currentItem.size / 2 - itemCenter)
                                                    }?.index
                                                if (newTarget != null && newTarget != targetIndex) {
                                                    targetIndex = newTarget
                                                }
                                            }
                                        }
                                    },
                                    onDragEnd = {
                                        if (draggingIndex != null && targetIndex != null && draggingIndex != targetIndex) {
                                            MusicPlayer.moveItem(draggingIndex!!, targetIndex!!)
                                        }
                                        draggingIndex = null
                                        targetIndex = null
                                        dragOffset = 0f
                                    },
                                    onDragCancel = {
                                        draggingIndex = null
                                        targetIndex = null
                                        dragOffset = 0f
                                    },
                                )
                            },
                        contentPadding = PaddingValues(
                            top = expandedTopBarHeightDp + 12.dp,
                            bottom = 64.dp
                        ),
                        flingBehavior = rememberSmoothFlingBehavior(),
                    ) {
                        itemsIndexed(
                            items = queue,
                            key = { index, song -> "${song.videoId}_$index" },
                        ) { index, song ->
                            val isCurrent = index == currentIndex
                            val isDragging = index == draggingIndex

                            // OriginOS / iOS bouncy reorder spring spec
                            val settleSpec = spring<Float>(
                                dampingRatio = 0.65f,
                                stiffness = 380f,
                            )
                            val dragSpec = spring<Float>(
                                dampingRatio = 0.75f,
                                stiffness = 420f,
                            )

                            val itemTranslationY by animateFloatAsState(
                                targetValue = if (draggingIndex != null && !isDragging) {
                                    val start = draggingIndex!!
                                    val end = targetIndex!!
                                    if (start < end) {
                                        if (index in (start + 1)..end) -42f else 0f
                                    } else {
                                        if (index in end until start) 42f else 0f
                                    }
                                } else 0f,
                                animationSpec = if (draggingIndex == null) settleSpec else dragSpec,
                                label = "translationY",
                            )

                            val itemTranslationX = 0f
                            val itemRotation = 0f

                            val scale by animateFloatAsState(
                                targetValue = if (isDragging) 1.04f else 1.0f,
                                animationSpec = spring(
                                    dampingRatio = 0.65f,
                                    stiffness = 380f,
                                ),
                                label = "scale",
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .zIndex(if (isDragging) 2f else 1f)
                                    .graphicsLayer {
                                        translationY = if (isDragging) dragOffset else itemTranslationY
                                        translationX = itemTranslationX
                                        rotationZ = itemRotation
                                        scaleX = scale
                                        scaleY = scale
                                        shadowElevation = if (isDragging) 12f else 0f
                                    }
                                    .background(Color.Transparent)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null,
                                        onClick = {
                                            MusicPlayer.playAtIndex(context, index)
                                        }
                                    )
                                    .padding(horizontal = 16.dp, vertical = 4.5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    WaveArtworkImage(
                                        url = song.thumbnailUrl,
                                        contentDescription = song.title,
                                        isVideo = false,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxSize(),
                                    )
                                    if (isCurrent) {
                                        QueueAudioSpectrumOverlay(
                                            isPlaying = MusicPlayer.isPlaying,
                                            accentColor = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.fillMaxSize(),
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = song.title,
                                        color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.White,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.5.sp,
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Clip,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .basicMarquee(
                                                iterations = Int.MAX_VALUE,
                                                animationMode = MarqueeAnimationMode.Immediately,
                                                initialDelayMillis = 1200,
                                            )
                                            .focusable(),
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = song.displayArtists,
                                        color = Color.White.copy(alpha = 0.88f),
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                                        maxLines = 1,
                                        overflow = TextOverflow.Clip,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .basicMarquee(
                                                iterations = Int.MAX_VALUE,
                                                animationMode = MarqueeAnimationMode.Immediately,
                                                initialDelayMillis = 1200,
                                            )
                                            .focusable(),
                                    )
                                }

                                IconButton(
                                    onClick = { selectedQueueSongForOptions = index to song },
                                    modifier = Modifier.size(40.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "Options",
                                        tint = Color.White.copy(alpha = 0.68f),
                                    )
                                }
                            }
                        }

                        item(key = "endless_queue_loader") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isRefreshingQueue) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        ExpressiveLoader(size = 24.dp)
                                        Text(
                                            text = "Fetching more songs...",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White.copy(alpha = 0.7f)
                                        )
                                    }
                                } else {
                                    TextButton(
                                        onClick = { MusicPlayer.requestMoreQueueSongs(context) }
                                    ) {
                                        Text(
                                            text = "Load more songs",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            UniversalTopBar(
                type = TopBarType.Queue(
                    currentSong = currentSong,
                    highResThumbnailUrl = MusicPlayer.highResThumbnailUrl,
                ),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .onGloballyPositioned { coords ->
                        val measured = with(density) { coords.size.height.toDp() }
                        if (measured > expandedTopBarHeightDp) {
                            expandedTopBarHeightDp = measured
                        }
                    },
                hazeState = hazeState,
                isCollapsed = !atTop && !isScrollingUp,
                isLiquidGlass = isLiquidGlass,
                tintColor = queueBgColor,
                tintAlpha = 0.62f,
                onBackClick = onBack,
            )
        }
    }
}
