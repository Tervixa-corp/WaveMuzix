package com.tervixa.wavemuzix.uiresource.screens

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Forward5
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay5
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.kashif_e.backdrop.backdrops.layerBackdrop
import com.kashif_e.backdrop.backdrops.rememberLayerBackdrop
import com.kashif_e.backdrop.drawBackdrop
import com.kashif_e.backdrop.effects.blur
import com.kashif_e.backdrop.effects.lens
import com.tervixa.wavemuzix.data.AudioFxManager
import com.tervixa.wavemuzix.data.DownloadWorker
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.data.database.PlaylistEntity
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.model.parseArtists
import com.tervixa.wavemuzix.repository.*
import com.tervixa.wavemuzix.ui.theme.DeepBlack
import com.tervixa.wavemuzix.ui.theme.SoftBlack
import com.tervixa.wavemuzix.ui.theme.TextSecondary
import com.tervixa.wavemuzix.uiresource.components.*
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

// --- CURATED 10-COLOR SYSTEM ---
val CuratedBaseColors = listOf(
    Color(0xFFE57373), // Red
    Color(0xFFF06292), // Pink
    Color(0xFFBA68C8), // Purple
    Color(0xFF9575CD), // Deep Purple
    Color(0xFF7986CB), // Indigo
    Color(0xFF64B5F6), // Blue
    Color(0xFF4FC3F7), // Light Blue
    Color(0xFF4DB6AC), // Teal
    Color(0xFF81C784), // Green
    Color(0xFFFFB74D)  // Orange
)

data class DerivedShades(
    val color1: Color, // Base
    val color2: Color, // Darker
    val color3: Color, // Much Darker
    val color4: Color  // Deep Dark
)

fun deriveShades(base: Color): DerivedShades {
    fun darken(c: Color, factor: Float): Color = Color(
        red = c.red * factor,
        green = c.green * factor,
        blue = c.blue * factor,
        alpha = 1f
    )
    return DerivedShades(
        color1 = base,
        color2 = darken(base, 0.45f),
        color3 = darken(base, 0.22f),
        color4 = darken(base, 0.08f)
    )
}

/**
 * Apple Music Slider with White Active Track and Oval Liquid Thumb at the end of progress:
 * - Active track: pure white (`Color.White.copy(alpha = 0.96f)`).
 * - Inactive track: soft translucent white (`Color.White.copy(alpha = 0.24f)`).
 * - Thumb at the end of the active bar: an oval liquid glass pill (`24.dp x 14.dp`, `RoundedCornerShape(50)`)
 *   with very low blur (`1.8.dp`) and low refraction height & refraction amount (`minDimension / 7.5f`, `minDimension / 5.5f`)
 *   just like Apple's iOS 26 liquid slider.
 */
/**
 * Hardware-accelerated TextureView Video Surface for ExoPlayer:
 * Uses `TextureView` (`setVideoTextureView`) instead of `SurfaceView` so video frames render
 * directly inside Compose `GraphicsLayer` (`layerBackdrop`), `.clip(RoundedCornerShape(...))`,
 * `LazyColumn`, and `LandscapePlayerOverlay` pinch-to-zoom transforms with zero black-screen issues.
 */
@Composable
fun WaveVideoPlayerSurface(
    modifier: Modifier = Modifier,
) {
    AndroidView(
        factory = { ctx ->
            android.view.TextureView(ctx).apply {
                isOpaque = false
                val vp = MusicPlayer.getVideoPlayer(ctx)
                tag = vp
                vp.setVideoTextureView(this)
            }
        },
        update = { view ->
            val vp = MusicPlayer.getVideoPlayer(view.context)
            if (view.tag !== vp) {
                view.tag = vp
                vp.setVideoTextureView(view)
            }
        },
        onRelease = { view ->
            try {
                view.tag = null
                MusicPlayer.getVideoPlayer(view.context).clearVideoTextureView(view)
            } catch (_: Exception) {}
        },
        modifier = modifier,
    )
}

@Composable
fun AppleLiquidSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    isLiquidGlass: Boolean = true,
    backdrop: LayerBackdrop? = LocalBackdrop.current,
) {
    val coercedValue = value.coerceIn(0f, 1f)
    var sliderWidthPx by remember { mutableFloatStateOf(1f) }
    var isDragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(coercedValue) }
    val activeFraction = if (isDragging) dragFraction else coercedValue

    val trackHeight by animateDpAsState(
        targetValue = if (isDragging) 10.dp else 7.5.dp,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f),
        label = "appleSliderTrackHeight",
    )
    // Slightly larger Apple-style oval nib per user request
    val thumbWidth by animateDpAsState(
        targetValue = if (isDragging) 34.dp else 28.dp,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "appleSliderThumbWidth",
    )
    val thumbHeight by animateDpAsState(
        targetValue = if (isDragging) 21.dp else 18.dp,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "appleSliderThumbHeight",
    )

    val density = LocalDensity.current
    val thumbWidthPx = with(density) { thumbWidth.toPx() }
    val liquidEnabled = rememberIsLiquidGlassEnabled(isLiquidGlass)
    val thumbShape = RoundedCornerShape(50)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .onSizeChanged { size ->
                sliderWidthPx = size.width.toFloat().coerceAtLeast(1f)
            }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val newFrac = (offset.x / sliderWidthPx).coerceIn(0f, 1f)
                    dragFraction = newFrac
                    onValueChange(newFrac)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        isDragging = true
                        val newFrac = (offset.x / sliderWidthPx).coerceIn(0f, 1f)
                        dragFraction = newFrac
                        onValueChange(newFrac)
                    },
                    onDragEnd = {
                        isDragging = false
                    },
                    onDragCancel = {
                        isDragging = false
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val newFrac = (change.position.x / sliderWidthPx).coerceIn(0f, 1f)
                        dragFraction = newFrac
                        onValueChange(newFrac)
                    },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        // White Apple Track
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(trackHeight),
        ) {
            val corner = CornerRadius(size.height / 2f, size.height / 2f)
            // Inactive track
            drawRoundRect(
                color = Color.White.copy(alpha = 0.24f),
                size = size,
                cornerRadius = corner,
            )
            // Active white track
            val activeW = (size.width * activeFraction).coerceIn(0f, size.width)
            if (activeW > 0f) {
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.96f),
                    size = Size(activeW, size.height),
                    cornerRadius = corner,
                )
            }
        }

        // Slightly larger Apple-style oval liquid nib with low blur and medium refraction height & refraction
        val thumbOffsetX = ((sliderWidthPx - thumbWidthPx).coerceAtLeast(0f) * activeFraction).roundToInt()
        Box(
            modifier = Modifier
                .offset { IntOffset(thumbOffsetX, 0) }
                .size(width = thumbWidth, height = thumbHeight)
                .then(
                    if (liquidEnabled && backdrop != null) {
                        Modifier.drawBackdrop(
                            backdrop = backdrop,
                            shape = { thumbShape },
                            effects = {
                                blur(radius = 2.2.dp.toPx())
                                lens(
                                    refractionHeight = size.minDimension * 0.38f,
                                    refractionAmount = size.minDimension * 0.48f,
                                    depthEffect = false,
                                )
                            },
                            onDrawSurface = {
                                drawRect(Color.White.copy(alpha = 0.28f))
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.56f),
                                            Color.White.copy(alpha = 0.16f),
                                        ),
                                    ),
                                )
                            },
                        )
                    } else if (liquidEnabled) {
                        Modifier
                            .clip(thumbShape)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.78f),
                                        Color.White.copy(alpha = 0.44f),
                                    ),
                                ),
                                shape = thumbShape,
                            )
                    } else {
                        Modifier
                            .clip(thumbShape)
                            .background(Color.White, thumbShape)
                    }
                )
                .border(
                    width = 1.15.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color.White.copy(alpha = 0.48f),
                            Color.White.copy(alpha = 0.85f),
                        ),
                    ),
                    shape = thumbShape,
                ),
        )
    }
}

/**
 * SimpMusic Inline Lyric Strip shown right above the Song Title on `PlayerScreen`:
 * - No leading lyrics icon (removed per user request).
 * - Animates word-by-word with SimpMusic's immersive glow (`SimpWordSyncedLyricLine`).
 */
@Composable
fun SimpInlineTitleLyricStrip(
    lyrics: String,
    currentPosition: Long,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val lines = remember(lyrics) {
        lyrics.split("\n").mapNotNull { line ->
            val match = Regex("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})](.*)").find(line)
            if (match != null) {
                val min = match.groupValues[1].toLong()
                val sec = match.groupValues[2].toLong()
                val msStr = match.groupValues[3]
                val ms = msStr.toLong() * (if (msStr.length == 2) 10 else 1)
                (min * 60000 + sec * 1000 + ms) to match.groupValues[4].trim()
            } else if (line.trim().isNotEmpty() && !line.startsWith("[") && !line.contains("Searching for lyrics") && !line.contains("Lyrics not available")) {
                0L to line.trim()
            } else null
        }.filter { it.second.isNotBlank() }
    }

    if (lines.isEmpty()) return

    val isSynced = remember(lyrics) {
        lyrics.contains(Regex("\\[\\d{2}:\\d{2}\\.\\d{2,3}]"))
    }
    val activeIdx = if (isSynced) lines.indexOfLast { it.first <= currentPosition }.coerceAtLeast(0) else 0
    val activePair = lines.getOrNull(activeIdx) ?: return
    val activeRawLine = activePair.second
    val lineStartMs = activePair.first
    val lineEndMs = lines.getOrNull(activeIdx + 1)?.first ?: (lineStartMs + 4200L)
    val cleanLine = remember(activeRawLine) {
        activeRawLine.replace(Regex("<\\d{2}:\\d{2}\\.\\d{2,3}>"), "").trim()
    }
    if (cleanLine.isBlank()) return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 4.dp),
    ) {
        AnimatedContent(
            targetState = Triple(activeIdx, activeRawLine, lineStartMs to lineEndMs),
            transitionSpec = {
                (fadeIn(tween(220)) + slideInVertically { it / 2 })
                    .togetherWith(fadeOut(tween(160)) + slideOutVertically { -it / 2 })
            },
            label = "InlineTitleLyricTransition",
        ) { (_, rawLine, bounds) ->
            SimpWordSyncedLyricLine(
                rawLineText = rawLine,
                currentPositionMs = currentPosition,
                isActiveLine = true,
                isPastLine = false,
                inactiveAlpha = 0.48f,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                lineStartMs = bounds.first,
                lineEndMs = bounds.second,
                maxLines = 1,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class, ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@UnstableApi
@Composable
fun PlayerScreen(
    onBack: () -> Unit,
    onQueueClick: () -> Unit,
    onSearchClick: () -> Unit,
    onArtistClick: (String) -> Unit,
    isLiquidGlass: Boolean,
    isAmbientEnabled: Boolean,
    backdrop: LayerBackdrop? = null,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }
    val playerType = settingsManager.playerType

    if (playerType == "Material 3") {
        Material3PlayerScreen(
            onBack = onBack,
            onQueueClick = onQueueClick,
            onSearchClick = onSearchClick,
            onArtistClick = onArtistClick,
            isLiquidGlass = isLiquidGlass,
            isAmbientEnabled = isAmbientEnabled,
            backdrop = backdrop,
            sharedTransitionScope = sharedTransitionScope,
            animatedVisibilityScope = animatedVisibilityScope
        )
    } else {
        ClassicPlayerScreen(
            onBack = onBack,
            onQueueClick = onQueueClick,
            onSearchClick = onSearchClick,
            onArtistClick = onArtistClick,
            isLiquidGlass = isLiquidGlass,
            isAmbientEnabled = isAmbientEnabled,
            backdrop = backdrop,
            sharedTransitionScope = sharedTransitionScope,
            animatedVisibilityScope = animatedVisibilityScope
        )
    }

    if (AudioFxManager.showEqualizerSheet) {
        BuiltInEqualizerBottomSheet(
            onDismiss = { AudioFxManager.showEqualizerSheet = false }
        )
    }
}

@OptIn(ExperimentalGlideComposeApi::class, ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@UnstableApi
@Composable
fun ClassicPlayerScreen(
    onBack: () -> Unit,
    onQueueClick: () -> Unit,
    onSearchClick: () -> Unit,
    onArtistClick: (String) -> Unit,
    isLiquidGlass: Boolean,
    isAmbientEnabled: Boolean,
    backdrop: LayerBackdrop? = null,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null
) {
    val activeSong = MusicPlayer.currentSong
    val isPlaying = MusicPlayer.isPlaying
    val isLoading = MusicPlayer.isLoading
    val currentPosition = MusicPlayer.currentPosition
    val duration = MusicPlayer.duration
    val context = LocalContext.current
    val playlistRepository = remember {
        PlaylistRepository(AppDatabase.getDatabase(context).playlistDao(), context)
    }
    val scope = rememberCoroutineScope()
    val settingsManager = remember { SettingsManager(context) }

    var showLyrics by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var showMoreOptions by remember { mutableStateOf(false) }
    var showSleepTimerMenu by remember { mutableStateOf(false) }
    var showPlaylistSelection by remember { mutableStateOf(false) }
    var showArtistSelector by remember { mutableStateOf(false) }

    val isPlayVideoEnabled = MusicPlayer.isVideoModeEnabled
    var lyricsStyle by remember { mutableStateOf(settingsManager.lyricsStyle) }

    val videoDetails by remember { derivedStateOf { MusicPlayer.videoDetails } }
    val isLoadingDetails by remember { derivedStateOf { MusicPlayer.isDetailsLoading } }

    val shades = remember(activeSong?.videoId) {
        val seed = activeSong?.videoId?.hashCode() ?: 0
        val safeIndex = ((seed % CuratedBaseColors.size) + CuratedBaseColors.size) % CuratedBaseColors.size
        val baseColor = CuratedBaseColors[safeIndex]
        deriveShades(baseColor)
    }
    val color1 by animateColorAsState(targetValue = shades.color1, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color1")
    val color2 by animateColorAsState(targetValue = shades.color2, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color2")
    val color3 by animateColorAsState(targetValue = shades.color3, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color3")
    val color4 by animateColorAsState(targetValue = shades.color4, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color4")

    val playerBackdrop = rememberLayerBackdrop {
        drawRect(color4)
        drawContent()
    }
    val sliderBackdrop = rememberLayerBackdrop {
        drawRect(color4)
        drawContent()
    }

    val parsedArtists = remember(activeSong) { activeSong?.parseArtists() ?: emptyList() }
    val handleArtistTrigger: () -> Unit = {
        if (parsedArtists.size > 1) {
            showArtistSelector = true
        } else {
            val first = parsedArtists.firstOrNull()
            val targetId = first?.id?.takeIf { it.isNotBlank() }
                ?: activeSong?.artistId?.takeIf { it.isNotBlank() }
                ?: "search:${first?.name ?: activeSong?.artist ?: ""}"
            if (targetId.isNotBlank()) onArtistClick(targetId)
        }
    }

    if (showArtistSelector && parsedArtists.isNotEmpty()) {
        CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
            ArtistModalBottomSheet(
                artists = parsedArtists,
                isLiquidGlass = isLiquidGlass,
                onDismiss = { showArtistSelector = false },
                onSelectArtist = { selected ->
                    showArtistSelector = false
                    val targetId = selected.id?.takeIf { it.isNotBlank() } ?: "search:${selected.name}"
                    onArtistClick(targetId)
                }
            )
        }
    }

    val pagerState = rememberPagerState(
        initialPage = if (MusicPlayer.queue.isEmpty()) 0 else (MusicPlayer.currentIndex).coerceIn(0, MusicPlayer.queue.size - 1),
        pageCount = { MusicPlayer.queue.size.coerceAtLeast(1) }
    )

    var isLaunched by remember { mutableStateOf(false) }
    var isProgrammaticScroll by remember { mutableStateOf(false) }
    var userSwipedPager by remember { mutableStateOf(false) }
    val isPagerDragged by pagerState.interactionSource.collectIsDraggedAsState()

    LaunchedEffect(isPagerDragged) {
        if (isPagerDragged) userSwipedPager = true
    }

    LaunchedEffect(MusicPlayer.currentIndex) {
        if (MusicPlayer.currentIndex != -1 && MusicPlayer.queue.isNotEmpty()) {
            val targetPage = MusicPlayer.currentIndex.coerceIn(0, MusicPlayer.queue.size - 1)
            if (pagerState.currentPage != targetPage) {
                isProgrammaticScroll = true
                userSwipedPager = false
                try {
                    if (!isLaunched || abs(pagerState.currentPage - targetPage) > 1) {
                        pagerState.scrollToPage(targetPage)
                    } else {
                        pagerState.animateScrollToPage(
                            page = targetPage,
                            animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)
                        )
                    }
                } catch (_: Exception) {
                    try { pagerState.scrollToPage(targetPage) } catch (_: Exception) {}
                } finally {
                    isProgrammaticScroll = false
                }
            }
            isLaunched = true
        }
    }

    LaunchedEffect(pagerState.settledPage, isPagerDragged) {
        if (isLaunched && !isProgrammaticScroll && !isPagerDragged && userSwipedPager &&
            pagerState.settledPage != MusicPlayer.currentIndex &&
            MusicPlayer.currentIndex != -1 && MusicPlayer.queue.isNotEmpty()
        ) {
            userSwipedPager = false
            val targetedSong = MusicPlayer.queue.getOrNull(pagerState.settledPage)
            if (targetedSong != null && targetedSong.videoId != MusicPlayer.currentSong?.videoId) {
                MusicPlayer.playAtIndex(context, pagerState.settledPage)
            }
        }
    }

    val lyricsText by remember {
        derivedStateOf {
            if (MusicPlayer.isLyricsLoading) "Searching for lyrics..."
            else MusicPlayer.lyricsText ?: "Lyrics not available for this track."
        }
    }
    val lyricsProviderName by remember { derivedStateOf { MusicPlayer.lyricsProvider ?: "" } }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    BackHandler(enabled = isLandscape) {
        val activity = context as? Activity
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    DisposableEffect(Unit) {
        MusicPlayer.isPlayerViewVisible = true
        MusicPlayer.updateVideoPlaybackState()
        onDispose {
            MusicPlayer.isPlayerViewVisible = false
            MusicPlayer.updateVideoPlaybackState()
        }
    }

    val isFavorite = MusicPlayer.isFavorite
    val isDownloaded = MusicPlayer.isDownloaded

    val playerSheetPortal = remember { WaveBottomSheetPortalState() }
    CompositionLocalProvider(LocalBottomSheetPortal provides playerSheetPortal) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color4)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .layerBackdrop(playerBackdrop)
                .background(color4)
        ) {
            // Background layer respecting blurPlayerBackground setting
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(sliderBackdrop)
            ) {
                val blurBg = settingsManager.blurPlayerBackground
                val bgArt = MusicPlayer.highResThumbnailUrl ?: activeSong?.thumbnailUrl
                if (blurBg && !bgArt.isNullOrBlank()) {
                    WaveArtworkImage(
                        url = bgArt,
                        contentDescription = null,
                        isVideo = false,
                        modifier = Modifier.fillMaxSize().blur(42.dp),
                        contentScale = ContentScale.Crop
                    )
                    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)))
                } else {
                    Box(modifier = Modifier.fillMaxSize().background(color4))
                }
            }
            if (isLandscape) {
                LandscapePlayerOverlay(
                    onBack = {
                        val activity = context as? Activity
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    },
                    isLiquidGlass = isLiquidGlass,
                    isAmbientEnabled = isAmbientEnabled,
                    backdrop = sliderBackdrop,
                )
            } else {
                CompositionLocalProvider(LocalBackdrop provides null) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                    ) {
                        val mainViewportHeight = (maxHeight - 50.dp).coerceAtLeast(536.dp)
                        val classicListState = rememberLazyListState()
                        val classicHazeState = remember { HazeState() }
                        val isClassicTitleScrolledOff by remember {
                            derivedStateOf {
                                classicListState.firstVisibleItemIndex > 0 || classicListState.firstVisibleItemScrollOffset > 320
                            }
                        }

                        Box(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            state = classicListState,
                            modifier = Modifier
                                .fillMaxSize()
                                .hazeSource(classicHazeState),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            flingBehavior = rememberSmoothFlingBehavior(),
                        ) {
                            item(key = "classic_player_main") {
                                Column(
                                    modifier = Modifier
                                        .fillParentMaxWidth()
                                        .height(mainViewportHeight)
                                        .padding(bottom = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                // Top Bar with small breathing space from top
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp)
                                        .padding(top = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    GlassIconButton(
                                        icon = Icons.Rounded.KeyboardArrowDown,
                                        onClick = onBack,
                                        isLiquidGlass = isLiquidGlass,
                                        contentDescription = "Close",
                                        containerSize = 44.dp,
                                        iconSize = 28.dp
                                    )

                                    val isCurrentSongVideo = MusicPlayer.isVideoAvailable && activeSong != null
                                    SongVideoModeSwitcher(
                                        isVideoEnabled = isPlayVideoEnabled,
                                        isVideoAvailable = isCurrentSongVideo,
                                        accentColor = color1,
                                        onToggle = { enabled ->
                                            MusicPlayer.setVideoPlaybackEnabled(context, enabled)
                                        }
                                    )

                                    GlassIconButton(
                                        icon = Icons.Rounded.MoreVert,
                                        onClick = { showMoreOptions = true },
                                        isLiquidGlass = isLiquidGlass,
                                        contentDescription = "More Options",
                                        containerSize = 44.dp,
                                        iconSize = 24.dp
                                    )
                                }

                                // SimpMusic reduced 1:1 Artwork / Video Canvas Container (px = 32.dp, adaptive weight)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 32.dp, vertical = 6.dp)
                                        .weight(1f, fill = false)
                                        .aspectRatio(1f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val isCurrentSongVideo = MusicPlayer.isVideoAvailable && activeSong != null
                                    if (isCurrentSongVideo && isPlayVideoEnabled && !showLyrics) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(16f / 9f)
                                                .clip(RoundedCornerShape(18.dp))
                                                .background(Color.Black)
                                        ) {
                                            WaveVideoPlayerSurface(modifier = Modifier.fillMaxSize())

                                            if (!MusicPlayer.isVideoActuallyPlaying) {
                                                WaveArtworkImage(
                                                    url = MusicPlayer.highResThumbnailUrl ?: activeSong?.thumbnailUrl,
                                                    videoId = activeSong?.videoId,
                                                    contentDescription = activeSong?.title,
                                                    isVideo = true,
                                                    shape = RoundedCornerShape(18.dp),
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.BottomEnd)
                                                    .padding(12.dp)
                                            ) {
                                                GlassIconButton(
                                                    icon = Icons.Default.Fullscreen,
                                                    onClick = {
                                                        val activity = context as? Activity
                                                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                                    },
                                                    isLiquidGlass = isLiquidGlass,
                                                    contentDescription = "Fullscreen",
                                                    containerSize = 40.dp,
                                                    iconSize = 22.dp
                                                )
                                            }
                                        }
                                    } else {
                                        HorizontalPager(
                                            state = pagerState,
                                            modifier = Modifier.fillMaxWidth(),
                                            contentPadding = PaddingValues(horizontal = 0.dp),
                                            pageSpacing = 16.dp,
                                            beyondViewportPageCount = 1
                                        ) { page ->
                                            val song = MusicPlayer.queue.getOrNull(page) ?: activeSong
                                            val isCurrentPage = page == MusicPlayer.currentIndex
                                            val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                                            val pageOffsetAbs = abs(pageOffset)

                                            val model = if (isCurrentPage) (MusicPlayer.highResThumbnailUrl ?: song?.thumbnailUrl) else song?.thumbnailUrl
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Surface(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .aspectRatio(1f)
                                                        .graphicsLayer {
                                                            val scale = 0.96f + 0.04f * (1f - pageOffsetAbs.coerceIn(0f, 1f))
                                                            scaleX = scale
                                                            scaleY = scale
                                                            compositingStrategy = CompositingStrategy.Auto
                                                        },
                                                    shape = RoundedCornerShape(18.dp),
                                                    shadowElevation = 8.dp,
                                                    color = Color(0xFF101015)
                                                ) {
                                                    WaveArtworkImage(
                                                        url = model,
                                                        videoId = song?.videoId,
                                                        contentDescription = song?.title,
                                                        isVideo = false,
                                                        shape = RoundedCornerShape(18.dp),
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // SimpMusic Word-by-Word Synced Lyric Strip with equal breathing space between thumbnail & title
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    SimpInlineTitleLyricStrip(
                                        lyrics = lyricsText,
                                        currentPosition = currentPosition,
                                        accentColor = color1,
                                        onClick = { showLyrics = true },
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = activeSong?.title ?: "No Song Selected",
                                                style = MaterialTheme.typography.headlineMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 22.sp
                                                ),
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Clip,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .basicMarquee(
                                                        iterations = Int.MAX_VALUE,
                                                        animationMode = MarqueeAnimationMode.Immediately,
                                                        initialDelayMillis = 1200,
                                                    )
                                                    .focusable()
                                            )
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text(
                                                text = activeSong?.displayArtists
                                                    ?: MusicPlayer.sanitizedArtistName.ifEmpty { "Select a track to play" },
                                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp),
                                                color = Color.White.copy(alpha = 0.76f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Clip,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .basicMarquee(
                                                        iterations = Int.MAX_VALUE,
                                                        animationMode = MarqueeAnimationMode.Immediately,
                                                        initialDelayMillis = 1200,
                                                    )
                                                    .focusable()
                                                    .clickable { handleArtistTrigger() }
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .background(
                                                    if (rememberIsLiquidGlassEnabled(isLiquidGlass)) Color.White.copy(alpha = 0.10f) else QueueSolidGrey,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            WaveHeartButton(
                                                isFavorite = isFavorite,
                                                onToggle = { MusicPlayer.toggleFavorite(context) },
                                                iconSize = 24.dp,
                                                buttonSize = 46.dp,
                                                activeColor = Color(0xFFFF2D55),
                                                inactiveColor = Color.White
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Apple White Slider with Oval Liquid Pill Thumb at the end of progress
                                val sliderPosition = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
                                AppleLiquidSlider(
                                    value = sliderPosition,
                                    onValueChange = { newValue ->
                                        if (duration > 0) {
                                            MusicPlayer.seekTo((newValue * duration).toLong())
                                        }
                                    },
                                    isLiquidGlass = isLiquidGlass,
                                    backdrop = sliderBackdrop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp),
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 26.dp, vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(formatTime(currentPosition), color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                                    Text(formatTime(duration), color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Transport Row (Container around Previous & Next removed per user request)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { MusicPlayer.shuffleEnabled = !MusicPlayer.shuffleEnabled }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Shuffle,
                                            contentDescription = "Shuffle",
                                            tint = if (MusicPlayer.shuffleEnabled) color1 else Color.White.copy(alpha = 0.7f),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(26.dp)
                                    ) {
                                        // Containerless Previous Button
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clip(CircleShape)
                                                .clickable(
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    indication = null,
                                                    onClick = { MusicPlayer.playPreviousInQueue(context) }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.SkipPrevious,
                                                contentDescription = "Previous",
                                                tint = Color.White,
                                                modifier = Modifier.size(38.dp)
                                            )
                                        }

                                        // Play/Pause Button (Containerless clean icon per user request)
                                        Box(
                                            modifier = Modifier
                                                .size(68.dp)
                                                .clip(CircleShape)
                                                .clickable(
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    indication = null,
                                                    onClick = { MusicPlayer.togglePlayPause(context) }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isLoading) {
                                                CircularProgressIndicator(
                                                    color = Color.White,
                                                    strokeWidth = 3.dp,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(52.dp)
                                                )
                                            }
                                        }

                                        // Containerless Next Button
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clip(CircleShape)
                                                .clickable(
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    indication = null,
                                                    onClick = { MusicPlayer.playNextInQueue(context) }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.SkipNext,
                                                contentDescription = "Next",
                                                tint = Color.White,
                                                modifier = Modifier.size(38.dp)
                                            )
                                        }
                                    }

                                    IconButton(onClick = {
                                        MusicPlayer.repeatMode = when (MusicPlayer.repeatMode) {
                                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                            else -> Player.REPEAT_MODE_OFF
                                        }
                                    }) {
                                        Icon(
                                            imageVector = if (MusicPlayer.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                                            contentDescription = "Repeat",
                                            tint = if (MusicPlayer.repeatMode != Player.REPEAT_MODE_OFF) color1 else Color.White.copy(alpha = 0.7f),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Bottom Action Bar
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ActionIcon(Icons.Default.Info, "Details") { showDetails = true }
                                    ActionIcon(WaveIcons.Lyrics, "Lyrics") { showLyrics = !showLyrics }
                                    ActionIcon(WaveIcons.Queue, "Queue") { onQueueClick() }
                                    ActionIcon(WaveIcons.Artist, "Artists") { handleArtistTrigger() }
                                }

                                // Breathing space so only the top header of LyricsPreviewBox peeks into view when scrolled to top
                                Spacer(modifier = Modifier.height(6.dp))
                                }
                            }

                            val hasLyrics = !MusicPlayer.isLyricsLoading && !MusicPlayer.lyricsText.isNullOrBlank() && MusicPlayer.lyricsText != "Lyrics not available for this track."
                            if (hasLyrics) {
                                item(key = "classic_lyrics_preview") {
                                    AnimatedVisibility(
                                        visible = hasLyrics,
                                        enter = fadeIn(tween(260)) + slideInVertically(initialOffsetY = { -it / 3 }) + expandVertically(),
                                        exit = fadeOut(tween(200)) + shrinkVertically(),
                                    ) {
                                        LyricsPreviewBox(
                                            lyrics = lyricsText,
                                            provider = lyricsProviderName,
                                            currentPosition = currentPosition,
                                            backgroundColor = color3,
                                            isAppleMusicBlur = !lyricsStyle.contains("Classic", ignoreCase = true),
                                            onShowClick = { showLyrics = true }
                                        )
                                    }
                                }
                            }

                            item(key = "classic_artist_banner") {
                                AnimatedVisibility(
                                    visible = true,
                                    enter = fadeIn(tween(260)) + slideInVertically(initialOffsetY = { -it / 4 }),
                                ) {
                                    ProgressiveArtistBannerCard(
                                        activeSong = activeSong,
                                        videoDetails = videoDetails,
                                        backgroundColor = color4,
                                        onClick = handleArtistTrigger
                                    )
                                }
                            }
                        }

                        // Collapsing Sticky Top Bar with Haze blur effect
                        AnimatedVisibility(
                            visible = isClassicTitleScrolledOff,
                            enter = slideInVertically(initialOffsetY = { -it }, animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)) + fadeIn(tween(200)),
                            exit = slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(180)) + fadeOut(tween(160)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                        ) {
                            PlayerCollapsingTopBar(
                                activeSong = activeSong,
                                currentPosition = currentPosition,
                                duration = duration,
                                isPlaying = isPlaying,
                                hazeState = classicHazeState,
                                onBack = onBack,
                                onPlayPause = { MusicPlayer.togglePlayPause(context) },
                                onMore = { showMoreOptions = true },
                                accentColor = color1,
                            )
                        }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showLyrics,
            enter = fadeIn(tween(240)) + scaleIn(initialScale = 0.96f, animationSpec = tween(240)),
            exit = fadeOut(tween(200)) + scaleOut(targetScale = 0.96f, animationSpec = tween(200))
        ) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                LyricsOverlay(
                    lyrics = lyricsText,
                    provider = lyricsProviderName,
                    currentPosition = currentPosition,
                    backgroundColor = color3,
                    isLiquidGlass = isLiquidGlass,
                    lyricsStyle = lyricsStyle,
                    onLyricsStyleChange = { newStyle ->
                        lyricsStyle = newStyle
                        settingsManager.lyricsStyle = newStyle
                    },
                    onSeekToMs = { targetMs ->
                        MusicPlayer.seekTo(targetMs)
                    },
                    onDismiss = { showLyrics = false }
                )
            }
        }

        if (showDetails) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                DetailsBottomSheet(
                    details = videoDetails,
                    isLoading = isLoadingDetails,
                    isLiquidGlass = isLiquidGlass,
                    onDismiss = { showDetails = false }
                )
            }
        }

        if (showMoreOptions && activeSong != null) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                PlayerOptionsBottomSheet(
                    song = activeSong,
                    isFavorite = isFavorite,
                    isDownloaded = isDownloaded,
                    isLiquidGlass = isLiquidGlass,
                    accentColor = color1,
                    onDismiss = { showMoreOptions = false },
                    onFavoriteClick = { MusicPlayer.toggleFavorite(context) },
                    onDownloadClick = {
                        scope.launch {
                            if (isDownloaded) {
                                AppDatabase.getDatabase(context).songDao().deleteDownload(activeSong.videoId)
                                val downloaded = AppDatabase.getDatabase(context).songDao().getDownloadByVideoId(activeSong.videoId)
                                downloaded?.filePath?.let { path -> java.io.File(path).delete() }
                                MusicPlayer.isDownloaded = false
                                Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                                return@launch
                            }

                            val result = MusicPlayer.unifiedRepository?.getStreamingUrl(
                                videoId = activeSong.videoId,
                                cookies = MusicPlayer.cookies,
                                failedClients = emptyList(),
                                targetBitrate = null,
                                priority = if (settingsManager.isDataSaverEnabled) "Data Saver" else "Force OPUS 160kbps",
                                preferredVideoQuality = settingsManager.preferredVideoQuality
                            )
                            if (result != null) {
                                val downloadRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
                                    .setInputData(
                                        workDataOf(
                                            "url" to result.url,
                                            "videoId" to activeSong.videoId,
                                            "title" to activeSong.title,
                                            "artist" to activeSong.artist,
                                            "thumbnailUrl" to activeSong.thumbnailUrl,
                                            "userAgent" to result.userAgent,
                                            "cookies" to MusicPlayer.cookies
                                        )
                                    )
                                    .build()
                                WorkManager.getInstance(context).enqueue(downloadRequest)
                                Toast.makeText(context, "Downloading ${activeSong.title}...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onAddToPlaylistClick = {
                        showMoreOptions = false
                        showPlaylistSelection = true
                    },
                    onSleepTimerClick = {
                        showMoreOptions = false
                        showSleepTimerMenu = true
                    },
                    onPlayNextClick = { MusicPlayer.playNext(activeSong) },
                    onArtistClick = { _ ->
                        showMoreOptions = false
                        handleArtistTrigger()
                    },
                    onShareClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Listen to ${activeSong.title} by ${activeSong.artist} on WaveMuzix: https://www.youtube.com/watch?v=${activeSong.videoId}")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, null))
                    }
                )
            }
        }

        if (showSleepTimerMenu) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                SleepTimerBottomSheet(
                    isLiquidGlass = isLiquidGlass,
                    onDismiss = { showSleepTimerMenu = false },
                    onTimerSelected = { minutes ->
                        if (minutes == -1) {
                            MusicPlayer.toggleStopAfterCurrentSong(true)
                        } else if (minutes > 0) {
                            MusicPlayer.startSleepTimer(minutes)
                        } else {
                            MusicPlayer.cancelSleepTimer()
                        }
                        showSleepTimerMenu = false
                    }
                )
            }
        }

        if (showPlaylistSelection && activeSong != null) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                PlaylistSelectionBottomSheet(
                    playlists = playlistRepository.allPlaylists.collectAsState(initial = emptyList()).value,
                    isLiquidGlass = isLiquidGlass,
                    onDismiss = { showPlaylistSelection = false },
                    onCreatePlaylist = { name ->
                        scope.launch {
                            val id = playlistRepository.createPlaylist(name)
                            playlistRepository.addSongToPlaylist(id, activeSong)
                            showPlaylistSelection = false
                        }
                    },
                    onPlaylistSelected = { playlist ->
                        scope.launch {
                            playlistRepository.addSongToPlaylist(playlist.id, activeSong)
                            showPlaylistSelection = false
                        }
                    }
                )
            }
        }

        WaveBottomSheetPortalHost(
            portalState = playerSheetPortal,
            defaultBackdrop = playerBackdrop
        )
    }
    }
}

@OptIn(ExperimentalGlideComposeApi::class, ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@UnstableApi
@Composable
fun Material3PlayerScreen(
    onBack: () -> Unit,
    onQueueClick: () -> Unit,
    onSearchClick: () -> Unit,
    onArtistClick: (String) -> Unit,
    isLiquidGlass: Boolean,
    isAmbientEnabled: Boolean,
    backdrop: LayerBackdrop? = null,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null
) {
    val activeSong = MusicPlayer.currentSong
    val isPlaying = MusicPlayer.isPlaying
    val isLoading = MusicPlayer.isLoading
    val currentPosition = MusicPlayer.currentPosition
    val duration = MusicPlayer.duration
    val context = LocalContext.current
    val playlistRepository = remember {
        PlaylistRepository(AppDatabase.getDatabase(context).playlistDao(), context)
    }
    val scope = rememberCoroutineScope()
    val settingsManager = remember { SettingsManager(context) }

    var showLyrics by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var showMoreOptions by remember { mutableStateOf(false) }
    var showSleepTimerMenu by remember { mutableStateOf(false) }
    var showPlaylistSelection by remember { mutableStateOf(false) }
    var showArtistSelector by remember { mutableStateOf(false) }

    val isPlayVideoEnabled = MusicPlayer.isVideoModeEnabled
    var lyricsStyle by remember { mutableStateOf(settingsManager.lyricsStyle) }

    val videoDetails by remember { derivedStateOf { MusicPlayer.videoDetails } }

    val shades = remember(activeSong?.videoId) {
        val seed = activeSong?.videoId?.hashCode() ?: 0
        val safeIndex = ((seed % CuratedBaseColors.size) + CuratedBaseColors.size) % CuratedBaseColors.size
        val baseColor = CuratedBaseColors[safeIndex]
        deriveShades(baseColor)
    }
    val color1 by animateColorAsState(targetValue = shades.color1, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color1")
    val color2 by animateColorAsState(targetValue = shades.color2, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color2")
    val color3 by animateColorAsState(targetValue = shades.color3, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color3")
    val color4 by animateColorAsState(targetValue = shades.color4, animationSpec = tween(1400, easing = LinearOutSlowInEasing), label = "color4")

    val playerBackdrop = rememberLayerBackdrop {
        drawRect(color4)
        drawContent()
    }

    val parsedArtists = remember(activeSong) { activeSong?.parseArtists() ?: emptyList() }
    val handleArtistTrigger: () -> Unit = {
        if (parsedArtists.size > 1) {
            showArtistSelector = true
        } else {
            val first = parsedArtists.firstOrNull()
            val targetId = first?.id?.takeIf { it.isNotBlank() }
                ?: activeSong?.artistId?.takeIf { it.isNotBlank() }
                ?: "search:${first?.name ?: activeSong?.artist ?: ""}"
            if (targetId.isNotBlank()) onArtistClick(targetId)
        }
    }

    if (showArtistSelector && parsedArtists.isNotEmpty()) {
        CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
            ArtistModalBottomSheet(
                artists = parsedArtists,
                isLiquidGlass = isLiquidGlass,
                onDismiss = { showArtistSelector = false },
                onSelectArtist = { selected ->
                    showArtistSelector = false
                    val targetId = selected.id?.takeIf { it.isNotBlank() } ?: "search:${selected.name}"
                    onArtistClick(targetId)
                }
            )
        }
    }

    val playPauseCorner by animateDpAsState(
        targetValue = if (isPlaying) 22.dp else 34.dp,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "playPauseCorner"
    )
    val skipInnerCorner by animateDpAsState(
        targetValue = if (isPlaying) 16.dp else 34.dp,
        animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
        label = "skipInnerCorner"
    )

    val pagerState = rememberPagerState(
        initialPage = if (MusicPlayer.queue.isEmpty()) 0 else (MusicPlayer.currentIndex).coerceIn(0, MusicPlayer.queue.size - 1),
        pageCount = { MusicPlayer.queue.size.coerceAtLeast(1) }
    )

    var isLaunched by remember { mutableStateOf(false) }
    var isProgrammaticScroll by remember { mutableStateOf(false) }
    var userSwipedPager by remember { mutableStateOf(false) }
    val isPagerDragged by pagerState.interactionSource.collectIsDraggedAsState()

    LaunchedEffect(isPagerDragged) {
        if (isPagerDragged) userSwipedPager = true
    }

    LaunchedEffect(MusicPlayer.currentIndex) {
        if (MusicPlayer.currentIndex != -1 && MusicPlayer.queue.isNotEmpty()) {
            val targetPage = MusicPlayer.currentIndex.coerceIn(0, MusicPlayer.queue.size - 1)
            if (pagerState.currentPage != targetPage) {
                isProgrammaticScroll = true
                userSwipedPager = false
                try {
                    if (!isLaunched || abs(pagerState.currentPage - targetPage) > 1) {
                        pagerState.scrollToPage(targetPage)
                    } else {
                        pagerState.animateScrollToPage(
                            page = targetPage,
                            animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)
                        )
                    }
                } catch (_: Exception) {
                    try { pagerState.scrollToPage(targetPage) } catch (_: Exception) {}
                } finally {
                    isProgrammaticScroll = false
                }
            }
            isLaunched = true
        }
    }

    LaunchedEffect(pagerState.settledPage, isPagerDragged) {
        if (isLaunched && !isProgrammaticScroll && !isPagerDragged && userSwipedPager &&
            pagerState.settledPage != MusicPlayer.currentIndex &&
            MusicPlayer.currentIndex != -1 && MusicPlayer.queue.isNotEmpty()
        ) {
            userSwipedPager = false
            val targetedSong = MusicPlayer.queue.getOrNull(pagerState.settledPage)
            if (targetedSong != null && targetedSong.videoId != MusicPlayer.currentSong?.videoId) {
                MusicPlayer.playAtIndex(context, pagerState.settledPage)
            }
        }
    }

    val lyricsText by remember {
        derivedStateOf {
            if (MusicPlayer.isLyricsLoading) "Searching for lyrics..."
            else MusicPlayer.lyricsText ?: "Lyrics not available for this track."
        }
    }
    val lyricsProviderName by remember { derivedStateOf { MusicPlayer.lyricsProvider ?: "" } }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    BackHandler(enabled = isLandscape) {
        val activity = context as? Activity
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    DisposableEffect(Unit) {
        MusicPlayer.isPlayerViewVisible = true
        MusicPlayer.updateVideoPlaybackState()
        onDispose {
            MusicPlayer.isPlayerViewVisible = false
            MusicPlayer.updateVideoPlaybackState()
        }
    }

    val isFavorite = MusicPlayer.isFavorite

    val playerSheetPortal = remember { WaveBottomSheetPortalState() }
    CompositionLocalProvider(LocalBottomSheetPortal provides playerSheetPortal) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color4)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .layerBackdrop(playerBackdrop)
                .background(color4)
        ) {
            val blurBg = settingsManager.blurPlayerBackground
            val bgArt = MusicPlayer.highResThumbnailUrl ?: activeSong?.thumbnailUrl
            if (blurBg && !bgArt.isNullOrBlank()) {
                WaveArtworkImage(
                    url = bgArt,
                    contentDescription = null,
                    isVideo = false,
                    modifier = Modifier.fillMaxSize().blur(42.dp),
                    contentScale = ContentScale.Crop
                )
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.58f)))
            } else {
                Box(modifier = Modifier.fillMaxSize().background(color4))
            }

            if (isLandscape) {
                LandscapePlayerOverlay(
                    onBack = {
                        val activity = context as? Activity
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    },
                    isLiquidGlass = isLiquidGlass,
                    isAmbientEnabled = isAmbientEnabled,
                    backdrop = playerBackdrop,
                )
            } else {
                CompositionLocalProvider(LocalBackdrop provides null) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                    ) {
                        val mainViewportHeight = (maxHeight - 50.dp).coerceAtLeast(536.dp)
                        val m3ListState = rememberLazyListState()
                        val m3HazeState = remember { HazeState() }
                        val isM3TitleScrolledOff by remember {
                            derivedStateOf {
                                m3ListState.firstVisibleItemIndex > 0 || m3ListState.firstVisibleItemScrollOffset > 320
                            }
                        }

                        Box(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            state = m3ListState,
                            modifier = Modifier
                                .fillMaxSize()
                                .hazeSource(m3HazeState),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            flingBehavior = rememberSmoothFlingBehavior(),
                        ) {
                            item(key = "m3_expressive_main") {
                                Column(
                                    modifier = Modifier
                                        .fillParentMaxWidth()
                                        .height(mainViewportHeight)
                                        .padding(horizontal = 24.dp)
                                        .padding(bottom = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Top Bar that scrolls upwards with the screen content
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        GlassIconButton(
                                            icon = Icons.Rounded.KeyboardArrowDown,
                                            onClick = onBack,
                                            isLiquidGlass = isLiquidGlass,
                                            contentDescription = "Back",
                                            containerSize = 42.dp,
                                            iconSize = 26.dp,
                                        )

                                        val isCurrentSongVideo = MusicPlayer.isVideoAvailable && activeSong != null
                                        SongVideoModeSwitcher(
                                            isVideoEnabled = isPlayVideoEnabled,
                                            isVideoAvailable = isCurrentSongVideo,
                                            accentColor = color1,
                                            onToggle = { enabled ->
                                                MusicPlayer.setVideoPlaybackEnabled(context, enabled)
                                            }
                                        )

                                        GlassIconButton(
                                            icon = Icons.Rounded.MoreVert,
                                            onClick = { showMoreOptions = true },
                                            isLiquidGlass = isLiquidGlass,
                                            contentDescription = "More",
                                            containerSize = 42.dp,
                                            iconSize = 22.dp,
                                        )
                                    }
                                item(key = "m3_expressive_main") {
                                    Column(
                                        modifier = Modifier
                                            .fillParentMaxWidth()
                                            .height(mainViewportHeight)
                                            .padding(horizontal = 24.dp)
                                            .padding(bottom = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        // SimpMusic reduced 1:1 Rounded Artwork / Video Card
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                                .weight(1f, fill = false)
                                                .aspectRatio(1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                        val isCurrentSongVideo = MusicPlayer.isVideoAvailable && activeSong != null
                                        if (isCurrentSongVideo && isPlayVideoEnabled && !showLyrics) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .aspectRatio(16f / 9f)
                                                    .clip(RoundedCornerShape(24.dp))
                                                    .background(Color.Black)
                                            ) {
                                                WaveVideoPlayerSurface(modifier = Modifier.fillMaxSize())

                                                if (!MusicPlayer.isVideoActuallyPlaying) {
                                                    WaveArtworkImage(
                                                        url = MusicPlayer.highResThumbnailUrl ?: activeSong?.thumbnailUrl,
                                                        videoId = activeSong?.videoId,
                                                        contentDescription = activeSong?.title,
                                                        isVideo = true,
                                                        shape = RoundedCornerShape(28.dp),
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }

                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomEnd)
                                                        .padding(12.dp)
                                                ) {
                                                    GlassIconButton(
                                                        icon = Icons.Default.Fullscreen,
                                                        onClick = {
                                                            val activity = context as? Activity
                                                            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                                        },
                                                        isLiquidGlass = isLiquidGlass,
                                                        contentDescription = "Fullscreen",
                                                        containerSize = 40.dp,
                                                        iconSize = 22.dp
                                                    )
                                                }
                                            }
                                        } else {
                                            HorizontalPager(
                                                state = pagerState,
                                                modifier = Modifier.fillMaxSize(),
                                                pageSpacing = 20.dp
                                            ) { page ->
                                                val song = MusicPlayer.queue.getOrNull(page) ?: activeSong
                                                val isCurrentPage = page == MusicPlayer.currentIndex
                                                val pageOffset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)

                                                val artUrl = if (isCurrentPage) (MusicPlayer.highResThumbnailUrl ?: song?.thumbnailUrl) else song?.thumbnailUrl
                                                Box(
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Surface(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .aspectRatio(1f)
                                                            .graphicsLayer {
                                                                val scale = 0.92f + (0.08f * (1f - abs(pageOffset).coerceIn(0f, 1f)))
                                                                scaleX = scale
                                                                scaleY = scale
                                                                alpha = 0.65f + (0.35f * (1f - abs(pageOffset).coerceIn(0f, 1f)))
                                                            },
                                                        shape = RoundedCornerShape(24.dp),
                                                        shadowElevation = 8.dp,
                                                        color = Color(0xFF101015)
                                                    ) {
                                                        WaveArtworkImage(
                                                            url = artUrl,
                                                            videoId = song?.videoId,
                                                            contentDescription = song?.title,
                                                            isVideo = false,
                                                            shape = RoundedCornerShape(24.dp),
                                                            modifier = Modifier.fillMaxSize()
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // SimpMusic Word-by-Word Synced Lyric Strip ABOVE Song Title with balanced spacing
                                    SimpInlineTitleLyricStrip(
                                        lyrics = lyricsText,
                                        currentPosition = currentPosition,
                                        accentColor = color1,
                                        onClick = { showLyrics = true },
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Song Info Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = activeSong?.title ?: "No Song",
                                                style = MaterialTheme.typography.headlineMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 22.sp
                                                ),
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Clip,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .basicMarquee(
                                                        iterations = Int.MAX_VALUE,
                                                        animationMode = MarqueeAnimationMode.Immediately,
                                                        initialDelayMillis = 1200,
                                                    )
                                                    .focusable()
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = activeSong?.displayArtists
                                                    ?: MusicPlayer.sanitizedArtistName.ifEmpty { "Unknown Artist" },
                                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp),
                                                color = Color.White.copy(alpha = 0.72f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Clip,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .basicMarquee(
                                                        iterations = Int.MAX_VALUE,
                                                        animationMode = MarqueeAnimationMode.Immediately,
                                                        initialDelayMillis = 1200,
                                                    )
                                                    .focusable()
                                                    .clickable { handleArtistTrigger() }
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .background(color3.copy(alpha = 0.85f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            WaveHeartButton(
                                                isFavorite = isFavorite,
                                                onToggle = { MusicPlayer.toggleFavorite(context) },
                                                iconSize = 24.dp,
                                                buttonSize = 48.dp,
                                                activeColor = Color(0xFFFF2D55),
                                                inactiveColor = Color.White
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    val sliderPosition = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
                                    WavySlider(
                                        value = sliderPosition,
                                        onValueChange = { newValue: Float ->
                                            if (duration > 0) MusicPlayer.seekTo((newValue * duration).toLong())
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        isPlaying = isPlaying,
                                        colors = SliderDefaults.colors(
                                            activeTrackColor = color1,
                                            inactiveTrackColor = color2,
                                            thumbColor = color1
                                        ),
                                        luminance = 0.2f
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(formatTime(currentPosition), color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.bodySmall)
                                        Text(formatTime(duration), color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.bodySmall)
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // ExpressiveTransportRow
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(68.dp),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            onClick = { MusicPlayer.playPreviousInQueue(context) },
                                            shape = RoundedCornerShape(
                                                topStart = 34.dp,
                                                bottomStart = 34.dp,
                                                topEnd = skipInnerCorner,
                                                bottomEnd = skipInnerCorner
                                            ),
                                            color = color2,
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(30.dp))
                                            }
                                        }

                                        Surface(
                                            onClick = { MusicPlayer.togglePlayPause(context) },
                                            shape = RoundedCornerShape(playPauseCorner),
                                            color = color1,
                                            modifier = Modifier
                                                .weight(1.45f)
                                                .fillMaxHeight()
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                if (isLoading) {
                                                    CircularProgressIndicator(
                                                        color = color4,
                                                        strokeWidth = 3.dp,
                                                        modifier = Modifier.size(28.dp)
                                                    )
                                                } else {
                                                    Icon(
                                                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                                        tint = color4,
                                                        modifier = Modifier.size(36.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Surface(
                                            onClick = { MusicPlayer.playNextInQueue(context) },
                                            shape = RoundedCornerShape(
                                                topStart = skipInnerCorner,
                                                bottomStart = skipInnerCorner,
                                                topEnd = 34.dp,
                                                bottomEnd = 34.dp
                                            ),
                                            color = color2,
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(30.dp))
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Segmented Connected Utility Group
                                    SimpExpressiveConnectedGroup(
                                        containerColor = color3,
                                        activeContainerColor = color1,
                                        contentColor = color1,
                                        activeContentColor = color4,
                                        isShuffle = MusicPlayer.shuffleEnabled,
                                        repeatMode = MusicPlayer.repeatMode,
                                        isVideoActive = isPlayVideoEnabled && MusicPlayer.isVideoAvailable,
                                        onDetailsClick = { showDetails = true },
                                        onShuffleClick = { MusicPlayer.shuffleEnabled = !MusicPlayer.shuffleEnabled },
                                        onRepeatClick = {
                                            MusicPlayer.repeatMode = when (MusicPlayer.repeatMode) {
                                                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                                else -> Player.REPEAT_MODE_OFF
                                            }
                                        },
                                        onLyricsClick = { showLyrics = true },
                                        onVideoToggleClick = {
                                            if (MusicPlayer.isVideoAvailable) {
                                                MusicPlayer.setVideoPlaybackEnabled(context, !isPlayVideoEnabled)
                                            }
                                        },
                                        onQueueClick = onQueueClick
                                    )

                                    // Breathing space so only the top header of LyricsPreviewBox peeks into view when scrolled to top
                                    Spacer(modifier = Modifier.height(6.dp))
                                    }
                                }

                                val hasLyrics = !MusicPlayer.isLyricsLoading && !MusicPlayer.lyricsText.isNullOrBlank() && MusicPlayer.lyricsText != "Lyrics not available for this track."
                                if (hasLyrics) {
                                    item(key = "m3_lyrics_preview") {
                                        AnimatedVisibility(
                                            visible = hasLyrics,
                                            enter = fadeIn(tween(260)) + slideInVertically(initialOffsetY = { -it / 3 }) + expandVertically(),
                                            exit = fadeOut(tween(200)) + shrinkVertically(),
                                        ) {
                                            LyricsPreviewBox(
                                                lyrics = lyricsText,
                                                provider = lyricsProviderName,
                                                currentPosition = currentPosition,
                                                backgroundColor = color3,
                                                isAppleMusicBlur = !lyricsStyle.contains("Classic", ignoreCase = true),
                                                onShowClick = { showLyrics = true }
                                            )
                                        }
                                    }
                                }

                                item(key = "m3_artist_banner") {
                                    AnimatedVisibility(
                                        visible = true,
                                        enter = fadeIn(tween(260)) + slideInVertically(initialOffsetY = { -it / 4 }),
                                    ) {
                                        ProgressiveArtistBannerCard(
                                            activeSong = activeSong,
                                            videoDetails = videoDetails,
                                            backgroundColor = color4,
                                            onClick = handleArtistTrigger
                                        )
                                    }
                                }
                            }

                            // Collapsing Sticky Top Bar with Haze blur effect
                            AnimatedVisibility(
                                visible = isM3TitleScrolledOff,
                                enter = slideInVertically(initialOffsetY = { -it }, animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)) + fadeIn(tween(200)),
                                exit = slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(180)) + fadeOut(tween(160)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.TopCenter)
                            ) {
                                PlayerCollapsingTopBar(
                                    activeSong = activeSong,
                                    currentPosition = currentPosition,
                                    duration = duration,
                                    isPlaying = isPlaying,
                                    hazeState = m3HazeState,
                                    onBack = onBack,
                                    onPlayPause = { MusicPlayer.togglePlayPause(context) },
                                    onMore = { showMoreOptions = true },
                                    accentColor = color1,
                                )
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showLyrics,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                LyricsOverlay(
                    lyrics = lyricsText,
                    provider = lyricsProviderName,
                    currentPosition = currentPosition,
                    backgroundColor = color3,
                    isLiquidGlass = isLiquidGlass,
                    lyricsStyle = lyricsStyle,
                    onLyricsStyleChange = { newStyle ->
                        lyricsStyle = newStyle
                        settingsManager.lyricsStyle = newStyle
                    },
                    onSeekToMs = { targetMs ->
                        MusicPlayer.seekTo(targetMs)
                    },
                    onDismiss = { showLyrics = false }
                )
            }
        }

        if (showDetails) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                DetailsBottomSheet(
                    details = videoDetails,
                    isLiquidGlass = isLiquidGlass,
                    isLoading = MusicPlayer.isDetailsLoading,
                    onDismiss = { showDetails = false }
                )
            }
        }

        if (showMoreOptions && activeSong != null) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                PlayerOptionsBottomSheet(
                    song = activeSong,
                    isFavorite = isFavorite,
                    isDownloaded = MusicPlayer.isDownloaded,
                    isLiquidGlass = isLiquidGlass,
                    accentColor = color1,
                    onDismiss = { showMoreOptions = false },
                    onFavoriteClick = { MusicPlayer.toggleFavorite(context) },
                    onDownloadClick = {
                        val workRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
                            .setInputData(
                                workDataOf(
                                    "videoId" to activeSong.videoId,
                                    "title" to activeSong.title,
                                    "artist" to activeSong.artist,
                                    "thumbnail" to activeSong.thumbnailUrl
                                )
                            )
                            .build()
                        WorkManager.getInstance(context).enqueue(workRequest)
                        showMoreOptions = false
                    },
                    onAddToPlaylistClick = {
                        showMoreOptions = false
                        showPlaylistSelection = true
                    },
                    onSleepTimerClick = {
                        showMoreOptions = false
                        showSleepTimerMenu = true
                    },
                    onPlayNextClick = {
                        MusicPlayer.playNext(activeSong)
                        showMoreOptions = false
                    },
                    onArtistClick = { _ ->
                        showMoreOptions = false
                        handleArtistTrigger()
                    },
                    onShareClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Listen to ${activeSong.title} by ${activeSong.artist} on WaveMuzix: https://www.youtube.com/watch?v=${activeSong.videoId}")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, null))
                    }
                )
            }
        }

        if (showSleepTimerMenu) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                SleepTimerBottomSheet(
                    isLiquidGlass = isLiquidGlass,
                    onDismiss = { showSleepTimerMenu = false },
                    onTimerSelected = { minutes ->
                        if (minutes == 0) {
                            MusicPlayer.cancelSleepTimer()
                        } else if (minutes == -1) {
                            MusicPlayer.stopAfterCurrentSong = true
                        } else {
                            MusicPlayer.startSleepTimer(minutes)
                        }
                        showSleepTimerMenu = false
                        Toast.makeText(context, if (minutes > 0) "Sleep timer set for $minutes minutes" else "Timer cancelled", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        if (showPlaylistSelection && activeSong != null) {
            CompositionLocalProvider(LocalBackdrop provides playerBackdrop) {
                PlaylistSelectionBottomSheet(
                    playlists = playlistRepository.allPlaylists.collectAsState(initial = emptyList()).value,
                    isLiquidGlass = isLiquidGlass,
                    onDismiss = { showPlaylistSelection = false },
                    onCreatePlaylist = { name ->
                        scope.launch {
                            val id = playlistRepository.createPlaylist(name)
                            playlistRepository.addSongToPlaylist(id, activeSong)
                            showPlaylistSelection = false
                        }
                    },
                    onPlaylistSelected = { playlist ->
                        scope.launch {
                            playlistRepository.addSongToPlaylist(playlist.id, activeSong)
                            showPlaylistSelection = false
                        }
                    }
                )
            }
        }

        WaveBottomSheetPortalHost(
            portalState = playerSheetPortal,
            defaultBackdrop = playerBackdrop
        )
        }
    }
    }
}
}

@Composable
private fun SongVideoModeSwitcher(
    isVideoEnabled: Boolean,
    isVideoAvailable: Boolean = true,
    accentColor: Color,
    onToggle: (Boolean) -> Unit
) {
    val effectiveVideoEnabled = isVideoEnabled && isVideoAvailable
    Row(
        modifier = Modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (isVideoAvailable) 0.12f else 0.07f))
            .padding(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .clip(CircleShape)
                .background(if (!effectiveVideoEnabled) accentColor else Color.Transparent)
                .clickable(enabled = isVideoAvailable) { onToggle(false) }
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Song",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = if (!effectiveVideoEnabled) Color.Black else Color.White.copy(alpha = 0.85f)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .clip(CircleShape)
                .background(if (effectiveVideoEnabled) accentColor else Color.Transparent)
                .clickable(enabled = isVideoAvailable) {
                    if (isVideoAvailable) onToggle(true)
                }
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            val videoContentAlpha = if (isVideoAvailable) 0.85f else 0.35f
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = WaveIcons.Video,
                    contentDescription = null,
                    tint = if (effectiveVideoEnabled) Color.Black else Color.White.copy(alpha = videoContentAlpha),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = "Video",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (effectiveVideoEnabled) Color.Black else Color.White.copy(alpha = videoContentAlpha)
                )
            }
        }
    }
}

@Composable
private fun SimpExpressiveConnectedGroup(
    containerColor: Color,
    activeContainerColor: Color,
    contentColor: Color,
    activeContentColor: Color,
    isShuffle: Boolean,
    repeatMode: Int,
    isVideoActive: Boolean,
    onDetailsClick: () -> Unit,
    onShuffleClick: () -> Unit,
    onRepeatClick: () -> Unit,
    onLyricsClick: () -> Unit,
    onVideoToggleClick: () -> Unit,
    onQueueClick: () -> Unit
) {
    val outerCap = 28.dp
    val innerCorner = 10.dp

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ExpressiveSlotButton(
            icon = Icons.Default.Info,
            contentDescription = "Details",
            isActive = false,
            shape = RoundedCornerShape(topStart = outerCap, bottomStart = outerCap, topEnd = innerCorner, bottomEnd = innerCorner),
            containerColor = containerColor,
            activeContainerColor = activeContainerColor,
            contentColor = contentColor,
            activeContentColor = activeContentColor,
            modifier = Modifier.weight(1f),
            onClick = onDetailsClick
        )
        ExpressiveSlotButton(
            icon = Icons.Rounded.Shuffle,
            contentDescription = "Shuffle",
            isActive = isShuffle,
            shape = RoundedCornerShape(innerCorner),
            containerColor = containerColor,
            activeContainerColor = activeContainerColor,
            contentColor = contentColor,
            activeContentColor = activeContentColor,
            modifier = Modifier.weight(1f),
            onClick = onShuffleClick
        )
        ExpressiveSlotButton(
            icon = if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
            contentDescription = "Repeat",
            isActive = repeatMode != Player.REPEAT_MODE_OFF,
            shape = RoundedCornerShape(innerCorner),
            containerColor = containerColor,
            activeContainerColor = activeContainerColor,
            contentColor = contentColor,
            activeContentColor = activeContentColor,
            modifier = Modifier.weight(1f),
            onClick = onRepeatClick
        )
        ExpressiveSlotButton(
            icon = WaveIcons.Lyrics,
            contentDescription = "Lyrics",
            isActive = false,
            shape = RoundedCornerShape(innerCorner),
            containerColor = containerColor,
            activeContainerColor = activeContainerColor,
            contentColor = contentColor,
            activeContentColor = activeContentColor,
            modifier = Modifier.weight(1f),
            onClick = onLyricsClick
        )
        ExpressiveSlotButton(
            icon = WaveIcons.Queue,
            contentDescription = "Queue",
            isActive = false,
            shape = RoundedCornerShape(topStart = innerCorner, bottomStart = innerCorner, topEnd = outerCap, bottomEnd = outerCap),
            containerColor = containerColor,
            activeContainerColor = activeContainerColor,
            contentColor = contentColor,
            activeContentColor = activeContentColor,
            modifier = Modifier.weight(1f),
            onClick = onQueueClick
        )
    }
}

@Composable
private fun ExpressiveSlotButton(
    icon: ImageVector,
    contentDescription: String,
    isActive: Boolean,
    shape: RoundedCornerShape,
    containerColor: Color,
    activeContainerColor: Color,
    contentColor: Color,
    activeContentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = shape,
        color = if (isActive) activeContainerColor else containerColor,
        modifier = modifier.fillMaxHeight()
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isActive) activeContentColor else contentColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
private fun ProgressiveArtistBannerCard(
    activeSong: Song?,
    videoDetails: VideoDetails?,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    val artistAvatar = MusicPlayer.artistAvatarUrl
    val bannerUrl = artistAvatar ?: videoDetails?.channelThumbnailUrl ?: activeSong?.thumbnailUrl
    if (bannerUrl.isNullOrEmpty()) return

    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val scrimHeight = screenWidth * 0.7f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(top = 12.dp, bottom = 32.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(backgroundColor)
            .clickable { onClick() }
    ) {
        WaveHazeHeader.VerticalGradient(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            backgroundColor = backgroundColor,
            blurRadius = 32.dp,
            blurHeight = 200.dp,
            gradientHeight = scrimHeight,
            headerImage = {
                GlideImage(
                    model = bannerUrl,
                    contentDescription = "Artist/Channel Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter
                )
            }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 20.dp, vertical = 22.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                val firstArtist = remember(activeSong) {
                    activeSong?.displayArtists?.split(",", "&", "feat.", "ft.", "/")?.firstOrNull()?.trim()
                        ?: activeSong?.artist?.split(",", "&", "feat.", "ft.", "/")?.firstOrNull()?.trim()
                        ?: "Wave Artist"
                }
                val bannerDisplayName = if (!artistAvatar.isNullOrEmpty()) {
                    firstArtist
                } else {
                    videoDetails?.channelName ?: firstArtist
                }

                val rawSubs = videoDetails?.subscriberCountText
                val followerLabel = remember(rawSubs) {
                    if (rawSubs.isNullOrBlank()) {
                        "Tap to view"
                    } else {
                        val numMatch = Regex("([0-9.,]+)\\s*([kKmMbB]?)(?:\\s*subscribers?|\\s*subs?|\\s*followers?)?", RegexOption.IGNORE_CASE).find(rawSubs)
                        if (numMatch != null) {
                            val count = numMatch.groupValues[1]
                            val unit = numMatch.groupValues[2].uppercase()
                            "$count$unit followers"
                        } else if (rawSubs.contains("subscriber", ignoreCase = true)) {
                            rawSubs.replace(Regex("subscribers?", RegexOption.IGNORE_CASE), "followers")
                        } else {
                            "Tap to view"
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = bannerDisplayName,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp
                        ),
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = followerLabel,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White.copy(alpha = 0.82f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/**
 * Landscape Video Preview Overlay (`LandscapePlayerOverlay`):
 * - Removes the round container around the Back icon and places the top header higher (`vertical = 8.dp`).
 * - Supports pinch-to-zoom (`1.0f .. 3.5f`) and pan when zoomed in.
 * - Supports double-tap left/right to seek `-5s` / `+5s` with visual feedback badges.
 * - Uses `AppleLiquidSlider` (white track + oval liquid glass thumb with very low blur and low refraction).
 */
@OptIn(ExperimentalGlideComposeApi::class)
@UnstableApi
@Composable
fun LandscapePlayerOverlay(
    onBack: () -> Unit,
    isLiquidGlass: Boolean,
    isAmbientEnabled: Boolean,
    backdrop: LayerBackdrop? = LocalBackdrop.current,
) {
    val context = LocalContext.current
    val activeSong = MusicPlayer.currentSong
    val isPlaying = MusicPlayer.isPlaying
    val currentPosition = MusicPlayer.currentPosition
    val duration = MusicPlayer.duration
    val videoQuality = MusicPlayer.currentVideoQuality

    val shades = remember(activeSong?.videoId) {
        val seed = activeSong?.videoId?.hashCode() ?: 0
        val safeIndex = ((seed % CuratedBaseColors.size) + CuratedBaseColors.size) % CuratedBaseColors.size
        val baseColor = CuratedBaseColors[safeIndex]
        deriveShades(baseColor)
    }
    val color4 by animateColorAsState(targetValue = shades.color4, animationSpec = tween(2000, easing = LinearOutSlowInEasing), label = "color4")

    var showControls by remember { mutableStateOf(true) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var seekBadgeState by remember { mutableStateOf<Int?>(null) } // -5 or +5
    var seekBadgeTrigger by remember { mutableIntStateOf(0) }

    val performance = LocalPerformanceConfig.current
    val controlsAlpha by animateFloatAsState(
        targetValue = if (showControls) 1f else 0f,
        animationSpec = if (performance.isLowSpec) tween(280) else tween(420),
        label = "ControlsAlpha"
    )

    LaunchedEffect(showControls) {
        if (showControls) {
            delay(4000)
            showControls = false
        }
    }

    LaunchedEffect(seekBadgeTrigger) {
        if (seekBadgeState != null) {
            delay(650)
            seekBadgeState = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { tapOffset ->
                        val width = size.width.toFloat().coerceAtLeast(1f)
                        when {
                            tapOffset.x < width * 0.44f -> {
                                val target = (MusicPlayer.currentPosition - 5000L).coerceAtLeast(0L)
                                MusicPlayer.seekTo(target)
                                seekBadgeState = -5
                                seekBadgeTrigger++
                            }
                            tapOffset.x > width * 0.56f -> {
                                val maxDur = MusicPlayer.duration.coerceAtLeast(0L)
                                val target = if (maxDur > 0L) {
                                    (MusicPlayer.currentPosition + 5000L).coerceAtMost(maxDur)
                                } else {
                                    MusicPlayer.currentPosition + 5000L
                                }
                                MusicPlayer.seekTo(target)
                                seekBadgeState = 5
                                seekBadgeTrigger++
                            }
                            else -> {
                                if (zoomScale > 1.01f) {
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                } else {
                                    zoomScale = 1.75f
                                }
                            }
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (zoomScale * zoom).coerceIn(1f, 3.5f)
                    zoomScale = newScale
                    if (newScale > 1.01f) {
                        val maxX = (size.width * (newScale - 1f)) / 2f
                        val maxY = (size.height * (newScale - 1f)) / 2f
                        panOffset = Offset(
                            x = (panOffset.x + pan.x).coerceIn(-maxX, maxX),
                            y = (panOffset.y + pan.y).coerceIn(-maxY, maxY),
                        )
                    } else {
                        panOffset = Offset.Zero
                    }
                }
            }
    ) {
        if (isAmbientEnabled) {
            AmbientFluidBackground(
                baseColor = shades.color4,
                accentColor = shades.color2
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
        ) {
            WaveVideoPlayerSurface(modifier = Modifier.fillMaxSize())

            if (!MusicPlayer.isVideoActuallyPlaying) {
                GlideImage(
                    model = MusicPlayer.highResThumbnailUrl ?: activeSong?.thumbnailUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
        }

        // Double-tap -5s / +5s visual seek feedback overlay
        AnimatedVisibility(
            visible = seekBadgeState == -5,
            enter = fadeIn(tween(120)) + scaleIn(initialScale = 0.85f, animationSpec = tween(120)),
            exit = fadeOut(tween(180)),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 64.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.62f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Replay5, contentDescription = "-5 seconds", tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("-5s", color = Color.White, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }

        AnimatedVisibility(
            visible = seekBadgeState == 5,
            enter = fadeIn(tween(120)) + scaleIn(initialScale = 0.85f, animationSpec = tween(120)),
            exit = fadeOut(tween(180)),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 64.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.62f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("+5s", color = Color.White, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Rounded.Forward5, contentDescription = "+5 seconds", tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
        }

        if (controlsAlpha > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = controlsAlpha }
                    .background(Color.Black.copy(alpha = 0.42f))
            ) {
                // Top Header placed higher up, with NO round container around the Back icon
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(42.dp),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            activeSong?.title ?: "Unknown Title",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            MusicPlayer.sanitizedArtistName.ifEmpty { activeSong?.artist ?: "Unknown Artist" },
                            color = Color.White.copy(alpha = 0.72f),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (zoomScale > 1.02f) {
                        Surface(
                            onClick = {
                                zoomScale = 1f
                                panOffset = Offset.Zero
                            },
                            color = Color.White.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.padding(start = 10.dp)
                        ) {
                            Text(
                                text = String.format("%.1fx • Reset", zoomScale),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                    if (videoQuality != null) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(start = 12.dp)
                        ) {
                            Text(
                                text = videoQuality,
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    WaveHeartButton(
                        isFavorite = MusicPlayer.isFavorite,
                        onToggle = { MusicPlayer.toggleFavorite(context) },
                        iconSize = 24.dp,
                        buttonSize = 44.dp
                    )
                }

                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(48.dp)
                ) {
                    IconButton(onClick = { MusicPlayer.playPreviousInQueue(context) }, modifier = Modifier.size(64.dp)) {
                        Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(48.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .clickable { MusicPlayer.togglePlayPause(context) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (MusicPlayer.isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(38.dp))
                        } else {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(56.dp)
                            )
                        }
                    }

                    IconButton(onClick = { MusicPlayer.playNextInQueue(context) }, modifier = Modifier.size(64.dp)) {
                        Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(48.dp))
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 44.dp, vertical = 20.dp)
                ) {
                    val sliderPosition = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
                    AppleLiquidSlider(
                        value = sliderPosition,
                        onValueChange = { newValue ->
                            if (duration > 0) {
                                MusicPlayer.seekTo((newValue * duration).toLong())
                            }
                        },
                        isLiquidGlass = isLiquidGlass,
                        backdrop = backdrop,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(currentPosition), color = Color.White, style = MaterialTheme.typography.labelMedium)
                        Text(formatTime(duration), color = Color.White, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistSelectionBottomSheet(
    playlists: List<PlaylistEntity>,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onPlaylistSelected: (PlaylistEntity) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val maxHeight = remember(configuration, density) { (configuration.screenHeightDp * 0.7f).dp }
    val floatingShape = RoundedCornerShape(30.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight)
                    .glassContainer(
                        shape = floatingShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp,
                    )
                    .clip(floatingShape)
                    .padding(top = 14.dp, bottom = 18.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 10.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.32f))
                )

                Text(
                    "Add to playlist",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )

                ListItem(
                    headlineContent = { Text("Create new playlist", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium) },
                    leadingContent = { Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.primary) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable { showCreateDialog = true }
                )

                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(playlists) { playlist ->
                        ListItem(
                            headlineContent = { Text(playlist.name, color = Color.White, style = MaterialTheme.typography.labelMedium) },
                            leadingContent = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null, tint = Color.White) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onPlaylistSelected(playlist) }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = SoftBlack,
            title = { Text("New Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Playlist Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newPlaylistName.isNotBlank()) {
                        onCreatePlaylist(newPlaylistName)
                        showCreateDialog = false
                    }
                }) { Text("Create", color = MaterialTheme.colorScheme.primary) }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerBottomSheet(
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onTimerSelected: (Int) -> Unit
) {
    var showCustomTimerDialog by remember { mutableStateOf(false) }
    var customTimeInput by remember { mutableStateOf("") }
    val floatingShape = RoundedCornerShape(30.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassContainer(
                        shape = floatingShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp,
                    )
                    .clip(floatingShape)
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 10.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.32f))
                )

                Text(
                    "Sleep timer",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                OptionItem(Icons.Default.Timer, "5 minutes") { onTimerSelected(5) }
                OptionItem(Icons.Default.Timer, "10 minutes") { onTimerSelected(10) }
                OptionItem(Icons.Default.Timer, "30 minutes") { onTimerSelected(30) }
                OptionItem(Icons.Default.Timer, "60 minutes") { onTimerSelected(60) }
                OptionItem(Icons.Default.Edit, "Custom time") { showCustomTimerDialog = true }
                OptionItem(Icons.AutoMirrored.Filled.PlaylistPlay, "End of track") { onTimerSelected(-1) }

                if (MusicPlayer.sleepTimerMillis > 0 || MusicPlayer.stopAfterCurrentSong) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 4.dp))
                    OptionItem(Icons.Default.Timer, "Turn off timer", tint = Color.Red) { onTimerSelected(0) }
                }
            }
        }
    }

    if (showCustomTimerDialog) {
        AlertDialog(
            onDismissRequest = { showCustomTimerDialog = false },
            containerColor = SoftBlack,
            title = { Text("Custom Sleep Timer", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = customTimeInput,
                    onValueChange = { if (it.all { char -> char.isDigit() }) customTimeInput = it },
                    label = { Text("Minutes") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    customTimeInput.toIntOrNull()?.let { onTimerSelected(it); showCustomTimerDialog = false; onDismiss() }
                }) { Text("Set", color = MaterialTheme.colorScheme.primary) }
            }
        )
    }
}

/**
 * SimpMusic Floating 3D Liquid Glass `PlayerOptionsBottomSheet`:
 * - **Separate Volume Control Container** floating in the air ABOVE the Options Bottom Sheet (`Spacer(12.dp)` air gap).
 * - **Increased vertical height** and generous row padding on the Options Bottom Sheet.
 * - **Increased blur & reduced brightness** (`deepFrostedSheet = true`, `baseAlpha = 0.90f`, `blurScale = 2.65f`).
 * - **Controlled by Enable Liquid Glass setting** (`isLiquidGlass` -> `QueueSolidGrey` when disabled).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerOptionsBottomSheet(
    song: Song,
    isFavorite: Boolean,
    isDownloaded: Boolean,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit,
    onFavoriteClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onAddToPlaylistClick: () -> Unit,
    onSleepTimerClick: () -> Unit,
    onPlayNextClick: () -> Unit,
    onArtistClick: (String) -> Unit,
    onShareClick: () -> Unit,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    val context = LocalContext.current
    val parsedArtists = remember(song) { song.parseArtists() }
    val volumeContainerShape = RoundedCornerShape(26.dp)
    val floatingSheetShape = RoundedCornerShape(30.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            // 1. Separate Floating Volume Control Container floating in air ABOVE the options bottom sheet
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .glassContainer(
                        shape = volumeContainerShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 1.45f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp,
                    )
                    .clip(volumeContainerShape)
                    .padding(horizontal = 18.dp),
            ) {
                Icon(
                    imageVector = if (MusicPlayer.userVolume <= 0.01f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    contentDescription = "Volume",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                AppleLiquidSlider(
                    value = MusicPlayer.userVolume,
                    onValueChange = { MusicPlayer.userVolume = it },
                    isLiquidGlass = isLiquidGlass,
                    backdrop = null,
                    modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "${(MusicPlayer.userVolume * 100).roundToInt()}%",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.widthIn(min = 38.dp),
                    textAlign = TextAlign.End,
                )
            }

            // Air gap between floating Volume container and floating Options Bottom Sheet
            Spacer(modifier = Modifier.height(12.dp))

            // 2. Main Floating Options Bottom Sheet with increased vertical height, higher blur, and reduced brightness
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassContainer(
                        shape = floatingSheetShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 1.45f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp
                    )
                    .clip(floatingSheetShape)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 12.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.34f))
                )

                // Song Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(66.dp)
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WaveArtworkImage(
                        url = MusicPlayer.getHighResThumbnailUrl(song.thumbnailUrl),
                        videoId = song.videoId,
                        contentDescription = song.title,
                        isVideo = false,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                                .focusable()
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = song.displayArtists.ifEmpty { MusicPlayer.sanitizedArtistName },
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                                .focusable()
                        )
                    }
                    WaveHeartButton(
                        isFavorite = isFavorite,
                        onToggle = onFavoriteClick,
                        iconSize = 24.dp,
                        buttonSize = 42.dp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.12f), modifier = Modifier.padding(vertical = 4.dp))
                Spacer(modifier = Modifier.height(4.dp))

                OptionItem(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, if (isFavorite) "Liked" else "Like", if (isFavorite) accentColor else Color.White) { onFavoriteClick(); onDismiss() }
                OptionItem(Icons.Default.Download, if (isDownloaded) "Downloaded" else "Download", if (isDownloaded) accentColor else Color.White) { onDownloadClick(); onDismiss() }
                OptionItem(Icons.AutoMirrored.Filled.PlaylistAdd, "Add to playlist") { onAddToPlaylistClick() }
                OptionItem(Icons.Rounded.GraphicEq, "Equalizer (Built-in AudioFX)") {
                    onDismiss()
                    MusicPlayer.openEqualizer(context)
                }
                OptionItem(Icons.Default.Timer, "Sleep timer") { onSleepTimerClick() }
                OptionItem(Icons.AutoMirrored.Filled.QueueMusic, "Play next") { onPlayNextClick(); onDismiss() }
                OptionItem(
                    icon = WaveIcons.Artist,
                    title = if (parsedArtists.size > 1) "Artists (${parsedArtists.size})" else "View Artist"
                ) {
                    onArtistClick(song.artistId ?: MusicPlayer.sanitizedArtistName)
                }
                OptionItem(Icons.Default.Share, "Share") { onShareClick(); onDismiss() }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun OptionItem(icon: ImageVector, title: String, tint: Color = Color.White, onClick: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            title,
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            ),
        )
    }
}

/**
 * SimpMusic Tonal Lyrics Preview Card:
 * - Positioned lower so only a small part of its top header peeks into view when scrolled to the top.
 * - Uses extra bold (`FontWeight.Black` / `FontWeight(900)`) words and letters, larger line spacing (`26.dp`),
 *   and SimpMusic's word-by-word immersive glow (`Shadow` blur).
 */
@Composable
fun LyricsPreviewBox(
    lyrics: String,
    provider: String,
    currentPosition: Long,
    backgroundColor: Color,
    isAppleMusicBlur: Boolean = true,
    onShowClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lines = remember(lyrics) {
        lyrics.split("\n").mapNotNull { line ->
            val match = Regex("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})](.*)").find(line)
            if (match != null) {
                val min = match.groupValues[1].toLong()
                val sec = match.groupValues[2].toLong()
                val msStr = match.groupValues[3]
                val ms = msStr.toLong() * (if (msStr.length == 2) 10 else 1)
                (min * 60000 + sec * 1000 + ms) to match.groupValues[4].trim()
            } else if (line.trim().isNotEmpty() && !line.startsWith("[")) 0L to line.trim() else null
        }
    }

    val isWordSynced = remember(lyrics) {
        RICH_WORD_TAG_REGEX.containsMatchIn(lyrics)
    }
    val isLineSynced = remember(lyrics) {
        lyrics.contains(Regex("\\[\\d{2}:\\d{2}\\.\\d{2,3}]"))
    }
    val syncStatusLabel = remember(isWordSynced, isLineSynced, provider) {
        val syncType = when {
            isWordSynced -> "WORD SYNCED"
            isLineSynced -> "LINE SYNCED"
            else -> "UNSYNCED"
        }
        if (provider.isNotBlank()) "$syncType • $provider" else syncType
    }

    val activeLineIndex = if (isLineSynced) lines.indexOfLast { it.first <= currentPosition }.coerceAtLeast(0) else 0
    val lazyListState = rememberLazyListState()

    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex in lines.indices) {
            lazyListState.animateScrollToItem(activeLineIndex, -70)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(380.dp)
            .padding(horizontal = 24.dp)
            .padding(top = 4.dp, bottom = 12.dp)
            .clip(RoundedCornerShape(28.dp))
            .clickable { onShowClick() },
        shape = RoundedCornerShape(28.dp),
        color = backgroundColor.copy(alpha = 0.94f),
        border = BorderStroke(1.15.dp, Color.White.copy(alpha = 0.18f))
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().align(Alignment.TopStart),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(WaveIcons.Lyrics, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Lyrics",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.14f),
                    modifier = Modifier.clickable { onShowClick() }
                ) {
                    Text(
                        text = "FULLSCREEN",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            if (lines.isEmpty() || lyrics.contains("Lyrics not available")) {
                Text(
                    "No lyrics available to preview",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.50f),
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 48.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(26.dp),
                    userScrollEnabled = false
                ) {
                    itemsIndexed(lines) { index, (lineStartMs, text) ->
                        val isActive = index == activeLineIndex
                        val distance = abs(index - activeLineIndex)
                        val blurDp = if (isAppleMusicBlur && !isActive) {
                            (distance * 1.6f).coerceAtMost(6.5f).dp
                        } else 0.dp
                        val alpha = if (isActive) 1f else (0.50f - distance * 0.08f).coerceIn(0.22f, 0.46f)
                        val nextLineStartMs = lines.getOrNull(index + 1)?.first ?: (lineStartMs + 4200L)

                        SimpWordSyncedLyricLine(
                            rawLineText = text,
                            currentPositionMs = currentPosition,
                            isActiveLine = isActive,
                            isPastLine = isLineSynced && index < activeLineIndex,
                            inactiveAlpha = alpha,
                            fontSize = if (isActive) 24.sp else 21.sp,
                            lineHeight = 34.sp,
                            lineStartMs = lineStartMs,
                            lineEndMs = nextLineStartMs,
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (blurDp > 0.dp) {
                                        Modifier.blur(radius = blurDp, edgeTreatment = BlurredEdgeTreatment.Unbounded)
                                    } else Modifier
                                )
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomEnd),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = syncStatusLabel,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

/**
 * SimpMusic Fullscreen Lyrics Overlay:
 * - Features SimpMusic's word-by-word immersive glow (`Shadow` blur), much larger vertical spacing
 *   between lyric lines (`padding(vertical = 22.dp)` + `spacedBy(8.dp)`), and heavy `FontWeight.Black` letters.
 */
@Composable
fun LyricsOverlay(
    lyrics: String,
    provider: String,
    currentPosition: Long,
    backgroundColor: Color,
    isLiquidGlass: Boolean,
    lyricsStyle: String = "Apple Music (Blur)",
    onLyricsStyleChange: (String) -> Unit = {},
    onSeekToMs: (Long) -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }
    val offsetMs = settingsManager.lyricsOffsetMs.toLong()

    val isAppleMusicBlur = !lyricsStyle.contains("Classic", ignoreCase = true)

    val lines = remember(lyrics) {
        lyrics.split("\n").mapNotNull { line ->
            val match = Regex("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})](.*)").find(line)
            if (match != null) {
                val min = match.groupValues[1].toLong()
                val sec = match.groupValues[2].toLong()
                val msStr = match.groupValues[3]
                val ms = msStr.toLong() * (if (msStr.length == 2) 10 else 1)
                (min * 60000 + sec * 1000 + ms) to match.groupValues[4].trim()
            } else if (line.trim().isNotEmpty() && !line.startsWith("[")) 0L to line.trim() else null
        }.filter { it.second.isNotBlank() }
    }
    val isWordSynced = remember(lyrics) {
        RICH_WORD_TAG_REGEX.containsMatchIn(lyrics)
    }
    val isSynced = remember(lyrics) {
        lyrics.contains(Regex("\\[\\d{2}:\\d{2}\\.\\d{2,3}]"))
    }
    val syncLabel = when {
        isWordSynced -> "Word Synced"
        isSynced -> "Line Synced"
        else -> "Unsynced"
    }

    val adjustedPosition = (currentPosition - offsetMs).coerceAtLeast(0L)
    val activeLineIndex = if (isSynced) lines.indexOfLast { it.first <= adjustedPosition }.coerceAtLeast(0) else -1
    val lazyListState = rememberLazyListState()

    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex != -1 && activeLineIndex in lines.indices) {
            lazyListState.animateScrollToItem(activeLineIndex, -220)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = backgroundColor.copy(alpha = 0.99f)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Lyrics",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                        color = Color.White
                    )
                    Text(
                        text = if (provider.isNotEmpty()) "$syncLabel • $provider" else syncLabel,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White.copy(alpha = 0.72f)
                    )
                }

                GlassIconButton(
                    icon = Icons.Rounded.KeyboardArrowDown,
                    onClick = onDismiss,
                    isLiquidGlass = isLiquidGlass,
                    containerSize = 44.dp,
                    iconSize = 28.dp
                )
            }

            LazyColumn(
                state = lazyListState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 28.dp, bottom = 150.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (lines.isEmpty()) {
                    item {
                        Text(
                            text = lyrics,
                            color = Color.White.copy(alpha = 0.94f),
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 27.sp,
                                lineHeight = 40.sp,
                            ),
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp)
                        )
                    }
                } else {
                    itemsIndexed(
                        items = lines,
                        key = { idx, pair -> "${pair.first}_$idx" }
                    ) { index, (timestampMs, text) ->
                        val isActive = if (isSynced) index == activeLineIndex else true
                        val distance = if (isSynced && activeLineIndex >= 0) abs(index - activeLineIndex) else 0
                        val nextTimestampMs = lines.getOrNull(index + 1)?.first ?: (timestampMs + 4200L)

                        val targetBlurDp = if (isAppleMusicBlur && isSynced && !isActive) {
                            (distance * 2.5f).coerceAtMost(10.5f).dp
                        } else {
                            0.dp
                        }
                        val animatedBlurDp by animateDpAsState(
                            targetValue = targetBlurDp,
                            animationSpec = spring(dampingRatio = 0.75f, stiffness = 300f),
                            label = "lyricBlur"
                        )
                        val targetScale = if (isActive && isSynced) 1.03f else 0.96f
                        val animatedScale by animateFloatAsState(
                            targetValue = targetScale,
                            animationSpec = spring(dampingRatio = 0.7f, stiffness = 320f),
                            label = "lyricScale"
                        )
                        val targetAlpha = when {
                            !isSynced -> 0.94f
                            isActive -> 1.0f
                            isAppleMusicBlur -> (0.50f - distance * 0.06f).coerceIn(0.18f, 0.46f)
                            else -> 0.44f
                        }
                        val animatedAlpha by animateFloatAsState(
                            targetValue = targetAlpha,
                            animationSpec = tween(250),
                            label = "lyricAlpha"
                        )

                        SimpWordSyncedLyricLine(
                            rawLineText = text,
                            currentPositionMs = adjustedPosition,
                            isActiveLine = isActive && isSynced,
                            isPastLine = isSynced && index < activeLineIndex,
                            inactiveAlpha = animatedAlpha,
                            fontSize = if (isAppleMusicBlur) 31.sp else 27.sp,
                            lineHeight = if (isAppleMusicBlur) 43.sp else 38.sp,
                            lineStartMs = timestampMs,
                            lineEndMs = nextTimestampMs,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = isSynced) {
                                    onSeekToMs((timestampMs + offsetMs).coerceAtLeast(0L))
                                }
                                .padding(vertical = 22.dp, horizontal = 24.dp)
                                .graphicsLayer {
                                    scaleX = animatedScale
                                    scaleY = animatedScale
                                    transformOrigin = TransformOrigin(0f, 0.5f)
                                }
                                .then(
                                    if (animatedBlurDp > 0.1.dp) {
                                        Modifier.blur(
                                            radius = animatedBlurDp,
                                            edgeTreatment = BlurredEdgeTreatment.Unbounded
                                        )
                                    } else Modifier
                                )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Floating 3D Liquid Glass Video & Track Details Menu (`DetailsBottomSheet`):
 * - Uses `deepFrostedSheet = true` (increased blur & reduced brightness) and respects `isLiquidGlass`.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalGlideComposeApi::class)
@Composable
fun DetailsBottomSheet(
    details: VideoDetails?,
    isLoading: Boolean,
    isLiquidGlass: Boolean,
    onDismiss: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val maxHeight = remember(configuration, density) { (configuration.screenHeightDp * 0.78f).dp }
    val artistAvatar = MusicPlayer.artistAvatarUrl
    val activeSong = MusicPlayer.currentSong
    val floatingShape = RoundedCornerShape(30.dp)

    WaveGlassBottomSheet(
        onDismissRequest = onDismiss
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight)
                    .glassContainer(
                        shape = floatingShape,
                        isLiquidGlass = isLiquidGlass,
                        baseAlpha = 0.90f,
                        blurScale = 2.65f,
                        deepFrostedSheet = true,
                        borderWidth = 1.25.dp
                    )
                    .clip(floatingShape)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .padding(bottom = 12.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.34f))
                )

                Text(
                    text = "Video & Track Details",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 18.dp)
                )

                if (isLoading) {
                    Box(modifier = Modifier.padding(vertical = 32.dp)) {
                        ExpressiveLoader(size = 44.dp)
                    }
                } else {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        WaveArtworkImage(
                            url = artistAvatar ?: details?.channelThumbnailUrl ?: activeSong?.thumbnailUrl,
                            videoId = activeSong?.videoId,
                            contentDescription = null,
                            isVideo = false,
                            shape = CircleShape,
                            modifier = Modifier.size(92.dp)
                        )

                        val source = MusicPlayer.artistAvatarSource
                        if (!source.isNullOrEmpty()) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier
                                    .size(26.dp)
                                    .offset(x = 4.dp, y = 4.dp),
                                shadowElevation = 4.dp
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (source == "Spotify") {
                                        Icon(
                                            painter = painterResource(id = android.R.drawable.ic_menu_info_details),
                                            contentDescription = "via Spotify",
                                            tint = Color(0xFF1DB954),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    } else {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = "via YouTube",
                                            tint = Color.Red,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (!artistAvatar.isNullOrEmpty()) {
                            MusicPlayer.sanitizedArtistName
                        } else {
                            details?.channelName ?: MusicPlayer.sanitizedArtistName
                        },
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Center
                    )
                    if (details?.subscriberCountText != null) {
                        Text(
                            text = details.subscriberCountText,
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(18.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Stream & Video Metadata",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        DetailMetaRow("Track Title", activeSong?.title ?: "Unknown")
                        DetailMetaRow("Video ID", activeSong?.videoId ?: "N/A")
                        DetailMetaRow("Video Stream", if (MusicPlayer.isVideoAvailable) "Available (${MusicPlayer.currentVideoQuality ?: "HD"})" else "Audio Only")
                        DetailMetaRow("Extraction Engine", MusicPlayer.currentServer)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (details != null && details.description.isNotBlank()) {
                        val cleanDesc = details.description.lines().filterNot { line ->
                            val l = line.trim().lowercase()
                            l.startsWith("provided to youtube by") ||
                            l.startsWith("auto-generated by youtube") ||
                            l.startsWith("released on:")
                        }.joinToString("\n").trim()

                        if (cleanDesc.isNotBlank()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "Description",
                                    color = MaterialTheme.colorScheme.primary,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    textAlign = TextAlign.End,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp)
                                )
                                Text(
                                    text = cleanDesc,
                                    color = Color.White.copy(alpha = 0.88f),
                                    style = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailMetaRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.65f)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ActionIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.82f), modifier = Modifier.size(22.dp))
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.65f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}

private data class SyncedWordToken(
    val text: String,
    val startMs: Long,
    val endMs: Long,
)

private val RICH_WORD_TAG_REGEX = Regex("<(\\d{2}):(\\d{2})\\.(\\d{2,3})>([^<]+)")

private fun parseRichLyricWords(
    rawLine: String,
    lineStartMs: Long = 0L,
    lineEndMs: Long = 0L,
): List<SyncedWordToken> {
    val matches = RICH_WORD_TAG_REGEX.findAll(rawLine).toList()
    if (matches.isNotEmpty()) {
        val parsed = matches.mapNotNull { m ->
            val min = m.groupValues[1].toLongOrNull() ?: 0L
            val sec = m.groupValues[2].toLongOrNull() ?: 0L
            val fracStr = m.groupValues[3]
            val fracMs = if (fracStr.length == 2) (fracStr.toLongOrNull() ?: 0L) * 10L else (fracStr.toLongOrNull() ?: 0L)
            val wordText = m.groupValues[4].trim()
            if (wordText.isEmpty()) null else (wordText to (min * 60_000L + sec * 1_000L + fracMs))
        }
        return parsed.mapIndexed { idx, (w, sMs) ->
            val eMs = parsed.getOrNull(idx + 1)?.second ?: maxOf(sMs + 420L, lineEndMs)
            SyncedWordToken(text = w, startMs = sMs, endMs = eMs)
        }
    }

    // Even when a lyric line only has line-level `[mm:ss.xx]` timestamps, synthesize smooth
    // character-weighted word timings across `[lineStartMs .. lineEndMs]` so word-by-word
    // immersive glow works on every synced song!
    val cleanLine = rawLine.replace(Regex("<\\d{2}:\\d{2}\\.\\d{2,3}>"), "").trim()
    if (cleanLine.isEmpty() || lineEndMs <= lineStartMs) return emptyList()
    val words = cleanLine.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (words.isEmpty()) return emptyList()

    val effectiveDuration = (lineEndMs - lineStartMs).coerceIn(800L, 6500L)
    val totalWeight = words.sumOf { it.length.coerceAtLeast(2) }.toFloat().coerceAtLeast(1f)
    var cursorMs = lineStartMs
    return words.mapIndexed { idx, word ->
        val weight = word.length.coerceAtLeast(2).toFloat() / totalWeight
        val wordDur = (effectiveDuration * weight).toLong().coerceAtLeast(110L)
        val start = cursorMs
        val end = if (idx == words.lastIndex) (lineStartMs + effectiveDuration) else (start + wordDur)
        cursorMs = end
        SyncedWordToken(text = word, startMs = start, endMs = end)
    }
}

/**
 * SimpMusic Word-by-Word Synced Lyric Line Renderer with Heavy Bold Typography (`FontWeight.Black`)
 * and Immersive Word-by-Word Glow (`Shadow` blur):
 * - Highlights each sung word in real time with a soft white radial `Shadow` glow.
 * - Uses thick `FontWeight.Black` (`900`) and `FontWeight.ExtraBold` (`800`) letters.
 */
@Composable
fun SimpWordSyncedLyricLine(
    rawLineText: String,
    currentPositionMs: Long,
    isActiveLine: Boolean,
    isPastLine: Boolean,
    inactiveAlpha: Float,
    fontSize: androidx.compose.ui.unit.TextUnit,
    lineHeight: androidx.compose.ui.unit.TextUnit,
    lineStartMs: Long = 0L,
    lineEndMs: Long = 0L,
    maxLines: Int = Int.MAX_VALUE,
    modifier: Modifier = Modifier,
) {
    val wordTokens = remember(rawLineText, lineStartMs, lineEndMs) {
        parseRichLyricWords(rawLineText, lineStartMs, lineEndMs)
    }
    val cleanPlainLine = remember(rawLineText, wordTokens) {
        if (wordTokens.isNotEmpty()) {
            wordTokens.joinToString(" ") { it.text }
        } else {
            rawLineText.replace(Regex("<\\d{2}:\\d{2}\\.\\d{2,3}>"), "").trim()
        }
    }

    if (!isActiveLine || wordTokens.isEmpty()) {
        Text(
            text = cleanPlainLine,
            color = Color.White.copy(alpha = if (isActiveLine) 1f else inactiveAlpha),
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = if (isActiveLine) FontWeight.Black else FontWeight.ExtraBold,
                fontSize = fontSize,
                lineHeight = lineHeight,
                letterSpacing = (-0.2).sp,
                shadow = if (isActiveLine) {
                    Shadow(
                        color = Color.White.copy(alpha = 0.55f),
                        offset = Offset.Zero,
                        blurRadius = 20f,
                    )
                } else null,
            ),
            maxLines = maxLines,
            overflow = if (maxLines == 1) TextOverflow.Ellipsis else TextOverflow.Clip,
            softWrap = maxLines > 1,
            modifier = modifier,
        )
    } else {
        val annotated = buildAnnotatedString {
            wordTokens.forEachIndexed { idx, token ->
                val wordDuration = (token.endMs - token.startMs).coerceAtLeast(110L)
                val progress = ((currentPositionMs - token.startMs).toFloat() / wordDuration.toFloat()).coerceIn(0f, 1f)
                val isCurrentlySingingWord = currentPositionMs in token.startMs..token.endMs
                val isWordSung = currentPositionMs >= token.endMs

                val wordAlpha = when {
                    isWordSung -> 1.0f
                    isCurrentlySingingWord -> 0.62f + (0.38f * progress)
                    else -> 0.36f
                }

                // SimpMusic immersive word-by-word glow on active & sung words
                val glowAlpha = when {
                    isCurrentlySingingWord -> 0.45f + (0.45f * progress)
                    isWordSung -> 0.52f
                    else -> 0f
                }
                val glowRadius = when {
                    isCurrentlySingingWord -> 26f
                    isWordSung -> 16f
                    else -> 0f
                }

                withStyle(
                    SpanStyle(
                        color = Color.White.copy(alpha = wordAlpha),
                        fontWeight = FontWeight.Black,
                        shadow = if (glowAlpha > 0f) {
                            Shadow(
                                color = Color.White.copy(alpha = glowAlpha),
                                offset = Offset.Zero,
                                blurRadius = glowRadius,
                            )
                        } else null,
                    )
                ) {
                    append(token.text)
                }
                if (idx < wordTokens.lastIndex) {
                    append(" ")
                }
            }
        }
        Text(
            text = annotated,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                fontSize = fontSize,
                lineHeight = lineHeight,
                letterSpacing = (-0.2).sp,
            ),
            maxLines = maxLines,
            overflow = if (maxLines == 1) TextOverflow.Ellipsis else TextOverflow.Clip,
            softWrap = maxLines > 1,
            modifier = modifier,
        )
    }
}

@Composable
fun PlayerCollapsingTopBar(
    activeSong: Song?,
    currentPosition: Long,
    duration: Long,
    isPlaying: Boolean,
    hazeState: HazeState,
    onBack: () -> Unit,
    onPlayPause: () -> Unit,
    onMore: () -> Unit,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    val progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    Row(
        modifier = modifier
            .fillMaxWidth()
            .hazeBlur(
                input = HazeInput.Sources(hazeState),
                style = barBlurStyle(tint = Color(0xFF0C0C14), tintAlpha = 0.85f, blurRadius = 28.dp),
            )
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(38.dp)) {
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowDown,
                contentDescription = "Close",
                tint = Color.White,
                modifier = Modifier.size(26.dp),
            )
        }

        // Now Playing Mini Card with non-interactive progress bar
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = activeSong?.title ?: "Wave Muzix",
                color = Color.White,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
                textAlign = TextAlign.Center,
            )
            Text(
                text = activeSong?.displayArtists ?: "",
                color = Color.White.copy(alpha = 0.82f),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            // Non-interactive progress slider bar
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .height(2.5.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.20f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(accentColor)
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPlayPause, modifier = Modifier.size(38.dp)) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp),
                )
            }
            IconButton(onClick = onMore, modifier = Modifier.size(38.dp)) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "Options",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}
