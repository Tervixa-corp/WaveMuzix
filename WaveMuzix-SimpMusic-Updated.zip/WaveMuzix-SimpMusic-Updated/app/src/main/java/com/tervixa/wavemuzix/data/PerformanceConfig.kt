package com.tervixa.wavemuzix.data

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf

@Immutable
data class PerformanceConfig(
    val isLowSpec: Boolean = false,
    val useGraphicsLayerForSize: Boolean = false,
    val useCompositingStrategyOffscreen: Boolean = false,
    val springDampingRatio: Float = 0.65f,
    val springStiffness: Float = 700f,
    val isLiquidGlassEnabled: Boolean = true,
    val surfaceAlpha: Float = 0.08f,
    val maxVisualizerComplexity: Int = 80,
    val maxScrollVelocity: Float = 5200f,
)

val LocalPerformanceConfig = staticCompositionLocalOf { PerformanceConfig() }
