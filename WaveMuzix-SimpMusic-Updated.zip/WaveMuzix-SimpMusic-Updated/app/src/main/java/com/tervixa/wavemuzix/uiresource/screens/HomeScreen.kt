package com.tervixa.wavemuzix.uiresource.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.tervixa.wavemuzix.data.AppNotification
import com.tervixa.wavemuzix.data.AppNotificationManager
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.NotificationType
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.repository.HomeShelf
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import com.tervixa.wavemuzix.ui.theme.TextSecondary
import com.tervixa.wavemuzix.uiresource.components.AmbientThemeGlow
import com.tervixa.wavemuzix.uiresource.components.HomeLoadingSplash
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveFilterChip
import com.tervixa.wavemuzix.uiresource.components.WaveIcons
import com.tervixa.wavemuzix.uiresource.components.WaveStateContainer
import com.tervixa.wavemuzix.uiresource.components.WaveThumbnailPrefetcher
import com.tervixa.wavemuzix.uiresource.components.WaveUserAvatar
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.tervixa.wavemuzix.uiresource.components.isScrollingUp
import com.tervixa.wavemuzix.utils.HorizontalCarouselNestedScrollConnection
import com.tervixa.wavemuzix.utils.LocationHelper
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import com.tervixa.wavemuzix.utils.rememberSnapRowFlingBehavior
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: UnifiedMusicRepository,
    onNotifyClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onPlaylistClick: (String) -> Unit,
    onArtistClick: (String) -> Unit,
    onSongClick: (Song) -> Unit,
    onLoginClick: () -> Unit,
    onManageAccountClick: () -> Unit,
    isLiquidGlass: Boolean,
    viewModel: MainViewModel? = null,
    onScrolling: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }
    val cookieManager = remember { CookieManager(context) }
    val auth = remember { Firebase.auth }
    var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }
    val scope = rememberCoroutineScope()

    val vmLoadingHomeState = viewModel?.isLoadingHome?.collectAsState()
    val isLoadingHome = vmLoadingHomeState?.value ?: false
    var isError by remember { mutableStateOf(false) }

    val vmRefreshingState = viewModel?.isRefreshing?.collectAsState()
    val isRefreshing = vmRefreshingState?.value ?: false

    val pullToRefreshState = rememberPullToRefreshState()
    val listState = rememberLazyListState()
    val performance = LocalPerformanceConfig.current

    val shelves = viewModel?.shelves ?: remember { mutableStateListOf<HomeShelf>() }
    val quickPicks = viewModel?.quickPicks ?: remember { mutableStateListOf<Song>() }
    val trending = viewModel?.trending ?: remember { mutableStateListOf<Song>() }
    val albums = viewModel?.albums ?: remember { mutableStateListOf<Map<String, String>>() }
    val continuationToken = viewModel?.continuationToken
    val isLoadingMore = viewModel?.isLoadingMore ?: false

    var userName by remember { mutableStateOf<String?>(viewModel?.userName) }
    var userAvatarUrl by remember { mutableStateOf<String?>(viewModel?.userAvatarUrl) }
    var userLocation by remember { mutableStateOf<String?>(settingsManager.userLocation) }

    val homeData by (viewModel?.homeData ?: MutableStateFlow(null)).collectAsState()

    LaunchedEffect(homeData, quickPicks.size, trending.size) {
        homeData?.let { response ->
            userName = auth.currentUser?.displayName ?: response.userName
            userAvatarUrl = auth.currentUser?.photoUrl?.toString() ?: response.userAvatarUrl

            if (viewModel?.userName == null) viewModel?.userName = userName
            if (viewModel?.userAvatarUrl == null) viewModel?.userAvatarUrl = userAvatarUrl
        }
        val urlsToPrefetch = buildList {
            quickPicks.take(16).forEach { add(it.thumbnailUrl) }
            trending.take(12).forEach { add(it.thumbnailUrl) }
            albums.take(10).forEach { add(it["thumbnail"]) }
        }
        if (urlsToPrefetch.isNotEmpty()) {
            WaveThumbnailPrefetcher.prefetchThumbnails(context, urlsToPrefetch)
        }
    }

    var selectedSongForOptions by remember { mutableStateOf<Song?>(null) }
    var showPlaylistDialogFor by remember { mutableStateOf<Song?>(null) }
    var showLoginPrompt by remember { mutableStateOf(false) }
    var showUpdateDialog by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<Map<String, Any>?>(null) }

    val favoriteRepository = remember { com.tervixa.wavemuzix.repository.FavoriteRepository(com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context).songDao(), context) }
    val playlistRepository = remember { com.tervixa.wavemuzix.repository.PlaylistRepository(com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context).playlistDao(), context) }

    val downloadedSongs by com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context).songDao().getAllDownloads().collectAsState(initial = emptyList())
    val likedSongs by com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context).songDao().getAllFavorites().collectAsState(initial = emptyList())
    val allPlaylists by playlistRepository.allPlaylists.collectAsState(initial = emptyList())

    val refreshData: () -> Unit = {
        isError = false
        if (viewModel != null) {
            viewModel.refreshFeed(context, repository)
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.entries.all { it.value }
        if (granted) {
            scope.launch {
                val countryCode = LocationHelper.getCountryCode(context)
                val region = LocationHelper.getRegionName(context)
                val loc = region ?: countryCode
                userLocation = loc
                settingsManager.userLocation = loc
                viewModel?.setUserLocation(context, loc)
                if (shelves.isEmpty()) {
                    refreshData()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            scope.launch {
                val countryCode = LocationHelper.getCountryCode(context)
                val region = LocationHelper.getRegionName(context)
                val loc = region ?: countryCode
                if (loc != null) {
                    userLocation = loc
                    settingsManager.userLocation = loc
                    viewModel?.setUserLocation(context, loc)
                }
            }
        } else if (userLocation == null) {
            locationPermissionLauncher.launch(permissions)
        }
    }

    LaunchedEffect(Unit) {
        auth.addAuthStateListener { firebaseAuth ->
            isLoggedIn = firebaseAuth.currentUser != null
        }
    }

    LaunchedEffect(isLoggedIn) {
        if (viewModel?.homeData?.value == null) {
            refreshData()
        }
    }

    LaunchedEffect(Unit) {
        if (!isLoggedIn && settingsManager.shouldShowLoginPrompt) {
            showLoginPrompt = true
        }
    }

    val endOfListReached by remember {
        derivedStateOf {
            val lastVisibleItem = listState.layoutInfo.visibleItemsInfo.lastOrNull()
            lastVisibleItem?.index != null && lastVisibleItem.index >= listState.layoutInfo.totalItemsCount - 3
        }
    }

    LaunchedEffect(endOfListReached) {
        if (endOfListReached && continuationToken != null && !isLoadingMore && !isRefreshing) {
            viewModel?.loadMore(context, repository)
        }
    }

    if (showPlaylistDialogFor != null) {
        com.tervixa.wavemuzix.uiresource.components.AddToPlaylistDialog(
            song = showPlaylistDialogFor!!,
            playlists = allPlaylists,
            onDismiss = { showPlaylistDialogFor = null },
            onPlaylistSelected = { playlist ->
                scope.launch {
                    playlistRepository.addSongToPlaylist(playlist.id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
            onCreatePlaylist = { name ->
                scope.launch {
                    val id = playlistRepository.createPlaylist(name)
                    playlistRepository.addSongToPlaylist(id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Created and added to $name", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            }
        )
    }

    if (showLoginPrompt) {
        com.tervixa.wavemuzix.uiresource.components.LoginPromptDialog(
            onDismiss = { showLoginPrompt = false },
            onLoginClick = { onLoginClick() },
            onDontShowAgain = { settingsManager.shouldShowLoginPrompt = !it },
            isLiquidGlass = isLiquidGlass
        )
    }

    LaunchedEffect(AppNotificationManager.triggerUpdateDialog) {
        if (AppNotificationManager.triggerUpdateDialog) {
            showUpdateDialog = true
            AppNotificationManager.triggerUpdateDialog = false
        }
    }

    if (showUpdateDialog && updateInfo != null) {
        com.tervixa.wavemuzix.uiresource.components.UpdateDialog(
            newVersionName = updateInfo!!["versionName"] as String,
            updateNotes = updateInfo!!["notes"] as String,
            onDismiss = { showUpdateDialog = false },
            onUpdateClick = {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(updateInfo!!["url"] as String))
                context.startActivity(intent)
                showUpdateDialog = false
            },
            onIgnoreClick = {
                AppNotificationManager.addNotification(
                    AppNotification(
                        id = "update_${updateInfo!!["versionCode"]}",
                        title = "New update available",
                        description = "Version ${updateInfo!!["versionName"]} is ready to install",
                        type = NotificationType.UPDATE
                    )
                )
                showUpdateDialog = false
            },
            isLiquidGlass = isLiquidGlass
        )
    }

    if (selectedSongForOptions != null) {
        val song = selectedSongForOptions!!
        val isDownloaded = downloadedSongs.any { it.videoId == song.videoId }
        val isFavorite = likedSongs.any { it.videoId == song.videoId }
        val cookies = cookieManager.getCookies()

        com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet(
            song = song,
            isFavorite = isFavorite,
            isDownloaded = isDownloaded,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { selectedSongForOptions = null },
            onFavoriteClick = {
                scope.launch { favoriteRepository.toggleFavorite(song) }
            },
            onDownloadClick = {
                scope.launch {
                    if (isDownloaded) {
                        com.tervixa.wavemuzix.data.database.AppDatabase.getDatabase(context).songDao().deleteDownload(song.videoId)
                        downloadedSongs.find { it.videoId == song.videoId }?.filePath?.let { java.io.File(it).delete() }
                        Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                    } else {
                        val result = repository.getStreamingUrl(
                            videoId = song.videoId,
                            cookies = cookies
                        )
                        if (result != null) {
                            DownloadManager.updateProgress(song.videoId, song.title, 0)
                            val request = androidx.work.OneTimeWorkRequestBuilder<com.tervixa.wavemuzix.data.DownloadWorker>()
                                .setInputData(androidx.work.workDataOf(
                                    "url" to result.url,
                                    "videoId" to song.videoId,
                                    "title" to song.title,
                                    "artist" to song.artist,
                                    "thumbnailUrl" to song.thumbnailUrl,
                                    "artistId" to song.artistId,
                                    "userAgent" to result.userAgent,
                                    "cookies" to cookies
                                ))
                                .build()
                            androidx.work.WorkManager.getInstance(context).enqueue(request)
                            Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            },
            onPlayNextClick = { MusicPlayer.playNext(song) },
            onAddToQueueClick = { MusicPlayer.addToQueue(song) },
            onArtistClick = { onArtistClick(it); selectedSongForOptions = null },
            onAddToPlaylistClick = { showPlaylistDialogFor = song; selectedSongForOptions = null },
            onShareClick = {
                val sendIntent = android.content.Intent().apply {
                    action = android.content.Intent.ACTION_SEND
                    putExtra(android.content.Intent.EXTRA_TEXT, "Listen to ${song.title} by ${song.artist} on WaveMuzix: https://www.youtube.com/watch?v=${song.videoId}")
                    type = "text/plain"
                }
                context.startActivity(android.content.Intent.createChooser(sendIntent, null))
            }
        )
    }

    val homeHazeState = remember { HazeState() }
    val density = LocalDensity.current
    val statusBarTopDp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val isScrollingUp by listState.isScrollingUp()
    val atTop by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 16
        }
    }
    var expandedTopBarHeightDp by remember(statusBarTopDp) {
        mutableStateOf(statusBarTopDp + 138.dp)
    }

    var selectedChip by remember { mutableStateOf("All") }

    LaunchedEffect(atTop, isScrollingUp) {
        onScrolling(atTop || isScrollingUp)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val onProfileClick = {
            if (isLoggedIn) onManageAccountClick() else onLoginClick()
        }

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { refreshData() },
            state = pullToRefreshState,
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = homeHazeState)
                .background(MaterialTheme.colorScheme.background),
            indicator = {
                PullToRefreshDefaults.Indicator(
                    state = pullToRefreshState,
                    isRefreshing = isRefreshing,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = expandedTopBarHeightDp),
                    color = MaterialTheme.colorScheme.primary,
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            }
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AmbientThemeGlow(
                    tint = MusicPlayer.accentColors.firstOrNull() ?: MaterialTheme.colorScheme.primary,
                    scrollState = listState,
                    showTopRightGlow = true
                )

                WaveStateContainer(
                    isLoading = isLoadingHome && shelves.isEmpty(),
                    isRefreshing = isRefreshing && shelves.isNotEmpty(),
                    showRefreshingIndicator = false,
                    isError = isError || MusicPlayer.isPlaybackError,
                    errorMessage = if (MusicPlayer.isPlaybackError) MusicPlayer.playbackErrorMessage else "Check Your Internet Connection",
                    onRetry = {
                        if (MusicPlayer.isPlaybackError) {
                            MusicPlayer.currentSong?.let { MusicPlayer.playSong(context, it) }
                        } else {
                            refreshData()
                        }
                    },
                    loadingContent = {
                        HomeLoadingSplash()
                    }
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        state = listState,
                        flingBehavior = rememberSmoothFlingBehavior(),
                        contentPadding = PaddingValues(
                            top = expandedTopBarHeightDp + 14.dp,
                            bottom = 190.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(28.dp)
                    ) {
                        if (quickPicks.isNotEmpty()) {
                            item(key = "quick_picks_section") {
                                Column {
                                    SectionHeader(
                                        title = "Quick picks",
                                        subtitle = "Let's start with a radio",
                                        onPlayAll = {
                                            quickPicks.firstOrNull()?.let { onSongClick(it) }
                                        }
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    SongHorizontalGrid(
                                        songs = quickPicks,
                                        onSongClick = onSongClick,
                                        onMoreClick = { selectedSongForOptions = it },
                                        performance = performance
                                    )
                                }
                            }
                        }

                        if (albums.isNotEmpty()) {
                            item(key = "albums_for_you_section") {
                                Column {
                                    SectionHeader(title = "Albums for you", subtitle = "Official releases")
                                    Spacer(modifier = Modifier.height(10.dp))
                                    val albumsRowState = rememberLazyListState()
                                    LazyRow(
                                        state = albumsRowState,
                                        modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
                                        contentPadding = PaddingValues(horizontal = 16.dp),
                                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                                        flingBehavior = rememberSnapRowFlingBehavior(albumsRowState)
                                    ) {
                                        items(
                                            items = albums,
                                            key = { album -> "home_album_${album["browseId"]}" }
                                        ) { album ->
                                            PlaylistCard(
                                                playlist = album,
                                                isLiquidGlass = performance.isLiquidGlassEnabled,
                                                onClick = { album["browseId"]?.let { onPlaylistClick(it) } }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (trending.isNotEmpty()) {
                            item(key = "trending_section") {
                                Column {
                                    SectionHeader(title = "Trending", subtitle = "Top hits right now")
                                    Spacer(modifier = Modifier.height(10.dp))
                                    SongHorizontalGrid(
                                        songs = trending,
                                        onSongClick = onSongClick,
                                        onMoreClick = { selectedSongForOptions = it },
                                        performance = performance
                                    )
                                }
                            }
                        }

                        shelves.forEachIndexed { index, shelf ->
                            if (shelf.items.isNotEmpty()) {
                                item(key = "shelf_section_$index") {
                                    Column {
                                        val subtitle = when (shelf.type) {
                                            "videos" -> "Music videos"
                                            "trending" -> "Charting tracks"
                                            "artists" -> "Recommended for you"
                                            else -> ""
                                        }
                                        SectionHeader(title = shelf.title, subtitle = subtitle)
                                        Spacer(modifier = Modifier.height(10.dp))

                                        if (shelf.type == "videos") {
                                            val songItems = shelf.items.filterIsInstance<Song>()
                                            if (songItems.isNotEmpty()) {
                                                VideoHorizontalRow(
                                                    songs = songItems,
                                                    onSongClick = onSongClick,
                                                    onMoreClick = { selectedSongForOptions = it },
                                                    performance = performance
                                                )
                                            }
                                        } else if (shelf.type == "songs" || shelf.type == "quick_picks" || shelf.type == "trending") {
                                            val songItems = shelf.items.filterIsInstance<Song>()
                                            if (songItems.isNotEmpty()) {
                                                SongHorizontalGrid(
                                                    songs = songItems,
                                                    onSongClick = onSongClick,
                                                    onMoreClick = { selectedSongForOptions = it },
                                                    performance = performance
                                                )
                                            } else {
                                                PlaylistShelfRow(
                                                    items = shelf.items,
                                                    shelfIndex = index,
                                                    onPlaylistClick = onPlaylistClick,
                                                    onArtistClick = onArtistClick,
                                                    onSongClick = onSongClick,
                                                    onMoreClick = { selectedSongForOptions = it },
                                                    performance = performance
                                                )
                                            }
                                        } else {
                                            PlaylistShelfRow(
                                                items = shelf.items,
                                                shelfIndex = index,
                                                onPlaylistClick = onPlaylistClick,
                                                onArtistClick = onArtistClick,
                                                onSongClick = onSongClick,
                                                onMoreClick = { selectedSongForOptions = it },
                                                performance = performance
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item(key = "home_footer") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 36.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Wave Muzix",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Tervixa-Corp • © ${java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary.copy(alpha = 0.65f)
                                )
                            }
                        }
                    }
                }
            }
        }

        val barTint = MaterialTheme.colorScheme.background
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .onGloballyPositioned { coords ->
                    val measured = with(density) { coords.size.height.toDp() }
                    if (measured > expandedTopBarHeightDp) {
                        expandedTopBarHeightDp = measured
                    }
                }
                .then(
                    if (atTop) {
                        Modifier.background(Color.Transparent)
                    } else {
                        Modifier.hazeBlur(
                            input = HazeInput.Sources(homeHazeState),
                            style = barBlurStyle(tint = barTint, tintAlpha = 0.58f, blurRadius = 32.dp)
                        )
                    }
                )
                .statusBarsPadding()
        ) {
            AnimatedVisibility(
                visible = atTop || isScrollingUp,
                enter = expandVertically(expandFrom = Alignment.Top, animationSpec = tween(250)) +
                    slideInVertically(initialOffsetY = { -it }, animationSpec = tween(250)) +
                    fadeIn(animationSpec = tween(220)),
                exit = shrinkVertically(shrinkTowards = Alignment.Top, animationSpec = tween(250)) +
                    slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(250)) +
                    fadeOut(animationSpec = tween(180))
            ) {
                HomeTopBar(
                    isLoggedIn = isLoggedIn,
                    userAvatarUrl = userAvatarUrl ?: auth.currentUser?.photoUrl?.toString(),
                    userName = userName ?: auth.currentUser?.displayName,
                    onNotifyClick = onNotifyClick,
                    onSettingsClick = onSettingsClick,
                    onProfileClick = onProfileClick,
                    isLiquidGlass = isLiquidGlass
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            FilterChipsRow(
                selectedChip = selectedChip,
                onSelectChip = { chip ->
                    selectedChip = chip
                }
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
fun HomeTopBar(
    isLoggedIn: Boolean,
    userAvatarUrl: String?,
    userName: String?,
    onNotifyClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onProfileClick: () -> Unit,
    isLiquidGlass: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Wave Muzix",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 24.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val greetingPrefix = when (currentHour) {
                in 6..11 -> "Good morning"
                in 12..16 -> "Good afternoon"
                in 17..19 -> "Good evening"
                else -> "Good night"
            }
            Text(
                text = if (isLoggedIn && !userName.isNullOrBlank()) "$greetingPrefix, $userName" else greetingPrefix,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f),
                    fontSize = 13.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(
                onClick = onNotifyClick,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = WaveIcons.Notifications,
                    contentDescription = "Notifications",
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(24.dp)
                )
            }
            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = WaveIcons.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(24.dp)
                )
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable { onProfileClick() },
                contentAlignment = Alignment.Center
            ) {
                if (isLoggedIn) {
                    WaveUserAvatar(
                        url = userAvatarUrl,
                        name = userName,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    IconButton(onClick = onProfileClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Login,
                            contentDescription = "Login",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilterChipsRow(
    selectedChip: String = "All",
    onSelectChip: (String) -> Unit = {}
) {
    val filters = remember { listOf("All", "Relax", "Sleep", "Energize", "Workout", "Focus", "Romance", "Party") }
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .nestedScroll(HorizontalCarouselNestedScrollConnection)
            .padding(vertical = 4.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        flingBehavior = rememberSmoothFlingBehavior()
    ) {
        items(
            items = filters,
            key = { it }
        ) { filter ->
            val isSelected = filter == selectedChip
            WaveFilterChip(
                text = filter,
                selected = isSelected,
                onClick = { onSelectChip(filter) },
                selectedContainerColor = Color.White.copy(alpha = 0.22f),
                selectedTextColor = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    onPlayAll: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                ),
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (onPlayAll != null) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.10f),
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { onPlayAll() }
            ) {
                Text(
                    text = "Play all",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                )
            }
        }
    }
}

@Composable
fun SongHorizontalGrid(
    songs: List<Song>,
    onSongClick: (Song) -> Unit,
    onMoreClick: ((Song) -> Unit)? = null,
    performance: com.tervixa.wavemuzix.data.PerformanceConfig = com.tervixa.wavemuzix.data.LocalPerformanceConfig.current
) {
    val chunks = remember(songs) { songs.chunked(4) }
    val gridRowState = rememberLazyListState()
    LazyRow(
        state = gridRowState,
        modifier = Modifier
            .fillMaxWidth()
            .nestedScroll(HorizontalCarouselNestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        flingBehavior = rememberSnapRowFlingBehavior(gridRowState)
    ) {
        itemsIndexed(
            items = chunks,
            key = { index, chunk -> "${chunk.firstOrNull()?.videoId ?: "empty"}_$index" }
        ) { _, chunk ->
            Column(
                modifier = Modifier.fillParentMaxWidth(0.88f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                chunk.forEach { song ->
                    HomeSongCard(
                        song = song,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onSongClick(song) },
                        onMoreClick = onMoreClick?.let { { it(song) } },
                        performance = performance
                    )
                }
            }
        }
    }
}

@Composable
fun PlaylistShelfRow(
    items: List<Any>,
    shelfIndex: Int,
    onPlaylistClick: (String) -> Unit,
    onArtistClick: (String) -> Unit,
    onSongClick: (Song) -> Unit,
    onMoreClick: ((Song) -> Unit)? = null,
    performance: com.tervixa.wavemuzix.data.PerformanceConfig = com.tervixa.wavemuzix.data.LocalPerformanceConfig.current
) {
    val shelfRowState = rememberLazyListState()
    LazyRow(
        state = shelfRowState,
        modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        flingBehavior = rememberSnapRowFlingBehavior(shelfRowState)
    ) {
        items(
            items = items,
            key = { item ->
                when (item) {
                    is Song -> "song_${item.videoId}_$shelfIndex"
                    is Map<*, *> -> "playlist_${item["title"]}_${item["browseId"]}_$shelfIndex"
                    else -> item.hashCode()
                }
            },
            contentType = { item -> if (item is Song) "song_card" else "playlist_card" }
        ) { item ->
            when (item) {
                is Song -> {
                    HomeItemSongCard(
                        song = item,
                        onClick = { onSongClick(item) }
                    )
                }
                is Map<*, *> -> {
                    @Suppress("UNCHECKED_CAST")
                    val data = item as Map<String, String>
                    val type = data["type"] ?: "playlist"
                    val browseId = data["browseId"] ?: ""

                    if (type == "artist") {
                        ArtistCard(
                            artist = data,
                            isLiquidGlass = performance.isLiquidGlassEnabled,
                            onClick = { if (browseId.isNotEmpty()) onArtistClick(browseId) }
                        )
                    } else {
                        PlaylistCard(
                            playlist = data,
                            isLiquidGlass = performance.isLiquidGlassEnabled,
                            onClick = { if (browseId.isNotEmpty()) onPlaylistClick(browseId) }
                        )
                    }
                }
                else -> {}
            }
        }
    }
}

/**
 * SimpMusic `QuickPicksItem` / `SongFullWidthItems` row:
 * - Uses a 52.dp 1:1 square thumbnail box where square thumbnails fill (`ContentScale.Crop`)
 *   and rectangular thumbnails fit inside the 1:1 box (`ContentScale.Fit`).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeSongCard(
    song: Song,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onMoreClick: (() -> Unit)? = null,
    performance: com.tervixa.wavemuzix.data.PerformanceConfig = com.tervixa.wavemuzix.data.LocalPerformanceConfig.current
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = spring(
            dampingRatio = performance.springDampingRatio,
            stiffness = performance.springStiffness
        ),
        label = "HomeSongCardScale"
    )

    Row(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = { onMoreClick?.invoke() }
            )
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        WaveArtworkImage(
            url = song.thumbnailUrl,
            contentDescription = song.title,
            isVideo = false,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.size(52.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                ),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200,
                    )
                    .focusable()
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = song.displayArtists,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200,
                    )
                    .focusable()
            )
        }
        if (onMoreClick != null) {
            IconButton(
                onClick = onMoreClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "More options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/**
 * SimpMusic `HomeItemSong` (160.dp 1:1 square card for horizontal song shelves:
 * square thumbnails fill the 1:1 box, rectangular thumbnails fit inside the 1:1 box)
 */
@Composable
fun HomeItemSongCard(
    song: Song,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .width(160.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(6.dp)
    ) {
        WaveArtworkImage(
            url = song.thumbnailUrl,
            contentDescription = song.title,
            isVideo = false,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.size(160.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = song.title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = song.displayArtists,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
    }
}

@Composable
fun PlaylistCard(
    playlist: Map<String, String>,
    modifier: Modifier = Modifier,
    isLiquidGlass: Boolean = true,
    onClick: () -> Unit
) {
    val thumbSize = 160.dp
    Column(
        modifier = modifier
            .width(thumbSize + 12.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(6.dp)
    ) {
        Box {
            WaveArtworkImage(
                url = playlist["thumbnail"],
                contentDescription = playlist["title"],
                isVideo = false,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(thumbSize)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.65f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = playlist["title"] ?: "",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = playlist["author"]?.takeIf { it.isNotBlank() }
                ?: if (playlist["type"] == "album") "Album" else "Playlist",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
    }
}

@Composable
fun ArtistCard(
    artist: Map<String, String>,
    modifier: Modifier = Modifier,
    isLiquidGlass: Boolean = true,
    onClick: () -> Unit
) {
    val artistSize = 160.dp
    Column(
        modifier = modifier
            .width(artistSize + 12.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WaveArtworkImage(
            url = artist["thumbnail"],
            contentDescription = artist["title"],
            isVideo = false,
            shape = CircleShape,
            modifier = Modifier.size(artistSize)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = artist["title"] ?: "",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "Artist",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

@Composable
fun VideoHorizontalRow(
    songs: List<Song>,
    onSongClick: (Song) -> Unit,
    onMoreClick: ((Song) -> Unit)? = null,
    performance: com.tervixa.wavemuzix.data.PerformanceConfig = com.tervixa.wavemuzix.data.LocalPerformanceConfig.current
) {
    val videoRowState = rememberLazyListState()
    LazyRow(
        state = videoRowState,
        modifier = Modifier
            .fillMaxWidth()
            .nestedScroll(HorizontalCarouselNestedScrollConnection),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        flingBehavior = rememberSnapRowFlingBehavior(videoRowState)
    ) {
        itemsIndexed(
            items = songs,
            key = { index, song -> "${song.videoId}_$index" }
        ) { _, song ->
            VideoCard(
                song = song,
                isLiquidGlass = performance.isLiquidGlassEnabled,
                onClick = { onSongClick(song) },
                onLongClick = onMoreClick?.let { { it(song) } }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoCard(
    song: Song,
    modifier: Modifier = Modifier,
    isLiquidGlass: Boolean = true,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val videoWidth = 284.5.dp
    val videoHeight = 160.dp
    Column(
        modifier = modifier
            .width(videoWidth)
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(6.dp)
    ) {
        Box {
            WaveArtworkImage(
                url = song.thumbnailUrl,
                contentDescription = song.title,
                isVideo = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .width(videoWidth)
                    .height(videoHeight)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(
                        Color.Black.copy(alpha = 0.72f),
                        RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = WaveIcons.Video,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    if (!song.durationText.isNullOrBlank()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = song.durationText,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = song.title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "${song.displayArtists} • Video",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(
                    iterations = Int.MAX_VALUE,
                    animationMode = MarqueeAnimationMode.Immediately,
                    initialDelayMillis = 1200,
                )
                .focusable()
        )
    }
}
