package com.tervixa.wavemuzix.utils

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs

/**
 * Native high-velocity spline fling behavior for all vertical lists (`HomeScreen`, `SearchScreen`,
 * `LibraryScreen`, `PlaylistScreen`, `ArtistScreen`, `SettingsScreen`, `AnalyticsScreen`):
 * - Removes artificial velocity clamping so hard flicks travel naturally across long lists.
 * - Releases the scroll lock immediately when the user initiates a perpendicular gesture,
 *   fixing horizontal-to-vertical and vertical-to-horizontal scroll axis lockups.
 */
@Composable
fun rememberSmoothFlingBehavior(): FlingBehavior {
    return ScrollableDefaults.flingBehavior()
}

/**
 * Axis-disambiguating [NestedScrollConnection] for horizontal carousels inside vertical lists:
 * Ensures leftover horizontal velocity never bleeds into or blocks vertical scrolling, so the user
 * can switch between horizontal `LazyRow`/`LazyHorizontalGrid` exploration and vertical `LazyColumn`
 * scrolling on the very first touch.
 */
val HorizontalCarouselNestedScrollConnection = object : NestedScrollConnection {
    override fun onPostScroll(
        consumed: Offset,
        available: Offset,
        source: NestedScrollSource,
    ): Offset {
        return if (abs(available.x) > abs(available.y) * 1.15f) {
            Offset(available.x, 0f)
        } else {
            Offset.Zero
        }
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        return Velocity(available.x, 0f)
    }
}

/**
 * SimpMusic horizontal row snapping fling behavior (`SnapPosition.Start`).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun rememberSnapRowFlingBehavior(
    lazyListState: LazyListState,
    snapPosition: SnapPosition = SnapPosition.Start,
): FlingBehavior {
    return rememberSnapFlingBehavior(
        lazyListState = lazyListState,
        snapPosition = snapPosition,
    )
}

/**
 * SimpMusic horizontal grid snapping fling behavior (`SnapPosition.Start`) for multi-row
 * `LazyHorizontalGrid` shelves.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun rememberSnapGridFlingBehavior(
    lazyGridState: LazyGridState,
    snapPosition: SnapPosition = SnapPosition.Start,
): FlingBehavior {
    return rememberSnapFlingBehavior(
        lazyGridState = lazyGridState,
        snapPosition = snapPosition,
    )
}
