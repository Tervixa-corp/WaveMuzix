package com.tervixa.wavemuzix.uiresource.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.kashif_e.backdrop.backdrops.layerBackdrop
import com.kashif_e.backdrop.backdrops.rememberLayerBackdrop
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.DownloadWorker
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.repository.ArtistDetail
import com.tervixa.wavemuzix.repository.ArtistRepository
import com.tervixa.wavemuzix.repository.FavoriteRepository
import com.tervixa.wavemuzix.repository.PlaylistRepository
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import com.tervixa.wavemuzix.uiresource.components.AddToPlaylistDialog
import com.tervixa.wavemuzix.uiresource.components.GlassIconButton
import com.tervixa.wavemuzix.uiresource.components.LiquidGlassContainer
import com.tervixa.wavemuzix.uiresource.components.LocalBackdrop
import com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet
import com.tervixa.wavemuzix.uiresource.components.StandardLoader
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveHazeHeader
import com.tervixa.wavemuzix.uiresource.components.WaveStateContainer
import com.tervixa.wavemuzix.uiresource.components.WaveThumbnailPrefetcher
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.tervixa.wavemuzix.uiresource.components.rememberImmersivePaletteColors
import com.tervixa.wavemuzix.utils.HorizontalCarouselNestedScrollConnection
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import com.tervixa.wavemuzix.utils.rememberSnapRowFlingBehavior
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtistScreen(
    artistId: String,
    repository: UnifiedMusicRepository,
    onBack: () -> Unit,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (String) -> Unit,
    isLiquidGlass: Boolean,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val favoriteRepository = remember { FavoriteRepository(AppDatabase.getDatabase(context).songDao(), context) }
    val artistRepository = remember { ArtistRepository(AppDatabase.getDatabase(context).songDao()) }
    val playlistRepository = remember { PlaylistRepository(AppDatabase.getDatabase(context).playlistDao(), context) }

    val downloadedSongs by AppDatabase.getDatabase(context).songDao().getAllDownloads().collectAsState(initial = emptyList())
    val likedSongs by AppDatabase.getDatabase(context).songDao().getAllFavorites().collectAsState(initial = emptyList())
    val allPlaylists by playlistRepository.allPlaylists.collectAsState(initial = emptyList())

    var currentArtistId by remember(artistId) { mutableStateOf(artistId) }

    var isFollowing by remember { mutableStateOf(false) }
    LaunchedEffect(currentArtistId) {
        isFollowing = artistRepository.isFollowing(currentArtistId)
    }

    var artistDetail by remember { mutableStateOf<ArtistDetail?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isError by remember { mutableStateOf(false) }
    var selectedSongForOptions by remember { mutableStateOf<Song?>(null) }
    var showPlaylistDialogFor by remember { mutableStateOf<Song?>(null) }
    var showAllSongs by remember { mutableStateOf(false) }
    var fullArtistSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var isLoadingMoreSongs by remember { mutableStateOf(false) }
    var isBioExpanded by remember { mutableStateOf(false) }

    val fetchData = {
        scope.launch {
            isLoading = true
            isError = false
            showAllSongs = false
            fullArtistSongs = emptyList()
            try {
                artistDetail = repository.fetchArtist(currentArtistId, CookieManager(context).getCookies())
                    ?: repository.getArtistChannel(currentArtistId.removePrefix("search:"), CookieManager(context).getCookies())
                if (artistDetail == null) isError = true
                else {
                    isFollowing = artistRepository.isFollowing(artistDetail!!.browseId)
                    WaveThumbnailPrefetcher.prefetchThumbnails(
                        context,
                        artistDetail!!.songs.map { it.thumbnailUrl }
                    )
                }
            } catch (e: Exception) {
                isError = true
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(currentArtistId) {
        fetchData()
    }

    LaunchedEffect(showAllSongs) {
        if (showAllSongs && fullArtistSongs.isEmpty()) {
            val detail = artistDetail
            if (detail != null) {
                isLoadingMoreSongs = true
                fullArtistSongs = repository.fetchArtistSongs(detail.name, detail.songsParams, CookieManager(context).getCookies())
                isLoadingMoreSongs = false
            }
        }
    }

    if (showPlaylistDialogFor != null) {
        AddToPlaylistDialog(
            song = showPlaylistDialogFor!!,
            playlists = allPlaylists,
            onDismiss = { showPlaylistDialogFor = null },
            onPlaylistSelected = { playlist ->
                scope.launch {
                    playlistRepository.addSongToPlaylist(playlist.id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
            onCreatePlaylist = { name ->
                scope.launch {
                    val id = playlistRepository.createPlaylist(name)
                    playlistRepository.addSongToPlaylist(id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Created and added to $name", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            }
        )
    }

    val paletteColors = rememberImmersivePaletteColors(artistDetail?.thumbnailUrl)
    val dynamicBgColor by animateColorAsState(
        targetValue = paletteColors.backgroundColor,
        animationSpec = tween(500),
        label = "artistBgColor"
    )
    SideEffect {
        MusicPlayer.activeScreenAccentTint = dynamicBgColor
    }
    val dynamicTintColor by animateColorAsState(
        targetValue = paletteColors.topBarTintColor,
        animationSpec = tween(500),
        label = "artistTintColor"
    )
    val pageBackdrop: LayerBackdrop = rememberLayerBackdrop {
        drawRect(dynamicBgColor)
        drawContent()
    }

    if (selectedSongForOptions != null) {
        val song = selectedSongForOptions!!
        val isDownloaded = downloadedSongs.any { it.videoId == song.videoId }
        val isFavorite = likedSongs.any { it.videoId == song.videoId }

        CompositionLocalProvider(LocalBackdrop provides pageBackdrop) {
            SongOptionsBottomSheet(
                song = song,
                isFavorite = isFavorite,
                isDownloaded = isDownloaded,
                isLiquidGlass = isLiquidGlass,
                onDismiss = { selectedSongForOptions = null },
                onFavoriteClick = { scope.launch { favoriteRepository.toggleFavorite(song) } },
                onDownloadClick = {
                    scope.launch {
                        if (isDownloaded) {
                            AppDatabase.getDatabase(context).songDao().deleteDownload(song.videoId)
                            downloadedSongs.find { it.videoId == song.videoId }?.filePath?.let { java.io.File(it).delete() }
                            Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                        } else {
                            val cookies = CookieManager(context).getCookies()
                            val result = repository.getStreamingUrl(song.videoId, cookies)
                            if (result != null) {
                                DownloadManager.updateProgress(song.videoId, song.title, 0)
                                val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                                    .setInputData(
                                        workDataOf(
                                            "url" to result.url,
                                            "videoId" to song.videoId,
                                            "title" to song.title,
                                            "artist" to song.artist,
                                            "thumbnailUrl" to song.thumbnailUrl,
                                            "userAgent" to result.userAgent,
                                            "cookies" to cookies,
                                        ),
                                    ).build()
                                WorkManager.getInstance(context).enqueue(request)
                                Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                onPlayNextClick = { MusicPlayer.playNext(song) },
                onAddToQueueClick = { MusicPlayer.addToQueue(song) },
                onArtistClick = { targetId ->
                    selectedSongForOptions = null
                    if (targetId.isNotBlank() && targetId != currentArtistId) {
                        currentArtistId = targetId
                    }
                },
                onAddToPlaylistClick = {
                    showPlaylistDialogFor = song
                    selectedSongForOptions = null
                },
                onShareClick = {
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, "Listen to ${song.title} on WaveMuzix: https://www.youtube.com/watch?v=${song.videoId}")
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, null))
                },
            )
        }
    }

    val lazyState = rememberLazyListState()
    val artistHazeState = remember { HazeState() }
    val showTopAppBar by remember {
        derivedStateOf {
            lazyState.firstVisibleItemIndex > 0 || lazyState.firstVisibleItemScrollOffset > 260
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(dynamicBgColor),
    ) {
        WaveStateContainer(
            isLoading = isLoading,
            isError = isError,
            onRetry = { fetchData() },
        ) {
            artistDetail?.let { detail ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .hazeSource(state = artistHazeState)
                        .background(dynamicBgColor)
                        .layerBackdrop(pageBackdrop)
                ) {
                    LazyColumn(
                        state = lazyState,
                        modifier = Modifier.fillMaxSize(),
                        flingBehavior = rememberSmoothFlingBehavior(),
                        contentPadding = PaddingValues(bottom = 170.dp),
                    ) {
                        item(key = "artist_header") {
                            ArtistHeaderSection(
                                detail = detail,
                                onBack = onBack,
                                isLiquidGlass = isLiquidGlass,
                                backgroundColor = dynamicBgColor,
                                accentColor = paletteColors.accentColor,
                                isFollowing = isFollowing,
                                onSearchClick = { showAllSongs = true },
                                onFollowClick = {
                                    scope.launch {
                                        artistRepository.toggleFollow(
                                            detail.browseId,
                                            detail.name,
                                            detail.thumbnailUrl,
                                        )
                                        isFollowing = !isFollowing
                                    }
                                },
                                repository = repository,
                            )
                        }

                        if (detail.songs.isNotEmpty()) {
                            item(key = "popular_tracks_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "Popular",
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 20.sp
                                        ),
                                        color = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.10f),
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .clickable { showAllSongs = !showAllSongs }
                                    ) {
                                        Text(
                                            text = if (showAllSongs) "Show less" else "More",
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                            color = MaterialTheme.colorScheme.onBackground,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        )
                                    }
                                }
                            }

                            if (showAllSongs && isLoadingMoreSongs) {
                                item(key = "loading_more_songs") {
                                    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                        StandardLoader()
                                    }
                                }
                            }

                            val songsToShow = if (showAllSongs) {
                                if (fullArtistSongs.isNotEmpty()) fullArtistSongs else detail.songs
                            } else {
                                detail.songs.take(5)
                            }
                            items(
                                songsToShow,
                                key = { "artist_song_${it.videoId}" },
                                contentType = { "artist_song_card" },
                            ) { song ->
                                ArtistSongCard(
                                    song = song,
                                    onOptionsClick = { selectedSongForOptions = song },
                                ) {
                                    MusicPlayer.playSong(context, song, songsToShow, isFromFixedList = true)
                                }
                            }
                        }

                        val albums = detail.items.filter { it["type"] == "album" || it["type"] == "single" }
                        if (albums.isNotEmpty()) {
                            item(key = "discography_label") {
                                SectionLabel("Releases")
                            }
                            item(key = "discography_row") {
                                val rowState = rememberLazyListState()
                                LazyRow(
                                    state = rowState,
                                    modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    flingBehavior = rememberSnapRowFlingBehavior(rowState),
                                ) {
                                    items(
                                        albums,
                                        key = { "album_${it["browseId"] ?: it["title"] ?: it.hashCode()}" },
                                    ) { album ->
                                        PlaylistCard(
                                            playlist = mapOf(
                                                "title" to (album["title"]?.toString() ?: ""),
                                                "thumbnail" to (album["thumbnail"]?.toString() ?: ""),
                                                "browseId" to (album["browseId"]?.toString() ?: ""),
                                                "author" to (album["subtitle"]?.toString() ?: "Album"),
                                                "type" to "album"
                                            ),
                                            isLiquidGlass = isLiquidGlass,
                                            onClick = {
                                                album["browseId"]?.toString()?.let { onAlbumClick(it) }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        val videos = detail.items.filter { it["type"] == "video" }.mapNotNull { map ->
                            val vid = map["videoId"]?.toString() ?: return@mapNotNull null
                            Song(
                                id = vid,
                                videoId = vid,
                                title = map["title"]?.toString() ?: "",
                                artist = map["artist"]?.toString() ?: detail.name,
                                thumbnailUrl = map["thumbnail"]?.toString() ?: "",
                                artistId = detail.browseId,
                                isVideo = true,
                            )
                        }
                        if (videos.isNotEmpty()) {
                            item(key = "artist_videos_label") {
                                SectionLabel("Videos")
                            }
                            item(key = "artist_videos_row") {
                                VideoHorizontalRow(
                                    songs = videos,
                                    onSongClick = { videoSong ->
                                        MusicPlayer.playSong(context, videoSong, videos, isFromFixedList = false)
                                        onSongClick(videoSong)
                                    },
                                    onMoreClick = { selectedSongForOptions = it }
                                )
                            }
                        }

                        val featuredPlaylists = detail.items.filter { it["type"] == "playlist" }
                        if (featuredPlaylists.isNotEmpty()) {
                            item(key = "featured_on_label") {
                                SectionLabel("Featured on")
                            }
                            item(key = "featured_on_row") {
                                val featRowState = rememberLazyListState()
                                LazyRow(
                                    state = featRowState,
                                    modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    flingBehavior = rememberSnapRowFlingBehavior(featRowState),
                                ) {
                                    items(
                                        featuredPlaylists,
                                        key = { "feat_${it["browseId"] ?: it["title"] ?: it.hashCode()}" },
                                    ) { pl ->
                                        PlaylistCard(
                                            playlist = mapOf(
                                                "title" to (pl["title"]?.toString() ?: ""),
                                                "thumbnail" to (pl["thumbnail"]?.toString() ?: ""),
                                                "browseId" to (pl["browseId"]?.toString() ?: ""),
                                                "author" to (pl["subtitle"]?.toString() ?: "Playlist"),
                                                "type" to "playlist"
                                            ),
                                            isLiquidGlass = isLiquidGlass,
                                            onClick = {
                                                pl["browseId"]?.toString()?.let { onAlbumClick(it) }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        val relatedArtists = detail.items.filter { it["type"] == "artist" }
                        if (relatedArtists.isNotEmpty()) {
                            item(key = "related_artists_label") {
                                SectionLabel("Fans also like")
                            }
                            item(key = "related_artists_row") {
                                val relRowState = rememberLazyListState()
                                LazyRow(
                                    state = relRowState,
                                    modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    flingBehavior = rememberSnapRowFlingBehavior(relRowState),
                                ) {
                                    items(
                                        relatedArtists,
                                        key = { "rel_artist_${it["browseId"] ?: it["title"] ?: it.hashCode()}" },
                                    ) { artistMap ->
                                        ArtistCard(
                                            artist = mapOf(
                                                "title" to (artistMap["title"]?.toString() ?: ""),
                                                "thumbnail" to (artistMap["thumbnail"]?.toString() ?: ""),
                                                "browseId" to (artistMap["browseId"]?.toString() ?: ""),
                                                "type" to "artist"
                                            ),
                                            isLiquidGlass = isLiquidGlass,
                                            onClick = {
                                                val id = artistMap["browseId"]?.toString().orEmpty()
                                                if (id.isNotEmpty()) {
                                                    currentArtistId = id
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        if (detail.description.isNotBlank()) {
                            item(key = "artist_about_section") {
                                SectionLabel("About")
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.White.copy(alpha = 0.06f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp)
                                        .clip(RoundedCornerShape(18.dp))
                                        .clickable { isBioExpanded = !isBioExpanded }
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        Text(
                                            text = detail.description,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.88f),
                                            maxLines = if (isBioExpanded) Int.MAX_VALUE else 4,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = if (isBioExpanded) "Show less" else "Read more",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showTopAppBar,
            enter = fadeIn(tween(220)) + slideInVertically(initialOffsetY = { -it }, animationSpec = tween(250)),
            exit = fadeOut(tween(180)) + slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(220)),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            TopAppBar(
                title = {
                    Text(
                        text = artistDetail?.name?.replace(" - Topic", "", ignoreCase = true) ?: "",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Clip,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee(
                                iterations = Int.MAX_VALUE,
                                animationMode = MarqueeAnimationMode.Immediately,
                                initialDelayMillis = 1200,
                            )
                            .focusable()
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                },
                actions = {
                    val songs = artistDetail?.songs.orEmpty()
                    if (songs.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                MusicPlayer.playSong(
                                    context,
                                    songs.shuffled().first(),
                                    songs,
                                    isFromFixedList = true,
                                )
                            },
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shuffle,
                                contentDescription = "Shuffle",
                                tint = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    IconButton(
                        onClick = { showAllSongs = true },
                    ) {
                        Icon(
                            imageVector = WaveIcons.Search,
                            contentDescription = "Search artist songs",
                            tint = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .hazeBlur(
                        input = HazeInput.Sources(artistHazeState),
                        style = barBlurStyle(
                            tint = dynamicTintColor,
                            tintAlpha = 0.64f,
                            blurRadius = 32.dp
                        ),
                    ),
            )
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        ),
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 10.dp),
    )
}

@Composable
fun ArtistSongCard(
    song: Song,
    onOptionsClick: () -> Unit,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WaveArtworkImage(
            url = song.thumbnailUrl,
            contentDescription = song.title,
            isVideo = false,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.size(44.dp),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200,
                    )
                    .focusable()
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = song.displayArtists,
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200,
                    )
                    .focusable()
            )
        }

        IconButton(onClick = onOptionsClick) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Options",
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
fun ArtistHeaderSection(
    detail: ArtistDetail,
    onBack: () -> Unit,
    isLiquidGlass: Boolean,
    backgroundColor: Color,
    accentColor: Color,
    isFollowing: Boolean,
    onFollowClick: () -> Unit,
    onSearchClick: () -> Unit = {},
    repository: UnifiedMusicRepository,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val scrimHeight = screenWidth * 0.75f
    val headerBackdrop: LayerBackdrop = rememberLayerBackdrop {
        drawRect(backgroundColor)
        drawContent()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
    ) {
        WaveHazeHeader.VerticalGradient(
            modifier = Modifier
                .fillMaxSize()
                .layerBackdrop(headerBackdrop),
            backgroundColor = backgroundColor,
            blurRadius = 32.dp,
            blurHeight = 200.dp,
            gradientHeight = scrimHeight,
            headerImage = {
                WaveArtworkImage(
                    url = detail.thumbnailUrl,
                    contentDescription = detail.name,
                    isVideo = false,
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxSize(),
                )
            },
        )

        CompositionLocalProvider(LocalBackdrop provides headerBackdrop) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GlassIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    onClick = onBack,
                    isLiquidGlass = isLiquidGlass,
                    contentDescription = "Back",
                    containerSize = 48.dp,
                    iconSize = 24.dp,
                )
                GlassIconButton(
                    icon = WaveIcons.Search,
                    onClick = onSearchClick,
                    isLiquidGlass = isLiquidGlass,
                    contentDescription = "Search artist songs",
                    containerSize = 48.dp,
                    iconSize = 24.dp,
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = detail.name.replace(" - Topic", "", ignoreCase = true),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                        ),
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )

                    val stats = remember(detail) {
                        listOfNotNull(
                            detail.subscriberCountText,
                            detail.listenerCountText,
                        ).joinToString(" • ")
                    }

                    if (stats.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stats,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f),
                            textAlign = TextAlign.Center,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    LiquidGlassContainer(
                        backdrop = headerBackdrop,
                        isLiquidGlass = isLiquidGlass,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(48.dp)
                            .clickable {
                                val radioBrowseId = detail.radioId
                                if (!radioBrowseId.isNullOrBlank()) {
                                    scope.launch {
                                        val pl = repository.fetchPlaylist(radioBrowseId, CookieManager(context).getCookies())
                                        val radioSongs = pl?.songs.orEmpty().ifEmpty { detail.songs }
                                        if (radioSongs.isNotEmpty()) {
                                            MusicPlayer.playSong(context, radioSongs.first(), radioSongs, isFromFixedList = false)
                                        }
                                    }
                                } else if (detail.songs.isNotEmpty()) {
                                    MusicPlayer.playSong(context, detail.songs.first(), detail.songs, isFromFixedList = false)
                                }
                            },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Sensors,
                            contentDescription = "Radio",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp),
                        )
                    }

                    LiquidGlassContainer(
                        backdrop = headerBackdrop,
                        isLiquidGlass = isLiquidGlass,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(64.dp)
                            .clickable {
                                val shuffleBrowseId = detail.shuffleId
                                if (!shuffleBrowseId.isNullOrBlank()) {
                                    scope.launch {
                                        val pl = repository.fetchPlaylist(shuffleBrowseId, CookieManager(context).getCookies())
                                        val shufSongs = (pl?.songs.orEmpty().ifEmpty { detail.songs }).shuffled()
                                        if (shufSongs.isNotEmpty()) {
                                            MusicPlayer.playSong(context, shufSongs.first(), shufSongs, isFromFixedList = true)
                                        }
                                    }
                                } else if (detail.songs.isNotEmpty()) {
                                    val shuffled = detail.songs.shuffled()
                                    MusicPlayer.playSong(context, shuffled.first(), shuffled, isFromFixedList = true)
                                }
                            },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shuffle,
                            contentDescription = "Shuffle",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(28.dp),
                        )
                    }

                    LiquidGlassContainer(
                        backdrop = headerBackdrop,
                        isLiquidGlass = isLiquidGlass,
                        shape = CircleShape,
                        modifier = Modifier
                            .height(48.dp)
                            .clickable { onFollowClick() },
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = if (isFollowing) Icons.Rounded.Check else Icons.Rounded.PersonAdd,
                                contentDescription = null,
                                tint = if (isFollowing) accentColor else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isFollowing) "Following" else "Follow",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isFollowing) accentColor else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }
        }
    }
}
