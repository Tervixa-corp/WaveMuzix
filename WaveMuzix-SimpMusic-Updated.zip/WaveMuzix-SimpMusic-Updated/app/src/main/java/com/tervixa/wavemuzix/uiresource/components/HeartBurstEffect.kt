package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Custom WaveMuzix Like Celebration Burst Effect:
 * Inspired by SimpMusic's `HeartBurstState` and refined with popular music app micro-interactions:
 * 1) Dual sonic wave rings expanding outward from the heart center.
 * 2) 18 multi-shape particles (Mini Floating Hearts, 4-Point Diamond Stars, and Acoustic Wave Shards)
 *    launching in a buoyant 360° crown with upward lift + gentle gravity arc.
 * 3) Elastic heart scale bounce (`0.72f -> 1.28f -> 1.0f`) on tap.
 *
 * Fires ONLY on the user tap that likes a song, never on track transitions.
 */
@Stable
class HeartBurstState internal constructor(
    private val scope: CoroutineScope,
) {
    internal val bursts = mutableStateListOf<WaveHeartBurst>()
    internal val heartScale = Animatable(1f)
    internal var colors: List<Color> = WaveHeartBurstDefaults.colors

    fun fire() {
        val burst = WaveHeartBurst(List(PARTICLES_PER_BURST) { randomWaveSpark(colors) })
        bursts += burst
        scope.launch {
            launch {
                heartScale.snapTo(0.72f)
                heartScale.animateTo(
                    targetValue = 1.28f,
                    animationSpec = tween(160, easing = FastOutSlowInEasing),
                )
                heartScale.animateTo(
                    targetValue = 1f,
                    animationSpec = spring(dampingRatio = 0.45f, stiffness = 420f),
                )
            }
            burst.progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(BURST_DURATION_MS, easing = LinearEasing),
            )
            bursts.remove(burst)
        }
    }
}

@Composable
fun rememberHeartBurstState(): HeartBurstState {
    val scope = rememberCoroutineScope()
    return remember { HeartBurstState(scope) }
}

@Composable
fun Modifier.heartBurst(
    state: HeartBurstState,
    colors: List<Color> = WaveHeartBurstDefaults.colors,
): Modifier {
    state.colors = colors
    val diamondPath = remember { buildDiamondStarPath() }
    val miniHeartPath = remember { buildMiniHeartPath() }

    return this.drawWithContent {
        drawContent()
        if (state.bursts.isEmpty()) return@drawWithContent

        val center = Offset(size.width / 2f, size.height / 2f)
        val launchOrigin = Offset(size.width / 2f, size.height * 0.38f)
        val reach = size.height * 2.35f

        state.bursts.forEach { burst ->
            val p = burst.progress.value
            if (p <= 0f) return@forEach

            // 1) Dual expanding sonic wave ring
            val ringProgress = (p / 0.55f).coerceIn(0f, 1f)
            if (ringProgress < 1f) {
                val easedRing = 1f - (1f - ringProgress) * (1f - ringProgress)
                val ringRadius = size.minDimension * (0.35f + 0.95f * easedRing)
                val ringAlpha = (1f - ringProgress) * 0.65f
                drawCircle(
                    color = colors.firstOrNull() ?: Color(0xFFFF2D55),
                    radius = ringRadius,
                    center = center,
                    alpha = ringAlpha,
                    style = Stroke(width = (3.dp.toPx() * (1f - ringProgress * 0.7f)).coerceAtLeast(1f)),
                )
            }

            // 2) Buoyant crown of Mini Hearts, 4-Point Diamonds, and Wave Shards
            val flight = 1f - (1f - p) * (1f - p) * (1f - p)
            val gravity = p * p * reach * 0.28f
            val alpha = ((1f - p) * 1.25f).coerceIn(0f, 1f)
            val scaleEnvelope = if (p < 0.2f) (p / 0.2f) else (1f - (p - 0.2f) * 0.45f)

            burst.sparks.forEach { spark ->
                val distance = spark.speed * flight * reach
                val x = launchOrigin.x + cos(spark.angleRad) * distance
                val y = launchOrigin.y + sin(spark.angleRad) * distance - (flight * reach * 0.15f) + gravity
                val sparkSize = size.height * spark.relativeSize * scaleEnvelope

                withTransform({
                    translate(x, y)
                    rotate(degrees = spark.spin * p * 280f, pivot = Offset.Zero)
                }) {
                    when (spark.shape) {
                        WaveSparkShape.MINI_HEART ->
                            withTransform({ scale(sparkSize, sparkSize, Offset.Zero) }) {
                                drawPath(miniHeartPath, color = spark.color, alpha = alpha)
                            }
                        WaveSparkShape.DIAMOND_STAR ->
                            withTransform({ scale(sparkSize, sparkSize, Offset.Zero) }) {
                                drawPath(diamondPath, color = spark.color, alpha = alpha)
                            }
                        WaveSparkShape.WAVE_SHARD ->
                            drawRoundRect(
                                color = spark.color,
                                alpha = alpha,
                                topLeft = Offset(-sparkSize * 0.22f, -sparkSize * 0.6f),
                                size = Size(sparkSize * 0.44f, sparkSize * 1.2f),
                                cornerRadius = CornerRadius(sparkSize * 0.22f, sparkSize * 0.22f),
                            )
                    }
                }
            }
        }
    }
}

/**
 * Ready-to-use Like Heart button with the custom WaveMuzix burst animation.
 * Supports both `isFavorite`/`checked` and `buttonSize`/`containerSize` parameter names.
 */
@Composable
fun WaveHeartButton(
    isFavorite: Boolean = false,
    checked: Boolean = isFavorite,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 40.dp,
    containerSize: Dp = buttonSize,
    iconSize: Dp = 24.dp,
    activeColor: Color = Color(0xFFFF2D55),
    inactiveColor: Color = Color.White,
) {
    val burstState = rememberHeartBurstState()
    val tint by animateColorAsState(
        targetValue = if (checked) activeColor else inactiveColor,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "WaveHeartTint",
    )

    Box(
        modifier = modifier
            .size(containerSize)
            .heartBurst(
                state = burstState,
                colors = listOf(
                    activeColor,
                    Color(0xFFFF8A80),
                    Color(0xFFFFD54F),
                    Color(0xFFF48FB1),
                    Color.White,
                ),
            )
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) {
                if (!checked) {
                    burstState.fire()
                }
                onToggle()
            },
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(
            targetState = checked,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = burstState.heartScale.value
                    scaleY = burstState.heartScale.value
                },
            label = "WaveHeartCrossfade",
        ) { isLiked ->
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = if (isLiked) "Liked" else "Like",
                    tint = tint,
                    modifier = Modifier.size(iconSize),
                )
            }
        }
    }
}

object WaveHeartBurstDefaults {
    val colors: List<Color> = listOf(
        Color(0xFFFF2D55),
        Color(0xFFFFD54F),
        Color(0xFFFF8A80),
        Color(0xFFF48FB1),
        Color(0xFF80D8FF),
        Color.White,
    )
}

private const val BURST_DURATION_MS = 820
private const val PARTICLES_PER_BURST = 18

internal enum class WaveSparkShape { MINI_HEART, DIAMOND_STAR, WAVE_SHARD }

internal class WaveHeartSpark(
    val angleRad: Float,
    val speed: Float,
    val relativeSize: Float,
    val spin: Float,
    val shape: WaveSparkShape,
    val color: Color,
)

internal class WaveHeartBurst(
    val sparks: List<WaveHeartSpark>,
) {
    val progress = Animatable(0f)
}

private fun randomWaveSpark(colors: List<Color>): WaveHeartSpark {
    val angle = (-PI * 0.92f + Random.nextFloat() * (PI * 0.84f)).toFloat()
    val roll = Random.nextFloat()
    val shape = when {
        roll < 0.38f -> WaveSparkShape.MINI_HEART
        roll < 0.74f -> WaveSparkShape.DIAMOND_STAR
        else -> WaveSparkShape.WAVE_SHARD
    }
    return WaveHeartSpark(
        angleRad = angle,
        speed = 0.52f + Random.nextFloat() * 0.48f,
        relativeSize = 0.13f + Random.nextFloat() * 0.11f,
        spin = -1.8f + Random.nextFloat() * 3.6f,
        shape = shape,
        color = colors[Random.nextInt(colors.size)],
    )
}

private fun buildDiamondStarPath(): Path =
    Path().apply {
        val innerRadius = 0.34f
        for (i in 0 until 8) {
            val radius = if (i % 2 == 0) 1f else innerRadius
            val angle = (-PI / 2 + i * PI / 4).toFloat()
            val x = cos(angle) * radius
            val y = sin(angle) * radius
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

private fun buildMiniHeartPath(): Path =
    Path().apply {
        moveTo(0f, 0.85f)
        cubicTo(-1.1f, 0.15f, -1.05f, -0.75f, -0.48f, -0.82f)
        cubicTo(-0.18f, -0.85f, 0f, -0.55f, 0f, -0.35f)
        cubicTo(0f, -0.55f, 0.18f, -0.85f, 0.48f, -0.82f)
        cubicTo(1.05f, -0.75f, 1.1f, 0.15f, 0f, 0.85f)
        close()
    }
