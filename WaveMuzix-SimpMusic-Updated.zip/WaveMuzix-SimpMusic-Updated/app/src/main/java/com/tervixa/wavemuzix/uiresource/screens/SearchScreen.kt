package com.tervixa.wavemuzix.uiresource.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NorthWest
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.repository.ArtistDetail
import com.tervixa.wavemuzix.repository.FavoriteRepository
import com.tervixa.wavemuzix.repository.PlaylistDetail
import com.tervixa.wavemuzix.repository.PlaylistRepository
import com.tervixa.wavemuzix.repository.SearchSuggestionItem
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import com.tervixa.wavemuzix.uiresource.components.AddToPlaylistDialog
import com.tervixa.wavemuzix.uiresource.components.AmbientThemeGlow
import com.tervixa.wavemuzix.uiresource.components.ExpressiveLoader
import com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveFilterChip
import com.tervixa.wavemuzix.uiresource.components.WaveIcons
import com.tervixa.wavemuzix.uiresource.components.WaveThumbnailPrefetcher
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.tervixa.wavemuzix.uiresource.components.isScrollingUp
import com.tervixa.wavemuzix.utils.HorizontalCarouselNestedScrollConnection
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import com.tervixa.wavemuzix.utils.rememberSnapRowFlingBehavior
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class SimpSearchScreenState {
    EMPTY_TRENDING,
    SEARCH_HISTORY,
    TYPING_SUGGESTIONS,
    LOADING_RESULTS,
    SEARCH_RESULTS,
}

/**
 * SimpMusic-Exact SearchScreen:
 * 1) When first opened (`EMPTY_TRENDING`), displays Most Searches / Trending Videos & Songs.
 * 2) When the user **taps the search box** (`SEARCH_HISTORY`), displays their persisted
 *    **Search History** (just like SimpMusic) with per-item fill/delete and `"Clear search history"`.
 * 3) While typing (`TYPING_SUGGESTIONS`), fetches live entity suggestions + autocomplete queries.
 * 4) When the user presses **Enter / Search** on the keyboard (`SEARCH_RESULTS`), displays SimpMusic's
 *    categorized full-width results layout (`All`, `Songs`, `Videos`, `Albums`, `Artists`, `Playlists`,
 *    `Featured Playlists`) with 1:1 thumbnail fill/fit rules.
 */
@Composable
fun SearchScreen(
    unifiedRepository: UnifiedMusicRepository,
    cookies: String?,
    onPlaylistClick: (String) -> Unit = {},
    onArtistClick: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager(context) }

    var searchQuery by remember { mutableStateOf("") }
    var isSearchFieldFocused by remember { mutableStateOf(false) }
    val searchHistoryList = remember { mutableStateListOf<String>().apply { addAll(settingsManager.searchHistory) } }

    val suggestQueries = remember { mutableStateListOf<String>() }
    val suggestItems = remember { mutableStateListOf<SearchSuggestionItem>() }

    val songResults = remember { mutableStateListOf<Song>() }
    val videoResults = remember { mutableStateListOf<Song>() }
    val playlistResults = remember { mutableStateListOf<PlaylistDetail>() }
    val artistResults = remember { mutableStateListOf<ArtistDetail>() }

    var isLoading by remember { mutableStateOf(false) }
    var isSuggestionLoading by remember { mutableStateOf(false) }
    var isSubmittedSearch by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("All") }

    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    val performance = LocalPerformanceConfig.current

    fun refreshHistoryFromStorage() {
        searchHistoryList.clear()
        searchHistoryList.addAll(settingsManager.searchHistory)
    }

    // High-performance in-memory instant search cache for millisecond retrieval
    val instantSearchCache = remember { java.util.concurrent.ConcurrentHashMap<String, Pair<List<SearchSuggestionItem>, List<String>>>() }
    var lastSearchLetterHash by remember { mutableStateOf("") }

    LaunchedEffect(searchQuery, isSubmittedSearch) {
        val trimmed = searchQuery.trim()
        if (trimmed.isEmpty()) {
            isSubmittedSearch = false
            isSuggestionLoading = false
            suggestQueries.clear()
            suggestItems.clear()
            lastSearchLetterHash = ""
            return@LaunchedEffect
        }
        if (isSubmittedSearch) return@LaunchedEffect

        // Check in-memory instant cache for sub-millisecond instant display
        val cached = instantSearchCache[trimmed.lowercase()]
        if (cached != null) {
            val newHash = cached.first.joinToString(",") { it.id } + cached.second.joinToString(",")
            if (newHash != lastSearchLetterHash) {
                lastSearchLetterHash = newHash
                suggestItems.clear()
                suggestItems.addAll(cached.first)
                suggestQueries.clear()
                suggestQueries.addAll(cached.second)
            }
            isSuggestionLoading = false
            return@LaunchedEffect
        }

        isSuggestionLoading = true
        delay(60) // Ultra-fast debounce: responds in milliseconds
        try {
            val response = unifiedRepository.getSearchSuggestionsWithItems(trimmed, cookies)
            instantSearchCache[trimmed.lowercase()] = Pair(response.recommendedItems, response.queries)
            val newHash = response.recommendedItems.joinToString(",") { it.id } + response.queries.joinToString(",")
            if (newHash != lastSearchLetterHash) {
                lastSearchLetterHash = newHash
                suggestItems.clear()
                suggestItems.addAll(response.recommendedItems)
                suggestQueries.clear()
                suggestQueries.addAll(response.queries)
            }
        } catch (_: Exception) {
        } finally {
            isSuggestionLoading = false
        }
    }

    val performFullSearch: (String) -> Unit = { targetQuery ->
        val q = targetQuery.trim()
        if (q.isNotEmpty()) {
            settingsManager.addSearchHistory(q)
            refreshHistoryFromStorage()
            searchQuery = q
            isSubmittedSearch = true
            isSearchFieldFocused = false
            isLoading = true
            keyboardController?.hide()
            focusManager.clearFocus()
            scope.launch {
                try {
                    val allTask = async {
                        unifiedRepository.searchAll(
                            q,
                            cookies,
                            filterVideos = false,
                            filterOnlyVideos = false,
                            filterOnlyAudio = false,
                        )
                    }
                    val videosTask = async {
                        unifiedRepository.searchSongs(
                            q,
                            cookies,
                            filterVideos = false,
                            filterOnlyVideos = true,
                            filterOnlyAudio = false,
                        )
                    }

                    val (songs, playlists, artists) = allTask.await()
                    val videos = videosTask.await().map { it.copy(isVideo = true) }

                    songResults.clear()
                    songResults.addAll(songs)

                    videoResults.clear()
                    videoResults.addAll(videos)

                    playlistResults.clear()
                    playlistResults.addAll(playlists)

                    artistResults.clear()
                    artistResults.addAll(artists)

                    WaveThumbnailPrefetcher.prefetchThumbnails(
                        context,
                        songs.take(12).map { it.thumbnailUrl } +
                            videos.take(8).map { it.thumbnailUrl } +
                            playlists.take(8).map { it.thumbnailUrl } +
                            artists.take(8).map { it.thumbnailUrl }
                    )
                } catch (_: Exception) {
                } finally {
                    isLoading = false
                }
            }
        }
    }

    val currentScreenState by remember {
        derivedStateOf {
            when {
                searchQuery.isBlank() && isSearchFieldFocused && searchHistoryList.isNotEmpty() ->
                    SimpSearchScreenState.SEARCH_HISTORY
                searchQuery.isBlank() ->
                    SimpSearchScreenState.EMPTY_TRENDING
                !isSubmittedSearch ->
                    SimpSearchScreenState.TYPING_SUGGESTIONS
                isLoading ->
                    SimpSearchScreenState.LOADING_RESULTS
                else ->
                    SimpSearchScreenState.SEARCH_RESULTS
            }
        }
    }

    val searchHazeState = remember { HazeState() }
    val density = LocalDensity.current
    val statusBarTopDp = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val listState = rememberLazyListState()
    val isScrollingUp by listState.isScrollingUp()
    val atTop by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 16
        }
    }
    var expandedTopBarHeightDp by remember(statusBarTopDp) {
        mutableStateOf(statusBarTopDp + 154.dp)
    }

    val favoriteRepository = remember {
        FavoriteRepository(AppDatabase.getDatabase(context).songDao(), context)
    }
    val playlistRepository = remember {
        PlaylistRepository(AppDatabase.getDatabase(context).playlistDao(), context)
    }

    val downloadedSongs by AppDatabase.getDatabase(context).songDao().getAllDownloads().collectAsState(initial = emptyList())
    val likedSongs by AppDatabase.getDatabase(context).songDao().getAllFavorites().collectAsState(initial = emptyList())
    val allPlaylists by playlistRepository.allPlaylists.collectAsState(initial = emptyList())

    val trendingSongs = remember { mutableStateListOf<Song>() }
    var selectedSongForOptions by remember { mutableStateOf<Song?>(null) }
    var showPlaylistDialogFor by remember { mutableStateOf<Song?>(null) }

    LaunchedEffect(Unit) {
        if (trendingSongs.isEmpty()) {
            try {
                val trending = unifiedRepository.fetchTopMusicVideos(cookies)
                trendingSongs.clear()
                trendingSongs.addAll(trending)
                WaveThumbnailPrefetcher.prefetchThumbnails(context, trending.take(15).map { it.thumbnailUrl })
            } catch (_: Exception) {
            }
        }
    }

    if (showPlaylistDialogFor != null) {
        AddToPlaylistDialog(
            song = showPlaylistDialogFor!!,
            playlists = allPlaylists,
            onDismiss = { showPlaylistDialogFor = null },
            onPlaylistSelected = { playlist ->
                scope.launch {
                    playlistRepository.addSongToPlaylist(playlist.id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
            onCreatePlaylist = { name ->
                scope.launch {
                    val id = playlistRepository.createPlaylist(name)
                    playlistRepository.addSongToPlaylist(id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Created and added to $name", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
        )
    }

    if (selectedSongForOptions != null) {
        val song = selectedSongForOptions!!
        val isDownloaded = downloadedSongs.any { it.videoId == song.videoId }
        val isFavorite = likedSongs.any { it.videoId == song.videoId }

        SongOptionsBottomSheet(
            song = song,
            isFavorite = isFavorite,
            isDownloaded = isDownloaded,
            isLiquidGlass = settingsManager.isLiquidGlass,
            onDismiss = { selectedSongForOptions = null },
            onFavoriteClick = {
                scope.launch { favoriteRepository.toggleFavorite(song) }
            },
            onDownloadClick = {
                scope.launch {
                    if (isDownloaded) {
                        AppDatabase.getDatabase(context).songDao().deleteDownload(song.videoId)
                        downloadedSongs.find { it.videoId == song.videoId }?.filePath?.let { java.io.File(it).delete() }
                        Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                    } else {
                        val result = unifiedRepository.getStreamingUrl(videoId = song.videoId, cookies = cookies)
                        if (result != null) {
                            DownloadManager.updateProgress(song.videoId, song.title, 0)
                            val request = androidx.work.OneTimeWorkRequestBuilder<com.tervixa.wavemuzix.data.DownloadWorker>()
                                .setInputData(
                                    androidx.work.workDataOf(
                                        "url" to result.url,
                                        "videoId" to song.videoId,
                                        "title" to song.title,
                                        "artist" to song.displayArtists,
                                        "thumbnailUrl" to song.thumbnailUrl,
                                        "artistId" to song.artistId,
                                        "userAgent" to result.userAgent,
                                        "cookies" to cookies,
                                    )
                                )
                                .build()
                            androidx.work.WorkManager.getInstance(context).enqueue(request)
                            Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            },
            onPlayNextClick = { MusicPlayer.playNext(song) },
            onAddToQueueClick = { MusicPlayer.addToQueue(song) },
            onArtistClick = { onArtistClick(it); selectedSongForOptions = null },
            onAddToPlaylistClick = { showPlaylistDialogFor = song; selectedSongForOptions = null },
            onShareClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "Listen to ${song.title} by ${song.displayArtists} on WaveMuzix: https://www.youtube.com/watch?v=${song.videoId}"
                    )
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, null))
            },
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = searchHazeState)
                .background(MaterialTheme.colorScheme.background),
        ) {
            AmbientThemeGlow(
                tint = MusicPlayer.accentColors.firstOrNull() ?: MaterialTheme.colorScheme.primary,
                scrollState = listState,
            )

            Crossfade(
                targetState = currentScreenState,
                animationSpec = tween(durationMillis = 220),
                label = "SimpSearchStateCrossfade",
            ) { state ->
                when (state) {
                    SimpSearchScreenState.LOADING_RESULTS -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = expandedTopBarHeightDp),
                            contentAlignment = Alignment.Center,
                        ) {
                            ExpressiveLoader(
                                size = 44.dp,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    SimpSearchScreenState.SEARCH_HISTORY -> {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            flingBehavior = rememberSmoothFlingBehavior(),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = expandedTopBarHeightDp + 6.dp,
                                bottom = 190.dp,
                            ),
                        ) {
                            item(key = "history_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.5.dp, horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "Recent Searches",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    TextButton(
                                        onClick = {
                                            settingsManager.clearSearchHistory()
                                            refreshHistoryFromStorage()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.DeleteSweep,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp),
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "Clear history",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                            }

                            itemsIndexed(
                                items = searchHistoryList,
                                key = { idx, item -> "history_${item}_$idx" },
                            ) { _, historyQuery ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { performFullSearch(historyQuery) }
                                        .padding(horizontal = 10.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp),
                                    )
                                    Spacer(Modifier.width(14.dp))
                                    Text(
                                        text = historyQuery,
                                        modifier = Modifier.weight(1f),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 14.5.sp,
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    IconButton(
                                        onClick = {
                                            searchQuery = historyQuery
                                            isSubmittedSearch = false
                                        },
                                        modifier = Modifier.size(32.dp),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.NorthWest,
                                            contentDescription = "Fill query",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            modifier = Modifier.size(18.dp),
                                        )
                                    }
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            settingsManager.removeSearchHistory(historyQuery)
                                            refreshHistoryFromStorage()
                                        },
                                        modifier = Modifier.size(32.dp),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Remove from history",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            modifier = Modifier.size(18.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }

                    SimpSearchScreenState.EMPTY_TRENDING -> {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            flingBehavior = rememberSmoothFlingBehavior(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = expandedTopBarHeightDp + 8.dp,
                                bottom = 190.dp,
                            ),
                        ) {
                            if (trendingSongs.isNotEmpty()) {
                                item(key = "trending_search_header") {
                                    Text(
                                        text = "Most Searches & Trending",
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 19.sp,
                                        ),
                                        color = MaterialTheme.colorScheme.onBackground,
                                        modifier = Modifier.padding(vertical = 4.dp),
                                    )
                                }
                                itemsIndexed(
                                    items = trendingSongs,
                                    key = { index, song -> "${song.videoId}_trending_$index" },
                                ) { _, song ->
                                    SearchSongCard(
                                        song = song,
                                        onClick = { MusicPlayer.playSong(context, song, cookies = cookies) },
                                        onMoreClick = { selectedSongForOptions = song },
                                    )
                                }
                            } else {
                                item(key = "search_empty_prompt") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 80.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = WaveIcons.Search,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                                                modifier = Modifier.size(60.dp),
                                            )
                                            Spacer(Modifier.height(14.dp))
                                            Text(
                                                text = "What do you want to listen to?",
                                                color = MaterialTheme.colorScheme.onSurface,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            )
                                            Spacer(Modifier.height(4.dp))
                                            Text(
                                                text = "Tap the search bar to see your search history or find songs, artists & albums",
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                style = MaterialTheme.typography.bodySmall,
                                                textAlign = TextAlign.Center,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    SimpSearchScreenState.TYPING_SUGGESTIONS -> {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            flingBehavior = rememberSmoothFlingBehavior(),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = expandedTopBarHeightDp + 6.dp,
                                bottom = 190.dp,
                            ),
                        ) {
                            if (isSuggestionLoading && suggestItems.isEmpty() && suggestQueries.isEmpty()) {
                                item(key = "typing_loading_indicator") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 36.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(28.dp),
                                            strokeWidth = 2.5.dp,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                            }

                            if (suggestItems.isNotEmpty()) {
                                itemsIndexed(
                                    items = suggestItems,
                                    key = { idx, item -> "sugg_item_${item.type}_${item.id}_$idx" },
                                ) { _, item ->
                                    SimpSuggestItemRow(
                                        item = item,
                                        onClick = {
                                            settingsManager.addSearchHistory(searchQuery.trim())
                                            refreshHistoryFromStorage()
                                            keyboardController?.hide()
                                            focusManager.clearFocus()
                                            when (item.type) {
                                                "artist" -> item.artist?.let { onArtistClick(it.browseId) } ?: onArtistClick(item.id)
                                                "album", "playlist" -> item.playlist?.let { onPlaylistClick(it.browseId) } ?: onPlaylistClick(item.id)
                                                else -> item.song?.let { song ->
                                                    MusicPlayer.playSong(context, song, cookies = cookies)
                                                }
                                            }
                                        },
                                        onMoreClick = item.song?.let { s ->
                                            { selectedSongForOptions = s }
                                        },
                                    )
                                }
                            }

                            if (suggestQueries.isNotEmpty()) {
                                itemsIndexed(
                                    items = suggestQueries,
                                    key = { idx, q -> "sugg_query_${q}_$idx" },
                                ) { _, queryText ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { performFullSearch(queryText) }
                                            .padding(vertical = 8.dp, horizontal = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Icon(
                                            imageVector = WaveIcons.Search,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                            modifier = Modifier.size(19.dp),
                                        )
                                        Spacer(Modifier.width(14.dp))
                                        Text(
                                            text = queryText,
                                            modifier = Modifier.weight(1f),
                                            color = MaterialTheme.colorScheme.onSurface,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        IconButton(
                                            onClick = {
                                                searchQuery = queryText
                                                isSubmittedSearch = false
                                            },
                                            modifier = Modifier.size(32.dp),
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.NorthWest,
                                                contentDescription = "Fill query",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                modifier = Modifier.size(18.dp),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    SimpSearchScreenState.SEARCH_RESULTS -> {
                        // SimpMusic Enter-Key Submitted Search Results Layout:
                        // Filter chips (`All`, `Songs`, `Videos`, `Albums`, `Artists`, `Playlists`, `Featured Playlists`)
                        // + vertical full-width categorized sections just like SimpMusic!
                        Crossfade(
                            targetState = selectedCategory,
                            animationSpec = tween(durationMillis = 200),
                            label = "SimpSearchCategoryCrossfade",
                        ) { activeCategory ->
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                flingBehavior = rememberSmoothFlingBehavior(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = expandedTopBarHeightDp + 10.dp,
                                    bottom = 190.dp,
                                ),
                            ) {
                                when (activeCategory) {
                                    "Songs" -> {
                                        itemsIndexed(
                                            items = songResults,
                                            key = { idx, s -> "song_only_${s.videoId}_$idx" },
                                        ) { _, song ->
                                            SearchSongCard(
                                                song = song,
                                                onClick = { MusicPlayer.playSong(context, song, cookies = cookies) },
                                                onMoreClick = { selectedSongForOptions = song },
                                            )
                                        }
                                    }

                                    "Videos" -> {
                                        val videos = videoResults.ifEmpty { songResults.map { it.copy(isVideo = true) } }
                                        itemsIndexed(
                                            items = videos,
                                            key = { idx, v -> "video_only_${v.videoId}_$idx" },
                                        ) { _, video ->
                                            VideoCard(
                                                song = video.copy(isVideo = true),
                                                modifier = Modifier.fillMaxWidth(),
                                                onClick = { MusicPlayer.playSong(context, video.copy(isVideo = true), cookies = cookies) },
                                                onLongClick = { selectedSongForOptions = video },
                                            )
                                        }
                                    }

                                    "Albums" -> {
                                        val albums = playlistResults.filter { it.type == "album" }.ifEmpty { playlistResults }
                                        itemsIndexed(
                                            items = albums,
                                            key = { idx, a -> "album_only_${a.browseId}_$idx" },
                                        ) { _, album ->
                                            SearchPlaylistRowItem(
                                                playlist = album,
                                                onClick = { onPlaylistClick(album.browseId) },
                                            )
                                        }
                                    }

                                    "Playlists", "Featured Playlists" -> {
                                        val playlists = playlistResults.filter { it.type != "album" }.ifEmpty { playlistResults }
                                        itemsIndexed(
                                            items = playlists,
                                            key = { idx, p -> "playlist_only_${p.browseId}_$idx" },
                                        ) { _, pl ->
                                            SearchPlaylistRowItem(
                                                playlist = pl,
                                                onClick = { onPlaylistClick(pl.browseId) },
                                            )
                                        }
                                    }

                                    "Artists" -> {
                                        itemsIndexed(
                                            items = artistResults,
                                            key = { idx, a -> "artist_only_${a.browseId}_$idx" },
                                        ) { _, artist ->
                                            SearchArtistRowItem(
                                                artist = artist,
                                                onClick = { onArtistClick(artist.browseId) },
                                            )
                                        }
                                    }

                                    else -> {
                                        // SimpMusic "All" Tab after pressing Enter:
                                        // 1. Top Result (Prominent Artist or Top Song Card)
                                        val qLower = searchQuery.trim().lowercase()
                                        val matchingTopArtists = artistResults.filter {
                                            val n = it.name.lowercase()
                                            n == qLower || n.startsWith(qLower) || qLower.startsWith(n) || n.contains(qLower)
                                        }.take(2)

                                        if (matchingTopArtists.isNotEmpty()) {
                                            item(key = "all_top_result_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Top result",
                                                    onMoreClick = { selectedCategory = "Artists" },
                                                )
                                            }
                                            itemsIndexed(
                                                items = matchingTopArtists,
                                                key = { idx, a -> "top_artist_${a.browseId}_$idx" },
                                            ) { _, artist ->
                                                SearchArtistRowItem(
                                                    artist = artist,
                                                    onClick = { onArtistClick(artist.browseId) },
                                                )
                                            }
                                        }

                                        // 2. Songs Section (Full-width rows with "More" chip)
                                        if (songResults.isNotEmpty()) {
                                            item(key = "all_songs_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Songs",
                                                    onMoreClick = { selectedCategory = "Songs" },
                                                )
                                            }
                                            itemsIndexed(
                                                items = songResults.take(5),
                                                key = { idx, s -> "all_song_${s.videoId}_$idx" },
                                            ) { _, song ->
                                                SearchSongCard(
                                                    song = song,
                                                    onClick = { MusicPlayer.playSong(context, song, cookies = cookies) },
                                                    onMoreClick = { selectedSongForOptions = song },
                                                )
                                            }
                                        }

                                        // 3. Videos Section
                                        if (videoResults.isNotEmpty()) {
                                            item(key = "all_videos_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Videos",
                                                    onMoreClick = { selectedCategory = "Videos" },
                                                )
                                            }
                                            item(key = "all_videos_row") {
                                                val videoRowState = rememberLazyListState()
                                                LazyRow(
                                                    state = videoRowState,
                                                    modifier = Modifier.nestedScroll(HorizontalCarouselNestedScrollConnection),
                                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                                    flingBehavior = rememberSnapRowFlingBehavior(videoRowState),
                                                ) {
                                                    itemsIndexed(
                                                        items = videoResults.take(8),
                                                        key = { idx, v -> "all_vid_${v.videoId}_$idx" },
                                                    ) { _, video ->
                                                        VideoCard(
                                                            song = video.copy(isVideo = true),
                                                            onClick = { MusicPlayer.playSong(context, video.copy(isVideo = true), cookies = cookies) },
                                                            onLongClick = { selectedSongForOptions = video },
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // 4. Albums & Playlists (Full-width SimpMusic rows)
                                        val albumsList = playlistResults.filter { it.type == "album" }
                                        val playlistsList = playlistResults.filter { it.type != "album" }

                                        if (albumsList.isNotEmpty()) {
                                            item(key = "all_albums_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Albums",
                                                    onMoreClick = { selectedCategory = "Albums" },
                                                )
                                            }
                                            itemsIndexed(
                                                items = albumsList.take(4),
                                                key = { idx, a -> "all_album_${a.browseId}_$idx" },
                                            ) { _, album ->
                                                SearchPlaylistRowItem(
                                                    playlist = album,
                                                    onClick = { onPlaylistClick(album.browseId) },
                                                )
                                            }
                                        }

                                        if (playlistsList.isNotEmpty()) {
                                            item(key = "all_playlists_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Community Playlists",
                                                    onMoreClick = { selectedCategory = "Playlists" },
                                                )
                                            }
                                            itemsIndexed(
                                                items = playlistsList.take(4),
                                                key = { idx, p -> "all_pl_${p.browseId}_$idx" },
                                            ) { _, pl ->
                                                SearchPlaylistRowItem(
                                                    playlist = pl,
                                                    onClick = { onPlaylistClick(pl.browseId) },
                                                )
                                            }
                                        }

                                        // 5. Artists Section
                                        if (artistResults.isNotEmpty()) {
                                            item(key = "all_artists_header") {
                                                SimpSearchSectionHeader(
                                                    title = "Artists",
                                                    onMoreClick = { selectedCategory = "Artists" },
                                                )
                                            }
                                            itemsIndexed(
                                                items = artistResults.take(4),
                                                key = { idx, a -> "all_artist_row_${a.browseId}_$idx" },
                                            ) { _, artist ->
                                                SearchArtistRowItem(
                                                    artist = artist,
                                                    onClick = { onArtistClick(artist.browseId) },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Collapsing Haze TopBar for SearchScreen
        val barTint = MaterialTheme.colorScheme.background
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .onGloballyPositioned { coords ->
                    val measured = with(density) { coords.size.height.toDp() }
                    if (measured > 80.dp) {
                        expandedTopBarHeightDp = measured
                    }
                }
                .then(
                    if (atTop) {
                        Modifier.background(Color.Transparent)
                    } else {
                        Modifier.hazeBlur(
                            input = HazeInput.Sources(searchHazeState),
                            style = barBlurStyle(tint = barTint, tintAlpha = 0.60f, blurRadius = 32.dp),
                        )
                    }
                )
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            AnimatedVisibility(
                visible = atTop || isScrollingUp,
                enter = expandVertically(expandFrom = Alignment.Top, animationSpec = tween(250)) +
                    slideInVertically(initialOffsetY = { -it }, animationSpec = tween(250)) +
                    fadeIn(animationSpec = tween(220)),
                exit = shrinkVertically(shrinkTowards = Alignment.Top, animationSpec = tween(250)) +
                    slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(250)) +
                    fadeOut(animationSpec = tween(180)),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "Search",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 23.sp,
                        ),
                    )
                }
            }

            // Pinned SimpMusic Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.76f), RoundedCornerShape(14.dp))
                    .border(
                        width = 0.8.dp,
                        color = if (isSearchFieldFocused) MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(14.dp),
                    )
                    .clickable {
                        isSearchFieldFocused = true
                        refreshHistoryFromStorage()
                        focusRequester.requestFocus()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = WaveIcons.Search,
                        contentDescription = null,
                        tint = if (isSearchFieldFocused) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )

                    Box(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "What do you want to listen to?",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                isSubmittedSearch = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester)
                                .onFocusChanged { focusState ->
                                    isSearchFieldFocused = focusState.isFocused
                                    if (focusState.isFocused) {
                                        refreshHistoryFromStorage()
                                    }
                                },
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.5.sp,
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { performFullSearch(searchQuery) }),
                            singleLine = true,
                        )
                    }

                    if (searchQuery.isNotEmpty() || isSearchFieldFocused) {
                        IconButton(
                            onClick = {
                                if (searchQuery.isNotEmpty()) {
                                    searchQuery = ""
                                    isSubmittedSearch = false
                                } else {
                                    isSearchFieldFocused = false
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                }
                            },
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }

            val categories = remember { listOf("All", "Songs", "Videos", "Albums", "Artists", "Playlists", "Featured Playlists") }
            // Only show the top category filter list ("All", "Songs", etc.) when the user taps Enter to search all!
            AnimatedVisibility(
                visible = isSubmittedSearch && searchQuery.isNotBlank(),
                enter = expandVertically(expandFrom = Alignment.Top, animationSpec = tween(220)) + fadeIn(tween(180)),
                exit = shrinkVertically(shrinkTowards = Alignment.Top, animationSpec = tween(180)) + fadeOut(tween(140)),
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nestedScroll(HorizontalCarouselNestedScrollConnection)
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    flingBehavior = rememberSmoothFlingBehavior(),
                ) {
                    items(categories, key = { it }) { category ->
                        val isSelected = selectedCategory == category
                        WaveFilterChip(
                            text = category,
                            selected = isSelected,
                            onClick = {
                                selectedCategory = category
                                if (searchQuery.isNotBlank() && !isSubmittedSearch) {
                                    performFullSearch(searchQuery)
                                }
                            },
                            selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.24f),
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SimpSearchSectionHeader(
    title: String,
    onMoreClick: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
            ),
            color = MaterialTheme.colorScheme.onBackground,
        )
        if (onMoreClick != null) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f))
                    .clickable { onMoreClick() }
                    .padding(horizontal = 12.dp, vertical = 5.dp),
            ) {
                Text(
                    text = "More",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}

@Composable
private fun SimpSuggestItemRow(
    item: SearchSuggestionItem,
    onClick: () -> Unit,
    onMoreClick: (() -> Unit)? = null,
) {
    val isArtist = item.type == "artist"
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            )
            .padding(vertical = 4.5.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WaveArtworkImage(
            url = item.thumbnailUrl,
            contentDescription = item.title,
            isVideo = false,
            shape = when {
                isArtist -> CircleShape
                else -> RoundedCornerShape(8.dp)
            },
            modifier = Modifier.size(44.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                ),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = item.subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                ),
                color = Color.White.copy(alpha = 0.88f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onMoreClick != null) {
            IconButton(
                onClick = onMoreClick,
                modifier = Modifier.size(34.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    contentDescription = "Options",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(19.dp),
                )
            }
        } else {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.CallMade,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier
                    .padding(end = 6.dp)
                    .size(18.dp),
            )
        }
    }
}

@Composable
fun SearchArtistCard(
    artist: ArtistDetail,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(136.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        WaveArtworkImage(
            url = artist.thumbnailUrl,
            contentDescription = artist.name,
            isVideo = false,
            shape = CircleShape,
            modifier = Modifier.size(120.dp),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = artist.name,
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                .focusable(),
        )
        Text(
            text = "Artist",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
        )
    }
}

@Composable
fun SearchPlaylistCard(
    playlist: PlaylistDetail,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(156.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(6.dp),
    ) {
        Box {
            WaveArtworkImage(
                url = playlist.thumbnailUrl,
                contentDescription = playlist.title,
                isVideo = false,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(144.dp),
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.65f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = playlist.title,
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                .focusable(),
        )
        Text(
            text = playlist.description.ifBlank { if (playlist.type == "album") "Album" else "Playlist" },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .fillMaxWidth()
                .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                .focusable(),
        )
    }
}

@Composable
fun SearchPlaylistRowItem(
    playlist: PlaylistDetail,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.5.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WaveArtworkImage(
            url = playlist.thumbnailUrl,
            contentDescription = playlist.title,
            isVideo = false,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.size(54.dp),
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = playlist.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${if (playlist.type == "album") "Album" else "Playlist"} • ${playlist.description}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
            )
        }
    }
}

@Composable
fun SearchArtistRowItem(
    artist: ArtistDetail,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WaveArtworkImage(
            url = artist.thumbnailUrl,
            contentDescription = artist.name,
            isVideo = false,
            shape = CircleShape,
            modifier = Modifier.size(54.dp),
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (!artist.subscriberCountText.isNullOrBlank()) "Artist • ${artist.subscriberCountText}" else "Artist",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * SimpMusic `SongFullWidthItems` card for SearchScreen:
 * Uses a 52.dp 1:1 square box (`isVideo = false`) so square thumbnails fill the 1:1 box
 * and rectangular thumbnails fit cleanly inside the 1:1 box.
 */
@Composable
fun SearchSongCard(
    song: Song,
    onClick: () -> Unit,
    onMoreClick: () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val performance = LocalPerformanceConfig.current
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        animationSpec = spring(dampingRatio = performance.springDampingRatio, stiffness = performance.springStiffness),
        label = "SearchSongCardScale",
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(10.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .padding(vertical = 4.5.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WaveArtworkImage(
            url = song.thumbnailUrl,
            contentDescription = song.title,
            isVideo = false,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.size(44.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (!song.durationText.isNullOrBlank()) {
                    "${song.displayArtists} • ${song.durationText}"
                } else {
                    song.displayArtists
                },
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(iterations = Int.MAX_VALUE, animationMode = MarqueeAnimationMode.Immediately, initialDelayMillis = 1200)
                    .focusable(),
            )
        }
        IconButton(
            onClick = onMoreClick,
            modifier = Modifier.size(36.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "More options",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}
