package com.tervixa.wavemuzix.model

import java.util.Objects

data class SongArtist(
    val name: String,
    val id: String? = null,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SongArtist) return false
        return Objects.equals(name as Any?, other.name as Any?) &&
            Objects.equals(id as Any?, other.id as Any?)
    }

    override fun hashCode(): Int {
        return Objects.hash(name as Any?, id as Any?)
    }
}

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val videoId: String = "",
    val artistId: String? = null,
    val thumbnailPath: String? = null,
    val lyrics: String? = null,
    val durationText: String? = null,
    val streamUrl: String? = null,
    val artists: List<SongArtist> = emptyList(),
    val isVideo: Boolean = false,
) {
    /**
     * Formatted string of all singer/artist names (e.g. "Arijit Singh, Shilpa Rao, Pritam")
     * for display below the song title across Player, Home, Search, Playlist, Artist, and Library screens.
     */
    val displayArtists: String
        get() {
            val safeList = (artists as List<SongArtist?>?)?.mapNotNull { it?.name?.trim()?.takeIf { n -> n.isNotEmpty() } }.orEmpty()
            if (safeList.isNotEmpty()) {
                return safeList.distinctBy { it.lowercase() }.joinToString(", ")
            }
            val parsed = parseArtists()
            if (parsed.isNotEmpty()) {
                return parsed.joinToString(", ") { it.name }
            }
            val fallback = (artist as String?)?.replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")?.trim().orEmpty()
            return fallback.ifEmpty { "Unknown Artist" }
        }

    /**
     * Null-safe equals & hashCode to prevent NullPointerException when Gson deserializes
     * cached Song objects via Unsafe.allocateInstance() from older schema JSON where
     * newly added or optional fields (such as [artists] or [videoId]) may be null in memory.
     */
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Song) return false
        return Objects.equals(id as Any?, other.id as Any?) &&
            Objects.equals(title as Any?, other.title as Any?) &&
            Objects.equals(artist as Any?, other.artist as Any?) &&
            Objects.equals(thumbnailUrl as Any?, other.thumbnailUrl as Any?) &&
            Objects.equals(videoId as Any?, other.videoId as Any?) &&
            Objects.equals(artistId as Any?, other.artistId as Any?) &&
            Objects.equals(thumbnailPath as Any?, other.thumbnailPath as Any?) &&
            Objects.equals(lyrics as Any?, other.lyrics as Any?) &&
            Objects.equals(durationText as Any?, other.durationText as Any?) &&
            Objects.equals(streamUrl as Any?, other.streamUrl as Any?) &&
            Objects.equals((artists as List<SongArtist>?) ?: emptyList<SongArtist>(), (other.artists as List<SongArtist>?) ?: emptyList<SongArtist>()) &&
            isVideo == other.isVideo
    }

    override fun hashCode(): Int {
        return Objects.hash(
            id as Any?,
            title as Any?,
            artist as Any?,
            thumbnailUrl as Any?,
            videoId as Any?,
            artistId as Any?,
            thumbnailPath as Any?,
            lyrics as Any?,
            durationText as Any?,
            streamUrl as Any?,
            (artists as List<SongArtist>?) ?: emptyList<SongArtist>(),
            isVideo,
        )
    }
}

private val RECORD_LABEL_CHANNELS = setOf(
    "t-series", "t-series tamil", "t-series telugu", "t-series malayalam", "t-series kannada",
    "t-series bhakti sagar", "t-series apna punjab", "t-series regional",
    "sony music india", "sony music south", "sonymusicindiavevo", "sonymusicsouthvevo",
    "zee music company", "zee music south", "zee music classic",
    "saregama music", "saregama tamil", "saregama malayalam", "saregama telugu", "saregama karvaan",
    "yrf", "yash raj films", "tips official", "tips tamil", "tips Industries",
    "think music india", "aditya music", "lahari music", "junglee music",
    "speed records", "white hill music", "desi melodies", "hombale films",
    "muzik247", "muzik 247", "satyam audios", "millennium audios", "manorama music",
    "goodwill entertainments", "bhavatharini music", "eros now music", "venus", "ishtar music",
    "shemaroo filmi gaane", "ultra bollywood", "panorama music", "svf music", "hitz music",
    "universal music india", "warner music india", "atlantic records", "republic records",
    "interscope records", "columbia records", "vevo", "youtube music", "various artists"
)

fun isRecordLabelOrChannelName(name: String?): Boolean {
    if (name.isNullOrBlank()) return true
    val lower = name.trim()
        .replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")
        .trim()
        .lowercase()
    if (lower in RECORD_LABEL_CHANNELS) return true
    if (lower.endsWith("vevo") && lower.contains("music")) return true
    if (lower.contains("t-series") || lower.contains("zee music") || lower.contains("sony music") ||
        lower.contains("saregama") || lower.contains("think music") || lower.contains("aditya music") ||
        lower.contains("tips official") || lower.contains("muzik247") || lower.contains("muzik 247") ||
        lower.contains("manorama music") || lower.contains("satyam audios") || lower.contains("millennium audios") ||
        lower.contains("lahari music") || lower.contains("speed records") || lower.contains("ishtar music") ||
        lower.contains("yash raj") || lower == "yrf"
    ) {
        return true
    }
    return false
}

/**
 * Normalizes a [Song] instance deserialized by Gson so that any field left null by
 * `Unsafe.allocateInstance()` is replaced with a valid non-null value.
 */
@Suppress("USELESS_ELVIS", "UNCHECKED_CAST")
fun Song.sanitized(): Song {
    val safeVideoId = (videoId as String?) ?: (id as String?) ?: ""
    val safeId = (id as String?) ?: safeVideoId
    val safeTitle = (title as String?) ?: ""
    val safeArtist = (artist as String?) ?: ""
    val safeThumbnailUrl = (thumbnailUrl as String?) ?: ""
    val rawArtists = (artists as List<SongArtist?>?)
    val safeArtists = rawArtists?.mapNotNull { item ->
        val artistName = (item?.name as String?)?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
        SongArtist(name = artistName, id = item.id)
    } ?: emptyList()

    val base = Song(
        id = safeId,
        title = safeTitle,
        artist = safeArtist,
        thumbnailUrl = safeThumbnailUrl,
        videoId = safeVideoId,
        artistId = artistId,
        thumbnailPath = thumbnailPath,
        lyrics = lyrics,
        durationText = durationText,
        streamUrl = streamUrl,
        artists = safeArtists,
        isVideo = isVideo,
    )
    val resolvedArtists = if (safeArtists.isNotEmpty() && safeArtists.none { isRecordLabelOrChannelName(it.name) }) {
        safeArtists
    } else {
        base.parseArtists()
    }
    val formattedArtistString = if (resolvedArtists.isNotEmpty()) {
        resolvedArtists.joinToString(", ") { it.name }
    } else {
        safeArtist
    }
    return base.copy(artist = formattedArtistString, artists = resolvedArtists)
}

/**
 * SimpMusic-style multi-singer/artist extractor:
 * Splits a song's artist field and featured-artist / pipe-separated credits into individual
 * selectable [SongArtist] entries (e.g., "Arijit Singh, Shilpa Rao, Anirudh Ravichander"),
 * automatically filtering out YouTube record-label uploader names like "T-Series" or "Sony Music".
 */
@Suppress("USELESS_ELVIS", "UNCHECKED_CAST")
fun Song.parseArtists(
    fallbackChannelName: String? = null,
    fallbackChannelId: String? = null,
): List<SongArtist> {
    val existingArtists = (artists as List<SongArtist?>?)
        ?.filterNotNull()
        ?.filter { !isRecordLabelOrChannelName(it.name) }
        .orEmpty()
    if (existingArtists.size > 1) return existingArtists

    val safeArtist = (artist as String?) ?: ""
    val safeTitle = (title as String?) ?: ""

    val result = mutableListOf<SongArtist>()
    val seenNames = mutableSetOf<String>()

    val nonArtistNoise = setOf(
        "unknown", "unknown artist", "various artists", "official", "music", "video", "lyrics",
        "full video", "full song", "audio", "lyrical", "lyric video", "hd", "4k", "8k", "mv",
        "new song", "latest song", "video song", "audio song", "ost", "original motion picture soundtrack"
    )

    fun addCandidate(rawName: String, id: String? = null, allowLabelFallback: Boolean = false) {
        val cleaned = rawName
            .replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("VEVO$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^(?:singer|singers|vocals|music|composed by|artist|artists|feat\\.?|ft\\.?)\\s*[:\\-]\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
            .trim(',', '&', '-', '•', '|', '/', '(', ')', '[', ']', ':')
            .trim()
        if (cleaned.length < 2 || cleaned.length > 48) return
        val key = cleaned.lowercase()
        if (key in nonArtistNoise) return
        if (!allowLabelFallback && isRecordLabelOrChannelName(cleaned)) return
        if (cleaned.any { it in listOf('"', '“', '”', '!', '?') }) return
        if (Regex("\\b(full video|video song|lyrical|official|trailer|teaser|jukebox|episode|chapter)\\b", RegexOption.IGNORE_CASE).containsMatchIn(cleaned)) return
        if (seenNames.add(key)) {
            result.add(SongArtist(name = cleaned, id = id))
        }
    }

    val splitRegex = Regex(
        pattern = "\\s*(?:,|&|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bwith\\b|\\bx\\b|\\bX\\b|•|/)\\s*",
        option = RegexOption.IGNORE_CASE
    )

    // 1. Add existing non-label artists first
    existingArtists.forEach { art ->
        art.name.split(splitRegex).forEachIndexed { idx, part ->
            addCandidate(part, if (idx == 0) art.id else null)
        }
    }

    // 2. Parse safeArtist if it's not a pure record-label channel name
    if (!isRecordLabelOrChannelName(safeArtist)) {
        val rawArtistParts = safeArtist
            .replace(Regex(" - Topic$", RegexOption.IGNORE_CASE), "")
            .split(splitRegex)
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        rawArtistParts.forEachIndexed { idx, part ->
            val assignedId = if (idx == 0) (artistId ?: fallbackChannelId) else null
            addCandidate(part, assignedId)
        }
    }

    // 3. Inspect title for (feat. X) / [ft. Y] credits
    val featRegex = Regex(
        pattern = "[\\(\\[](?:feat\\.?|ft\\.?|with|prod\\.?\\s*by)\\s+([^\\)\\]]+)[\\)\\]]",
        option = RegexOption.IGNORE_CASE
    )
    featRegex.findAll(safeTitle).forEach { match ->
        val featBlock = match.groupValues.getOrNull(1).orEmpty()
        featBlock.split(splitRegex).forEach { featArtist ->
            addCandidate(featArtist, null)
        }
    }

    // 4. Also check inline "feat. X" or "ft. X" outside parentheses
    val inlineFeatRegex = Regex(
        pattern = "\\b(?:feat\\.?|ft\\.?)\\s+([^|\\-\\(\\[]+)",
        option = RegexOption.IGNORE_CASE
    )
    inlineFeatRegex.findAll(safeTitle).forEach { match ->
        val featBlock = match.groupValues.getOrNull(1).orEmpty()
        featBlock.split(splitRegex).forEach { featArtist ->
            addCandidate(featArtist, null)
        }
    }

    // 5. If artist was a record label (e.g. T-Series, Sony Music) or title has pipe/hyphen segments,
    // extract singer credits from "Song | Movie | Singer 1, Singer 2 | Composer"
    if (result.isEmpty() || isRecordLabelOrChannelName(safeArtist)) {
        if (safeTitle.contains("|")) {
            val pipeParts = safeTitle.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            // Skip index 0 (which is the song title) and inspect subsequent segments for singers
            pipeParts.drop(1).forEach { segment ->
                segment.split(splitRegex).forEach { candidate ->
                    addCandidate(candidate, null)
                }
            }
        } else if (safeTitle.contains(" - ")) {
            val dashParts = safeTitle.split(" - ").map { it.trim() }.filter { it.isNotEmpty() }
            if (dashParts.size >= 2) {
                dashParts.drop(1).forEach { segment ->
                    segment.split(splitRegex).forEach { candidate ->
                        addCandidate(candidate, null)
                    }
                }
            }
        }
    }

    // 6. Fallback to channel name only if no singer could be extracted
    if (result.isEmpty()) {
        if (fallbackChannelName != null && !isRecordLabelOrChannelName(fallbackChannelName)) {
            addCandidate(fallbackChannelName, fallbackChannelId ?: artistId, allowLabelFallback = true)
        }
        if (result.isEmpty() && safeArtist.isNotBlank()) {
            addCandidate(safeArtist, artistId ?: fallbackChannelId, allowLabelFallback = true)
        }
    }

    return result
}
