package com.tervixa.wavemuzix.uiresource.components

import androidx.compose.animation.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Downloading
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tervixa.wavemuzix.data.DownloadManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Apple iOS-style Center-Opening Liquid Glass Notification Banner:
 * - Fluid capsule container with 3D specular rim and frosted liquid glass surface.
 * - Center-origin smooth spring scaleIn / scaleOut animation matching iOS Dynamic Island.
 * - Sleek circular glyph indicator, crisp title and progress bar, and swipe-to-dismiss gesture.
 */
@Composable
fun DownloadNotificationOverlay(onClick: () -> Unit) {
    val latestNotification by DownloadManager.latestNotification
    val offsetX = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    AnimatedVisibility(
        visible = latestNotification != null,
        enter = scaleIn(
            initialScale = 0.55f,
            transformOrigin = TransformOrigin(0.5f, 0.5f),
            animationSpec = spring(dampingRatio = 0.68f, stiffness = 380f),
        ) + fadeIn(tween(180)) + slideInVertically(
            initialOffsetY = { -it / 2 },
            animationSpec = spring(dampingRatio = 0.68f, stiffness = 380f),
        ),
        exit = scaleOut(
            targetScale = 0.65f,
            transformOrigin = TransformOrigin(0.5f, 0.5f),
            animationSpec = tween(200, easing = FastOutSlowInEasing),
        ) + fadeOut(tween(160)) + slideOutVertically(
            targetOffsetY = { -it / 2 },
            animationSpec = tween(200),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .offset { IntOffset(offsetX.value.roundToInt(), 0) },
    ) {
        latestNotification?.let { notification ->
            LaunchedEffect(notification) {
                offsetX.snapTo(0f)
            }

            LaunchedEffect(notification.isFinished) {
                if (notification.isFinished) {
                    delay(3800)
                    DownloadManager.clearLatestNotification()
                }
            }

            val pillShape = RoundedCornerShape(26.dp)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 16.dp, shape = pillShape, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(pillShape)
                    .background(Color(0xFF14141B).copy(alpha = 0.92f))
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.08f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.20f),
                            ),
                        ),
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.28f),
                                Color.White.copy(alpha = 0.06f),
                                Color.White.copy(alpha = 0.16f),
                            ),
                            start = Offset.Zero,
                            end = Offset(600f, 200f),
                        ),
                        shape = pillShape,
                    )
                    .pointerInput(notification.videoId) {
                        detectDragGestures(
                            onDragEnd = {
                                scope.launch {
                                    if (abs(offsetX.value) > size.width / 3.5f) {
                                        offsetX.animateTo(
                                            targetValue = if (offsetX.value > 0) size.width.toFloat() else -size.width.toFloat(),
                                            animationSpec = tween(220),
                                        )
                                        DownloadManager.ignoreNotification(notification.videoId)
                                    } else {
                                        offsetX.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 400f))
                                    }
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                scope.launch {
                                    offsetX.snapTo(offsetX.value + dragAmount.x)
                                }
                            },
                        )
                    }
                    .clickable {
                        onClick()
                        DownloadManager.clearLatestNotification()
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Left circular icon
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (notification.isFinished) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.20f)
                                } else {
                                    Color.White.copy(alpha = 0.10f)
                                }
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (notification.isFinished) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Finished",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Downloading,
                                contentDescription = "Downloading",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = notification.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.5.sp,
                            ),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = if (notification.isFinished) "Download Complete" else "Downloading: ${notification.progress}%",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                            color = if (notification.isFinished) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.70f),
                        )

                        if (!notification.isFinished) {
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (notification.progress.coerceIn(0, 100) / 100f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.5.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = Color.White.copy(alpha = 0.12f),
                            )
                        }
                    }
                }
            }
        }
    }
}
