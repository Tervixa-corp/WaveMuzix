package com.tervixa.wavemuzix.uiresource.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kashif_e.backdrop.backdrops.LayerBackdrop
import com.kashif_e.backdrop.backdrops.layerBackdrop
import com.kashif_e.backdrop.backdrops.rememberLayerBackdrop
import com.tervixa.wavemuzix.data.CookieManager
import com.tervixa.wavemuzix.data.DownloadManager
import com.tervixa.wavemuzix.data.LocalPerformanceConfig
import com.tervixa.wavemuzix.data.MusicPlayer
import com.tervixa.wavemuzix.data.SettingsManager
import com.tervixa.wavemuzix.data.database.AppDatabase
import com.tervixa.wavemuzix.model.Song
import com.tervixa.wavemuzix.repository.FavoriteRepository
import com.tervixa.wavemuzix.repository.PlaylistDetail
import com.tervixa.wavemuzix.repository.PlaylistRepository
import com.tervixa.wavemuzix.repository.UnifiedMusicRepository
import com.tervixa.wavemuzix.uiresource.components.AddToPlaylistDialog
import com.tervixa.wavemuzix.uiresource.components.GlassIconButton
import com.tervixa.wavemuzix.uiresource.components.LiquidGlassContainer
import com.tervixa.wavemuzix.uiresource.components.LocalBackdrop
import com.tervixa.wavemuzix.uiresource.components.SongOptionsBottomSheet
import com.tervixa.wavemuzix.uiresource.components.StandardLoader
import com.tervixa.wavemuzix.uiresource.components.WaveArtworkImage
import com.tervixa.wavemuzix.uiresource.components.WaveHazeHeader
import com.tervixa.wavemuzix.uiresource.components.WaveHeartButton
import com.tervixa.wavemuzix.uiresource.components.WaveIcons
import com.tervixa.wavemuzix.uiresource.components.WaveStateContainer
import com.tervixa.wavemuzix.uiresource.components.WaveThumbnailPrefetcher
import com.tervixa.wavemuzix.uiresource.components.barBlurStyle
import com.tervixa.wavemuzix.uiresource.components.rememberImmersivePaletteColors
import com.tervixa.wavemuzix.utils.rememberSmoothFlingBehavior
import dev.chrisbanes.haze.HazeInput
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.blur.hazeBlur
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun PlaylistScreen(
    browseId: String,
    isLocal: Boolean = false,
    repository: UnifiedMusicRepository,
    onBack: () -> Unit,
    onArtistClick: (String) -> Unit,
    isLiquidGlass: Boolean,
) {
    val context = LocalContext.current
    val cookieManager = remember { CookieManager(context) }
    val scope = rememberCoroutineScope()

    var playlistDetail by remember { mutableStateOf<PlaylistDetail?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isError by remember { mutableStateOf(false) }
    var isMoreLoading by remember { mutableStateOf(false) }
    var continuationToken by remember { mutableStateOf<String?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    var showPlaylistDialogFor by remember { mutableStateOf<Song?>(null) }
    val db = remember { AppDatabase.getDatabase(context) }
    val playlistRepository = remember { PlaylistRepository(db.playlistDao(), context) }
    val favoriteRepository = remember { FavoriteRepository(db.songDao(), context) }
    val allPlaylists by playlistRepository.allPlaylists.collectAsState(initial = emptyList())

    // Hoisted Room flows: collected ONCE at screen level instead of inside every song row item!
    val downloadedSongs by db.songDao().getAllDownloads().collectAsState(initial = emptyList())
    val likedSongs by db.songDao().getAllFavorites().collectAsState(initial = emptyList())
    val downloadedIds = remember(downloadedSongs) { downloadedSongs.map { it.videoId }.toHashSet() }
    val likedIds = remember(likedSongs) { likedSongs.map { it.videoId }.toHashSet() }

    val fetchData = {
        scope.launch {
            isLoading = true
            isError = false
            val startTime = System.currentTimeMillis()

            try {
                if (isLocal) {
                    val playlistId = browseId.toLongOrNull()
                    if (playlistId != null) {
                        val playlist = db.playlistDao().getPlaylistById(playlistId)
                        if (playlist != null) {
                            val songs = db.playlistDao().getSongsInPlaylist(playlistId).first().map { songEntry ->
                                Song(
                                    id = songEntry.videoId,
                                    title = songEntry.title,
                                    artist = songEntry.artist,
                                    thumbnailUrl = songEntry.thumbnailUrl,
                                    videoId = songEntry.videoId,
                                    artistId = songEntry.artistId,
                                )
                            }
                            playlistDetail = PlaylistDetail(playlist.name, "Custom Playlist", songs.firstOrNull()?.thumbnailUrl ?: "", songs, browseId, "playlist")
                        }
                    }
                } else {
                    val settingsManager = SettingsManager(context)
                    val detail = repository.fetchPlaylist(browseId, cookieManager.getCookies(), settingsManager.selectedLanguages)
                    playlistDetail = detail
                    continuationToken = detail?.continuation
                }

                if (playlistDetail == null) isError = true
                else {
                    WaveThumbnailPrefetcher.prefetchThumbnails(
                        context,
                        playlistDetail!!.songs.take(24).map { it.thumbnailUrl }
                    )
                }
            } catch (e: Exception) {
                isError = true
            } finally {
                val remainingTime = 350 - (System.currentTimeMillis() - startTime)
                if (remainingTime > 0) delay(remainingTime)
                isLoading = false
            }
        }
    }

    LaunchedEffect(browseId, isLocal) {
        fetchData()
    }

    if (showPlaylistDialogFor != null) {
        AddToPlaylistDialog(
            song = showPlaylistDialogFor!!,
            playlists = allPlaylists,
            onDismiss = { showPlaylistDialogFor = null },
            onPlaylistSelected = { playlist ->
                scope.launch {
                    playlistRepository.addSongToPlaylist(playlist.id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            },
            onCreatePlaylist = { name ->
                scope.launch {
                    val id = playlistRepository.createPlaylist(name)
                    playlistRepository.addSongToPlaylist(id, showPlaylistDialogFor!!)
                    Toast.makeText(context, "Created and added to $name", Toast.LENGTH_SHORT).show()
                    showPlaylistDialogFor = null
                }
            }
        )
    }

    val filteredSongs = remember(playlistDetail, searchQuery) {
        if (searchQuery.isEmpty()) {
            playlistDetail?.songs ?: emptyList()
        } else {
            playlistDetail?.songs?.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                    it.artist.contains(searchQuery, ignoreCase = true)
            } ?: emptyList()
        }
    }

    val paletteColors = rememberImmersivePaletteColors(playlistDetail?.thumbnailUrl)
    val dynamicBgColor by animateColorAsState(
        targetValue = paletteColors.backgroundColor,
        animationSpec = tween(500),
        label = "playlistBgColor"
    )
    SideEffect {
        MusicPlayer.activeScreenAccentTint = dynamicBgColor
    }
    val dynamicTintColor by animateColorAsState(
        targetValue = paletteColors.topBarTintColor,
        animationSpec = tween(500),
        label = "playlistTintColor"
    )

    val lazyListState = rememberLazyListState()
    val playlistHazeState = remember { HazeState() }
    val pageBackdrop: LayerBackdrop = rememberLayerBackdrop {
        drawRect(dynamicBgColor)
        drawContent()
    }

    val isScrolledPastHeader by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex > 0 || lazyListState.firstVisibleItemScrollOffset > 260
        }
    }

    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
            .collect { lastIndex ->
                if (lastIndex != null && lastIndex >= (playlistDetail?.songs?.size ?: 0) - 5 && continuationToken != null && !isMoreLoading) {
                    isMoreLoading = true
                    val (nextSongs, nextContinuation) = repository.fetchNextSongs("", browseId, cookieManager.getCookies(), continuationToken)
                    if (nextSongs.isNotEmpty()) {
                        playlistDetail = playlistDetail?.copy(songs = playlistDetail!!.songs + nextSongs)
                        continuationToken = nextContinuation
                    } else {
                        continuationToken = null
                    }
                    isMoreLoading = false
                }
            }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(dynamicBgColor),
    ) {
        WaveStateContainer(
            isLoading = isLoading,
            isError = isError && playlistDetail == null,
            errorMessage = "Check Your Internet Connection",
            onRetry = {
                if (MusicPlayer.isPlaybackError) {
                    MusicPlayer.currentSong?.let { MusicPlayer.playSong(context, it) }
                } else {
                    fetchData()
                }
            },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .hazeSource(state = playlistHazeState)
                    .background(dynamicBgColor)
                    .layerBackdrop(pageBackdrop),
            ) {
                CompositionLocalProvider(LocalBackdrop provides null) {
                    LazyColumn(
                        state = lazyListState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 190.dp),
                        flingBehavior = rememberSmoothFlingBehavior(),
                    ) {
                        item(key = "playlist_header") {
                            PlaylistHeader(
                                playlist = playlistDetail!!,
                                backgroundColor = dynamicBgColor,
                                repository = repository,
                                scope = scope,
                                cookieManager = cookieManager,
                                isLiquidGlass = isLiquidGlass,
                                onBack = onBack,
                                onSearchClick = { isSearchActive = true },
                                onPlayAll = {
                                    if (playlistDetail!!.songs.isNotEmpty()) {
                                        val firstSong = playlistDetail!!.songs.first()
                                        MusicPlayer.playSong(context, firstSong, playlistDetail!!.songs, cookieManager.getCookies(), isFromFixedList = true)
                                    }
                                },
                                onShuffle = {
                                    if (playlistDetail!!.songs.isNotEmpty()) {
                                        val shuffled = playlistDetail!!.songs.shuffled()
                                        MusicPlayer.playSong(context, shuffled.first(), shuffled, cookieManager.getCookies(), isFromFixedList = true)
                                    }
                                },
                            )
                        }

                        val isAlbumOrSoundtrack = playlistDetail?.type == "album" || playlistDetail?.type == "soundtrack"

                        itemsIndexed(
                            items = filteredSongs,
                            key = { index, song: Song -> "${song.videoId}_$index" },
                            contentType = { _, _ -> "playlist_song_item" },
                        ) { index, song ->
                            PlaylistSongItem(
                                song = song,
                                modifier = Modifier,
                                index = index + 1,
                                showNumber = isAlbumOrSoundtrack,
                                repository = repository,
                                scope = scope,
                                isDownloadedOverride = song.videoId in downloadedIds,
                                isFavoriteOverride = song.videoId in likedIds,
                                favoriteRepositoryOverride = favoriteRepository,
                                onClick = {
                                    MusicPlayer.playSong(context, song, playlistDetail!!.songs, cookieManager.getCookies(), isFromFixedList = true)
                                },
                                onArtistClick = onArtistClick,
                                onAddToPlaylist = { showPlaylistDialogFor = song },
                                isLiquidGlass = isLiquidGlass,
                            )
                        }

                        if (filteredSongs.isEmpty() && searchQuery.isNotEmpty()) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("No songs found matching \"$searchQuery\"", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        if (isMoreLoading) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                    StandardLoader(size = 32.dp)
                                }
                            }
                        }
                    }
                }
            }
        }

                AnimatedVisibility(
            visible = isScrolledPastHeader || isSearchActive,
            enter = fadeIn(tween(220)) + slideInVertically(initialOffsetY = { -it }, animationSpec = tween(250)),
            exit = fadeOut(tween(180)) + slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(220)),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .hazeBlur(
                        input = HazeInput.Sources(playlistHazeState),
                        style = barBlurStyle(
                            tint = dynamicTintColor,
                            tintAlpha = 0.64f,
                            blurRadius = 32.dp
                        ),
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (isSearchActive) {
                    IconButton(
                        onClick = {
                            isSearchActive = false
                            searchQuery = ""
                        },
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
                    }

                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                            .focusRequester(focusRequester),
                        textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text("Search in playlist...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
                            }
                            innerTextField()
                        },
                    )

                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                    }
                } else {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp),
                        )
                    }

                    Text(
                        text = playlistDetail?.title ?: "",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Clip,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 12.dp)
                            .basicMarquee(
                                iterations = Int.MAX_VALUE,
                                animationMode = MarqueeAnimationMode.Immediately,
                                initialDelayMillis = 1200,
                            )
                            .focusable()
                    )

                    IconButton(
                        onClick = { isSearchActive = true },
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(
                            imageVector = WaveIcons.Search,
                            contentDescription = "Search in playlist",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }
            }
        }    }
}

@Composable
fun PlaylistHeader(
    playlist: PlaylistDetail,
    backgroundColor: Color,
    repository: UnifiedMusicRepository,
    scope: kotlinx.coroutines.CoroutineScope,
    cookieManager: CookieManager,
    isLiquidGlass: Boolean = true,
    onBack: () -> Unit = {},
    onSearchClick: () -> Unit = {},
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
) {
    val context = LocalContext.current
    var isLiked by remember { mutableStateOf(false) }
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val scrimHeight = screenWidth * 0.78f
    val headerBackdrop: LayerBackdrop = rememberLayerBackdrop {
        drawRect(backgroundColor)
        drawContent()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
        ) {
            WaveHazeHeader.VerticalGradient(
                modifier = Modifier
                    .fillMaxSize()
                    .layerBackdrop(headerBackdrop),
                backgroundColor = backgroundColor,
                blurRadius = 32.dp,
                blurHeight = 200.dp,
                gradientHeight = scrimHeight,
                headerImage = {
                    WaveArtworkImage(
                        url = playlist.thumbnailUrl,
                        contentDescription = playlist.title,
                        isVideo = false,
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxSize(),
                    )
                },
            )

            CompositionLocalProvider(LocalBackdrop provides headerBackdrop) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GlassIconButton(
                        icon = Icons.AutoMirrored.Rounded.ArrowBack,
                        onClick = onBack,
                        isLiquidGlass = isLiquidGlass,
                        contentDescription = "Back",
                        containerSize = 48.dp,
                        iconSize = 24.dp,
                    )
                    GlassIconButton(
                        icon = WaveIcons.Search,
                        onClick = onSearchClick,
                        isLiquidGlass = isLiquidGlass,
                        contentDescription = "Search in playlist",
                        containerSize = 48.dp,
                        iconSize = 24.dp,
                    )
                }
            }

            CompositionLocalProvider(LocalBackdrop provides headerBackdrop) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = playlist.title,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 26.sp,
                        ),
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )

                    val metaSubtitle = remember(playlist) {
                        val countStr = "${playlist.songs.size} tracks"
                        if (playlist.description.isNotBlank()) {
                            "${playlist.description.lines().firstOrNull()?.take(48) ?: ""} • $countStr"
                        } else {
                            countStr
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = metaSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.78f),
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        LiquidGlassContainer(
                            backdrop = headerBackdrop,
                            isLiquidGlass = isLiquidGlass,
                            shape = CircleShape,
                            modifier = Modifier.size(48.dp),
                        ) {
                            WaveHeartButton(
                                isFavorite = isLiked,
                                onToggle = {
                                    isLiked = !isLiked
                                    Toast.makeText(
                                        context,
                                        if (isLiked) "Saved to Library" else "Removed from Library",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                iconSize = 22.dp,
                                buttonSize = 48.dp,
                                activeColor = Color(0xFFFF2D55),
                                inactiveColor = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        LiquidGlassContainer(
                            backdrop = headerBackdrop,
                            isLiquidGlass = isLiquidGlass,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(52.dp)
                                .clickable(onClick = onShuffle),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shuffle,
                                contentDescription = "Shuffle",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp),
                            )
                        }

                        Button(
                            onClick = onPlayAll,
                            modifier = Modifier.height(54.dp),
                            contentPadding = PaddingValues(horizontal = 24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = CircleShape,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Play All",
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "Play",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        LiquidGlassContainer(
                            backdrop = headerBackdrop,
                            isLiquidGlass = isLiquidGlass,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(52.dp)
                                .clickable {
                                    scope.launch {
                                        val cookies = cookieManager.getCookies()
                                        Toast.makeText(context, "Downloading playlist...", Toast.LENGTH_SHORT).show()
                                        playlist.songs.forEach { song ->
                                            val result = repository.getStreamingUrl(
                                                videoId = song.videoId,
                                                cookies = cookies,
                                                targetBitrate = null,
                                            )
                                            if (result != null) {
                                                DownloadManager.updateProgress(song.videoId, song.title, 0)
                                                val workRequest = androidx.work.OneTimeWorkRequestBuilder<com.tervixa.wavemuzix.data.DownloadWorker>()
                                                    .setInputData(
                                                        androidx.work.workDataOf(
                                                            "url" to result.url,
                                                            "videoId" to song.videoId,
                                                            "title" to song.title,
                                                            "artist" to song.artist,
                                                            "thumbnailUrl" to song.thumbnailUrl,
                                                            "artistId" to song.artistId,
                                                            "userAgent" to result.userAgent,
                                                            "cookies" to cookies,
                                                        ),
                                                    )
                                                    .build()
                                                androidx.work.WorkManager.getInstance(context).enqueue(workRequest)
                                            }
                                        }
                                    }
                                },
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DownloadForOffline,
                                contentDescription = "Download",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp),
                            )
                        }

                        LiquidGlassContainer(
                            backdrop = headerBackdrop,
                            isLiquidGlass = isLiquidGlass,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(48.dp)
                                .clickable {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "Check out this playlist: ${playlist.title}\nhttps://music.youtube.com/playlist?list=${playlist.browseId.removePrefix("VL")}",
                                        )
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, null))
                                },
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = "Share",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistSongItem(
    song: Song,
    modifier: Modifier = Modifier,
    index: Int? = null,
    showNumber: Boolean = false,
    repository: UnifiedMusicRepository,
    scope: kotlinx.coroutines.CoroutineScope,
    onClick: () -> Unit,
    onArtistClick: (String) -> Unit = {},
    onAddToPlaylist: () -> Unit = {},
    isLiquidGlass: Boolean = false,
    isDownloadedOverride: Boolean? = null,
    isFavoriteOverride: Boolean? = null,
    favoriteRepositoryOverride: FavoriteRepository? = null,
) {
    var showOptions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val favoriteRepository = favoriteRepositoryOverride ?: remember { FavoriteRepository(AppDatabase.getDatabase(context).songDao(), context) }

    val isDownloaded = isDownloadedOverride ?: false
    val isFavorite = isFavoriteOverride ?: false

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val performance = LocalPerformanceConfig.current

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = spring(
            dampingRatio = performance.springDampingRatio,
            stiffness = performance.springStiffness,
        ),
        label = "PlaylistSongItemScale",
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 16.dp, vertical = 4.5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showNumber && index != null) {
            Box(
                modifier = Modifier.size(40.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = index.toString(),
                    color = Color.White.copy(alpha = 0.88f),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                )
            }
        } else {
            WaveArtworkImage(
                url = song.thumbnailUrl,
                contentDescription = song.title,
                isVideo = false,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(44.dp),
            )
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = Color.White,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                ),
                maxLines = 1,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth()
                    .basicMarquee(
                        iterations = Int.MAX_VALUE,
                        animationMode = MarqueeAnimationMode.Immediately,
                        initialDelayMillis = 1200,
                    )
                    .focusable()
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isDownloaded) {
                    Icon(
                        imageVector = Icons.Rounded.DownloadDone,
                        contentDescription = "Downloaded",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(14.dp)
                            .padding(end = 4.dp),
                    )
                }
                Text(
                    text = song.displayArtists,
                    color = Color.White.copy(alpha = 0.88f),
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    modifier = Modifier
                        .weight(1f)
                        .basicMarquee(
                            iterations = Int.MAX_VALUE,
                            animationMode = MarqueeAnimationMode.Immediately,
                            initialDelayMillis = 1200,
                        )
                        .focusable()
                )
            }
        }

        IconButton(onClick = { showOptions = true }) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "More Options",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (showOptions) {
        val cookies = CookieManager(context).getCookies()
        SongOptionsBottomSheet(
            song = song,
            isFavorite = isFavorite,
            isDownloaded = isDownloaded,
            isLiquidGlass = isLiquidGlass,
            onDismiss = { showOptions = false },
            onFavoriteClick = {
                scope.launch { favoriteRepository.toggleFavorite(song) }
            },
            onDownloadClick = {
                scope.launch {
                    val dao = AppDatabase.getDatabase(context).songDao()
                    if (isDownloaded) {
                        val existing = dao.getDownloadByVideoId(song.videoId)
                        dao.deleteDownload(song.videoId)
                        existing?.filePath?.let { java.io.File(it).delete() }
                        Toast.makeText(context, "Removed download", Toast.LENGTH_SHORT).show()
                    } else {
                        val result = repository.getStreamingUrl(
                            videoId = song.videoId,
                            cookies = cookies,
                        )
                        if (result != null) {
                            DownloadManager.updateProgress(song.videoId, song.title, 0)
                            val request = androidx.work.OneTimeWorkRequestBuilder<com.tervixa.wavemuzix.data.DownloadWorker>()
                                .setInputData(
                                    androidx.work.workDataOf(
                                        "url" to result.url,
                                        "videoId" to song.videoId,
                                        "title" to song.title,
                                        "artist" to song.artist,
                                        "thumbnailUrl" to song.thumbnailUrl,
                                        "artistId" to song.artistId,
                                        "userAgent" to result.userAgent,
                                        "cookies" to cookies,
                                    ),
                                )
                                .build()
                            androidx.work.WorkManager.getInstance(context).enqueue(request)
                            Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            },
            onPlayNextClick = { MusicPlayer.playNext(song) },
            onAddToQueueClick = { MusicPlayer.addToQueue(song) },
            onArtistClick = { id ->
                showOptions = false
                if (id.isNotEmpty()) onArtistClick(id)
            },
            onAddToPlaylistClick = {
                showOptions = false
                onAddToPlaylist()
            },
            onShareClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "Listen to ${song.title} by ${song.artist} on WaveMuzix: https://www.youtube.com/watch?v=${song.videoId}",
                    )
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, null))
            },
        )
    }
}
