# Privacy Policy

**Last Updated:** October 2026

**WaveMuzix** is designed with user control and transparency at its core.

## 1. Local Data & Storage
- By default, your listening history, analytics, liked songs, custom playlists, and cached audio streams are stored locally on your device inside an encrypted/sandboxed Android Room SQLite database and app-private storage.

## 2. Optional "Connect To Wave" Integrations
- **YouTube Music, Spotify, Last.fm, and Discord**: When you sign in through **Settings → Connect To Wave**, authentication cookies or session tokens (`SAPISID`, `sp_dc`, Last.fm session key, or Discord token) are stored locally on your device in `SharedPreferences` and are used solely to communicate directly between your device and the respective service APIs.

## 3. Optional Firebase Cloud Backup
- If you sign in to a **WaveMuzix Account** (via Google Sign-In or Email/Password inside the app), WaveMuzix syncs your settings, playlists, liked songs, followed artists, and listening analytics to **Google Cloud Firestore** under your authenticated `users/{uid}` document so you can restore your library across devices.
- WaveMuzix **never** accesses any external account outside the credentials you explicitly sign in with inside the app.
