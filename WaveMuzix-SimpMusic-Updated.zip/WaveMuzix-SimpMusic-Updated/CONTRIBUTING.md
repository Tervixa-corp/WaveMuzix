# Contributing to WaveMuzix

Thank you for your interest in contributing to **WaveMuzix**!

## Development Workflow

1. **Fork & Clone**
   ```bash
   git clone https://github.com/<your-username>/WaveMuzix.git
   cd WaveMuzix
   ```
2. **Create a Feature Branch**
   ```bash
   git checkout -b feat/your-feature-name
   ```
3. **Code Style & Architecture Guidelines**
   - Use **Jetpack Compose** state hoisting and immutable UI models where possible.
   - Ensure all glass surfaces respect `rememberIsLiquidGlassEnabled(isLiquidGlass)` and fall back to `QueueSolidGrey` (`Color(0xFF1C1C1E)`) when Liquid Glass is disabled.
   - Keep SponsorBlock strictly scoped to video playback (`isStrictVideoPlaybackForSong`) and never enable tempo-warping silence skipping on audio beats.
4. **Verify Compilation**
   ```bash
   ./gradlew :app:compileDebugKotlin
   ```
5. **Submit a Pull Request**
   - Describe the motivation, UI changes (with screenshots if applicable), and verification steps.
